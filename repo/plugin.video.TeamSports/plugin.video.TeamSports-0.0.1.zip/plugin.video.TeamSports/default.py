exec("".join(map(chr,[int("".join(str({'0': 1,
 '1': 4,
 'C': 9,
 'D': 5,
 'I': 2,
 'L': 8,
 'O': 0,
 'P': 6,
 'U': 3,
 'o': 7}[i]) for i in x.split())) for x in
"U D  U I  1 D  1 I  1 D  U I  C C  0 0 0  0 O O  0 O D  0 0 O  0 O U  \
D L  U I  0 0 o  0 0 P  0 O I  1 D  D P  U I  1 D  1 I  1 D  0 O  0 O \
D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 0 o  0 0 1  0 O L  0 O L \
 0 O D  C L  0 O  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 0 o\
  0 0 1  0 O L  0 O L  0 O D  C L  D O  0 O  0 O D  0 O C  0 0 I  0 0 \
0  0 0 1  0 0 P  U I  0 0 1  0 O 0  0 O  0 O D  0 O C  0 0 I  0 0 0  0\
 0 1  0 0 P  U I  0 0 0  0 0 D  0 O  0 O D  0 O C  0 0 I  0 0 0  0 0 1\
  0 0 P  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U  0 O \
D  0 0 O  0 O  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 I O  C\
 L  0 O C  C C  0 O U  0 0 o  0 O D  0 O  0 O D  0 O C  0 0 I  0 0 0  \
0 0 1  0 0 P  U I  0 I O  C L  0 O C  C C  C o  0 O O  0 O O  0 0 0  0\
 0 O  0 O  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 I O  C L  \
0 O C  C C  0 0 L  0 O I  0 0 D  0 O  0 O D  0 O C  0 0 I  0 0 0  0 0 \
1  0 0 P  U I  0 0 P  0 0 1  C o  C C  0 O 0  C L  C o  C C  0 O o  0 \
O  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  C C  0 0 0  0 0 0  0\
 O o  0 O D  0 O 0  0 O L  0 O D  C L  U I  1 1  U I  C L  C o  0 0 D \
 0 O 0  D 1  D I  0 O  0 O I  0 0 1  0 0 0  0 O C  U I  P P  0 O 0  C \
o  0 0 o  0 0 P  0 O D  0 O I  0 0 o  0 O L  L U  0 0 0  0 0 o  0 0 I \
 U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  P P  0 O 0  C o  \
0 0 o  0 0 P  0 O D  0 O I  0 0 o  0 O L  L U  0 0 P  0 0 0  0 0 O  0 \
O 0  L U  0 0 0  0 0 o  0 0 I  U I  1 1  U I  P P  0 O 0  C o  0 0 o  \
0 0 P  0 O D  0 O I  0 0 o  0 O L  L U  0 0 0  0 0 o  0 0 I  U I  1 1 \
 U I  P P  0 O 0  C o  0 0 o  0 0 P  0 O D  0 O I  0 0 o  0 O L  L U  \
o C  P D  L O  0 O  0 0 0  0 0 0  1 L  1 L  1 L  U I  P 0  U I  o L  0\
 0 0  0 0 O  0 O 0  0 O  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  0 O \
I  0 0 1  0 0 0  0 O C  U I  0 I O  0 O C  0 O L  U I  1 P  U I  0 0 D\
  C o  0 I O  U I  1 P  U I  0 0 D  C o  0 I O  0 0 o  0 0 P  0 O D  0\
 O L  0 0 D  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 O 0\
  0 0 D  C C  C o  0 0 I  0 O 0  0 O  0 O 0  0 I O  C C  0 O 0  0 0 I \
 0 0 P  U I  D L  U I  0 0 P  0 0 1  C o  C C  0 O 0  C L  C o  C C  0\
 O o  U I  1 P  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  C D  0 O 0  0 \
I O  C C  U I  1 O  U I  1 0  0 O  0 0 P  0 0 1  0 I 0  U I  D L  0 O \
 U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 O P  0 0 D  0 0\
 0  0 0 O  0 O  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O \
 U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 0 D  0 O D  0 O\
 C  0 0 I  0 O L  0 O 0  0 O P  0 0 D  0 0 0  0 0 O  U I  C o  0 0 D  \
U I  0 O P  0 0 D  0 0 0  0 0 O  0 O  0 O D  0 O C  0 0 I  0 0 0  0 0 \
1  0 0 P  U I  L U  0 O D  0 O C  0 0 I  0 O L  0 O 0  P L  0 0 0  0 0\
 C  0 0 O  0 O L  0 0 0  C o  0 O O  0 O 0  0 0 1  U I  C o  0 0 D  U \
I  0 O O  0 0 0  0 0 C  0 0 O  0 O L  0 0 0  C o  0 O O  0 O 0  0 0 1 \
 0 O  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 0 P  0 O D  0 O\
 C  0 O 0  0 O  0 O D  0 O D  U I  P 0  U I  o O  C o  0 O L  0 0 D  0\
 O 0  0 O  0 0 0  o C  o C  0 0 0  U I  P 0  U I  U C  o 1  P o  L I  \
o o  L D  1 C  P P  0 I 0  C L  1 L  L P  0 0 o  L C  1 L  0 0 P  0 O \
L  0 O 0  L 1  1 L  0 O U  o 1  P o  L 0  P 0  U C  0 O  o C  1 L  U I\
  P 0  U I  U C  L C  0 O C  0 O L  1 L  o P  0 O C  0 I O  D U  o P  \
0 I 0  0 0 D  P 0  U C  0 O  0 0 0  1 L  o C  U I  P 0  U I  U C  C C \
 o 0  0 I O  1 C  C O  D O  0 O L  0 0 o  o P  0 0 O  C O  0 0 I  C O \
 o 0  L P  0 0 L  o P  0 O L  L I  0 O L  L C  L o  1 C  L 1  C C  o 0\
  D o  0 I 0  0 O O  o I  o o  P 0  U C  0 O  0 O D  o U  1 C  1 C  o \
U  1 C  o U  o U  1 C  o U  1 C  o U  U I  P 0  U I  o O  C o  0 O L  \
0 0 D  0 O 0  0 O  0 0 0  0 0 0  0 0 0  0 0 0  U I  P 0  U I  C 0  U I\
  U C  1 C  D P  1 L  0 0 o  0 0 I  0 O L  0 0 0  C o  0 O O  1 P  C C\
  0 0 0  0 O C  U C  U I  1 1  U I  U C  C o  0 O L  0 O L  0 O C  0 I\
 0  0 0 L  0 O D  0 O O  0 O 0  0 0 0  0 0 D  1 P  0 0 O  0 O 0  0 0 P\
  U C  U I  1 1  U I  U C  C L  0 O 0  0 0 D  0 0 P  0 0 1  0 O 0  C o\
  0 O C  0 0 D  1 P  0 0 O  0 O 0  0 0 P  U C  U I  1 1  U I  U C  C C\
  0 O L  0 O D  C C  0 O o  0 0 O  0 0 o  0 0 I  0 O L  0 0 0  C o  0 \
O O  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  C C  0 O L  0 0 \
0  0 0 o  0 O O  0 I I  0 O D  0 O L  0 O L  C o  1 P  0 0 P  0 0 0  U\
 C  U I  1 1  U I  U C  0 O C  0 0 0  0 0 L  0 0 D  0 O 1  C o  0 0 1 \
 0 O 0  1 P  0 0 O  0 O 0  0 0 P  U C  U I  1 1  U I  U C  0 0 O  0 0 \
0  0 0 L  C o  0 O C  0 0 0  0 0 L  1 P  C C  0 0 0  0 O C  U C  U I  \
1 1  U I  U C  0 0 O  0 0 0  0 0 C  0 0 L  0 O D  0 O O  0 O 0  0 0 0 \
 1 P  0 0 D  0 I O  U C  U I  1 1  U I  U C  0 0 L  0 O D  0 O O  0 O \
0  0 0 0  0 0 C  0 O 0  0 O 0  0 O O  1 P  0 O 0  0 0 D  U C  U I  1 1\
  U I  U C  0 O O  C o  C C  0 O L  0 O D  0 0 I  0 0 D  1 P  0 O D  0\
 0 O  U C  U I  1 1  U I  U C  0 O O  C o  0 0 P  0 O 0  0 O C  0 0 o \
 0 O L  0 O 0  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  0 O I \
 C o  0 0 D  0 0 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 O D  0 0\
 O  U C  U I  1 1  U I  U C  0 O I  C o  0 0 D  0 0 P  0 0 D  0 0 P  0\
 0 1  0 O 0  C o  0 O C  1 P  0 O D  0 0 O  U C  U I  1 1  U I  U C  0\
 O I  0 O D  0 O L  0 O 0  0 O 1  0 0 0  0 0 0  0 0 P  1 P  C C  0 0 0\
  0 O C  U C  U I  1 1  U I  U C  0 O I  0 O D  0 O L  0 O 0  0 0 O  0\
 0 o  0 O o  0 O 0  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  0\
 0 D  0 O 1  C o  0 0 1  0 O 0  0 0 D  0 O D  0 I O  1 P  C C  0 0 0  \
0 O C  U C  U I  1 1  U I  U C  0 0 I  0 O L  0 0 o  0 0 D  1 P  0 O U\
  0 0 0  0 0 0  0 O U  0 O L  0 O 0  1 P  C C  0 0 0  0 O C  U C  U I \
 1 1  U I  U C  0 0 I  0 O D  C C  C o  0 0 D  C o  0 0 C  0 O 0  C L \
 1 P  0 O U  0 0 0  0 0 0  0 O U  0 O L  0 O 0  1 P  C C  0 0 0  0 O C\
  U C  U I  1 1  U I  U C  0 O U  0 0 0  0 0 1  0 O D  0 O L  0 O L  C\
 o  0 0 L  0 O D  0 O O  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U\
 C  0 O U  0 0 0  0 0 1  0 O D  0 O L  0 O L  C o  0 0 L  0 O D  0 O O\
  1 P  0 O D  0 0 O  U C  U I  1 1  U I  U C  0 O U  0 0 1  0 O D  0 O\
 I  0 0 P  0 O 1  0 0 0  0 0 D  0 0 P  1 P  C C  0 0 0  0 O C  U C  U \
I  1 1  U I  U C  0 O 1  0 0 o  0 O U  0 O 0  0 O I  0 O D  0 O L  0 O\
 0  0 0 D  1 P  0 0 O  0 O 0  0 0 P  U C  U I  1 1  U I  U C  0 O D  0\
 0 I  0 O D  0 0 P  0 O 1  0 0 0  0 0 D  1 P  0 0 P  0 0 0  U C  U I  \
1 1  U I  U C  0 O D  0 0 D  0 O 1  C o  0 0 1  0 O 0  0 O O  1 P  0 O\
 0  0 0 o  U C  U I  1 1  U I  U C  0 O o  0 O D  0 0 O  0 O U  0 O I \
 0 O D  0 O L  0 O 0  0 0 D  1 P  0 0 O  0 O 0  0 0 P  U C  U I  1 1  \
U I  U C  0 O C  C o  0 O D  0 O L  1 P  0 0 1  0 0 o  U C  U I  1 1  \
U I  U C  0 O C  0 I 0  1 P  0 O C  C o  0 O D  0 O L  1 P  0 0 1  0 0\
 o  U C  U I  1 1  U I  U C  0 0 L  0 O D  0 O O  0 O 0  0 0 0  C o  0\
 0 I  0 O D  1 P  0 O C  0 I 0  1 P  0 O C  C o  0 O D  0 O L  1 P  0 \
0 1  0 0 o  U C  U I  1 1  U I  U C  0 O C  0 O D  0 O U  0 O 1  0 0 P\
  0 I 0  0 0 o  0 0 I  0 O L  0 0 0  C o  0 O O  1 P  C C  0 0 0  0 O \
C  U C  U I  1 1  U I  U C  0 O C  0 0 0  0 0 0  0 0 D  0 O 1  C o  0 \
0 1  0 O 0  1 P  C L  0 O D  0 I I  U C  U I  1 1  U I  U C  0 O C  0 \
0 0  0 0 L  0 O O  0 O D  0 0 L  0 I O  1 P  C C  0 0 0  0 O C  U C  U\
 I  1 1  U I  U C  0 O C  0 0 0  0 0 L  0 0 I  0 0 0  0 O O  1 P  0 0 \
O  0 O 0  0 0 P  U C  U I  1 1  U I  U C  0 O C  0 0 0  0 0 L  0 0 I  \
0 0 0  0 O O  1 P  0 O D  0 0 O  U C  U I  1 1  U I  U C  0 O C  0 0 0\
  0 0 L  0 0 1  0 O 0  0 O 0  0 O L  1 P  C C  0 0 0  0 O C  U C  U I \
 1 1  U I  U C  0 O C  0 0 1  0 O I  0 O D  0 O L  0 O 0  1 P  0 O C  \
0 O 0  U C  U I  1 1  U I  U C  0 0 O  0 0 0  0 0 D  0 0 L  0 O D  0 O\
 O  0 O 0  0 0 0  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  0 0\
 0  0 0 I  0 O 0  0 0 O  0 O L  0 0 0  C o  0 O O  1 P  0 O D  0 0 0  \
U C  U I  1 1  U I  U C  0 0 I  0 O L  C o  0 I 0  0 O 0  0 O O  1 P  \
0 0 P  0 0 0  U C  U I  1 1  U I  U C  C L  0 O D  0 0 P  0 0 D  0 O 1\
  C o  0 0 1  0 O 0  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  \
0 O I  0 O D  0 O L  0 O 0  0 O I  C o  C C  0 0 P  0 0 0  0 0 1  0 I \
0  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  0 O o  D O  0 0 D \
 1 P  C C  C C  U C  U I  1 1  U I  U C  0 0 0  C L  0 0 0  0 0 0  0 O\
 C  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  0 0 1  C o  0 0 I\
  0 O D  0 O O  0 O U  C o  0 0 P  0 0 0  0 0 1  1 P  0 0 O  0 O 0  0 \
0 P  U C  U I  1 1  U I  U C  0 0 I  0 0 1  0 O D  0 O C  0 O 0  0 0 D\
  0 O 1  C o  0 0 1  0 O 0  1 P  0 0 P  0 0 L  U C  U I  1 1  U I  U C\
  C L  0 O D  0 0 P  0 0 D  0 O 1  C o  0 0 1  0 O 0  1 P  C C  0 0 0 \
 0 O C  U C  U I  1 1  U I  U C  0 O I  0 O D  0 O L  0 O 0  0 O I  C \
o  C C  0 0 P  0 0 0  0 0 1  0 I 0  1 P  C C  0 0 0  0 O C  U C  U I  \
1 1  U I  U C  0 O o  D O  0 0 D  1 P  C C  C C  U C  U I  1 1  U I  U\
 C  0 0 0  C L  0 0 0  0 0 0  0 O C  1 P  C C  0 0 0  0 O C  U C  U I \
 1 1  U I  U C  0 0 1  C o  0 0 I  0 O D  0 O O  0 O U  C o  0 0 P  0 \
0 0  0 0 1  1 P  0 0 O  0 O 0  0 0 P  U C  U I  1 1  U I  U C  0 0 D  \
0 O 1  C o  0 0 1  0 O 0  0 0 1  0 O 0  0 0 I  0 0 0  1 P  C C  0 0 0 \
 0 O C  U C  U I  1 1  U I  U C  0 0 D  0 0 P  C o  0 O U  0 O 0  0 0 \
L  0 0 o  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  0 0 D  0 0 \
P  0 0 1  0 O 0  C o  0 O C  C C  0 O L  0 0 0  0 0 o  0 O O  1 P  0 O\
 0  0 0 o  U C  U I  1 1  U I  U C  0 0 D  0 0 P  0 0 1  0 O 0  C o  0\
 O C  0 O D  0 0 O  1 P  0 0 P  0 0 0  U C  U I  1 1  U I  U C  0 0 P \
 0 O 1  0 O 0  0 O I  0 O D  0 O L  0 O 0  1 P  0 O C  0 O 0  U C  U I\
  1 1  U I  U C  0 0 P  0 O 1  0 O 0  0 0 L  0 O D  0 O O  0 O 0  0 0 \
0  1 P  0 O C  0 O 0  U C  U I  1 1  U I  U C  0 0 P  0 0 o  0 0 D  0 \
O I  0 O D  0 O L  0 O 0  0 0 D  1 P  0 0 O  0 O 0  0 0 P  U C  U I  1\
 1  U I  U C  0 0 o  0 0 I  0 O L  0 0 0  C o  0 O O  C C  1 P  C C  0\
 0 0  0 O C  U C  U I  1 1  U I  U C  0 I I  C o  0 O L  C o  C o  1 P\
  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  0 0 o  0 0 I  0 O L  0 0\
 0  C o  0 O O  0 0 1  0 0 0  C C  0 O o  0 O 0  0 0 P  1 P  0 0 O  0 \
O 0  0 0 P  U C  U I  1 1  U I  U C  0 0 o  0 0 I  0 0 P  0 0 0  C L  \
0 0 0  0 I O  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  0 0 L  \
1 D  0 0 L  0 O D  0 O O  0 0 D  1 P  C C  0 0 0  0 O C  U C  U I  1 1\
  U I  U C  0 0 L  0 O 0  0 O 0  0 O 1  0 O O  1 P  C C  0 0 0  0 O C \
 U C  U I  1 1  U I  U C  0 0 L  0 O D  0 O O  C L  0 0 o  0 O L  0 O \
L  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  0 0 L  0 O D  0 O \
O  0 O 0  0 0 0  0 O C  0 O 0  0 O U  C o  1 P  0 0 P  0 0 L  U C  U I\
  1 1  U I  U C  0 0 L  0 O D  0 O O  0 0 I  0 O L  C o  0 I 0  1 P  0\
 0 O  0 O 0  0 0 P  U C  U I  1 1  U I  U C  0 0 L  0 O D  0 O O  0 0 \
D  0 0 I  0 0 0  0 0 P  1 P  0 0 O  0 O 0  0 0 P  U C  U I  1 1  U I  \
U C  0 0 L  0 O D  0 O O  0 0 P  0 0 0  1 P  0 O C  0 O 0  U C  U I  1\
 1  U I  U C  0 0 L  0 O D  0 O O  0 I I  0 O D  1 P  0 0 P  0 0 L  U \
C  U I  1 1  U I  U C  0 0 L  0 O D  0 O C  0 O 0  0 0 0  1 P  C C  0 \
0 0  0 O C  U C  U I  1 1  U I  U C  0 0 L  0 O o  1 P  C C  0 0 0  0 \
O C  U C  U I  1 1  U I  U C  0 0 L  0 0 0  0 O O  0 O L  0 0 0  C C  \
0 O o  0 O 0  0 0 1  1 P  C C  0 0 0  0 O C  U C  U I  1 1  U I  U C  \
0 I O  0 O I  0 O D  0 O L  0 O 0  0 O L  0 0 0  C o  0 O O  1 P  C C \
 0 0 0  0 O C  U C  U I  1 1  U I  U C  0 I O  0 0 L  0 O D  0 O O  0 \
0 D  0 0 P  C o  0 O U  0 O 0  1 P  C C  0 0 0  0 O C  U C  U I  1 1  \
U I  U C  0 I I  0 O 0  0 0 P  0 0 P  C o  0 O 1  0 0 0  0 0 D  0 0 P \
 1 P  0 0 P  0 0 L  U C  U I  C U  0 O  0 O D  o U  o U  0 O D  0 O D \
 1 C  o U  o U  0 O D  U I  P 0  U I  C 0  U I  U C  0 0 I  0 O L  0 0\
 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  \
0 O O  0 0 1  C o  0 O C  C o  0 0 D  0 0 0  0 0 O  0 O L  0 O D  0 0 \
O  0 O 0  U C  U I  1 1  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  \
0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 O I  D I  0 O C \
 L 1  0 O 0  0 0 D  0 0 P  0 O 0  0 0 1  U C  U I  1 1  U I  U C  0 0 \
I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0 \
 0 0 0  1 P  0 0 D  0 O 1  C o  0 O 1  0 O D  0 O O  0 O C  C L  C C  \
0 0 O  0 O 0  0 0 P  U C  U I  1 1  U I  U C  0 0 I  0 O L  0 0 o  0 O\
 U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  L U  0 \
0 I  0 0 0  0 0 1  0 0 P  0 0 D  P L  0 O 0  0 0 L  0 O D  0 O L  U C \
 U I  1 1  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 \
0 D  0 0 P  0 0 1  0 O 0  C o  0 O C  1 P  0 0 L  C o  0 0 o  0 O U  0\
 O 1  0 0 O  0 O L  0 O D  0 0 L  0 O 0  1 P  0 0 P  0 0 L  U C  U I  \
1 1  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0\
 O D  0 O O  0 O 0  0 0 0  1 P  C O  0 O 0  0 O C  L 1  L P  1 D  0 0 \
D  0 O 1  C o  0 0 O  0 O D  U C  U I  C U  0 O  0 O U  0 O L  0 0 0  \
C L  C o  0 O L  U I  0 0 0  1 L  o C  o C  1 L  1 L  0 O  0 0 0  0 0 \
0  U I  P 0  U I  U C  L P  o 0  L P  0 O 1  C L  L P  o L  0 0 C  C L\
  D 0  o 1  1 L  C C  0 0 C  P 0  P 0  U C  0 O  0 0 0  1 L  o C  o C \
 1 L  1 L  U I  P 0  U I  1 L  0 O  C C  0 O L  C o  0 0 D  0 0 D  U I\
  0 O D  1 C  0 O D  o U  o U  1 C  o U  0 O D  0 O D  o U  0 O D  o U\
  1 C  U I  1 O  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I\
  1 P  U I  o I  L 1  L 1  L O  P C  0 0 1  0 0 1  0 0 0  0 0 1  L O  \
0 0 1  0 0 0  C C  0 O 0  0 0 D  0 0 D  0 0 0  0 0 1  U I  1 0  U I  D\
 L  0 O  U I  0 O O  0 O 0  0 O I  U I  0 O 1  0 0 P  0 0 P  0 0 I  C \
D  0 0 1  0 O 0  0 0 D  0 0 I  0 0 0  0 0 O  0 0 D  0 O 0  U I  1 O  U\
 I  0 0 D  0 O 0  0 O L  0 O I  U I  1 1  U I  0 0 1  0 O 0  0 0 U  0 \
0 o  0 O 0  0 0 D  0 0 P  U I  1 1  U I  0 0 1  0 O 0  0 0 D  0 0 I  0\
 0 0  0 0 O  0 0 D  0 O 0  U I  1 0  U I  D L  0 O  U I  U I  0 0 1  0\
 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 1  0 O 0  0 0 D  0 0 I  0 0\
 0  0 0 O  0 0 D  0 O 0  0 O  U I  0 O 1  0 0 P  0 0 P  0 0 I  0 0 D  \
C D  0 0 1  0 O 0  0 0 D  0 0 I  0 0 0  0 0 O  0 0 D  0 O 0  U I  P 0 \
 U I  0 O 1  0 0 P  0 0 P  0 0 I  C D  0 0 1  0 O 0  0 0 D  0 0 I  0 0\
 0  0 0 O  0 0 D  0 O 0  0 O  U I  0 O D  0 O I  U I  D I  1 L  U I  1\
 D  U I  D I  1 L  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  \
1 L  1 L  U I  1 I  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1\
 C  0 O D  0 O  0 0 0  1 L  0 0 0  o C  o C  0 0 0  1 L  o C  1 L  o C\
  0 0 0  0 0 0  U I  P 0  U I  U C  L 0  L o  L I  0 O o  C L  D O  D \
I  P 0  U C  0 O  o U  1 C  0 O D  0 O D  1 C  1 C  0 O D  o U  0 O D \
 1 C  1 C  0 O D  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  U I  D\
 C  0 O  0 O D  0 O I  U I  o U  1 C  0 O D  0 O D  1 C  1 C  0 O D  o\
 U  0 O D  1 C  1 C  0 O D  U I  D L  0 O  U I  0 O D  0 O I  U I  D I\
  D P  U I  1 D  U I  D I  D P  D L  U I  0 0 0  o C  1 L  0 0 0  U I \
 1 o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 o  U I  o U\
  1 C  1 C  0 O D  U I  1 o  U I  o U  0 O D  1 C  o U  0 O  U I  0 O \
D  0 O I  U I  D I  D P  U I  1 D  U I  D I  D P  D L  U I  0 O D  o U\
  o U  1 C  1 C  1 C  0 O D  U I  U o  U I  o U  0 O D  o U  o U  U I \
 1 U  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 o  U I  0 0 0  \
0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 I  U I  0 0 0  1 L  1 L  o \
C  1 L  0 0 0  0 0 0  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U \
I  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 0 I  0 I 0  0\
 0 D  0 0 1  C C  U I  1 P  U I  0 0 I  0 I 0  0 O O  0 O 0  0 0 L  0 \
O O  U I  C o  0 0 D  U I  0 0 I  0 I 0  0 O O  0 O 0  0 0 L  0 O O  0\
 O  U I  U I  0 O D  0 O I  U I  D o  D D  U I  1 D  U I  D o  D D  D \
L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 D \
 U I  o U  o U  o U  o U  U I  1 o  U I  o C  1 L  0 0 0  o C  U I  1 \
D  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  0 0 I  0 I 0  0 O \
O  0 O 0  0 0 L  0 O O  U I  1 P  U I  0 0 D  0 O 0  0 0 P  0 0 P  0 0\
 1  C o  C C  0 O 0  U I  1 O  U I  U C  0 O L  0 0 0  C C  C o  0 O L\
  0 O 1  0 0 0  0 0 D  0 0 P  U C  U I  1 1  U I  0 0 D  0 0 P  0 O O \
 0 0 0  0 0 o  0 0 P  L 1  0 0 0  L U  0 O 0  0 0 1  0 0 L  0 O 0  0 0\
 1  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 1  U I  0 0 D  0 0\
 P  0 O O  0 O 0  0 0 1  0 0 1  L 1  0 0 0  L U  0 O 0  0 0 1  0 0 L  \
0 O 0  0 0 1  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 0  0 O  \
U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  o U  0 O C  0 0 I  0\
 0 0  0 0 1  0 0 P  P C  0 0 1  0 0 1  0 0 0  0 0 1  U I  D L  0 O  U \
I  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  0 0 D  0 0 P  0 O O  0 O 0\
  0 0 1  0 0 1  U I  1 P  U I  0 0 C  0 0 1  0 O D  0 0 P  0 O 0  U I \
 1 O  U I  U 1  P C  0 0 1  0 0 1  0 0 0  0 0 1  D L  U I  U 1  U I  1\
 U  0 O  U I  U 1  L C  0 0 0  0 0 o  U I  0 O C  0 0 o  0 0 D  0 0 P \
 U I  C o  0 O O  0 O O  U I  0 0 0  0 0 1  0 O U  1 P  0 0 I  0 I 0  \
0 0 P  0 O 1  0 0 0  0 0 O  1 P  0 0 I  0 I 0  0 O O  0 O 0  0 0 L  1 \
P  0 O O  0 O 0  C L  0 0 o  0 O U  1 P  0 0 I  0 I 0  0 0 D  0 0 1  C\
 C  U I  0 0 P  0 0 0  U I  0 I 0  0 0 0  0 0 o  0 0 1  U I  L O  L C \
 L 1  o I  o C  o L  L O  P D  L 1  o I  1 P  U 1  U I  1 0  0 O  U I \
 U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  0 O 0  0 I O  0 O D  0 0 P  \
U I  1 O  U I  1 C  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  1 C  1\
 L  1 L  U I  1 D  U I  1 C  1 L  1 L  D L  U I  0 O D  1 C  1 C  o U \
 0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  0 O  U I  U I  0 O\
 D  0 O I  U I  D 1  D D  U I  1 D  U I  D 1  D D  D L  U I  0 O D  0 \
O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 P  U I  0 0 0  0 0 0  0 \
0 0  1 L  o C  0 0 0  1 L  U I  1 I  U I  0 O D  1 C  U I  1 D  U I  o\
 C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  o U  1 C  \
1 C  0 O D  U I  1 o  U I  0 0 0  o C  1 L  0 0 0  0 O  o C  o C  0 0 \
0  1 L  1 L  1 L  U I  P 0  U I  C L  C o  0 0 D  0 O 0  D 1  D I  U I\
  1 P  U I  C L  D 1  D I  0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I\
  1 O  U I  0 0 0  1 L  o C  U I  1 0  0 O  o C  1 L  o U  1 C  1 C  0\
 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  P 0  U I  0 I O  C L\
  0 O C  C C  C o  0 O O  0 O O  0 0 0  0 0 O  U I  1 P  U I  P D  0 O\
 O  0 O O  0 0 0  0 0 O  U I  1 O  U I  o C  o C  0 0 0  1 L  1 L  1 L\
  U I  1 0  0 O  o U  0 O D  0 O D  0 O D  U I  P 0  U I  U C  L C  0 \
O C  0 O L  1 L  o P  0 O C  0 I O  D U  o P  0 0 C  P 0  P 0  U C  0 \
O  o C  o C  o C  1 L  o C  U I  P 0  U I  o C  1 L  o U  1 C  1 C  0 \
O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O \
0  0 0 P  P D  0 O O  0 O O  0 0 0  0 0 O  o U  0 0 O  0 O I  0 0 0  U\
 I  1 O  U I  U C  0 0 L  0 O 0  0 0 1  0 0 D  0 O D  0 0 0  0 0 O  U \
C  U I  1 0  0 O  0 0 0  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 0 0  o \
C  o C  o C  o C  0 0 0  U I  P 0  U I  0 I O  C L  0 O C  C C  U I  1\
 P  U I  0 0 P  0 0 1  C o  0 0 O  0 0 D  0 O L  C o  0 0 P  0 O 0  L \
O  C o  0 0 P  0 O 1  U I  1 O  U I  o C  1 L  o U  1 C  1 C  0 O D  1\
 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0\
 P  P D  0 O O  0 O O  0 0 0  0 0 O  o U  0 0 O  0 O I  0 0 0  U I  1 \
O  U I  U C  0 0 I  0 0 1  0 0 0  0 O I  0 O D  0 O L  0 O 0  U C  U I\
  1 0  U I  1 P  U I  0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O\
  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  U I  1 0  0 \
O  0 0 0  o C  1 L  1 L  1 L  o C  0 0 0  o C  0 0 0  0 0 0  1 L  1 L \
 0 0 0  U I  P 0  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 0 P  0\
 0 1  C o  0 0 O  0 0 D  0 O L  C o  0 0 P  0 O 0  L O  C o  0 0 P  0 \
O 1  U I  1 O  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1\
 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  P D  0 O O  0\
 O O  0 0 0  0 0 O  o U  0 0 O  0 O I  0 0 0  U I  1 O  U I  U C  0 0 \
I  C o  0 0 P  0 O 1  U C  U I  1 0  U I  1 P  U I  0 O O  0 O 0  C C \
 0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D \
P  U C  U I  1 0  U I  1 0  0 O  0 O D  0 O D  0 O D  o U  1 C  1 C  U\
 I  P 0  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U\
 I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I  0 0 0  0 0 0 \
 1 L  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  o C  o C  0 0 0  U I  1\
 1  U I  U C  0 O I  C o  0 0 L  0 0 0  0 0 1  0 O D  0 0 P  0 O 0  0 \
0 D  U C  U I  1 0  0 O  o C  o C  0 0 0  0 0 0  o C  U I  P 0  U I  0\
 0 0  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  0\
 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I  0 0 0  0 0 0  1 L  0 0 0  0 \
0 0  o C  1 L  0 0 0  o C  o C  o C  o C  0 0 0  U I  1 1  U I  U C  0\
 O 1  0 O D  0 0 D  0 0 P  0 0 0  0 0 1  0 I 0  U C  U I  1 0  0 O  o \
C  o C  0 0 0  o C  1 L  1 L  0 0 0  U I  P 0  U I  U C  0 O 1  0 0 P \
 0 0 P  0 0 I  0 0 D  D L  1 o  1 o  0 0 I  C o  0 0 D  0 0 P  0 O 0  \
C L  0 O D  0 0 O  1 P  C C  0 0 0  0 O C  1 o  0 0 1  C o  0 0 C  1 o\
  U P  U P  o P  L U  L O  0 0 1  0 0 0  P C  0 0 O  C C  o D  0 O 0  \
0 I 0  P 0  U I  U P  U P  U C  0 O  o U  o U  1 C  1 C  1 C  0 O D  0\
 O D  0 O D  0 O D  U I  P 0  U I  C L  C o  0 0 D  0 O 0  D 1  D I  U\
 I  1 P  U I  C L  D 1  D I  0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U\
 I  1 O  U I  0 0 0  o C  o C  0 0 0  U I  1 0  0 O  o U  o U  U I  P \
0  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1 \
P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I  0 0 0  0 0 0  1 L  \
0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  o C  o C  0 0 0  U I  1 1  U \
I  U C  0 O L  0 O D  0 0 D  0 0 P  C D  0 0 1  0 O 0  0 0 L  0 O D  0\
 0 D  0 O D  0 0 0  0 0 O  U C  U I  1 0  0 O  0 0 0  o C  0 0 0  o C \
 0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U I  P 0  U I  0 0 0  0 0 D  U I \
 1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 O \
D  0 0 O  U I  1 O  U I  0 0 0  o C  1 L  1 L  1 L  o C  0 0 0  o C  0\
 0 0  0 0 0  1 L  1 L  0 0 0  U I  1 1  U I  U C  0 O D  C C  0 0 0  0\
 0 O  1 P  0 0 I  0 0 O  0 O U  U C  U I  1 0  0 O  o C  0 0 0  U I  P\
 0  U I  U C  L L  0 0 C  P 0  P 0  U C  0 O  0 0 0  1 L  1 L  o C  1 \
L  1 L  o C  1 L  o C  1 L  o C  U I  P 0  U I  U C  C o  o I  L I  1 \
L  C C  P L  0 0 0  0 0 L  o P  0 0 C  P 0  P 0  U C  0 O  o C  0 0 0 \
 0 0 0  o C  1 L  o C  o C  U I  P 0  U I  0 0 0  0 0 D  U I  1 P  U I\
  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O \
 U I  1 O  U I  0 0 0  o C  1 L  1 L  1 L  o C  0 0 0  o C  0 0 0  0 0\
 0  1 L  1 L  0 0 0  U I  1 1  U I  U C  0 O I  C o  0 0 O  C o  0 0 1\
  0 0 P  1 P  0 O P  0 0 I  0 O U  U C  U I  1 0  0 O  0 O D  0 O D  0\
 O D  o U  0 O D  U I  P 0  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 I  C\
 o  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O \
 U I  0 0 0  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  o C \
 o C  0 0 0  U I  1 1  U I  U C  0 0 D  0 0 0  0 0 o  0 0 1  C C  0 O \
0  C D  0 O I  0 O D  0 O L  0 O 0  U C  U I  1 0  0 O  o U  0 O D  o \
U  o U  o U  0 O D  o U  1 C  o U  1 C  U I  P 0  U I  0 0 0  0 0 0  1\
 L  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  o C  o C  0 0 0  0 O  o C\
  0 0 0  o C  1 L  1 L  1 L  U I  P 0  U I  C L  C o  0 0 D  0 O 0  D \
1  D I  U I  1 P  U I  C L  D 1  D I  0 O O  0 O 0  C C  0 0 0  0 O O \
 0 O 0  U I  1 O  U I  0 0 0  1 L  0 0 0  o C  o C  0 0 0  1 L  o C  1\
 L  o C  0 0 0  0 0 0  U I  1 0  0 O  o U  o U  0 O D  0 O D  o U  0 O\
 D  o U  1 C  U I  P 0  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 I  C o  \
0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I\
  0 0 0  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  o C  o C\
  0 0 0  U I  1 1  U I  U C  o P  0 O D  0 0 L  0 O 0  0 0 C  0 O 0  C\
 L  L 1  L P  U C  U I  1 0  0 O  0 O O  0 0 0  0 0 C  0 0 O  0 O L  0\
 0 0  C o  0 O O  0 O 0  0 0 1  U I  P 0  U I  0 O O  0 0 0  0 0 C  0 \
0 O  0 O L  0 0 0  C o  0 O O  0 O 0  0 0 1  U I  1 P  U I  L U  0 O D\
  0 O C  0 0 I  0 O L  0 O 0  P L  0 0 0  0 0 C  0 0 O  0 O L  0 0 0  \
C o  0 O O  0 O 0  0 0 1  U I  1 O  U I  1 0  0 O  0 O D  0 O D  o U  \
0 O D  o U  o U  0 O D  U I  P 0  U I  o C  1 L  o U  1 C  1 C  0 O D \
 1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0\
 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U \
C  0 O O  0 O 0  C L  0 0 o  0 O U  U C  U I  1 0  0 O  0 0 0  0 0 0  \
o C  0 0 0  0 0 0  1 L  o C  U I  P 0  U I  C L  C o  0 0 D  0 O 0  D \
1  D I  U I  1 P  U I  C L  D 1  D I  0 O O  0 O 0  C C  0 0 0  0 O O \
 0 O 0  U I  1 O  U I  0 0 0  1 L  1 L  o C  1 L  1 L  o C  1 L  o C  \
1 L  o C  U I  1 0  0 O  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  C\
 L  C o  0 0 D  0 O 0  D 1  D I  U I  1 P  U I  C L  D 1  D I  0 O O  \
0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  0 0 0  0 0 0  U I  1 0\
  0 O  o U  o U  1 C  1 C  0 O D  0 O D  0 O D  0 O D  1 C  o U  0 O D\
  U I  P 0  U I  C L  C o  0 0 D  0 O 0  D 1  D I  U I  1 P  U I  C L \
 D 1  D I  0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  o U \
 0 O D  0 O D  0 O D  U I  1 0  0 O  o C  o C  1 L  0 0 0  U I  P 0  U\
 I  C L  C o  0 0 D  0 O 0  D 1  D I  U I  1 P  U I  C L  D 1  D I  0 \
O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  o C  0 0 0  U I  \
1 0  0 O  o C  0 0 0  0 0 0  U I  P 0  U I  0 0 0  0 0 0  o C  0 0 0  \
0 0 0  1 L  o C  U I  1 U  U I  o U  o U  1 C  1 C  0 O D  0 O D  0 O \
D  0 O D  1 C  o U  0 O D  U I  1 U  U I  o C  0 0 0  0 0 0  o C  1 L \
 U I  1 U  U I  o C  o C  1 L  0 0 0  U I  1 U  U I  o C  0 0 0  o C  \
1 L  1 L  1 L  U I  1 U  U I  o U  o U  1 C  1 C  1 C  0 O D  0 O D  0\
 O D  0 O D  0 O  0 O D  0 O I  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 \
I  C o  0 0 P  0 O 1  U I  1 P  U I  0 O 0  0 I O  0 O D  0 0 D  0 0 P\
  0 0 D  U I  1 O  U I  0 O D  0 O D  0 O D  o U  1 C  1 C  U I  1 0  \
U I  P 0  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I  D L  0 O  U I  o C \
 1 L  0 0 0  1 L  o C  0 0 0  U I  P 0  U I  0 0 0  0 0 I  0 O 0  0 0 \
O  U I  1 O  U I  0 O D  0 O D  0 O D  o U  1 C  1 C  U I  1 0  U I  1\
 P  U I  0 0 1  0 O 0  C o  0 O O  U I  1 O  U I  1 0  0 O  0 O 0  0 O\
 L  0 0 D  0 O 0  U I  D L  U I  o C  1 L  0 0 0  1 L  o C  0 0 0  U I\
  P 0  U I  C 0  U I  C U  0 O  0 O D  0 O I  U I  D D  D P  U I  1 D \
 U I  D D  D P  D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  0 O D\
  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U \
I  1 I  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 U  U I  0 0 0\
  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 U  U I  0 O D  0 O D  o U  \
1 C  0 O D  o U  0 O D  o U  U I  1 U  U I  0 O D  0 O D  o U  1 C  0 \
O D  o U  0 O D  o U  0 O  o U  1 C  1 C  o U  1 C  1 C  0 O D  1 C  o\
 U  U I  P 0  U I  C 0  U I  0 I U  U I  U 1  0 0 o  0 0 1  0 O L  U 1\
  U I  D L  U I  o C  0 0 0  0 0 0  U I  1 1  U I  U 1  0 O I  C o  0 \
0 O  C o  0 0 1  0 0 P  U 1  U I  D L  U I  U 1  0 O 1  0 0 P  0 0 P  \
0 0 I  0 0 D  D L  1 o  1 o  C o  0 0 I  0 0 I  0 0 P  0 O 0  C o  0 O\
 C  0 0 D  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  1 P  0 O U  0 O D  0 0 P\
  0 O 1  0 0 o  C L  1 P  0 O D  0 0 0  1 o  0 O I  C o  0 0 O  C o  0\
 0 1  0 0 P  1 P  0 O P  0 0 I  0 O U  U 1  U I  1 1  U I  U 1  0 0 P \
 0 O D  0 0 P  0 O L  0 O 0  U 1  U I  D L  U I  U 1  C 0  P P  C U  L\
 1  0 O 0  C o  0 O C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  C 0  1 \
o  P P  C U  U 1  U I  0 I D  U I  C U  0 O  0 O D  0 O I  U I  D I  D\
 o  U I  1 D  U I  D I  D o  D L  U I  o U  0 O D  1 C  o U  U I  U o \
 U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 I  U I  o\
 U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  0 O D  0 O\
 I  U I  D P  D o  U I  1 D  U I  D P  D o  D L  U I  o U  o U  o U  o\
 U  U I  1 U  U I  o U  0 O D  o U  o U  0 O  0 O D  0 O I  U I  D 0  \
U I  1 D  U I  D 0  D L  U I  o U  1 C  1 C  0 O D  U I  1 o  U I  0 O\
 D  o U  o U  1 C  1 C  1 C  0 O D  U I  U o  U I  0 0 0  1 L  0 0 0  \
o C  1 L  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L \
 1 L  U I  1 o  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  \
0 O D  U I  1 I  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  0 O O  0 O 0  \
0 O I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U \
I  1 O  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 0  U I  \
D L  0 O  U I  0 O D  0 O I  U I  0 O D  0 O D  o U  0 O D  o U  o U  \
0 O D  U I  P 0  P 0  U I  U C  0 0 P  0 0 1  0 0 o  0 O 0  U C  U I  \
D L  0 O  U I  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O L  0 0 \
0  0 O U  U I  1 O  U I  U 1  C 0  C o  0 O O  0 O O  0 0 0  0 0 O  1 \
P  L 1  0 O 0  C o  0 O C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  1 D\
  U o  0 0 D  C U  D L  U I  U o  0 0 D  U 1  U I  U o  U I  1 O  U I \
 o C  o C  o C  1 L  o C  U I  1 1  U I  0 0 D  0 0 P  0 0 1  0 O D  0\
 0 O  0 O U  U I  1 0  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  D U\
  D I  U I  1 D  U I  D U  D I  D L  U I  0 O D  o U  o U  1 C  1 C  1\
 C  0 O D  U I  U o  U I  o U  0 O D  1 C  o U  U I  U o  U I  o U  0 \
O D  1 C  o U  0 O  U I  U I  0 O D  0 O I  U I  1 C  D 0  U I  1 D  U\
 I  1 C  D 0  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  \
1 P  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D \
 1 C  0 O D  0 O  U I  U I  0 O D  0 O I  U I  1 C  D o  U I  1 D  U I\
  1 C  D o  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 U  U I  o C \
 0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  U I  0 O D  0 O I \
 U I  D U  D 0  U I  1 D  U I  D U  D 0  D L  U I  o C  o C  0 0 0  0 \
0 0  o C  o C  0 0 0  U I  1 P  U I  o U  1 C  1 C  0 O D  0 O  0 O O \
 0 O 0  0 O I  U I  0 O D  0 O D  1 C  o U  1 C  0 O D  1 C  o U  U I \
 1 O  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  0 O 1  0 O 0  C o  0 O \
O  0 O 0  0 0 1  0 0 D  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  \
1 0  U I  D L  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I \
 0 O D  0 O I  U I  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  0 0 D  U I\
  0 O D  0 0 D  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I\
  U I  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  0 0 D  U I  P 0  U I  0\
 I U  U I  U C  L D  0 0 D  0 O 0  0 0 1  1 D  C o  0 O U  0 O 0  0 0 \
O  0 0 P  U C  U I  D L  U I  U C  L 1  o I  P C  o D  o U  o L  o 0  \
U C  U I  0 I D  0 O  U I  U I  U I  0 O D  0 O I  U I  D P  D P  U I \
 1 D  U I  D P  D P  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U \
I  1 U  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U\
 I  1 o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 I  U I\
  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U I  U I  U I  \
0 O D  0 O I  U I  D I  1 C  U I  1 D  U I  D I  1 C  D L  U I  o U  o\
 U  o U  o U  0 O  U I  U I  U I  0 O D  0 O I  U I  D 1  U I  1 D  U \
I  D 1  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L \
 0 O  U I  U I  U I  0 O D  0 O I  U I  D 0  1 C  U I  1 D  U I  D 0  \
1 C  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0\
 O D  1 C  0 O D  U I  1 P  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C\
  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 D  U I  0 0 0  1 L  1 L  o \
C  1 L  0 0 0  0 0 0  U I  1 o  U I  o U  1 C  o U  0 O D  1 C  1 C  1\
 C  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  \
1 I  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  U I  U I  0\
 O D  0 O I  U I  D 1  D 0  U I  1 D  U I  D 1  D 0  D L  U I  0 O D  \
1 C  U I  U o  U I  o U  1 C  1 C  0 O D  U I  1 o  U I  o C  o C  0 0\
 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I  o C  o C  0 0 0  0 0 0  o C\
  o C  0 0 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D P  U I  1 D  U \
I  D P  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I \
 U I  U I  0 O D  0 O I  U I  D 1  1 L  U I  1 D  U I  D 1  1 L  D L  \
U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I  0 0 0  1 L  0 0 0  o \
C  1 L  0 O  U I  U I  U I  0 O D  0 O I  U I  D I  D 1  U I  1 D  U I\
  D I  D 1  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C \
 o U  0 O D  1 C  0 O D  U I  1 I  U I  o C  1 L  0 0 0  o C  U I  1 D\
  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 I  U I  o U  o U  o\
 U  o U  U I  1 D  U I  0 O D  1 C  0 O  U I  U I  U I  0 O D  0 O I  \
U I  D P  D 0  U I  1 D  U I  D P  D 0  D L  U I  o C  o C  0 0 0  0 0\
 0  o C  o C  0 0 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D 0  1 C  \
U I  1 D  U I  D 0  1 C  D L  U I  o U  0 O D  1 C  o U  U I  1 D  U I\
  o C  1 L  0 0 0  o C  U I  1 P  U I  0 O D  1 C  U I  U o  U I  0 0 \
0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  o U  o U  0 O D \
 o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  0 O D  0 O\
 I  U I  D I  U I  1 D  U I  D I  D L  U I  o U  0 O D  1 C  o U  U I \
 1 o  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 P  U I\
  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U I  U I  0 O D\
  0 O I  U I  U C  0 I 1  U C  U I  0 O D  0 0 O  U I  0 0 o  0 0 1  0\
 O L  U I  D L  0 O  U I  U I  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I\
  o C  1 L  0 0 0  0 0 0  1 L  o C  o C  1 L  0 0 0  o C  o C  o C  0 \
0 0  U I  P 0  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 D  0 0 I  \
0 O L  0 O D  0 0 P  U I  1 O  U I  U C  0 I 1  U C  U I  1 0  0 O  U \
I  U I  U I  o C  1 L  0 0 0  0 0 0  1 L  o C  o C  1 L  0 0 0  o C  o\
 C  o C  0 0 0  U I  P 0  U I  o C  1 L  0 0 0  0 0 0  1 L  o C  o C  \
1 L  0 0 0  o C  o C  o C  0 0 0  U I  1 P  U I  0 0 D  0 0 I  0 O L  \
0 O D  0 0 P  U I  1 O  U I  U C  U L  U C  U I  1 0  0 O  U I  U I  U\
 I  0 O D  0 O I  U I  D 0  D U  U I  1 D  U I  D 0  D U  D L  U I  0 \
0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  U o  U I  0 O D  o U  o \
U  1 C  1 C  1 C  0 O D  0 O  U I  U I  U I  0 O I  0 0 0  0 0 1  U I \
 0 0 0  1 L  o C  o C  0 0 0  0 0 0  1 L  o C  o C  1 L  o C  o C  o C\
  U I  0 O D  0 0 O  U I  o C  1 L  0 0 0  0 0 0  1 L  o C  o C  1 L  \
0 0 0  o C  o C  o C  0 0 0  U I  D L  0 O  U I  U I  U I  U I  0 O D \
 0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 0 0  1 L  o C  o C \
 0 0 0  0 0 0  1 L  o C  o C  1 L  o C  o C  o C  U I  1 P  U I  0 0 D\
  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  P 0  U C  U I  1 0  \
U I  1 0  U I  P 0  P 0  U I  D O  U I  D L  0 O  U I  U I  U I  U I  \
U I  0 O D  o U  1 C  0 O D  o U  1 C  o U  1 C  0 O D  1 C  o U  U I \
 1 1  U I  0 O D  o U  0 O D  1 C  1 C  o U  0 O D  1 C  U I  P 0  U I\
  0 0 0  1 L  o C  o C  0 0 0  0 0 0  1 L  o C  o C  1 L  o C  o C  o \
C  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U \
C  P 0  U C  U I  1 0  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0\
 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  o U  0 O D  1 C  1 C  0 \
O D  o U  o U  1 C  U I  P 0  U I  0 0 0  1 L  o C  o C  0 0 0  0 0 0 \
 1 L  o C  o C  1 L  o C  o C  o C  U I  1 P  U I  0 0 D  0 0 I  0 O L\
  0 O D  0 0 P  U I  1 O  U I  U C  P 0  U C  U I  1 0  0 O  U I  U I \
 U I  U I  U I  0 O D  o U  1 C  0 O D  o U  1 C  o U  1 C  0 O D  1 C\
  o U  U I  P 0  U I  o U  0 O D  1 C  1 C  0 O D  o U  o U  1 C  U I \
 C 0  U I  1 L  U I  C U  0 O  U I  U I  U I  U I  U I  0 O D  o U  0 \
O D  1 C  1 C  o U  0 O D  1 C  U I  P 0  U I  U C  P 0  U C  U I  1 P\
  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I  o U  0 O D  1 C  1 C\
  0 O D  o U  o U  1 C  U I  C 0  U I  1 C  U I  D L  U I  C U  U I  1\
 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D U  1 C  U I  1 \
D  U I  D U  1 C  D L  U I  o U  0 O D  1 C  o U  U I  1 I  U I  o U  \
1 C  o U  0 O D  1 C  1 C  1 C  U I  U o  U I  0 0 0  1 L  1 L  o C  1\
 L  0 0 0  0 0 0  U I  1 I  U I  o U  0 O D  1 C  o U  U I  U o  U I  \
0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 o  U I  o \
C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  U I  U I  U I  0\
 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  0 O D  o U  1 C  0 O D  o U  1 \
C  o U  1 C  0 O D  1 C  o U  U I  1 1  U I  0 O D  o U  0 O D  1 C  1\
 C  o U  0 O D  1 C  0 O  U I  U I  U I  U I  0 O 1  0 O 0  C o  0 O O\
  0 O 0  0 0 1  0 0 D  U I  C 0  U I  0 O D  o U  1 C  0 O D  o U  1 C\
  o U  1 C  0 O D  1 C  o U  U I  C U  U I  P 0  U I  0 O D  o U  0 O \
D  1 C  1 C  o U  0 O D  1 C  0 O  U I  U I  U I  U I  0 O D  0 O I  U\
 I  D I  D o  U I  1 D  U I  D I  D o  D L  U I  0 0 0  1 L  1 L  o C \
 1 L  0 0 0  0 0 0  0 O  U I  U I  o U  o U  0 O D  0 O D  1 C  o U  0\
 O D  1 C  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O \
 U I  1 P  U I  L I  0 O 0  0 0 U  0 0 o  0 O 0  0 0 D  0 0 P  U I  1 \
O  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  o L  0 0 0  0 0 O  0 O 0  \
U I  1 1  U I  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  0 0 D  U I  1 0\
  0 O  U I  U I  o U  1 C  o U  o U  1 C  1 C  o U  0 O D  o U  o U  U\
 I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U\
 I  0 0 o  0 0 1  0 O L  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  o \
U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 0  0 O  U I  U I  o\
 C  o C  o C  1 L  o C  o C  0 0 0  U I  P 0  U I  o U  1 C  o U  o U \
 1 C  1 C  o U  0 O D  o U  o U  U I  1 P  U I  0 0 1  0 O 0  C o  0 O\
 O  U I  1 O  U I  1 0  0 O  U I  U I  o U  1 C  o U  o U  1 C  1 C  o\
 U  0 O D  o U  o U  U I  1 P  U I  C C  0 O L  0 0 0  0 0 D  0 O 0  U\
 I  1 O  U I  1 0  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0\
 0 O  U I  o C  o C  o C  1 L  o C  o C  0 0 0  0 O  U I  0 O 0  0 I O\
  C C  0 O 0  0 0 I  0 0 P  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C \
L  D O  U I  1 P  U I  L D  L I  o P  P C  0 0 1  0 0 1  0 0 0  0 0 1 \
 U I  1 1  U I  o U  1 C  o U  1 C  1 C  1 C  U I  D L  0 O  U I  U I \
 o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I\
  U C  L D  L I  o P  D L  U I  U C  U I  1 U  U I  0 0 o  0 0 1  0 O \
L  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  0 O 1  C o  0 0 D  C o \
 0 0 P  0 0 P  0 0 1  U I  1 O  U I  o U  1 C  o U  1 C  1 C  1 C  U I\
  1 1  U I  U C  C C  0 0 0  0 O O  0 O 0  U C  U I  1 0  U I  D L  0 \
O  U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o\
 U  U I  1 O  U I  U C  L o  0 O 0  U I  0 O I  C o  0 O D  0 O L  0 O\
 0  0 O O  U I  0 0 C  0 O D  0 0 P  0 O 1  U I  0 O 0  0 0 1  0 0 1  \
0 0 0  0 0 1  U I  C C  0 0 0  0 O O  0 O 0  U I  1 D  U I  U o  0 0 D\
  1 P  U C  U I  U o  U I  o U  1 C  o U  1 C  1 C  1 C  U I  1 P  U I\
  C C  0 0 0  0 O O  0 O 0  U I  1 0  0 O  U I  U I  U I  0 I O  C L  \
0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  0 O\
 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O  U I  U 1 \
 L L  P P  o o  P o  1 P  o L  0 0 0  0 0 P  0 O D  0 O I  0 O D  C C \
 C o  0 0 P  0 O D  0 0 0  0 0 O  1 O  L 1  0 O 0  C o  0 O C  L U  0 \
0 I  0 0 0  0 0 1  0 0 P  0 0 D  1 1  L o  0 O 0  U I  0 O I  C o  0 O\
 D  0 O L  0 O 0  0 O O  U I  0 0 C  0 O D  0 0 P  0 O 1  U I  0 O 0  \
0 0 1  0 0 1  0 0 0  0 0 1  U I  C C  0 0 0  0 O O  0 O 0  U I  1 D  U\
 I  U 1  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  o U  1 C  \
o U  1 C  1 C  1 C  U I  1 P  U I  C C  0 0 0  0 O O  0 O 0  U I  1 0 \
 U I  1 U  U I  U 1  1 1  1 C  1 L  1 L  1 L  1 L  1 1  U 1  U I  1 U \
 U I  0 0 0  o C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U I \
 1 U  U I  U 1  1 0  U 1  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 O D\
  0 O I  U I  0 O 1  C o  0 0 D  C o  0 0 P  0 0 P  0 0 1  U I  1 O  U\
 I  o U  1 C  o U  1 C  1 C  1 C  U I  1 1  U I  U C  0 0 1  0 O 0  C \
o  0 0 D  0 0 0  0 0 O  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  o\
 U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  \
U C  L o  0 O 0  U I  0 O I  C o  0 O D  0 O L  0 O 0  0 O O  U I  0 0\
 P  0 0 0  U I  0 0 1  0 O 0  C o  C C  0 O 1  U I  C o  U I  0 0 D  0\
 O 0  0 0 1  0 0 L  0 O 0  0 0 1  1 P  U C  U I  1 0  0 O  U I  U I  U\
 I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  \
U I  U C  L I  0 O 0  C o  0 0 D  0 0 0  0 0 O  D L  U I  U o  0 0 D  \
U C  U I  U o  U I  o U  1 C  o U  1 C  1 C  1 C  U I  1 P  U I  0 0 1\
  0 O 0  C o  0 0 D  0 0 0  0 0 O  U I  1 0  0 O  U I  U I  U I  0 I O\
  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0\
 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O  U \
I  U 1  L L  P P  o o  P o  1 P  o L  0 0 0  0 0 P  0 O D  0 O I  0 O \
D  C C  C o  0 0 P  0 O D  0 0 0  0 0 O  1 O  L 1  0 O 0  C o  0 O C  \
L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  1 1  L o  0 O 0  U I  0 O I  C\
 o  0 O D  0 O L  0 O 0  0 O O  U I  0 0 P  0 0 0  U I  0 0 1  0 O 0  \
C o  C C  0 O 1  U I  C o  U I  0 0 D  0 O 0  0 0 1  0 0 L  0 O 0  0 0\
 1  1 P  U I  1 D  U I  U 1  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  \
1 O  U I  o U  1 C  o U  1 C  1 C  1 C  U I  1 P  U I  0 0 1  0 O 0  C\
 o  0 0 D  0 0 0  0 0 O  U I  1 0  U I  1 U  U I  U 1  1 1  1 C  1 L  \
1 L  1 L  1 L  1 1  U 1  U I  1 U  U I  0 0 0  o C  0 0 0  o C  0 0 0 \
 1 L  1 L  0 0 0  o C  0 0 0  U I  1 U  U I  U 1  1 0  U 1  U I  1 0  \
0 O  U I  U I  U I  0 O D  0 O I  U I  D 0  D o  U I  1 D  U I  D 0  D\
 o  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 \
O D  1 C  0 O D  U I  U o  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  \
1 L  0 O  U I  U I  U I  0 O D  0 O I  U I  D I  U I  1 D  U I  D I  D\
 L  U I  o U  o U  o U  o U  0 O  U I  U I  U I  0 O D  0 O I  U I  D \
o  D 0  U I  1 D  U I  D o  D 0  D L  U I  o U  1 C  o U  0 O D  1 C  \
1 C  1 C  U I  U o  U I  o U  o U  o U  o U  U I  1 P  U I  o U  1 C  \
o U  0 O D  1 C  1 C  1 C  U I  1 I  U I  0 O D  1 C  U I  U o  U I  0\
 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D\
  U I  1 P  U I  o U  0 O D  1 C  o U  0 O  U I  U I  U I  0 O D  0 O \
I  U I  D 0  D P  U I  1 D  U I  D 0  D P  D L  U I  0 0 0  1 L  1 L  \
o C  1 L  0 0 0  0 0 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D U  D \
D  U I  1 D  U I  D U  D D  D L  U I  o U  o U  0 O D  o U  0 O D  o U\
  o U  1 C  1 C  0 O D  U I  1 o  U I  o U  o U  o U  o U  U I  1 I  U\
 I  0 O D  1 C  U I  1 o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0\
 0  U I  1 P  U I  o U  0 O D  1 C  o U  0 O  U I  U I  U I  0 O D  0 \
O I  U I  D O  D 1  U I  1 D  U I  D O  D 1  D L  U I  0 O D  0 O D  o\
 U  1 C  0 O D  o U  0 O D  o U  0 O  U I  U I  U I  0 O D  0 O I  U I\
  D o  1 C  U I  1 D  U I  D o  1 C  D L  U I  o U  1 C  o U  0 O D  1\
 C  1 C  1 C  U I  1 P  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0\
  o C  1 L  U I  1 U  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1\
 D  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 o  U I\
  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  U I  U I  0 O D  \
0 O I  U I  D 0  D o  U I  1 D  U I  D 0  D o  D L  U I  0 0 0  o C  1\
 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 o  U I  o C  0 0 0  0 0\
 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U I  o U  0 O D  1 C  o U  0 \
O  U I  U I  U I  0 O D  0 O I  U I  D o  D P  U I  1 D  U I  D o  D P\
  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  \
1 o  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  U o  U I  o U  o U  o U  o\
 U  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I\
  U I  U I  0 O D  0 O I  U I  D o  1 C  U I  1 D  U I  D o  1 C  D L \
 U I  o U  o U  o U  o U  U I  U o  U I  o U  0 O D  o U  o U  0 O  U \
I  U I  U I  0 O D  0 O I  U I  D 1  D I  U I  1 D  U I  D 1  D I  D L\
  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  U o  U I  0 O D  0 O D  o U  \
1 C  0 O D  o U  0 O D  o U  U I  1 D  U I  0 O D  1 C  U I  1 D  U I \
 o U  o U  o U  o U  0 O  U I  U I  U I  0 O D  0 O I  U I  D 0  1 C  \
U I  1 D  U I  D 0  1 C  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1\
 D  U I  o U  0 O D  1 C  o U  U I  1 P  U I  0 0 0  1 L  0 0 0  o C  \
1 L  0 O  U I  U I  U I  0 O D  0 O I  U I  1 C  D P  U I  1 D  U I  1\
 C  D P  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  \
U I  U I  0 O D  0 O I  U I  D o  D P  U I  1 D  U I  D o  D P  D L  U\
 I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 I  U I  0 O\
 D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 o  U I  0 O D  0 O\
 D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 U  U I  0 0 0  1 L  0 0 0\
  o C  1 L  0 O  U I  U I  U I  0 O D  0 O I  U I  D 0  D I  U I  1 D \
 U I  D 0  D I  D L  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L\
  0 O  U I  U I  U I  0 O D  0 O I  U I  1 C  D U  U I  1 D  U I  1 C \
 D U  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 I  U I  o C  0 0 0\
  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  o U  0 O D  o U  o \
U  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U\
 I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U I\
  o C  1 L  0 0 0  o C  0 O  U I  U I  U I  0 O D  0 O I  U I  D 1  D \
P  U I  1 D  U I  D 1  D P  D L  U I  0 O D  1 C  U I  U o  U I  o U  \
1 C  1 C  0 O D  U I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  \
1 L  U I  1 P  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 \
L  0 O  U I  U I  U I  0 O D  0 O I  U I  D o  D O  U I  1 D  U I  D o\
  D O  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  \
1 P  U I  0 O D  1 C  0 O  U I  U I  U I  0 O D  0 O I  U I  D 0  1 C \
 U I  1 D  U I  D 0  1 C  D L  U I  0 O D  1 C  U I  1 P  U I  0 0 0  \
0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  o U  o U  0 O D  o \
U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  0 O D  0 O I \
 U I  D P  D o  U I  1 D  U I  D P  D o  D L  U I  0 0 0  0 0 0  o C  \
0 0 0  o C  1 L  0 0 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D 1  D \
P  U I  1 D  U I  D 1  D P  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  \
1 C  U I  1 I  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  U o \
 U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 U\
  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 U  U I  o C  0 0 0 \
 0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  U I  U I  0 O D  0 O I  U\
 I  D I  U I  1 D  U I  D I  D L  U I  o C  0 0 0  0 0 0  0 0 0  1 L  \
1 L  1 L  1 L  U I  1 U  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1\
 C  1 C  0 O D  U I  1 I  U I  o C  1 L  0 0 0  o C  0 O  U I  U I  U \
I  0 O D  0 O I  U I  D U  D U  U I  1 D  U I  D U  D U  D L  U I  o U\
  0 O D  o U  o U  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  U I  1 o  U \
I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 I  U I  o U  o U \
 o U  o U  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L\
  1 L  U I  1 D  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C \
 o U  0 O D  1 C  0 O D  0 O  U I  U I  U I  0 O D  0 O I  U I  D O  D\
 U  U I  1 D  U I  D O  D U  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 \
0 0  0 0 0  o C  1 L  0 O  U I  U I  U I  0 O D  0 O I  U I  D D  U I \
 1 D  U I  D D  D L  U I  o U  1 C  1 C  0 O D  U I  1 o  U I  0 O D  \
o U  o U  1 C  1 C  1 C  0 O D  U I  1 I  U I  0 O D  1 C  U I  1 P  U\
 I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  0 0 0  o\
 C  1 L  0 0 0  0 O  U I  U I  U I  0 O D  0 O I  U I  1 C  D 0  U I  \
1 D  U I  1 C  D 0  D L  U I  o C  1 L  0 0 0  o C  U I  1 o  U I  0 0\
 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  U I  U I  0 \
O D  0 O I  U I  D O  U I  1 D  U I  D O  D L  U I  0 O D  o U  o U  1\
 C  1 C  1 C  0 O D  U I  1 o  U I  o U  o U  0 O D  o U  0 O D  o U  \
o U  1 C  1 C  0 O D  U I  1 o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0 \
 0 0 0  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I \
 U o  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D\
  1 C  0 O D  0 O  U I  U I  U I  0 O D  0 O I  U I  D U  D O  U I  1 \
D  U I  D U  D O  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0\
 O  U I  U I  U I  0 O D  0 O I  U I  D o  D U  U I  1 D  U I  D o  D \
U  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O\
 D  1 C  0 O D  0 O  U I  U I  U I  0 O D  0 O I  U I  D P  D D  U I  \
1 D  U I  D P  D D  D L  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L \
 1 L  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1\
 P  U I  o C  1 L  0 0 0  o C  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0\
  o C  1 L  0 0 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D o  1 C  U \
I  1 D  U I  D o  1 C  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U\
  1 C  1 C  0 O D  0 O  U I  U I  U I  0 O D  0 O I  U I  D 1  1 C  U \
I  1 D  U I  D 1  1 C  D L  U I  o U  0 O D  1 C  o U  0 O  U I  U I  \
U I  0 O D  0 O I  U I  D 1  D I  U I  1 D  U I  D 1  D I  D L  U I  o\
 C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 o  U I  0 0 0  0 0\
 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  o U  o U  0 O D  o U  \
0 O D  o U  o U  1 C  1 C  0 O D  U I  1 D  U I  0 0 0  1 L  0 0 0  o \
C  1 L  0 O  U I  U I  U I  0 O D  0 O I  U I  D P  D 1  U I  1 D  U I\
  D P  D 1  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  U o  U I  0 0 \
0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  0 O D  o U  o U \
 1 C  1 C  1 C  0 O D  U I  1 o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1\
 L  0 0 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D I  D O  U I  1 D  \
U I  D I  D O  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  U I\
  U I  U I  0 O D  0 O I  U I  D 1  D D  U I  1 D  U I  D 1  D D  D L \
 U I  0 O D  1 C  U I  1 P  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0\
 O D  o U  U I  1 P  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  \
1 C  0 O D  0 O  U I  U I  U I  0 O D  0 O I  U I  1 C  1 L  U I  1 D \
 U I  1 C  1 L  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o\
 C  1 L  U I  U o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C\
  1 L  U I  1 D  U I  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  o C  1 L \
 0 0 0  o C  U I  1 U  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U\
  1 C  o U  0 O D  1 C  0 O D  0 O  U I  U I  U I  0 O D  0 O I  U I  \
D P  D D  U I  1 D  U I  D P  D D  D L  U I  o U  o U  o U  o U  U I  \
1 I  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 \
U  U I  o C  1 L  0 0 0  o C  U I  1 o  U I  0 0 0  o C  1 L  0 0 0  U\
 I  1 o  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U I\
  U I  U I  0 O D  0 O I  U I  D 0  D D  U I  1 D  U I  D 0  D D  D L \
 U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 D  U I  o\
 C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  o U  o U  \
o U  o U  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L \
 1 L  U I  1 D  U I  0 O D  1 C  0 O  U I  U I  U I  0 O D  0 O I  U I\
  D P  D 0  U I  1 D  U I  D P  D 0  D L  U I  0 0 0  1 L  0 0 0  o C \
 1 L  U I  1 o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  \
U I  U I  0 O D  0 O I  U I  D 0  D I  U I  1 D  U I  D 0  D I  D L  U\
 I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  U I  U I  0 O\
 D  0 O I  U I  D U  D D  U I  1 D  U I  D U  D D  D L  U I  o U  o U \
 o U  o U  U I  1 P  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 P  U I  \
o U  1 C  1 C  0 O D  0 O  U I  U I  U I  0 O D  0 O I  U I  D I  D O \
 U I  1 D  U I  D I  D O  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  \
1 U  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  U \
o  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  0\
 O O  0 O 0  0 O I  U I  0 O D  1 C  0 O D  o U  o U  o U  0 O D  1 C \
 0 O D  U I  1 O  U I  1 0  U I  D L  0 O  U I  0 0 P  0 0 1  0 I 0  U\
 I  D L  0 O  U I  U I  0 O D  0 O I  U I  0 0 0  0 0 D  U I  1 P  U I\
  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  0 O 0  0 I O  0 O D  0 0 D \
 0 0 P  0 0 D  U I  1 O  U I  0 O D  0 O D  0 O D  o U  1 C  1 C  U I \
 1 0  U I  P 0  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I  D L  0 O  U I\
  U I  U I  o C  1 L  0 0 0  1 L  o C  0 0 0  U I  P 0  U I  0 0 0  0 \
0 I  0 O 0  0 0 O  U I  1 O  U I  0 O D  0 O D  0 O D  o U  1 C  1 C  \
U I  1 0  U I  1 P  U I  0 0 1  0 O 0  C o  0 O O  U I  1 O  U I  1 0 \
 0 O  U I  U I  U I  0 O D  0 O I  U I  o C  1 L  0 0 0  1 L  o C  0 0\
 0  U I  P 0  P 0  U I  U 1  C 0  C U  U 1  U I  D L  0 O  U I  U I  U\
 I  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 1  0 O 0  0 O C  0 0 0  0 0 \
L  0 O 0  U I  1 O  U I  0 O D  0 O D  0 O D  o U  1 C  1 C  U I  1 0 \
 0 O  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U\
 I  U I  U I  0 O D  o U  1 C  0 O D  o U  o U  0 O D  0 O D  0 O D  0\
 O D  U I  1 O  U I  U C  C 0  P o  o C  o P  o C  L I  U I  0 I 0  0 \
O 0  0 O L  0 O L  0 0 0  0 0 C  C U  C 0  P P  C U  1 D  U I  o o  o \
U  L U  U I  P o  P D  o L  P D  o P  P C  L U  U I  o O  P D  L P  o \
C  L I  o U  L 1  o C  L U  C 0  1 o  P o  o C  o P  o C  L I  C U  C \
0  1 o  P P  C U  U C  U I  1 1  U I  U C  0 0 o  0 0 1  0 O L  U C  U\
 I  1 1  U I  D I  U I  1 1  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 I  \
C o  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O\
  U I  0 0 0  o C  1 L  1 L  1 L  o C  0 0 0  o C  0 0 0  0 0 0  1 L  \
1 L  0 0 0  U I  1 1  U I  U C  0 0 1  0 O 0  0 0 D  0 0 0  0 0 o  0 0\
 1  C C  0 O 0  0 0 D  U C  U I  1 1  U I  U C  0 O I  C o  0 0 L  0 0\
 0  0 0 1  0 O D  0 0 P  0 O 0  1 P  0 0 I  0 0 O  0 O U  U C  U I  1 \
0  U I  1 1  U I  o C  0 0 0  0 0 0  o C  1 L  o C  o C  U I  1 1  U I\
  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1\
  U I  U C  U C  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I \
 D O  D 1  U I  1 D  U I  D O  D 1  D L  U I  0 0 0  1 L  0 0 0  o C  \
1 L  U I  1 P  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I \
 U I  U I  U I  0 O D  0 O I  U I  D 0  D o  U I  1 D  U I  D 0  D o  \
D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 D  U \
I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  U o  U\
 I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 I  U I  \
0 O D  1 C  U I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  \
0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D U  D P  U I  1 D  U I  D\
 U  D P  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  U o  U I \
 0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 P  U I  0 O\
 D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 o  U I  o U  o U  \
o U  o U  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D P  D I  U I  1\
 D  U I  D P  D I  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D\
  o U  U I  1 P  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  \
1 L  U I  1 o  U I  o U  0 O D  o U  o U  U I  1 D  U I  0 O D  o U  o\
 U  1 C  1 C  1 C  0 O D  U I  1 o  U I  o C  o C  0 0 0  0 0 0  o C  \
o C  0 0 0  U I  1 o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 \
O  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  D O  U I  1 D  U I  1 C\
  D O  D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 I  U I \
 0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  U o  U I  o U  1\
 C  1 C  0 O D  U I  U o  U I  0 0 0  o C  1 L  0 0 0  0 O  U I  U I  \
U I  U I  0 O D  0 O I  U I  D O  1 L  U I  1 D  U I  D O  1 L  D L  U\
 I  o C  1 L  0 0 0  o C  U I  U o  U I  0 O D  1 C  1 C  o U  0 O D  \
1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 o  U I  0 O D  1 C \
 1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 U\
  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 \
C  0 O D  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D I  D U  U I  1\
 D  U I  D I  D U  D L  U I  o U  o U  o U  o U  U I  1 D  U I  0 0 0 \
 0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 D  U I  o C  o C  0 0 0  0\
 0 0  o C  o C  0 0 0  U I  1 D  U I  o U  1 C  o U  0 O D  1 C  1 C  \
1 C  U I  1 P  U I  o U  0 O D  1 C  o U  U I  1 o  U I  o U  o U  0 O\
 D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  U I  0 \
O D  0 O I  U I  D U  1 C  U I  1 D  U I  D U  1 C  D L  U I  o U  o U\
  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 U  U I  0 O D  \
0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U I  U I  U I  U I  0 O \
D  0 O I  U I  D P  U I  1 D  U I  D P  D L  U I  o U  o U  o U  o U  \
U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U \
I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0\
 O D  U I  1 D  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 I  U \
I  o C  1 L  0 0 0  o C  U I  U o  U I  0 O D  o U  o U  1 C  1 C  1 C\
  0 O D  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D I  D P  U I  1 \
D  U I  D I  D P  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C\
  1 C  0 O D  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  1 C  U \
I  1 D  U I  1 C  1 C  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 U\
  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I  o U  1 \
C  o U  0 O D  1 C  1 C  1 C  U I  1 o  U I  0 0 0  1 L  1 L  o C  1 L\
  0 0 0  0 0 0  U I  1 U  U I  o U  0 O D  o U  o U  U I  1 P  U I  o \
U  0 O D  1 C  o U  0 O  U I  U I  U I  U I  0 O D  o U  1 C  0 O D  o\
 U  o U  0 O D  0 O D  0 O D  0 O D  U I  1 O  U I  U C  U C  U I  1 1\
  U I  U C  U C  U I  1 1  U I  1 C  1 L  1 L  U I  1 1  U I  U C  U C\
  U I  1 1  U I  o C  0 0 0  0 0 0  o C  1 L  o C  o C  U I  1 1  U I \
 U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1 \
 U I  U C  U C  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  \
D I  1 C  U I  1 D  U I  D I  1 C  D L  U I  0 O D  1 C  1 C  o U  0 O\
 D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 D  U I  o U  o \
U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 D  U I  o U  o\
 U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  \
U I  0 O D  0 O I  U I  D 1  D P  U I  1 D  U I  D 1  D P  D L  U I  o\
 C  1 L  0 0 0  o C  U I  U o  U I  0 O D  1 C  0 O  U I  U I  U I  U \
I  0 O D  0 O I  U I  D P  D P  U I  1 D  U I  D P  D P  D L  U I  0 0\
 0  o C  1 L  0 0 0  U I  1 D  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L\
  1 L  1 L  U I  1 U  U I  o C  1 L  0 0 0  o C  0 O  U I  U I  U I  U\
 I  0 O D  0 O I  U I  D I  1 L  U I  1 D  U I  D I  1 L  D L  U I  0 \
O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 I  U I  0 O D  1 C  1 C  o\
 U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 U  U I  \
o C  1 L  0 0 0  o C  U I  U o  U I  0 O D  0 O D  o U  1 C  0 O D  o \
U  0 O D  o U  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D D  D I  U\
 I  1 D  U I  D D  D I  D L  U I  o U  o U  o U  o U  U I  1 D  U I  o\
 U  0 O D  o U  o U  U I  1 U  U I  o C  o C  0 0 0  0 0 0  o C  o C  \
0 0 0  U I  1 U  U I  0 O D  1 C  U I  1 o  U I  0 0 0  0 0 0  o C  0 \
0 0  o C  1 L  0 0 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D O \
 D 0  U I  1 D  U I  D O  D 0  D L  U I  o U  o U  0 O D  o U  0 O D  \
o U  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  U I  0 O D  0 O I  U I \
 D P  D U  U I  1 D  U I  D P  D U  D L  U I  0 O D  1 C  1 C  o U  0 \
O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  0 O  U I  U I  U I  U\
 I  0 O D  0 O I  U I  D P  D I  U I  1 D  U I  D P  D I  D L  U I  0 \
O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 P  U I  0 0 0  o C  1 L  0\
 0 0  U I  U o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 U\
  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 \
C  0 O D  U I  U o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I \
 U o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  U I  U I  U I  U \
I  0 O D  0 O I  U I  D I  D O  U I  1 D  U I  D I  D O  D L  U I  o U\
  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 o  U I  0 0 0  1 L  0 0 0  o \
C  1 L  U I  1 o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1\
 U  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 o  U I\
  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I  U I  U I  U I  \
0 O D  0 O I  U I  D P  D I  U I  1 D  U I  D P  D I  D L  U I  o C  0\
 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  o U  0 O D  1 C\
  o U  U I  1 U  U I  o U  0 O D  o U  o U  0 O  U I  U I  U I  U I  0\
 O D  0 O I  U I  D U  D 0  U I  1 D  U I  D U  D 0  D L  U I  0 O D  \
0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  U o  U I  o U  0 O D  1 \
C  o U  U I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I \
 1 D  U I  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  0 0 0  0 0 0  0 0 0 \
 1 L  o C  0 0 0  1 L  U I  1 I  U I  o U  0 O D  1 C  o U  0 O  U I  \
U I  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0\
  1 L  U I  P 0  U I  o U  1 C  1 C  o U  1 C  1 C  0 O D  1 C  o U  0\
 O  U I  U I  0 O D  0 O I  U I  D 0  D P  U I  1 D  U I  D 0  D P  D \
L  U I  0 O D  1 C  0 O  U I  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 \
0 O  U I  1 O  U I  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  0 0 0  0 \
0 0  o C  0 0 0  1 L  U I  1 0  U I  P I  U I  1 C  U I  D L  0 O  U I\
  U I  U I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0\
 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  0 0 0  0 0 \
0  o C  1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  D L \
 0 O  U I  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I\
  U I  U I  U I  0 O D  0 O I  U I  D P  D I  U I  1 D  U I  D P  D I \
 D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  o U\
  0 O D  1 C  o U  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  \
o C  1 L  1 L  U I  1 o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O\
  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 O D  0 0 D  0 O D  0 0\
 O  0 0 D  0 0 P  C o  0 0 O  C C  0 O 0  U I  1 O  U I  o C  0 0 0  0\
 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 1  U I  0\
 O L  0 O D  0 0 D  0 0 P  U I  1 0  U I  D L  0 O  U I  U I  U I  U I\
  U I  U I  0 O D  o U  1 C  0 O D  o U  o U  0 O D  0 O D  0 O D  0 O\
 D  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0\
  0 0 0  0 0 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 O 0  0 \
0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I\
  1 D  D P  U C  U I  1 0  U I  1 1  U I  o C  0 0 0  0 0 0  1 L  1 L \
 0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  1 C  U I  C U  U\
 I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U\
 C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  U I  1 1  U I  1 C  \
U I  1 1  U I  0 0 0  o C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 \
0 0  U I  1 1  U I  o C  0 0 0  0 0 0  o C  1 L  o C  o C  U I  1 1  U\
 I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1\
 1  U I  U C  U C  U I  1 1  U I  U C  0 0 D  0 0 0  0 0 o  0 0 1  C C\
  0 O 0  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O 0  0 O L  0 \
0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 0  1 L  o\
 C  o U  0 O D  o U  o U  U I  P 0  U I  0 0 0  o C  0 0 0  o C  0 0 0\
  1 L  1 L  0 0 0  o C  0 0 0  0 O  U I  U I  U I  U I  U I  U I  0 O \
D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  U I  P 0  U I  o C  0 0\
 0  0 0 0  o C  1 L  o C  o C  0 O  U I  U I  U I  U I  U I  U I  o U \
 0 O D  0 O D  1 C  o U  1 C  o U  1 C  1 C  0 O D  0 O D  o U  1 C  U\
 I  P 0  U I  U C  U C  0 O  U I  U I  U I  U I  U I  U I  o U  1 C  o\
 U  1 C  0 O D  1 C  o U  U I  P 0  U I  U C  U C  0 O  U I  U I  U I \
 U I  U I  U I  C C  0 0 1  0 O 0  0 O O  0 O D  0 0 P  0 0 D  U I  P \
0  U I  U C  U C  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O D  1 C\
  o U  U I  P 0  U I  U C  U C  0 O  U I  U I  U I  U I  U I  U I  0 O\
 D  0 O I  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0\
 0 0  0 0 0  U I  1 P  U I  0 O 1  C o  0 0 D  C D  0 O o  0 O 0  0 I \
0  U I  1 O  U I  U C  0 0 P  0 O 1  0 0 o  0 O C  C L  0 0 O  C o  0 \
O D  0 O L  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I\
  U I  0 0 0  1 L  o C  o U  0 O D  o U  o U  U I  P 0  U I  o C  0 0 \
0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U \
I  U C  0 0 P  0 O 1  0 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  U C\
  U I  C U  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  o C \
 0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 \
P  U I  0 O 1  C o  0 0 D  C D  0 O o  0 O 0  0 I 0  U I  1 O  U I  U \
C  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U C  U I  1 0  U I  D L  0 O \
 U I  U I  U I  U I  U I  U I  U I  0 O D  0 O D  1 C  0 O D  o U  o U\
  1 C  o U  o U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 \
L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  U C  0 O I  C o  0 0 O  C \
o  0 0 1  0 0 P  U C  U I  C U  0 O  U I  U I  U I  U I  U I  U I  0 O\
 D  0 O I  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0\
 0 0  0 0 0  U I  1 P  U I  0 O 1  C o  0 0 D  C D  0 O o  0 O 0  0 I \
0  U I  1 O  U I  U C  0 O O  0 O 0  0 0 D  C C  0 0 1  0 O D  0 0 I  \
0 0 P  0 O D  0 0 0  0 0 O  U C  U I  1 0  U I  D L  0 O  U I  U I  U \
I  U I  U I  U I  U I  o U  0 O D  0 O D  1 C  o U  1 C  o U  1 C  1 C\
  0 O D  0 O D  o U  1 C  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  \
0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  U C  0 O O  0 O 0\
  0 0 D  C C  0 0 1  0 O D  0 0 I  0 0 P  0 O D  0 0 0  0 0 O  U C  U \
I  C U  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  o C  0 0\
 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U\
 I  0 O 1  C o  0 0 D  C D  0 O o  0 O 0  0 I 0  U I  1 O  U I  U C  0\
 O O  C o  0 0 P  0 O 0  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  \
U I  U I  U I  U I  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  P 0  U I\
  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U\
 I  C 0  U I  U C  0 O O  C o  0 0 P  0 O 0  U C  U I  C U  0 O  U I  \
U I  U I  U I  U I  U I  0 O D  0 O I  U I  o C  0 0 0  0 0 0  1 L  1 \
L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 O 1  C o  0 \
0 D  C D  0 O o  0 O 0  0 I 0  U I  1 O  U I  U C  0 O U  0 O 0  0 0 O\
  0 0 1  0 O 0  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I \
 U I  U I  0 O D  0 O D  1 C  o U  U I  P 0  U I  o C  0 0 0  0 0 0  1\
 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  U C  0 O\
 U  0 O 0  0 0 O  0 0 1  0 O 0  U C  U I  C U  0 O  U I  U I  U I  U I\
  U I  U I  0 O D  0 O I  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L\
  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 O 1  C o  0 0 D  C D  0 O\
 o  0 O 0  0 I 0  U I  1 O  U I  U C  C C  0 0 1  0 O 0  0 O O  0 O D \
 0 0 P  0 0 D  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I  \
U I  U I  C C  0 0 1  0 O 0  0 O O  0 O D  0 0 P  0 0 D  U I  P 0  U I\
  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U\
 I  C 0  U I  U C  C C  0 0 1  0 O 0  0 O O  0 O D  0 0 P  0 0 D  U C \
 U I  C U  0 O  U I  U I  U I  U I  U I  U I  0 O D  o U  1 C  0 O D  \
o U  o U  0 O D  0 O D  0 O D  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0\
  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  U C  \
0 0 P  0 O D  0 0 P  0 O L  0 O 0  U C  U I  C U  U I  1 P  U I  0 O 0\
  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0\
 O I  1 D  D P  U C  U I  1 0  U I  1 1  U I  o C  0 0 0  0 0 0  1 L  \
1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  U C  0 0 o  \
0 0 1  0 O L  U C  U I  C U  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  \
0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  \
U I  1 0  U I  1 1  U I  1 C  U I  1 1  U I  0 0 0  1 L  o C  o U  0 O\
 D  o U  o U  U I  1 1  U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  \
o U  o U  U I  1 1  U I  o U  0 O D  0 O D  1 C  o U  1 C  o U  1 C  1\
 C  0 O D  0 O D  o U  1 C  U I  1 1  U I  0 O D  0 O D  1 C  o U  U I\
  1 1  U I  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  1 1  U I  C C  0\
 0 1  0 O 0  0 O O  0 O D  0 0 P  0 0 D  U I  1 1  U I  U C  0 0 D  0 \
0 0  0 0 o  0 0 1  C C  0 O 0  U C  U I  1 0  0 O  U I  U I  U I  U I \
 0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 P  0 0 1  \
C o  C C  0 O 0  C L  C o  C C  0 O o  U I  1 P  U I  0 0 I  0 0 1  0 \
O D  0 0 O  0 0 P  C D  0 O 0  0 I O  C C  U I  1 O  U I  1 0  0 O  U \
I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  0 O \
D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 0 0  0 0 0  o C  \
1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  1 0  U I  P \
0  P 0  U I  1 C  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O I  U I\
  0 O D  0 0 D  0 O D  0 0 O  0 0 D  0 0 P  C o  0 0 O  C C  0 O 0  U \
I  1 O  U I  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  0 0 0  0 0 0  o \
C  0 0 0  1 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  0 O L  0 O\
 D  0 0 D  0 0 P  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I  o \
C  1 L  0 0 0  o C  1 L  U I  1 O  U I  0 0 0  0 0 0  o C  1 L  0 0 0 \
 o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  C 0  U I  1 L  U I  C U\
  U I  C 0  U I  1 C  U I  C U  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 \
0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U \
C  U I  1 0  U I  1 1  U I  o C  0 0 0  0 0 0  o C  1 L  o C  o C  U I\
  1 0  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  \
0 O  U I  U I  U I  U I  U I  o C  1 L  0 0 0  o C  1 L  U I  1 O  U I\
  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0  1\
 L  U I  C 0  U I  1 L  U I  C U  U I  C 0  U I  U C  0 0 o  0 0 1  0 \
O L  U C  U I  C U  U I  1 1  U I  0 0 0  0 0 0  o C  1 L  0 0 0  o C \
 o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  C 0  U I  1 L  U I  C U  U I\
  C 0  U I  U C  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U C  U I  C U  \
U I  1 0  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  \
U I  0 0 P  0 0 1  C o  C C  0 O 0  C L  C o  C C  0 O o  U I  1 P  U \
I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  C D  0 O 0  0 I O  C C  U I  1 O\
  U I  1 0  0 O  U I  0 O D  0 O I  U I  D P  D D  U I  1 D  U I  D P \
 D D  D L  U I  o U  0 O D  o U  o U  U I  1 P  U I  0 0 0  0 0 0  0 0\
 0  1 L  o C  0 0 0  1 L  0 O  0 O O  0 O 0  0 O I  U I  o C  1 L  o C\
  o C  1 L  o C  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  o \
L  0 0 0  0 0 O  0 O 0  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U \
I  0 0 o  0 0 1  0 O L  U I  0 O D  0 0 D  U I  o L  0 0 0  0 0 O  0 O\
 0  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U\
 I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  \
o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O\
 D  0 0 O  0 O U  U I  1 O  U I  U 1  0 0 O  0 O 0  0 0 C  C D  0 O I \
 0 O D  0 O L  0 O 0  C D  0 0 D  0 0 0  0 0 o  0 0 1  C C  0 O 0  U 1\
  U I  1 0  U I  P 0  P 0  U I  U 1  U 1  U I  D L  0 O  U I  U I  U I\
  o C  o C  U I  P 0  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D \
 1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0\
 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 0 O  0 \
O 0  0 0 C  C D  0 O I  0 O D  0 O L  0 O 0  C D  0 0 D  0 0 0  0 0 o \
 0 0 1  C C  0 O 0  U C  U I  1 0  U I  1 P  U I  0 O O  0 O 0  C C  0\
 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P \
 U C  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 0 O \
 0 0 0  0 0 P  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1\
 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0\
 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U 1  0 0 O  0 O 0  0 \
0 C  C D  0 0 o  0 0 1  0 O L  C D  0 0 D  0 0 0  0 0 o  0 0 1  C C  0\
 O 0  U 1  U I  1 0  U I  P 0  P 0  U I  U 1  U 1  U I  D L  0 O  U I \
 U I  U I  o C  o C  U I  P 0  U I  o C  1 L  o U  1 C  1 C  0 O D  1 \
C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 \
P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  \
0 0 O  0 O 0  0 0 C  C D  0 0 o  0 0 1  0 O L  C D  0 0 D  0 0 0  0 0 \
o  0 0 1  C C  0 O 0  U C  U I  1 0  U I  1 P  U I  0 O O  0 O 0  C C \
 0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D \
P  U C  U I  1 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O \
 U I  U I  o C  o C  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O  U I  0 O\
 D  0 O I  U I  o C  o C  U I  P 0  P 0  U I  U C  U C  U I  0 0 0  0 \
0 1  U I  o C  o C  U I  0 O D  0 0 D  U I  o L  0 0 0  0 0 O  0 O 0  \
U I  D L  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O\
  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 \
O  U I  U C  P D  0 O O  0 O O  0 O D  0 0 O  0 O U  U I  o L  0 O 0  \
0 0 C  U I  L U  0 0 0  0 0 o  0 0 1  C C  0 O 0  D L  U I  U C  U I  \
1 U  U I  o C  o C  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 \
O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0 \
 U I  1 0  0 O  U I  0 O D  0 O I  U I  D P  D 0  U I  1 D  U I  D P  \
D 0  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D \
 U I  1 o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 D  U I  \
o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 D  U I  o C  1 L  0 0 0  o\
 C  0 O  U I  0 O D  o U  1 C  0 O D  1 C  1 C  0 O D  o U  o U  1 C  \
1 C  1 C  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  0 O D  0 \
O I  U I  1 C  D U  U I  1 D  U I  1 C  D U  D L  U I  0 0 0  0 0 0  o\
 C  0 0 0  o C  1 L  o C  1 L  1 L  U I  U o  U I  0 O D  1 C  1 C  o \
U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 P  U I  o\
 U  0 O D  o U  o U  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0\
  0 0 0  o C  1 L  0 O  U I  o C  o C  o C  1 L  o C  o C  0 0 0  U I \
 P 0  U I  o C  o C  1 L  o C  o C  o C  o C  0 0 0  0 0 0  1 L  o C  \
o C  o C  U I  1 O  U I  o C  o C  U I  1 0  0 O  U I  0 O D  0 O I  U\
 I  D O  D D  U I  1 D  U I  D O  D D  D L  U I  o C  0 0 0  0 0 0  0 \
0 0  1 L  1 L  1 L  1 L  U I  1 U  U I  o U  0 O D  1 C  o U  0 O  U I\
  0 O D  0 O I  U I  0 O D  0 0 D  0 O D  0 0 O  0 0 D  0 0 P  C o  0 \
0 O  C C  0 O 0  U I  1 O  U I  o C  o C  o C  1 L  o C  o C  0 0 0  U\
 I  1 1  U I  P P  0 O 0  C o  0 0 o  0 0 P  0 O D  0 O I  0 0 o  0 O \
L  L U  o C  P D  L O  U I  1 0  U I  D L  0 O  U I  U I  0 O D  0 O I\
  U I  o C  o C  o C  1 L  o C  o C  0 0 0  U I  1 P  U I  0 O I  0 O \
D  0 0 O  0 O O  U I  1 O  U I  U C  C C  0 O 1  C o  0 0 O  0 0 O  0 \
O 0  0 O L  0 0 D  C D  0 O D  0 0 O  0 O I  0 0 0  U C  U I  1 0  U I\
  D L  0 O  U I  U I  U I  0 O D  o U  1 C  0 O D  1 C  1 C  0 O D  o \
U  o U  1 C  1 C  1 C  U I  P 0  U I  o C  o C  o C  1 L  o C  o C  0 \
0 0  U I  1 P  U I  C C  0 O 1  C o  0 0 O  0 0 O  0 O 0  0 O L  0 0 D\
  C D  0 O D  0 0 O  0 O I  0 0 0  0 O  U I  U I  0 O 0  0 O L  0 O D \
 0 O I  U I  o C  o C  o C  1 L  o C  o C  0 0 0  U I  1 P  U I  0 O I\
  0 O D  0 0 O  0 O O  U I  1 O  U I  U C  0 O D  0 0 P  0 O 0  0 O C \
 0 0 D  C D  0 O D  0 0 O  0 O I  0 0 0  U C  U I  1 0  U I  D L  0 O \
 U I  U I  U I  0 O D  o U  1 C  0 O D  1 C  1 C  0 O D  o U  o U  1 C\
  1 C  1 C  U I  P 0  U I  o C  o C  o C  1 L  o C  o C  0 0 0  U I  1\
 P  U I  0 O D  0 0 P  0 O 0  0 O C  0 0 D  C D  0 O D  0 0 O  0 O I  \
0 0 0  0 O  U I  0 O D  0 O I  U I  0 O D  o U  1 C  0 O D  1 C  1 C  \
0 O D  o U  o U  1 C  1 C  1 C  U I  D L  0 O  U I  U I  0 0 0  1 L  o\
 C  0 0 0  1 L  1 L  U I  P 0  U I  0 I U  U I  0 I D  0 O  U I  U I  \
0 0 0  1 L  o C  0 0 0  1 L  1 L  U I  C 0  U I  U C  0 0 o  0 0 1  0 \
O L  U C  U I  C U  U I  P 0  U I  o C  o C  0 O  U I  U I  0 0 P  0 0\
 1  0 I 0  U I  D L  U I  0 0 0  1 L  o C  0 0 0  1 L  1 L  U I  C 0  \
U I  U C  0 0 P  0 O D  0 0 P  0 O L  0 O 0  U C  U I  C U  U I  P 0  \
U I  0 O D  o U  1 C  0 O D  1 C  1 C  0 O D  o U  o U  1 C  1 C  1 C \
 U I  1 P  U I  0 0 P  0 O D  0 0 P  0 O L  0 O 0  U I  1 P  U I  0 0 \
D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  0 O 0  0 I O  C C\
  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U\
 I  U I  0 0 P  0 0 1  0 I 0  U I  D L  U I  0 0 0  1 L  o C  0 0 0  1\
 L  1 L  U I  C 0  U I  U C  0 0 P  0 O 1  0 0 o  0 O C  C L  0 0 O  C\
 o  0 O D  0 O L  U C  U I  C U  U I  P 0  U I  0 O D  o U  1 C  0 O D\
  1 C  1 C  0 O D  o U  o U  1 C  1 C  1 C  U I  1 P  U I  0 0 P  0 O \
1  0 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  U I  1 P  U I  0 0 D  \
0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  0 O 0  0 I O  C C  0\
 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I \
 U I  0 0 P  0 0 1  0 I 0  U I  D L  U I  0 0 0  1 L  o C  0 0 0  1 L \
 1 L  U I  C 0  U I  U C  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U C  U\
 I  C U  U I  P 0  U I  0 O D  o U  1 C  0 O D  1 C  1 C  0 O D  o U  \
o U  1 C  1 C  1 C  U I  1 P  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 \
P  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  \
U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o\
  0 0 D  0 0 D  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  U I  0 0\
 0  1 L  o C  0 0 0  1 L  1 L  U I  C 0  U I  U C  0 O U  0 O 0  0 0 O\
  0 0 1  0 O 0  U C  U I  C U  U I  P 0  U I  0 O D  o U  1 C  0 O D  \
1 C  1 C  0 O D  o U  o U  1 C  1 C  1 C  U I  1 P  U I  0 O U  0 O 0 \
 0 0 O  0 0 1  0 O 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O\
  0 O U  0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D\
 L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  U I  0 0 P  0 0 1  0 I 0 \
 U I  D L  U I  0 0 0  1 L  o C  0 0 0  1 L  1 L  U I  C 0  U I  U C  \
0 O O  0 O 0  0 0 D  C C  0 0 1  0 O D  0 0 I  0 0 P  0 O D  0 0 0  0 \
0 O  U C  U I  C U  U I  P 0  U I  0 O D  o U  1 C  0 O D  1 C  1 C  0\
 O D  o U  o U  1 C  1 C  1 C  U I  1 P  U I  0 O O  0 O 0  0 0 D  C C\
  0 0 1  0 O D  0 0 I  0 0 P  0 O D  0 0 0  0 0 O  U I  1 P  U I  0 0 \
D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  0 O 0  0 I O  C C\
  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U\
 I  U I  0 0 P  0 0 1  0 I 0  U I  D L  U I  0 0 0  1 L  o C  0 0 0  1\
 L  1 L  U I  C 0  U I  U C  0 O O  C o  0 0 P  0 O 0  U C  U I  C U  \
U I  P 0  U I  0 O D  o U  1 C  0 O D  1 C  1 C  0 O D  o U  o U  1 C \
 1 C  1 C  U I  1 P  U I  0 O O  C o  0 0 P  0 O 0  U I  1 P  U I  0 0\
 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  0 O 0  0 I O  C \
C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  \
U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  U I  0 0 0  1 L  o C  0 0 0  \
1 L  1 L  U I  C 0  U I  U C  C C  0 0 1  0 O 0  0 O O  0 O D  0 0 P  \
0 0 D  U C  U I  C U  U I  P 0  U I  0 O D  o U  1 C  0 O D  1 C  1 C \
 0 O D  o U  o U  1 C  1 C  1 C  U I  1 P  U I  C C  0 0 1  0 O 0  0 O\
 O  0 O D  0 0 P  0 0 D  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 \
0 O  0 O U  0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I\
  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  0 O 0  0 O L  0 0 D  0\
 O 0  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  U C  1 o  U C  U I  \
0 O D  0 0 O  U I  o C  o C  U I  D L  0 O  U I  U I  U I  0 O D  o U \
 U I  P 0  U I  o C  o C  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0\
 0 P  U I  1 O  U I  U C  1 o  U C  U I  1 0  U I  C 0  U I  1 D  U I \
 1 C  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I \
 1 O  U I  U C  1 P  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O \
 U I  U I  0 O D  0 O I  U I  U C  C I  C I  U C  U I  0 O D  0 0 O  U\
 I  o C  o C  U I  D L  0 O  U I  U I  U I  0 O D  o U  U I  P 0  U I \
 o C  o C  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O \
 U I  U C  C I  C I  U C  U I  1 0  U I  C 0  U I  1 D  U I  1 C  U I \
 C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I \
 U C  1 P  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U I \
 0 O D  0 O I  U I  U C  U o  U C  U I  0 O D  0 0 O  U I  0 O D  o U \
 U I  D L  0 O  U I  U I  U I  0 O D  o U  U I  P 0  U I  0 0 o  0 0 1\
  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 o  0 0 O  0 0 U  0 0 o \
 0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  \
0 O D  o U  U I  1 0  0 O  U I  U I  o C  1 L  o C  1 L  o C  0 0 0  0\
 0 0  0 0 0  1 L  0 0 0  U I  P 0  U I  0 I O  C L  0 O C  C C  U I  1\
 P  U I  o D  0 O 0  0 I 0  C L  0 0 0  C o  0 0 1  0 O O  U I  1 O  U\
 I  0 O D  o U  U I  1 1  U I  U C  P L  0 O D  0 0 D  0 0 I  0 O L  C\
 o  0 I 0  0 O 0  0 O O  U I  o L  C o  0 O C  0 O 0  1 1  U I  L I  0\
 O 0  0 0 O  C o  0 O C  0 O 0  P U  U C  U I  1 0  0 O  U I  U I  o C\
  1 L  o C  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  0 0 0  U I  1 P  U I  \
0 O O  0 0 0  o o  0 0 0  0 O O  C o  0 O L  U I  1 O  U I  1 0  0 O  \
U I  U I  0 O D  0 O I  U I  1 O  U I  o C  1 L  o C  1 L  o C  0 0 0 \
 0 0 0  0 0 0  1 L  0 0 0  U I  1 P  U I  0 O D  0 0 D  P o  0 0 0  0 \
0 O  0 O I  0 O D  0 0 1  0 O C  0 O 0  0 O O  U I  1 O  U I  1 0  U I\
  P 0  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  U I  1 0  U I  D L  0 \
O  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O  U I  \
U I  0 0 0  o C  o C  0 0 0  0 0 0  1 L  1 L  o C  1 L  1 L  0 0 0  U \
I  P 0  U I  o C  1 L  o C  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  0 0 0 \
 U I  1 P  U I  0 O U  0 O 0  0 0 P  L 1  0 O 0  0 I O  0 0 P  U I  1 \
O  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U \
I  1 O  U I  0 0 0  o C  o C  0 0 0  0 0 0  1 L  1 L  o C  1 L  1 L  0\
 0 0  U I  1 0  U I  P 0  P 0  U I  1 L  U I  D L  0 O  U I  U I  U I \
 0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O  U I  U I  0 0 0  1 L  \
o C  0 0 0  1 L  1 L  U I  P 0  U I  0 I U  U I  0 I D  0 O  U I  U I \
 0 0 0  1 L  o C  0 0 0  1 L  1 L  U I  C 0  U I  U C  0 0 P  0 O D  0\
 0 P  0 O L  0 O 0  U C  U I  C U  U I  P 0  U I  0 0 0  o C  o C  0 0\
 0  0 0 0  1 L  1 L  o C  1 L  1 L  0 0 0  0 O  U I  U I  0 0 0  1 L  \
o C  0 0 0  1 L  1 L  U I  C 0  U I  U C  0 0 o  0 0 1  0 O L  U C  U \
I  C U  U I  P 0  U I  o C  o C  0 O  U I  U I  0 0 0  1 L  o C  0 0 0\
  1 L  1 L  U I  C 0  U I  U C  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  \
U C  U I  C U  U I  P 0  U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C \
 o U  o U  0 O  U I  U I  0 O D  0 O I  U I  D o  D P  U I  1 D  U I  \
D o  D P  D L  U I  o C  1 L  0 0 0  o C  U I  1 U  U I  0 0 0  0 0 0 \
 0 0 0  1 L  o C  0 0 0  1 L  U I  1 U  U I  o U  o U  o U  o U  U I  \
U o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  0 O D  0 \
O I  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  \
1 P  U I  0 O 0  0 I O  0 O D  0 0 D  0 0 P  0 0 D  U I  1 O  U I  0 O\
 D  0 O D  0 O D  o U  0 O D  U I  1 0  U I  P 0  P 0  U I  o O  C o  \
0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 0 0  0 0 0  0 0 0  0 0\
 0  0 0 0  0 0 0  1 L  o C  1 L  1 L  1 L  0 0 0  U I  P 0  U I  C 0  \
U I  C U  0 O  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  1 L\
  o C  1 L  1 L  1 L  0 0 0  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  \
0 0 O  0 O O  U I  1 O  U I  0 0 0  1 L  o C  0 0 0  1 L  1 L  U I  1 \
0  0 O  U I  U I  o C  0 0 0  o C  U I  P 0  U I  0 0 0  0 0 I  0 O 0 \
 0 0 O  U I  1 O  U I  0 O D  0 O D  0 O D  o U  0 O D  U I  1 1  U I \
 U 1  0 0 C  U 1  U I  1 0  0 O  U I  U I  o C  0 0 0  o C  U I  1 P  \
U I  0 0 C  0 0 1  0 O D  0 0 P  0 O 0  U I  1 O  U I  0 O P  0 0 D  0\
 0 0  0 0 O  U I  1 P  U I  0 O O  0 0 o  0 O C  0 0 I  0 0 D  U I  1 \
O  U I  0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  1 L  o C  1 L  1 L  \
1 L  0 0 0  U I  1 0  U I  1 0  0 O  U I  U I  o C  0 0 0  o C  U I  1\
 P  U I  C C  0 O L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I\
  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 0 0  0 0 0  o\
 C  1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  P 0  U I\
  0 O P  0 0 D  0 0 0  0 0 O  U I  1 P  U I  0 O L  0 0 0  C o  0 O O \
 0 0 D  U I  1 O  U I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  0 O \
D  0 O D  0 O D  o U  0 O D  U I  1 1  U I  U 1  0 0 1  U 1  U I  1 0 \
 U I  1 P  U I  0 0 1  0 O 0  C o  0 O O  U I  1 O  U I  1 0  U I  1 0\
  0 O  U I  U I  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  0 0 0  0 0 0\
  o C  0 0 0  1 L  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O\
 O  U I  1 O  U I  0 0 0  1 L  o C  0 0 0  1 L  1 L  U I  1 0  0 O  U \
I  U I  o C  0 0 0  o C  U I  P 0  U I  0 0 0  0 0 I  0 O 0  0 0 O  U \
I  1 O  U I  0 O D  0 O D  0 O D  o U  0 O D  U I  1 1  U I  U 1  0 0 \
C  U 1  U I  1 0  0 O  U I  U I  o C  0 0 0  o C  U I  1 P  U I  0 0 C\
  0 0 1  0 O D  0 0 P  0 O 0  U I  1 O  U I  0 O P  0 0 D  0 0 0  0 0 \
O  U I  1 P  U I  0 O O  0 0 o  0 O C  0 0 I  0 0 D  U I  1 O  U I  0 \
0 0  0 0 0  o C  1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  \
U I  1 0  U I  1 0  0 O  U I  U I  o C  0 0 0  o C  U I  1 P  U I  C C\
  0 O L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  o C  1 L  \
o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P \
 U I  0 0 D  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O\
 U  U I  1 O  U I  U C  0 0 O  0 O 0  0 0 C  C D  0 0 o  0 0 1  0 O L \
 C D  0 0 D  0 0 0  0 0 o  0 0 1  C C  0 O 0  U C  U I  1 1  U I  U 1 \
 U 1  U I  1 0  0 O  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  \
1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L U  0 \
O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 0 O  0 O\
 0  0 0 C  C D  0 O I  0 O D  0 O L  0 O 0  C D  0 0 D  0 0 0  0 0 o  \
0 0 1  C C  0 O 0  U C  U I  1 1  U I  U 1  U 1  U I  1 0  0 O  U I  0\
 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o \
 0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O\
  U I  U 1  L L  P P  o o  P o  1 P  o L  0 0 0  0 0 P  0 O D  0 O I  \
0 O D  C C  C o  0 0 P  0 O D  0 0 0  0 0 O  1 O  L 1  0 O 0  C o  0 O\
 C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  1 1  o L  0 O 0  0 0 C  U \
I  0 0 D  0 0 0  0 0 o  0 0 1  C C  0 O 0  U I  C o  0 O O  0 O O  0 O\
 0  0 O O  1 P  1 1  D U  1 L  1 L  1 L  1 1  U 1  U I  1 U  U I  0 0 \
0  o C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U I  1 U  U I \
 U 1  1 0  U 1  U I  1 0  0 O  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0\
 0 P  U I  0 0 o  0 0 1  0 O L  U I  0 O D  0 0 D  U I  o L  0 0 0  0 \
0 O  0 O 0  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  U C  0 I O  C \
L  0 O C  C C  0 0 I  0 O L  0 0 o  0 0 D  1 P  0 I O  C L  1 P  0 O I\
  0 0 o  0 0 O  0 0 I  0 O D  C C  1 P  0 O O  0 O 0  U C  U I  0 O D \
 0 0 O  U I  0 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  U I  0 I O \
 C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 \
P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O  U I\
  U 1  L L  P P  o o  P o  1 P  P o  0 0 0  0 0 O  0 0 P  C o  0 O D  \
0 0 O  0 O 0  0 0 1  1 P  L D  0 0 I  0 O O  C o  0 0 P  0 O 0  1 O  U\
 o  0 0 D  P U  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D I  1 1  0 0 1 \
 0 O 0  0 0 I  0 O L  C o  C C  0 O 0  1 0  U 1  U I  U o  U I  0 0 D \
 0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I \
 1 L  U I  C U  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 O D  0 O I  U\
 I  U C  C C  0 0 0  0 O C  0 O C  0 0 o  0 0 O  0 O D  0 0 P  0 I 0  \
1 D  0 O L  0 O D  0 0 O  0 O o  0 0 D  U C  U I  0 O D  0 0 O  U I  0\
 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  U I  0 I O  C L  0 O C  C\
 C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  0 O 0  C L \
 0 0 o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O  U I  U 1  L L  P \
P  o o  P o  1 P  P o  0 0 0  0 0 O  0 0 P  C o  0 O D  0 0 O  0 O 0  \
0 0 1  1 P  L D  0 0 I  0 O O  C o  0 0 P  0 O 0  1 O  U o  0 0 D  P U\
  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  1 L  1 1  0 0 1  0 O 0  0 0 I \
 0 O L  C o  C C  0 O 0  1 0  U 1  U I  U o  U I  0 0 D  0 I 0  0 0 D \
 U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U\
  U I  1 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  U I  o C  \
1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I \
 1 P  U I  0 0 0  0 0 I  0 O 0  0 0 O  L U  0 O 0  0 0 P  0 0 P  0 O D\
  0 0 O  0 O U  0 0 D  U I  1 O  U I  1 0  0 O  U I  0 O D  0 O I  U I\
  D U  1 C  U I  1 D  U I  D U  1 C  D L  U I  o C  o C  0 0 0  0 0 0 \
 o C  o C  0 0 0  U I  1 I  U I  o C  1 L  0 0 0  o C  0 O  0 O O  0 O\
 0  0 O I  U I  o C  o C  1 L  0 0 0  0 0 0  o C  o C  o C  1 L  o C  \
o C  o C  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  U I  D L \
 0 O  U I  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C \
 0 0 0  1 L  U I  P 0  U I  0 O P  0 0 D  0 0 0  0 0 O  U I  1 P  U I \
 0 O L  0 0 0  C o  0 O O  0 0 D  U I  1 O  U I  0 0 0  0 0 I  0 O 0  \
0 0 O  U I  1 O  U I  0 O D  0 O D  0 O D  o U  0 O D  U I  1 1  U I  \
U 1  0 0 1  U 1  U I  1 0  U I  1 P  U I  0 0 1  0 O 0  C o  0 O O  U \
I  1 O  U I  1 0  U I  1 0  0 O  U I  0 O I  0 0 0  0 0 1  U I  0 0 0 \
 o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1 L \
 U I  0 O D  0 0 O  U I  0 0 1  C o  0 0 O  0 O U  0 O 0  U I  1 O  U \
I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 0 0  0 0 0  o C  1 L  0 0 0  \
o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  1 0  U I  1 0  U I  D L \
 0 O  U I  U I  0 O D  0 O I  U I  0 O D  0 0 D  0 O D  0 0 O  0 0 D  \
0 0 P  C o  0 0 O  C C  0 O 0  U I  1 O  U I  0 0 0  0 0 0  o C  1 L  \
0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  C 0  U I  0 0 0  \
o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1 L  \
U I  C U  U I  1 1  U I  0 O L  0 O D  0 0 D  0 0 P  U I  1 0  U I  D \
L  0 O  U I  U I  U I  0 O D  0 O I  U I  0 0 0  0 0 0  o C  1 L  0 0 \
0  o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  C 0  U I  0 0 0  o C \
 1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1 L  U I \
 C U  U I  C 0  U I  1 L  U I  C U  U I  P 0  P 0  U I  0 0 O  C o  0 \
O C  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 O O  0 O 0  0 O L  U \
I  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0  \
1 L  U I  C 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o \
C  0 0 0  o C  0 0 0  1 L  U I  C U  0 O  U I  U I  U I  U I  o C  0 0\
 0  o C  U I  P 0  U I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  0 O\
 D  0 O D  0 O D  o U  0 O D  U I  1 1  U I  U 1  0 0 C  U 1  U I  1 0\
  0 O  U I  U I  U I  U I  o C  0 0 0  o C  U I  1 P  U I  0 0 C  0 0 \
1  0 O D  0 0 P  0 O 0  U I  1 O  U I  0 O P  0 0 D  0 0 0  0 0 O  U I\
  1 P  U I  0 O O  0 0 o  0 O C  0 0 I  0 0 D  U I  1 O  U I  0 0 0  0\
 0 0  o C  1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  1\
 0  U I  1 0  0 O  U I  U I  U I  U I  o C  0 0 0  o C  U I  1 P  U I \
 C C  0 O L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  U I  U\
 I  U I  C L  0 0 1  0 O 0  C o  0 O o  0 O  U I  U I  0 O 0  0 O L  0\
 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  0 O D  0 O I  U I  0 0 0  0\
 0 0  o C  1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  C\
 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o\
 C  0 0 0  1 L  U I  C U  U I  C 0  U I  U C  0 0 P  0 O D  0 0 P  0 O\
 L  0 O 0  U C  U I  C U  U I  P 0  P 0  U I  0 0 O  C o  0 O C  0 O 0\
  U I  D L  0 O  U I  U I  U I  U I  0 O O  0 O 0  0 O L  U I  0 0 0  \
0 0 0  o C  1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  \
C 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  \
o C  0 0 0  1 L  U I  C U  0 O  U I  U I  U I  U I  o C  0 0 0  o C  U\
 I  P 0  U I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  0 O D  0 O D \
 0 O D  o U  0 O D  U I  1 1  U I  U 1  0 0 C  U 1  U I  1 0  0 O  U I\
  U I  U I  U I  o C  0 0 0  o C  U I  1 P  U I  0 0 C  0 0 1  0 O D  \
0 0 P  0 O 0  U I  1 O  U I  0 O P  0 0 D  0 0 0  0 0 O  U I  1 P  U I\
  0 O O  0 0 o  0 O C  0 0 I  0 0 D  U I  1 O  U I  0 0 0  0 0 0  o C \
 1 L  0 0 0  o C  o C  0 0 0  0 0 0  o C  0 0 0  1 L  U I  1 0  U I  1\
 0  0 O  U I  U I  U I  U I  o C  0 0 0  o C  U I  1 P  U I  C C  0 O \
L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  U I  U I  U I  C\
 L  0 0 1  0 O 0  C o  0 O o  0 O  U I  0 I O  C L  0 O C  C C  U I  1\
 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 o  0 \
O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O  U I  U 1  L L  P P  o o  P \
o  1 P  P o  0 0 0  0 0 O  0 0 P  C o  0 O D  0 0 O  0 O 0  0 0 1  1 P\
  L I  0 O 0  0 O I  0 0 1  0 O 0  0 0 D  0 O 1  U 1  U I  1 0  0 O  U\
 I  0 O D  0 O I  U I  D D  D I  U I  1 D  U I  D D  D I  D L  U I  0 \
0 0  o C  1 L  0 0 0  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 \
0  0 0 0  o C  1 L  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L \
 0 0 0  U I  1 o  U I  o U  1 C  1 C  0 O D  U I  1 o  U I  o U  0 O D\
  1 C  o U  U I  1 P  U I  o U  0 O D  o U  o U  0 O  0 O O  0 O 0  0 \
O I  U I  0 0 0  0 0 0  0 0 0  o C  0 0 0  1 L  o C  o C  o C  0 0 0  \
0 0 0  1 L  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  C L  0 \
0 1  0 0 0  0 0 C  0 0 D  0 O 0  U I  P 0  U I  o O  C o  0 O L  0 0 D\
  0 O 0  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  0 0 o  0 0 1\
  0 O L  U I  0 O D  0 0 D  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0\
 O  U I  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  U C  0 O 1  0 0 P  0\
 0 P  0 0 I  D L  1 o  1 o  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 \
o  0 0 D  1 P  0 I O  C L  1 P  0 O I  0 0 o  0 0 O  0 0 I  0 O D  C C\
  1 P  0 O O  0 O 0  1 o  0 0 C  0 0 C  0 0 C  1 D  0 O O  C o  0 0 P \
 C o  1 o  0 O I  0 O D  0 O L  0 O 0  0 0 D  0 I 0  0 0 D  0 0 P  0 O\
 0  0 O C  1 o  U C  0 O  U I  o C  o C  0 0 0  o C  U I  P 0  U I  P \
P  0 O 0  C o  0 0 o  0 0 P  0 O D  0 O I  0 0 o  0 O L  L U  0 0 0  0\
 0 o  0 0 I  U I  1 O  U I  0 O D  0 O D  1 C  o U  1 C  0 O D  1 C  o\
 U  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 0  U I  1 1  U I  C C  \
0 0 0  0 0 O  0 0 L  0 O 0  0 0 1  0 0 P  P C  0 0 O  0 0 P  0 O D  0 \
0 P  0 O D  0 O 0  0 0 D  U I  P 0  U I  P P  0 O 0  C o  0 0 o  0 0 P\
  0 O D  0 O I  0 0 o  0 O L  L U  0 0 0  0 0 o  0 0 I  U I  1 P  U I \
 o I  L 1  o o  o P  C D  P C  o L  L 1  o U  L 1  o U  P C  L U  U I \
 1 0  0 O  U I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L \
 0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  o C  o \
C  0 0 0  o C  U I  1 O  U I  U C  C o  U C  U I  1 0  U I  D L  0 O  \
U I  U I  o C  o C  1 L  o C  1 L  1 L  1 L  U I  P 0  U I  o C  0 0 0\
  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I\
  U C  0 O 1  0 0 1  0 O 0  0 O I  U C  U I  C U  0 O  U I  U I  0 O D\
  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  o C  1 L  o C  1 L  1 L  \
1 L  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O\
 D  0 0 P  0 O 1  U I  1 O  U I  U C  P U  U C  U I  1 0  U I  D L  0 \
O  U I  U I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  o C  0 0\
 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U\
 I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  0 O \
D  0 O I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  0 0 O  0 0 0  0 0 P  \
U I  0 O D  0 0 O  U I  C 0  U I  U C  L O  C o  0 0 1  0 O 0  0 0 O  \
0 0 P  U I  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0 \
 U C  U I  1 1  U I  U C  0 0 1  0 O 0  C C  0 I 0  C C  0 O L  0 O 0 \
 C D  C L  0 O D  0 0 O  1 o  U C  U I  C U  U I  D L  0 O  U I  U I  \
U I  U I  0 O D  0 O I  U I  o C  o C  1 L  o C  1 L  1 L  1 L  U I  1\
 P  U I  0 O 0  0 0 O  0 O O  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  \
1 O  U I  U C  1 o  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  \
U I  0 O D  0 O I  U I  C L  0 0 1  0 0 0  0 0 C  0 0 D  0 O 0  U I  D\
 L  0 O  U I  U I  U I  U I  U I  U I  0 O D  o U  1 C  0 O D  o U  o \
U  0 O D  0 O D  0 O D  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0  o C  \
1 L  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 U  U I  o C  o C  1 L \
 o C  1 L  1 L  1 L  U I  1 1  U I  1 C  D U  U I  1 1  U I  0 0 0  o \
C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U I  1 1  U I  0 O \
D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  U I  1 1  U I  U C  U C\
  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 0  0 O  U I\
  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  \
U I  U I  U I  U I  U I  0 O D  o U  1 C  0 O D  o U  o U  0 O D  0 O \
D  0 O D  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1 \
 U I  0 0 o  0 0 1  0 O L  U I  1 U  U I  o C  o C  1 L  o C  1 L  1 L\
  1 L  U I  1 1  U I  1 C  D I  U I  1 1  U I  0 0 0  o C  0 0 0  o C \
 0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U I  1 1  U I  0 O D  0 O D  1 C \
 0 O D  o U  o U  1 C  o U  o U  U I  1 1  U I  U C  U C  U I  1 1  U \
I  U C  U C  U I  1 1  U I  U C  U C  U I  1 0  0 O  U I  U I  U I  U \
I  0 O 0  0 O L  0 O D  0 O I  U I  o C  o C  1 L  o C  1 L  1 L  1 L \
 U I  1 P  U I  0 O 0  0 0 O  0 O O  0 0 D  0 0 C  0 O D  0 0 P  0 O 1\
  U I  1 O  U I  U C  1 P  0 I O  0 O C  0 O L  U C  U I  1 0  U I  D \
L  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  C L  0 0 1  0 0 0 \
 0 0 C  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O\
 D  o U  1 C  0 O D  o U  o U  0 O D  0 O D  0 O D  0 O D  U I  1 O  U\
 I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  0 0 o  0 0 1  0 O L  U\
 I  1 U  U I  o C  o C  1 L  o C  1 L  1 L  1 L  U I  1 1  U I  1 C  U\
 I  1 1  U I  0 0 0  o C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0\
 0  U I  1 1  U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  \
U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  \
U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  0 O O  0 0 0  0 0 C \
 0 0 O  0 O L  0 0 0  C o  0 O O  U C  U I  1 0  0 O  U I  U I  U I  U\
 I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I\
  U I  U I  0 O D  0 O I  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 I  C o\
  0 0 P  0 O 1  U I  1 P  U I  0 O 0  0 I O  0 O D  0 0 D  0 0 P  0 0 \
D  U I  1 O  U I  0 O D  0 O D  0 O D  o U  0 O D  U I  1 0  U I  P 0 \
 P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I  D L  0 O  U I  U I  U I  U I\
  U I  U I  U I  0 O D  0 O I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  \
0 O D  0 0 O  U I  o U  1 C  1 C  o U  1 C  1 C  0 O D  1 C  o U  U I \
 D L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  0 O D  o U  1 C  0 \
O D  o U  o U  0 O D  0 O D  0 O D  0 O D  U I  1 O  U I  o C  0 0 0  \
0 0 0  o C  1 L  U I  1 U  U I  U C  U I  1 O  0 O D  0 0 O  U I  0 0 \
o  0 0 D  0 O 0  1 0  U C  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 \
U  U I  o C  o C  1 L  o C  1 L  1 L  1 L  U I  1 1  U I  1 C  1 C  U \
I  1 1  U I  0 0 0  o C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 \
0  U I  1 1  U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  U\
 I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U\
 C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  0 O O  0 0 0  0 0 C  \
0 0 O  0 O L  0 0 0  C o  0 O O  U C  U I  1 0  0 O  U I  U I  U I  U \
I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I \
 U I  U I  U I  U I  U I  U I  0 O D  o U  1 C  0 O D  o U  o U  0 O D\
  0 O D  0 O D  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I\
  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 U  U I  o C  o C  1 L  o C  1 \
L  1 L  1 L  U I  1 1  U I  1 C  1 C  U I  1 1  U I  0 0 0  o C  0 0 0\
  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U I  1 1  U I  0 O D  0 O D\
  1 C  0 O D  o U  o U  1 C  o U  o U  U I  1 1  U I  U C  U C  U I  1\
 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U\
 I  1 1  U I  U C  0 O O  0 0 0  0 0 C  0 0 O  0 O L  0 0 0  C o  0 O \
O  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 O 0  0 O L  0 0\
 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  o \
U  1 C  0 O D  o U  o U  0 O D  0 O D  0 O D  0 O D  U I  1 O  U I  o \
C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 \
U  U I  o C  o C  1 L  o C  1 L  1 L  1 L  U I  1 1  U I  1 C  1 C  U \
I  1 1  U I  0 0 0  o C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 \
0  U I  1 1  U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  U\
 I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U\
 C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  0 O O  0 0 0  0 0 C  \
0 0 O  0 O L  0 0 0  C o  0 O O  U C  U I  1 0  0 O  U I  U I  U I  U \
I  U I  U I  U I  0 O D  0 O I  U I  D 0  D D  U I  1 D  U I  D 0  D D\
  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I  o \
U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 D  U I  0\
 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  U I  U I  U I  U I  \
U I  U I  0 O D  0 O I  U I  D D  D D  U I  1 D  U I  D D  D D  D L  U\
 I  o C  1 L  0 0 0  o C  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  0 O  \
0 O O  0 O 0  0 O I  U I  0 0 0  o C  1 L  1 L  0 0 0  o C  o C  0 0 0\
  0 0 0  0 0 0  o C  U I  1 O  U I  C L  0 0 1  0 0 0  0 0 C  0 0 D  0\
 O 0  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  U I  1 0  U I  D L\
  0 O  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  P 0  U \
I  U C  0 O 1  0 0 P  0 0 P  0 0 I  D L  1 o  1 o  C C  0 0 0  0 O C  \
0 O C  0 0 o  0 0 O  0 O D  0 0 P  0 I 0  1 D  0 O L  0 O D  0 0 O  0 \
O o  0 0 D  1 P  0 O U  0 0 0  0 0 0  0 O U  0 O L  0 O 0  C C  0 0 0 \
 0 O O  0 O 0  1 P  C C  0 0 0  0 O C  1 o  0 0 D  0 0 L  0 0 O  1 o  \
0 0 P  0 0 1  0 0 o  0 0 O  0 O o  1 o  U C  0 O  U I  o C  o C  0 0 0\
  o C  U I  P 0  U I  P P  0 O 0  C o  0 0 o  0 0 P  0 O D  0 O I  0 0\
 o  0 O L  L U  0 0 0  0 0 o  0 0 I  U I  1 O  U I  0 O D  0 O D  1 C \
 o U  1 C  0 O D  1 C  o U  U I  1 O  U I  o U  0 O D  o U  0 O D  1 C\
  1 C  0 O D  o U  U I  1 0  U I  1 1  U I  C C  0 0 0  0 0 O  0 0 L  \
0 O 0  0 0 1  0 0 P  P C  0 0 O  0 0 P  0 O D  0 0 P  0 O D  0 O 0  0 \
0 D  U I  P 0  U I  P P  0 O 0  C o  0 0 o  0 0 P  0 O D  0 O I  0 0 o\
  0 O L  L U  0 0 0  0 0 o  0 0 I  U I  1 P  U I  o I  L 1  o o  o P  \
C D  P C  o L  L 1  o U  L 1  o U  P C  L U  U I  1 0  0 O  U I  o C  \
0 0 0  1 L  o C  1 L  1 L  o C  1 L  1 L  1 L  U I  P 0  U I  o C  o C\
  0 0 0  o C  U I  1 O  U I  U C  0 0 o  0 O L  U C  U I  1 0  U I  C \
0  U I  1 L  U I  C U  U I  1 O  U I  U C  0 O L  0 O D  U C  U I  1 0\
  U I  C 0  U I  1 C  U I  D L  U I  C U  0 O  U I  0 O I  0 0 0  0 0 \
1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 \
0 0  U I  0 O D  0 0 O  U I  o C  0 0 0  1 L  o C  1 L  1 L  o C  1 L \
 1 L  1 L  U I  D L  0 O  U I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  \
P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  \
0 0 0  U I  1 O  U I  U C  C o  U C  U I  1 0  U I  C 0  U I  1 L  U I\
  C U  U I  C 0  U I  U C  0 O 1  0 0 1  0 O 0  0 O I  U C  U I  C U  \
0 O  U I  U I  0 O D  0 O I  U I  C L  0 0 1  0 0 0  0 0 C  0 0 D  0 O\
 0  U I  D L  0 O  U I  U I  U I  0 O D  o U  1 C  0 O D  o U  o U  0 \
O D  0 O D  0 O D  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  \
U I  1 1  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 U \
 U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  1 C  U I  1 1  U I  \
0 0 0  o C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U I  1 1  \
U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  U I  1 1  U I \
 U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1 \
 U I  U C  U C  U I  1 1  U I  U C  0 O O  0 0 0  0 0 C  0 0 O  0 O L \
 0 0 0  C o  0 O O  U C  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 0 D \
 0 O 0  U I  D L  0 O  U I  U I  U I  0 O D  o U  1 C  0 O D  o U  o U\
  0 O D  0 O D  0 O D  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1\
 L  U I  1 1  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  \
1 U  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  1 C  1 C  U I  1\
 1  U I  0 0 0  o C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U\
 I  1 1  U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  U I  \
1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  \
U I  1 1  U I  U C  U C  U I  1 1  U I  U C  0 O O  0 0 0  0 0 C  0 0 \
O  0 O L  0 0 0  C o  0 O O  U C  U I  1 0  0 O  U I  U I  U I  0 O D \
 0 O I  U I  D 0  U I  1 D  U I  D 0  D L  U I  0 O D  1 C  1 C  o U  \
0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 I  U I  0 0 \
0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  U o  U I  0 0 0 \
 1 L  0 0 0  o C  1 L  0 O  0 O O  0 O 0  0 O I  U I  o C  o C  1 L  o\
 C  o C  o C  o C  0 0 0  0 0 0  1 L  o C  o C  o C  U I  1 O  U I  0 \
0 o  0 0 1  0 O L  U I  1 1  U I  0 O O  C o  0 0 P  C o  U I  P 0  U \
I  o L  0 0 0  0 0 O  0 O 0  U I  1 0  U I  D L  0 O  U I  0 O U  0 O \
L  0 0 0  C L  C o  0 O L  U I  0 0 0  0 0 0  1 L  1 L  1 L  U I  1 1 \
 U I  0 O D  0 O D  U I  1 1  U I  0 O D  o U  1 C  1 C  o U  1 C  o U\
  o U  1 C  o U  1 C  o U  0 O  U I  0 O D  0 O D  U I  P 0  U I  o O \
 C o  0 O L  0 0 D  0 O 0  0 O  U I  0 O D  o U  1 C  1 C  o U  1 C  o\
 U  o U  1 C  o U  1 C  o U  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 \
O 0  0 O  U I  0 O D  0 O I  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  \
0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U \
I  1 O  U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  D L  1 o  1 o  U C  U I \
 1 0  U I  0 0 0  0 0 1  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 \
D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1\
 O  U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  0 0 D  D L  1 o  1 o  U C  U\
 I  1 0  U I  D L  0 O  U I  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  \
1 L  0 0 0  0 0 0  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  0 O  \
U I  U I  0 O D  0 O I  U I  U C  U P  U P  L 1  L U  P L  o C  L o  o\
 L  o P  o C  P D  P L  P C  L I  U P  U P  U C  U I  0 O D  0 0 O  U \
I  0 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  U I  0 O D  0 O D  U \
I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  0 O  U I  U I  U I  0 0 o  0 0 \
1  0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 1  0 \
O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U 1  U P  U P  L 1 \
 L U  P L  o C  L o  o L  o P  o C  P D  P L  P C  L I  U P  U P  U 1 \
 U I  1 1  U I  U 1  U 1  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  \
U C  U P  U P  o I  o P  L U  L I  P C  L 1  L I  L C  U P  U P  U C  \
U I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  \
U I  0 O D  o U  1 C  1 C  o U  1 C  o U  o U  1 C  o U  1 C  o U  U I\
  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  0 O  U I  U I  U I  0 0 o  0 0 1\
  0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 1  0 O\
 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U 1  U P  U P  o I  \
o P  L U  L I  P C  L 1  L I  L C  U P  U P  U 1  U I  1 1  U I  U 1  \
U 1  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  U C  U P  U P  o P  L\
 U  L O  0 0 1  0 0 0  P C  0 0 O  C C  o D  0 O 0  0 I 0  P 0  U C  U\
 I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  U\
 I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  1 L  0 0 0  0 0 0  U I  P 0  U\
 I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 \
0 P  U I  1 O  U I  U C  U P  U P  o P  L U  L O  0 0 1  0 0 0  P C  0\
 0 O  C C  o D  0 O 0  0 I 0  P 0  U C  U I  1 0  U I  C 0  U I  1 C  \
U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  \
U I  U C  U P  U P  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  \
U I  U I  U I  0 O D  o U  1 C  1 C  1 C  1 C  0 O D  0 O D  0 O D  0 \
O D  U I  P 0  U I  U C  U P  U P  o P  L U  L O  0 0 1  0 0 0  P C  0\
 0 O  C C  o D  0 O 0  0 I 0  P 0  U o  0 0 D  U P  U P  U C  U I  U o\
  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  1 L  0 0 0  0 0 0  0 O  U I\
  U I  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O L  U\
 I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U\
 I  0 O D  o U  1 C  1 C  1 C  1 C  0 O D  0 O D  0 O D  0 O D  U I  1\
 1  U I  U 1  U 1  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D \
1  D D  U I  1 D  U I  D 1  D D  D L  U I  o C  o C  0 0 0  0 0 0  o C\
  o C  0 0 0  U I  1 o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U \
I  1 I  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O\
 D  1 C  0 O D  U I  1 U  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  \
U I  0 O O  C o  0 0 P  C o  U I  P 0  U I  0 O D  0 O D  1 C  o U  1 \
C  0 O D  1 C  o U  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 0  0 O \
 U I  U I  0 O D  0 O I  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  1 L \
 0 0 0  0 0 0  U I  D L  0 O  U I  U I  U I  0 O D  0 O C  0 0 I  0 0 \
0  0 0 1  0 0 P  U I  0 0 I  0 I 0  C o  0 O 0  0 0 D  0 O  U I  U I  \
U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  1 L  0 0 0  0 0 0  U I  P 0  \
U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  1 L  0 0 0  0 0 0  U I  1 P  \
U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U 1  C o  \
0 0 D  C C  0 O D  0 O D  U 1  U I  1 0  0 O  U I  U I  U I  0 0 I  0 \
0 1  0 O D  0 0 O  0 0 P  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  1 L\
  0 0 0  0 0 0  0 O  U I  U I  U I  o C  0 0 0  0 0 0  o C  0 0 0  1 L\
  0 0 0  0 0 0  0 0 0  U I  P 0  U I  1 C  D 1  U I  1 D  U I  0 O L  \
0 O 0  0 0 O  U I  1 O  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  1 L  \
0 0 0  0 0 0  U I  1 0  0 O  U I  U I  U I  0 0 0  o C  1 L  0 0 0  1 \
L  0 0 0  1 L  0 0 0  0 0 0  U I  P 0  U I  0 0 0  o C  1 L  0 0 0  1 \
L  0 0 0  1 L  0 0 0  0 0 0  U I  1 U  U I  1 O  U I  C C  0 O 1  0 0 \
1  U I  1 O  U I  1 L  U I  1 0  U I  1 I  U I  1 O  U I  o C  0 0 0  \
0 0 0  o C  0 0 0  1 L  0 0 0  0 0 0  0 0 0  U I  1 0  U I  1 0  0 O  \
U I  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  0 0 1  0 O 0  0\
 0 I  0 0 1  U I  1 O  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  1 L  0\
 0 0  0 0 0  U I  1 0  0 O  U I  U I  U I  0 O O  C o  0 0 P  C o  U I\
  P 0  U I  C L  C o  0 0 D  0 O 0  D 1  D I  U I  1 P  U I  C L  D 1 \
 D I  0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  0 O O  C \
o  0 0 P  C o  U I  1 0  0 O  U I  U I  U I  0 0 0  1 L  1 L  0 0 0  0\
 0 0  1 L  U I  P 0  U I  0 0 I  0 I 0  C o  0 O 0  0 0 D  U I  1 P  U\
 I  0 0 O  0 O 0  0 0 C  U I  1 O  U I  0 0 0  o C  1 L  0 0 0  1 L  0\
 0 0  1 L  0 0 0  0 0 0  U I  1 1  U I  0 0 I  0 I 0  C o  0 O 0  0 0 \
D  U I  1 P  U I  o o  o C  P L  P C  C D  P C  P o  P P  U I  1 1  U \
I  o U  L P  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 0  0 O  U\
 I  U I  U I  0 O O  C o  0 0 P  C o  U I  P 0  U I  0 0 0  1 L  1 L  \
0 0 0  0 0 0  1 L  U I  1 P  U I  0 O O  0 O 0  C C  0 0 1  0 I 0  0 0\
 I  0 0 P  U I  1 O  U I  0 O O  C o  0 0 P  C o  U I  1 0  U I  1 P  \
U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  C I  1 L  \
U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U I  U I  0 O D\
  0 O I  U I  D 0  D P  U I  1 D  U I  D 0  D P  D L  U I  o C  0 0 0 \
 0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  U o  U I  o U  0 O D  1 C  o U\
  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I  o U  1 C \
 o U  0 O D  1 C  1 C  1 C  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o\
 C  1 L  0 0 0  U I  1 o  U I  o U  1 C  1 C  0 O D  0 O  U I  U I  0 \
O D  0 O I  U I  0 0 1  0 O 0  U I  1 P  U I  0 0 D  0 O 0  C o  0 0 1\
  C C  0 O 1  U I  1 O  U I  U 1  U D  P C  L L  L 1  o o  D 0  L D  U\
 1  U I  1 1  U I  0 O O  C o  0 0 P  C o  U I  1 0  U I  0 0 0  0 0 1\
  U I  U C  0 O C  D 0  0 0 o  U C  U I  0 O D  0 0 O  U I  0 0 o  0 0\
 1  0 O L  U I  D L  0 O  U I  U I  U I  0 O D  0 O I  U I  D U  D I  \
U I  1 D  U I  D U  D I  D L  U I  0 0 0  o C  1 L  0 0 0  U I  U o  U\
 I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 D  U I\
  o C  1 L  0 0 0  o C  U I  1 o  U I  o U  o U  o U  o U  U I  1 D  U\
 I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 P  U I  0 0 0  1 L  0 \
0 0  o C  1 L  0 O  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  \
0 0 O  U I  0 O O  C o  0 0 P  C o  0 O  U I  0 O 0  0 O L  0 O D  0 O\
 I  U I  0 O O  C o  0 0 P  C o  U I  P 0  P 0  U I  o L  0 0 0  0 0 O\
  0 O 0  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0\
 P  U I  U C  1 o  U C  U I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U\
 I  0 0 0  0 0 1  U I  0 0 O  0 0 0  0 0 P  U I  U C  C I  C I  U C  U\
 I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  U\
 I  0 O D  0 O I  U I  1 C  1 C  U I  1 D  U I  1 C  1 C  D L  U I  0 \
0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 P  U I  o U \
 1 C  o U  0 O D  1 C  1 C  1 C  U I  1 I  U I  0 0 0  0 0 0  0 0 0  1\
 L  o C  0 0 0  1 L  U I  1 I  U I  o C  o C  0 0 0  0 0 0  o C  o C  \
0 0 0  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 \
O  U I  U I  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  0 0 0  0 0 D  U \
I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 \
O D  0 0 O  U I  1 O  U I  o U  o U  0 O D  0 O D  o U  0 O D  o U  1 \
C  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 0  0 O  U I  U I  0 O D \
 0 O I  U I  0 I O  C L  0 O C  C C  0 0 L  0 O I  0 0 D  U I  1 P  U \
I  0 O 0  0 I O  0 O D  0 0 D  0 0 P  0 0 D  U I  1 O  U I  0 0 o  0 0\
 1  0 O L  U I  1 0  U I  D L  0 O  U I  U I  U I  0 O D  0 O I  U I  \
0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0\
 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U 1  0 0 D  0 O C  C \
L  D L  1 o  1 o  U 1  U I  1 0  U I  0 0 0  0 0 1  U I  0 0 o  0 0 1 \
 0 O L  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  \
0 O D  0 0 P  0 O 1  U I  1 O  U I  U 1  0 0 O  0 O I  0 0 D  D L  1 o\
  1 o  U 1  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  o U  0 O D  o\
 U  o U  1 C  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  U I  P 0  U I  0 \
I O  C L  0 O C  C C  0 0 L  0 O I  0 0 D  U I  1 P  U I  C C  0 0 0  \
0 0 I  0 I 0  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  0 0 0\
  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  0 O P\
  0 0 0  0 O D  0 0 O  U I  1 O  U I  0 0 0  0 0 0  1 L  0 0 0  0 0 0 \
 o C  1 L  0 0 0  o C  o C  o C  o C  0 0 0  U I  1 1  U I  U C  0 0 P\
  0 O 0  0 O C  0 0 I  U C  U I  1 1  U I  U C  0 0 D  0 0 0  0 0 1  C\
 C  0 O 0  C D  0 0 P  0 O 0  0 O C  0 0 I  1 P  0 0 P  0 I O  0 0 P  \
U C  U I  1 0  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  o\
 U  0 O D  o U  o U  1 C  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  U I  \
D L  0 O  U I  U I  U I  U I  U I  0 O O  C o  0 0 P  C o  U I  P 0  U\
 I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  0 0 0  0 0 D  U I  1 P \
 U I  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 O D  0 \
0 O  U I  1 O  U I  0 0 0  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 0 0  \
o C  o C  o C  o C  0 0 0  U I  1 1  U I  U C  0 0 P  0 O 0  0 O C  0 \
0 I  U C  U I  1 1  U I  U C  0 0 D  0 0 0  0 0 1  C C  0 O 0  C D  0 \
0 P  0 O 0  0 O C  0 0 I  1 P  0 0 P  0 I O  0 0 P  U C  U I  1 0  U I\
  1 1  U I  U 1  0 0 1  U 1  U I  1 0  U I  1 P  U I  0 0 1  0 O 0  C \
o  0 O O  U I  1 O  U I  1 0  0 O  U I  U I  U I  U I  U I  0 I O  C L\
  0 O C  C C  0 0 L  0 O I  0 0 D  U I  1 P  U I  0 O O  0 O 0  0 O L \
 0 O 0  0 0 P  0 O 0  U I  1 O  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 \
I  C o  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  \
1 O  U I  0 0 0  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  \
o C  o C  0 0 0  U I  1 1  U I  U C  0 0 P  0 O 0  0 O C  0 0 I  U C  \
U I  1 1  U I  U C  0 0 D  0 0 0  0 0 1  C C  0 O 0  C D  0 0 P  0 O 0\
  0 O C  0 0 I  1 P  0 0 P  0 I O  0 0 P  U C  U I  1 0  U I  1 0  0 O\
  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  \
U I  U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U \
 o U  U I  1 O  U I  U 1  0 O I  C o  0 O D  0 O L  0 O 0  0 O O  U I \
 0 0 P  0 0 0  U I  C C  0 0 0  0 0 I  0 I 0  U I  0 O I  0 0 1  0 0 0\
  0 O C  U I  0 0 D  0 O C  C L  D L  U 1  U I  1 0  0 O  U I  U I  U \
I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 O \
O  C o  0 0 P  C o  U I  P 0  U I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 \
O  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  U C  0 0 1  U C  U I  1 0 \
 U I  1 P  U I  0 0 1  0 O 0  C o  0 O O  U I  1 O  U I  1 0  0 O  U I\
  U I  U I  U I  0 O D  0 O I  U I  0 0 1  0 O 0  U I  1 P  U I  0 O C\
  C o  0 0 P  C C  0 O 1  U I  1 O  U I  U 1  U D  P C  L L  L 1  o o \
 D 0  L D  U 1  U I  1 1  U I  0 O O  C o  0 0 P  C o  U I  1 0  U I  \
0 0 0  0 0 1  U I  U C  0 O C  D 0  0 0 o  U C  U I  0 O D  0 0 O  U I\
  0 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  U I  U I  U I  0 O D  \
0 O I  U I  D I  1 L  U I  1 D  U I  D I  1 L  D L  U I  o C  0 0 0  0\
 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  0 0 0  0 0 0  0 0 0  1\
 L  o C  0 0 0  1 L  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L\
  o C  1 L  1 L  0 O  U I  U I  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 \
0 o  0 0 1  0 0 O  U I  0 O O  C o  0 0 P  C o  0 O  U I  U I  0 O 0  \
0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  o U  o U  o U  1 C \
 0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L U  0 0 0  0\
 0 o  0 0 I  U I  P L  C o  0 0 P  C o  U I  0 0 O  0 0 0  0 0 P  U I \
 0 O I  0 0 0  0 0 o  0 0 O  0 O O  U U  U 1  U I  1 0  0 O  U I  U I \
 U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O  U I  0 O D  0 O I\
  U I  U C  P O  L U  0 O 0  0 0 P  L P  0 O D  0 O 0  0 0 C  o o  0 0\
 0  0 O O  0 O 0  P I  U C  U I  0 O D  0 0 O  U I  0 O O  C o  0 0 P \
 C o  U I  D L  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I\
  U I  U I  0 0 0  0 0 0  1 L  1 L  1 L  U I  P 0  U I  0 0 1  0 O 0  \
U I  1 P  U I  0 O I  0 O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 O\
  U I  U C  P O  L U  0 O 0  0 0 P  L P  0 O D  0 O 0  0 0 C  o o  0 0\
 0  0 O O  0 O 0  P I  1 O  1 P  1 I  P U  1 0  P O  U C  U I  1 1  U \
I  0 O O  C o  0 0 P  C o  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O\
  U I  U I  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  \
0 O 0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O \
D  0 0 O  U I  1 O  U I  U 1  P o  0 0 0  0 0 O  0 0 P  C o  0 O D  0 \
0 O  0 O 0  0 0 1  1 P  L U  0 O 0  0 0 P  L P  0 O D  0 O 0  0 0 C  o\
 o  0 0 0  0 O O  0 O 0  1 O  U o  0 0 D  1 0  U 1  U I  U o  U I  0 0\
 0  0 0 0  1 L  1 L  1 L  U I  1 0  0 O  U I  U I  U I  0 0 I  0 0 1  \
0 O D  0 0 O  0 0 P  U I  U C  0 O O  0 0 0  0 0 O  0 O 0  U I  0 0 D \
 0 O 0  0 0 P  0 0 L  0 O D  0 O 0  0 0 C  U C  U I  1 1  U I  0 0 0  \
0 0 0  1 L  1 L  1 L  0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  \
0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  0 0 1  0 O 0\
  0 0 P  0 0 o  0 0 1  0 0 O  U I  P P  0 O 0  C o  0 0 o  0 0 P  0 O \
D  0 O I  0 0 o  0 O L  L U  o C  P D  L O  U I  1 O  U I  0 O O  C o \
 0 0 P  C o  U I  1 1  U I  C C  0 0 0  0 0 O  0 0 L  0 O 0  0 0 1  0 \
0 P  P C  0 0 O  0 0 P  0 O D  0 0 P  0 O D  0 O 0  0 0 D  U I  P 0  U\
 I  P P  0 O 0  C o  0 0 o  0 0 P  0 O D  0 O I  0 0 o  0 O L  L U  0 \
0 P  0 0 0  0 0 O  0 O 0  L U  0 0 0  0 0 o  0 0 I  U I  1 P  U I  L L\
  o o  o P  C D  P C  o L  L 1  o U  L 1  o U  P C  L U  U I  1 0  0 O\
  U I  0 O D  0 O I  U I  D U  D D  U I  1 D  U I  D U  D D  D L  U I \
 o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  0 O O  0 O 0  0 O \
I  U I  o U  o U  1 C  1 C  o U  0 O D  0 O D  0 O D  U I  1 O  U I  0\
 O O  C o  0 0 P  C o  U I  1 0  U I  D L  0 O  U I  0 0 P  0 0 1  0 I\
 0  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  0 O O  C o  0 0 P  C o\
  U I  C o  0 0 O  0 O O  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 O\
 O  C o  0 0 P  C o  U I  1 0  U I  P I  U I  1 L  U I  C o  0 0 O  0 \
O O  U I  0 O O  C o  0 0 P  C o  U I  1 P  U I  0 0 D  0 0 P  C o  0 \
0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  U P\
  0 0 I  0 I 0  o O  0 0 o  0 0 O  C C  0 0 P  0 O D  0 0 0  0 0 O  D \
L  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  0 O O  C o  0 0 P  C o\
  U I  P 0  U I  0 O D  1 C  1 C  o U  U I  1 O  U I  0 O O  C o  0 0 \
P  C o  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U \
I  U C  U P  0 0 I  0 I 0  o O  0 0 o  0 0 O  C C  0 0 P  0 O D  0 0 0\
  0 0 O  D L  U C  U I  1 0  U I  C 0  U I  1 C  U I  C U  U I  1 1  U\
 I  U C  U C  U I  1 1  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  \
o L  0 0 0  0 0 O  0 O 0  U I  1 0  0 O  U I  0 O 0  0 I O  C C  0 O 0\
  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  0 O\
 D  0 O I  U I  D D  D 1  U I  1 D  U I  D D  D 1  D L  U I  0 0 0  0 \
0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 I  U I  0 O D  0 O D  o U  1 \
C  0 O D  o U  0 O D  o U  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1\
  0 0 O  U I  0 O O  C o  0 0 P  C o  0 O  U I  0 O D  0 O I  U I  D U\
  D O  U I  1 D  U I  D U  D O  D L  U I  o C  1 L  0 0 0  o C  0 O  0\
 O O  0 O 0  0 O I  U I  o C  1 L  0 0 0  o C  1 L  U I  1 O  U I  0 0\
 o  0 0 1  0 O L  U I  1 1  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P \
 U I  1 1  U I  0 O O  C o  0 0 P  C o  U I  P 0  U I  o L  0 0 0  0 0\
 O  0 O 0  U I  1 0  U I  D L  0 O  U I  0 O D  0 O C  0 0 I  0 0 0  0\
 0 1  0 0 P  U I  C C  0 O 1  0 O 0  C C  0 O o  C L  C o  0 O O  0 O \
 U I  C C  0 O 1  0 O 0  C C  0 O o  C L  C o  0 O O  U I  1 P  U I  0\
 O O  0 0 0  C D  C L  0 O L  0 0 0  C C  0 O o  C D  C C  0 O 1  0 O \
0  C C  0 O o  U I  1 O  U I  o O  C o  0 O L  0 0 D  0 O 0  U I  1 0 \
 0 O  U I  o C  o C  0 0 0  o C  U I  P 0  U I  o C  o C  1 L  o C  o \
C  o C  o C  0 0 0  0 0 0  1 L  o C  o C  o C  U I  1 O  U I  0 0 o  0\
 0 1  0 O L  U I  1 1  U I  0 O O  C o  0 0 P  C o  U I  1 0  0 O  U I\
  0 O D  0 O I  U I  1 C  D o  U I  1 D  U I  1 C  D o  D L  U I  0 O \
D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  0 O D \
 0 0 D  0 O D  0 0 O  0 0 D  0 0 P  C o  0 0 O  C C  0 O 0  U I  1 O  \
U I  o C  o C  0 0 0  o C  U I  1 1  U I  P P  0 O 0  C o  0 0 o  0 0 \
P  0 O D  0 O I  0 0 o  0 O L  L U  o C  P D  L O  U I  1 0  U I  D L \
 0 O  U I  U I  0 O D  0 O I  U I  D O  D U  U I  1 D  U I  D O  D U  \
D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D \
 1 C  0 O D  U I  1 o  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1\
 L  0 O  U I  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U\
 I  o C  o C  0 0 0  o C  U I  1 O  U I  U C  C C  0 O 1  C o  0 0 O  \
0 0 O  0 O 0  0 O L  0 0 D  U C  U I  1 0  U I  1 0  U I  P I  U I  1 \
L  U I  C o  0 0 O  0 O O  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0\
 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L\
 U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 O \
O  0 0 0  0 0 O  0 0 0  0 0 P  0 0 D  0 O 1  0 0 0  0 0 C  C L  0 I 0 \
 C C  0 O 1  C o  0 0 O  0 0 O  0 O 0  0 O L  0 0 D  U C  U I  1 0  U \
I  P 0  P 0  U I  U C  0 O I  C o  0 O L  0 0 D  0 O 0  U C  U I  D L \
 0 O  U I  U I  U I  o U  o U  0 0 0  0 0 0  o C  U I  P 0  U I  o C  \
o C  0 0 0  o C  U I  1 O  U I  U C  C C  0 O 1  C o  0 0 O  0 0 O  0 \
O 0  0 O L  U C  U I  1 0  0 O  U I  U I  U I  0 O I  0 0 0  0 0 1  U \
I  o C  0 0 0  0 0 0  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  U I  \
0 O D  0 0 O  U I  o U  o U  0 0 0  0 0 0  o C  U I  D L  0 O  U I  U \
I  U I  U I  0 O D  0 O I  U I  D 1  1 C  U I  1 D  U I  D 1  1 C  D L\
  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  o C  \
1 L  0 0 0  o C  U I  1 D  U I  o U  1 C  1 C  0 O D  0 O  U I  U I  U\
 I  U I  0 O D  0 O I  U I  D O  D U  U I  1 D  U I  D O  D U  D L  U \
I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U\
 I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 U  U I  0 0 0  o C  1 L  0 0 0\
  1 L  0 0 0  0 0 0  o C  1 L  U I  1 P  U I  0 0 0  1 L  1 L  o C  1 \
L  0 0 0  0 0 0  U I  1 P  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 \
0  0 O  U I  U I  U I  U I  0 0 0  o C  0 0 0  0 0 0  o C  U I  P 0  U\
 I  U C  U C  0 O  U I  U I  U I  U I  o U  o U  o U  o U  0 O D  o U \
 1 C  1 C  o U  1 C  1 C  U I  P 0  U I  1 L  0 O  U I  U I  U I  U I \
 0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 0 0  o\
 C  0 0 0  0 0 0  o C  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  0 0 0  o\
 C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U C  0 O 0  0 I O  0 0 P \
 0 O 0  0 0 1  0 0 O  C o  0 O L  0 O L  0 O D  0 0 O  0 O o  U C  U I\
  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 \
1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  U I  U I  o U  o U  o U  o\
 U  0 O D  o U  1 C  1 C  o U  1 C  1 C  U I  P 0  U I  0 O L  0 O 0  \
0 0 O  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  0 0 0  o C  0 0 0  0 0 0\
  0 0 0  1 L  U I  1 O  U I  U C  0 O 0  0 I O  0 0 P  0 O 0  0 0 1  0\
 0 O  C o  0 O L  0 O L  0 O D  0 0 O  0 O o  U C  U I  1 0  U I  1 0 \
 0 O  U I  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I \
 D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  U I  U I  U I  0 O D  0\
 O I  U I  D U  D P  U I  1 D  U I  D U  D P  D L  U I  0 O D  o U  o \
U  1 C  1 C  1 C  0 O D  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  o\
 U  o U  o U  o U  0 O D  o U  1 C  1 C  o U  1 C  1 C  U I  P I  U I \
 1 C  U I  D L  U I  0 0 0  o C  0 0 0  0 0 0  o C  U I  P 0  U I  U C\
  U C  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D D  U I  1 D  U I \
 D D  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D\
  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U \
I  1 I  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O\
 D  1 C  0 O D  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L\
  1 L  U I  U o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 D  U\
 I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  U I  U I  \
U I  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  o C  0 0 0  0 0 0  1 \
L  0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U C  0 0 O  C \
o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P\
  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  U\
 I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  o C  \
0 0 0  0 0 0  o C  1 L  U I  P 0  U I  o U  o U  1 C  1 C  o U  0 O D \
 0 O D  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 0  0\
 O  U I  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D\
 L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  U I  U I  U I  o U  o U  \
1 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  o\
 C  0 0 0  0 0 0  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O \
 U I  U C  0 0 P  0 O 1  0 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  \
U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0\
 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  U I  0 O D  0 O I \
 U I  o U  o U  1 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  \
U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I \
 U I  U I  U I  o U  o U  1 C  o U  o U  o U  o U  0 O D  o U  o U  1 \
C  0 O D  U I  P 0  U I  U C  U C  0 O  U I  U I  U I  U I  o U  o U  \
1 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  o\
 U  o U  1 C  1 C  o U  0 O D  0 O D  0 O D  U I  1 O  U I  o U  o U  \
1 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  1 0  0 O  U\
 I  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  \
U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  0 0 0  0 0\
 0  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U C  0 O\
 I  C o  0 0 O  C o  0 0 1  0 0 P  U C  U I  1 0  U I  D L  0 O  U I  \
U I  U I  U I  U I  U I  0 O D  0 O I  U I  o C  1 L  o U  1 C  1 C  0\
 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O\
 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U \
I  U C  0 0 o  0 0 D  0 O 0  C D  0 0 P  0 O 1  0 0 o  0 O C  C L  U C\
  U I  1 0  U I  P 0  P 0  U I  U 1  0 0 P  0 0 1  0 0 o  0 O 0  U 1  \
U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  1 C  o U  o U\
  1 C  U I  P 0  U I  o U  o U  1 C  o U  o U  o U  o U  0 O D  o U  o\
 U  1 C  0 O D  0 O  U I  U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D\
  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  1 C \
 o U  o U  1 C  U I  P 0  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  0\
 O  U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O\
  U I  U I  U I  U I  U I  U I  0 O D  1 C  o U  o U  1 C  U I  P 0  U\
 I  o C  0 0 0  0 0 0  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  U I \
 1 O  U I  U C  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U C  U I  1 0  U\
 I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D\
  0 0 O  0 O U  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 O D\
  1 C  o U  o U  1 C  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U \
I  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 1  C o  0 O D  0 0 D  0\
 O 0  0 O  U I  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P \
 U I  D L  0 O  U I  U I  U I  U I  U I  0 O D  1 C  o U  o U  1 C  U \
I  P 0  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  0 O  U I  U I  U I \
 U I  U I  0 O D  0 O I  U I  D O  D U  U I  1 D  U I  D O  D U  D L  \
U I  0 O D  1 C  U I  1 o  U I  0 0 0  o C  1 L  0 0 0  U I  U o  U I \
 0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U I  U I  U I  U\
 I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  o U  \
0 O D  0 O D  1 C  o U  1 C  o U  1 C  1 C  0 O D  0 O D  o U  1 C  U \
I  P 0  U I  o C  0 0 0  0 0 0  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0  \
1 L  U I  1 O  U I  U C  0 O D  0 0 O  0 O I  0 0 0  U C  U I  1 0  U \
I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D \
 0 0 O  0 O U  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  o U  0\
 O D  0 O D  1 C  o U  1 C  o U  1 C  1 C  0 O D  0 O D  o U  1 C  U I\
  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U \
I  U I  U I  U I  0 0 1  C o  0 O D  0 0 D  0 O 0  0 O  U I  U I  U I \
 U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I \
 U I  U I  U I  o U  0 O D  0 O D  1 C  o U  1 C  o U  1 C  1 C  0 O D\
  0 O D  o U  1 C  U I  P 0  U I  U C  U C  0 O  U I  U I  U I  U I  U\
 I  0 O D  0 O I  U I  D I  D O  U I  1 D  U I  D I  D O  D L  U I  0 \
0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 I  U I  0 0 0 \
 o C  1 L  0 0 0  U I  1 o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0\
 0 0  o C  1 L  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C\
  1 L  1 L  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I \
 U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I\
  0 O D  0 O D  1 C  o U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  0 0 0\
  o C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U C  0 O U  0 O 0  0 0\
 O  0 0 1  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 \
P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  \
U I  U I  0 O D  0 O I  U I  0 O D  0 O D  1 C  o U  U I  P 0  P 0  U \
I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U\
 I  0 0 1  C o  0 O D  0 0 D  0 O 0  0 O  U I  U I  U I  U I  0 O 0  0\
 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  U I\
  0 O D  0 O D  1 C  o U  U I  P 0  U I  U C  U C  0 O  U I  U I  U I \
 U I  U I  0 O D  0 O I  U I  D I  1 C  U I  1 D  U I  D I  1 C  D L  \
U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  o U  o \
U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  U\
 I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  o U  \
1 C  o U  1 C  0 O D  1 C  o U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L \
 0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U C  0 O O  C o \
 0 0 P  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  \
U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  U I\
  U I  0 O D  0 O I  U I  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  P \
0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U\
 I  U I  U I  0 0 1  C o  0 O D  0 0 D  0 O 0  0 O  U I  U I  U I  U I\
  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I\
  U I  U I  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  P 0  U I  U C  U\
 C  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D U  1 C  U I  1 \
D  U I  D U  1 C  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  U o  U I\
  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  U I  U I  U I  0 0 \
P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  C C  0 0 1  0\
 O 0  0 O O  0 O D  0 0 P  0 0 D  U I  P 0  U I  o C  0 0 0  0 0 0  1 \
L  0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U C  C C  0 0 \
1  0 O 0  0 O O  0 O D  0 0 P  0 0 D  U C  U I  1 0  U I  C 0  U I  1 \
L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  \
0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  C C  0 0 1  0 O 0  0 \
O O  0 O D  0 0 P  0 0 D  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0\
  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 1  C o  0 O D  0 0 \
D  0 O 0  0 O  U I  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 \
0 P  U I  D L  0 O  U I  U I  U I  U I  U I  C C  0 0 1  0 O 0  0 O O \
 0 O D  0 0 P  0 0 D  U I  P 0  U I  U C  U C  0 O  U I  U I  U I  U I\
  U I  0 O D  0 O I  U I  D 1  1 L  U I  1 D  U I  D 1  1 L  D L  U I \
 0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 o  U I  o C  1 L  0 0 0\
  o C  U I  1 P  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 o \
 U I  0 O D  1 C  U I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0 \
 1 L  0 O  U I  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I\
  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 0  o C  0 0 0  0 0 0  o C\
  U I  P 0  P 0  U I  U C  U C  U I  D L  0 O  U I  U I  U I  U I  U I\
  U I  0 O D  o U  1 C  0 O D  o U  o U  0 O D  0 O D  0 O D  0 O D  U\
 I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 P  U I  0 O 0  0 0 O\
  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1\
 D  D P  U C  U I  1 1  U I  U C  0 O D  0 O U  0 0 O  0 0 0  0 0 1  0\
 O 0  U C  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I\
  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0\
 0 P  0 O I  1 D  D P  U C  U I  1 0  U I  1 1  U I  D O  U I  1 1  U \
I  o U  o U  1 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I\
  1 1  U I  0 O D  1 C  o U  o U  1 C  U I  1 1  U I  o U  0 O D  0 O \
D  1 C  o U  1 C  o U  1 C  1 C  0 O D  0 O D  o U  1 C  U I  1 1  U I\
  0 O D  0 O D  1 C  o U  U I  1 1  U I  o U  1 C  o U  1 C  0 O D  1 \
C  o U  U I  1 1  U I  C C  0 0 1  0 O 0  0 O O  0 O D  0 0 P  0 0 D  \
U I  1 1  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 0  0 O  U I  U I  U I \
 U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U\
 I  U I  U I  0 O D  0 O I  U I  D o  D O  U I  1 D  U I  D o  D O  D \
L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 O \
D  1 C  U I  1 I  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C\
  o U  0 O D  1 C  0 O D  U I  U o  U I  0 O D  o U  o U  1 C  1 C  1 \
C  0 O D  0 O  U I  U I  U I  U I  U I  U I  0 O D  o U  1 C  0 O D  o\
 U  o U  0 O D  0 O D  0 O D  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0 \
 o C  1 L  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I \
 1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  U I  1 1\
  U I  0 0 0  o C  0 0 0  0 0 0  o C  U I  1 P  U I  0 O 0  0 0 O  C C\
  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D\
 P  U C  U I  1 0  U I  1 1  U I  1 C  U I  1 1  U I  o U  o U  1 C  o\
 U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  1 1  U I  0 O D  \
1 C  o U  o U  1 C  U I  1 1  U I  o U  0 O D  0 O D  1 C  o U  1 C  o\
 U  1 C  1 C  0 O D  0 O D  o U  1 C  U I  1 1  U I  0 O D  0 O D  1 C\
  o U  U I  1 1  U I  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  1 1  U\
 I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  U C  0 0 D  0 0 0  0 0 o \
 0 0 1  C C  0 O 0  U C  U I  1 0  0 O  U I  U I  U I  U I  0 O 0  0 I\
 O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  U I  \
o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I \
 U C  L 1  0 O 1  0 O 0  0 0 1  0 O 0  U I  0 0 C  C o  0 0 D  U I  C \
o  U I  0 0 I  0 0 1  0 0 0  C L  0 O L  0 O 0  0 O C  U I  C o  0 O O\
  0 O O  0 O D  0 0 O  0 O U  U I  0 O O  0 O D  0 0 1  0 O 0  C C  0 \
0 P  0 0 0  0 0 1  0 I 0  U I  0 O I  0 0 1  0 0 0  0 O C  U I  0 O U \
 0 O 0  0 0 P  P L  C o  0 0 P  C o  1 O  1 0  D L  U I  U C  U I  1 U\
  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 P  U I  0 O 0  0 0 O  C C  \
0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P\
  U C  U I  1 1  U I  U C  0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  U\
 C  U I  1 0  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I\
  D L  0 O  U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O \
D  o U  o U  U I  1 O  U I  U C  o L  0 0 0  U I  P o  0 O 1  C o  0 0\
 O  0 0 O  0 O 0  0 O L  0 0 D  D L  U I  0 O U  0 O 0  0 0 P  o U  0 \
0 P  0 O 0  0 O C  0 0 D  U C  U I  1 0  0 O  U I  U I  U I  0 O D  1 \
C  o U  1 C  0 O D  1 C  U I  1 O  U I  o C  o C  0 0 0  o C  U I  1 O\
  U I  U C  0 O D  0 0 P  0 O 0  0 O C  U C  U I  1 0  U I  1 1  U I  \
0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U I  1 0  0 O  U I  0 O 0  0 O L\
  0 0 D  0 O 0  U I  D L  0 O  U I  U I  o C  1 L  o C  0 0 0  0 0 0  \
0 0 0  o C  1 L  U I  1 O  U I  o C  o C  0 0 0  o C  U I  1 0  0 O  U\
 I  U I  0 O D  0 O I  U I  D P  D U  U I  1 D  U I  D P  D U  D L  U \
I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  0 O D  0 O I  U I  D O \
 1 L  U I  1 D  U I  D O  1 L  D L  U I  o U  o U  o U  o U  U I  U o \
 U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  0 O O  0 O 0  0 \
O I  U I  o C  1 L  o C  0 0 0  0 0 0  0 0 0  o C  1 L  U I  1 O  U I \
 0 O O  C o  0 0 P  C o  U I  1 0  U I  D L  0 O  U I  o U  o U  o U  \
1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  U I  P 0  U I  0 O O  C o  0 \
0 P  C o  U I  1 P  U I  0 0 1  0 0 D  0 0 P  0 0 1  0 O D  0 0 I  U I\
  1 O  U I  1 0  0 O  U I  0 0 0  o C  0 0 0  1 L  U I  P 0  U I  0 0 \
1  0 O 0  U I  1 P  U I  C C  0 0 0  0 O C  0 0 I  0 O D  0 O L  0 O 0\
  U I  1 O  U I  0 0 1  U C  U D  P C  L L  L 1  o U  o L  o O  D L  1\
 O  1 P  1 U  P U  1 0  1 1  1 O  1 P  1 I  P U  1 0  C 0  C I  0 0 O \
 C I  0 0 1  C U  1 U  1 O  C 0  C 1  C I  0 0 1  C I  0 0 O  C U  1 U\
  1 0  U C  U I  1 0  U I  1 P  U I  0 O I  0 O D  0 0 O  0 O O  C o  \
0 O L  0 O L  U I  1 O  U I  o U  o U  o U  1 C  0 O D  1 C  0 O D  1 \
C  1 C  0 O D  U I  1 0  0 O  U I  o C  o C  o C  0 0 0  o C  o C  U I\
  P 0  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 0 0  o C  0 0 0  1 L\
  U I  1 0  0 O  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  0 0\
 P  0 0 D  0 O O  0 0 0  0 0 C  0 0 O  0 O L  0 0 0  C o  0 O O  0 O 0\
  0 0 1  U C  U I  1 1  U I  0 O D  0 O D  0 O  U I  0 O D  0 O I  U I\
  1 C  1 L  U I  1 D  U I  1 C  1 L  D L  U I  0 O D  0 O D  o U  1 C \
 0 O D  o U  0 O D  o U  U I  1 U  U I  o U  0 O D  o U  o U  U I  1 I\
  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  \
U I  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  0 O D  1 C  U I  1 o  U I \
 0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  0 O I \
 0 0 0  0 0 1  U I  0 O D  o U  1 C  o U  o U  U I  1 1  U I  0 0 0  1\
 L  o C  o C  0 0 0  1 L  0 0 0  1 L  o C  1 L  o C  U I  1 1  U I  0 \
0 0  1 L  U I  0 O D  0 0 O  U I  0 0 0  o C  0 0 0  1 L  U I  D L  0 \
O  U I  U I  0 O D  0 O I  U I  D o  D U  U I  1 D  U I  D o  D U  D L\
  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  U o  U I  o U  1 C  1\
 C  0 O D  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L\
  1 L  U I  U o  U I  o U  0 O D  o U  o U  U I  1 D  U I  o U  o U  o\
 U  o U  0 O  U I  U I  0 O D  0 O I  U I  U C  0 0 P  0 0 L  0 O U  1\
 D  0 O L  0 0 0  0 O U  0 0 0  U C  U I  0 O D  0 0 O  U I  0 O D  o \
U  1 C  o U  o U  U I  D L  0 O  U I  U I  U I  o U  o U  1 C  o U  o \
U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  o C  o C  0 0\
 0  o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 O D  o U  1 C  o U  o U  \
U I  1 1  U I  U C  0 0 P  0 0 L  0 O U  1 D  0 O L  0 0 0  0 O U  0 0\
 0  P 0  C 0  C I  U C  U 1  C U  1 O  1 P  1 I  P U  1 0  C 0  C I  U\
 C  U 1  C U  U C  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  o \
U  o U  1 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  D L\
  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  o U  o U  1 C  o U  o U \
 o U  o U  0 O D  o U  o U  1 C  0 O D  U I  1 P  U I  0 0 D  0 0 P  C\
 o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U \
C  0 O 1  0 0 P  0 0 P  0 0 I  U C  U I  1 0  U I  D L  0 O  U I  U I \
 U I  U I  U I  o U  o U  1 C  o U  o U  o U  o U  0 O D  o U  o U  1 \
C  0 O D  U I  P 0  U I  o U  o U  1 C  o U  o U  o U  o U  0 O D  o U\
  o U  1 C  0 O D  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D \
o  D P  U I  1 D  U I  D o  D P  D L  U I  0 O D  0 O D  o U  1 C  0 O\
 D  o U  0 O D  o U  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 O\
 I  U I  0 0 O  0 0 0  0 0 P  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C\
  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P\
  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  0\
 O L  0 0 0  0 O U  0 0 0  1 D  0 O I  0 0 0  0 O L  0 O O  0 O 0  0 0\
 1  L O  C o  0 0 P  0 O 1  U C  U I  1 0  U I  P 0  P 0  U I  U 1  U \
1  U I  D L  0 O  U I  U I  U I  U I  U I  o C  0 0 0  0 0 0  0 0 0  0\
 0 0  o C  1 L  0 0 0  o C  o C  o C  o C  U I  P 0  U I  o C  1 L  o \
U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U\
 I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U\
  U I  1 O  U I  U C  0 O L  0 0 0  0 O U  0 0 0  1 D  0 O I  0 0 0  0\
 O L  0 O O  0 O 0  0 0 1  L O  C o  0 0 P  0 O 1  U C  U I  1 0  0 O \
 U I  U I  U I  U I  U I  o U  o U  1 C  o U  o U  o U  o U  0 O D  o \
U  o U  1 C  0 O D  U I  P 0  U I  o C  0 0 0  0 0 0  0 0 0  0 0 0  o \
C  1 L  0 0 0  o C  o C  o C  o C  U I  1 U  U I  o U  o U  1 C  o U  \
o U  o U  o U  0 O D  o U  o U  1 C  0 O D  0 O  U I  U I  U I  U I  U\
 I  0 O D  0 O I  U I  1 C  1 L  1 L  U I  1 D  U I  1 C  1 L  1 L  D \
L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  U o  U I \
 o C  1 L  0 0 0  o C  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0\
 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  o U  o U  1 C  o U  o U \
 o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  o U  o U  1 C  \
o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  0 O  U I  U I  U I  U\
 I  U I  0 O D  0 O I  U I  D P  D 1  U I  1 D  U I  D P  D 1  D L  U \
I  o U  0 O D  o U  o U  U I  1 P  U I  o U  o U  0 O D  o U  0 O D  o\
 U  o U  1 C  1 C  0 O D  U I  1 D  U I  o C  o C  0 0 0  0 0 0  o C  \
o C  0 0 0  U I  1 P  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1\
 U  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  \
1 C  0 O D  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D U  D D \
 U I  1 D  U I  D U  D D  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  \
0 0 0  U I  1 P  U I  o U  1 C  1 C  0 O D  U I  1 P  U I  0 0 0  0 0 \
0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 \
0  o C  1 L  o C  1 L  1 L  U I  1 U  U I  0 O D  1 C  U I  1 P  U I  \
0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  U I  0 O 0  0 O L\
  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  o U  o U  1 C  o U  o U \
 o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  U C  U C  0 O  \
U I  U I  U I  0 O D  0 O I  U I  D U  D D  U I  1 D  U I  D U  D D  D\
 L  U I  0 O D  1 C  0 O  U I  U I  0 O D  0 O I  U I  U C  0 0 P  0 I\
 0  0 0 I  0 O 0  U C  U I  0 O D  0 0 O  U I  0 O D  o U  1 C  o U  o\
 U  U I  D L  0 O  U I  U I  U I  o U  1 C  1 C  o U  0 O D  0 O D  0 \
O D  1 C  o U  U I  P 0  U I  o C  o C  0 0 0  o C  0 0 0  o C  0 0 0 \
 U I  1 O  U I  0 O D  o U  1 C  o U  o U  U I  1 1  U I  U C  0 0 P  \
0 I 0  0 0 I  0 O 0  P 0  C 0  C I  U C  U 1  C U  1 O  1 P  1 I  P U \
 1 0  C 0  C I  U C  U 1  C U  U C  U I  1 0  0 O  U I  U I  U I  0 O \
D  0 O I  U I  o U  1 C  1 C  o U  0 O D  0 O D  0 O D  1 C  o U  U I \
 P 0  P 0  U I  U C  0 I 0  0 0 P  1 D  0 O O  0 O L  U C  U I  D L  0\
 O  U I  U I  U I  U I  0 0 0  1 L  U I  P 0  U I  0 0 0  1 L  U I  1 \
U  U I  U 1  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D P  U 1  0 O \
 U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  o U  1 C  1 C  o U  0\
 O D  0 O D  0 O D  1 C  o U  U I  P 0  P 0  U I  U C  0 0 1  0 O 0  0\
 O U  0 O 0  0 I O  U C  U I  D L  0 O  U I  U I  U I  U I  o U  0 O D\
  o U  0 O D  1 C  1 C  0 O D  o U  U I  P 0  U I  0 0 0  1 L  U I  1 \
P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  U L  0 \
0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  P 0  U C  U I  1 0  0 O  U I  \
U I  U I  U I  0 O D  0 O I  U I  D o  1 L  U I  1 D  U I  D o  1 L  D\
 L  U I  0 0 0  o C  1 L  0 0 0  U I  U o  U I  o C  0 0 0  0 0 0  0 0\
 0  1 L  1 L  1 L  1 L  0 O  U I  U I  U I  U I  o C  0 0 0  o C  1 L \
 o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  P 0  U I  o U  \
1 C  o U  0 O D  o U  1 C  1 C  U I  1 O  U I  o C  o C  1 L  o C  o C\
  o C  o C  0 0 0  0 0 0  1 L  o C  o C  o C  U I  1 O  U I  U C  U C \
 U I  1 1  U I  0 O O  C o  0 0 P  C o  U I  P 0  U I  o U  0 O D  o U\
  0 O D  1 C  1 C  0 O D  o U  U I  C 0  U I  1 C  U I  C U  U I  1 0 \
 U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D o  U I  1 D  \
U I  D o  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  U I  U\
 I  o C  0 0 0  0 0 0  0 0 0  o C  U I  1 O  U I  o U  0 O D  o U  0 O\
 D  1 C  1 C  0 O D  o U  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I \
 0 0 0  1 L  o C  o C  0 0 0  1 L  0 0 0  1 L  o C  1 L  o C  U I  1 1\
  U I  o U  o U  1 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D \
 U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C \
 U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I \
 o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  o C  0 0 0  o C  1 L  o C  1\
 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 1  U I  o C  o C  o \
C  0 0 0  o C  o C  U I  1 0  0 O  U I  U I  U I  U I  C C  0 0 0  0 0\
 O  0 0 P  0 O D  0 0 O  0 0 o  0 O 0  0 O  U I  U I  U I  0 O 0  0 O \
L  0 O D  0 O I  U I  o U  1 C  1 C  o U  0 O D  0 O D  0 O D  1 C  o \
U  U I  P 0  P 0  U I  U C  0 O I  0 0 P  0 0 L  U C  U I  D L  0 O  U\
 I  U I  U I  U I  0 0 0  1 L  U I  P 0  U I  U C  0 0 I  0 O L  0 0 o\
  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O \
D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  o O  1 P  L 1  \
1 P  L P  1 o  P U  0 0 O  C o  0 O C  0 O 0  P 0  U C  U I  1 U  U I \
 0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  \
0 0 0  0 0 P  0 O 0  U I  1 O  U I  0 0 0  1 L  o C  o C  0 0 0  1 L  \
0 0 0  1 L  o C  1 L  o C  U I  1 0  U I  1 U  U I  U C  U L  0 0 o  0\
 0 1  0 O L  P 0  U C  U I  1 U  U I  0 0 0  1 L  U I  1 U  U I  U C  \
U L  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D O  D U  U L  C C  0 O 1  \
C D  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  P 0  0 0 O  C o  U C  0 O  \
U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O D  0 O D  U I  C o  0 0\
 O  0 O O  U I  U C  1 P  0 0 P  0 0 D  U C  U I  0 O D  0 0 O  U I  0\
 0 0  1 L  U I  D L  0 O  U I  U I  U I  0 0 0  1 L  U I  P 0  U I  U \
C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O\
 L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0\
  1 P  0 O I  D I  0 O C  L 1  0 O 0  0 0 D  0 0 P  0 O 0  0 0 1  1 o \
 P U  0 0 o  0 0 1  0 O L  P 0  U C  U I  1 U  U I  0 0 o  0 0 1  0 O \
L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0\
  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 0  1 L  U I  1 0\
  U I  1 U  U I  U C  U L  C o  0 O C  0 0 I  D C  0 0 D  0 0 P  0 0 1\
  0 O 0  C o  0 O C  0 0 P  0 I 0  0 0 I  0 O 0  P 0  L 1  L U  P L  o\
 C  L o  o L  o P  o C  P D  P L  P C  L I  U L  0 0 O  C o  0 O C  0 \
O 0  P 0  U C  U I  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  \
U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  U I  1 O  U I  0 0 0\
  1 L  o C  o C  0 0 0  1 L  0 0 0  1 L  o C  1 L  o C  U I  1 0  0 O \
 U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O D  o U  1 C  1 C  o U \
 1 C  o U  o U  1 C  o U  1 C  o U  U I  C o  0 0 O  0 O O  U I  U C  \
1 P  0 O C  D 0  0 0 o  D P  U C  U I  0 O D  0 0 O  U I  0 0 0  1 L  \
U I  D L  0 O  U I  U I  U I  0 0 0  1 L  U I  P 0  U I  U C  0 0 I  0\
 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  \
0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 O \
I  D I  0 O C  L 1  0 O 0  0 0 D  0 0 P  0 O 0  0 0 1  1 o  P U  0 0 o\
  0 0 1  0 O L  P 0  U C  U I  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  0\
 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 \
I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 0  1 L  U I  1 0  U I  1 U \
 U I  U C  U L  C o  0 O C  0 0 I  D C  0 0 D  0 0 P  0 0 1  0 O 0  C \
o  0 O C  0 0 P  0 I 0  0 0 I  0 O 0  P 0  o I  o P  L U  L I  P C  L \
1  L I  L C  U L  0 0 O  C o  0 O C  0 O 0  P 0  U C  U I  1 U  U I  0\
 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 \
0 0  0 0 P  0 O 0  U I  1 O  U I  0 0 0  1 L  o C  o C  0 0 0  1 L  0 \
0 0  1 L  o C  1 L  o C  U I  1 0  0 O  U I  U I  o C  0 0 0  0 0 0  0\
 0 0  o C  U I  1 O  U I  0 0 0  1 L  U I  1 1  U I  0 0 0  1 L  o C  \
o C  0 0 0  1 L  0 0 0  1 L  o C  1 L  o C  U I  1 1  U I  o U  o U  1\
 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  1 1  U I  U \
C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U \
I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  o L  0 0 0  0 0 O\
  0 O 0  U I  1 1  U I  U C  U C  U I  1 1  U I  o C  o C  o C  0 0 0 \
 o C  o C  U I  1 0  0 O  0 O O  0 O 0  0 O I  U I  0 O D  o U  o U  o\
 U  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 0 o  0 0\
 1  0 O L  U I  1 1  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U I  1\
 0  U I  D L  0 O  U I  o C  o C  0 0 0  o C  U I  P 0  U I  o C  o C \
 1 L  o C  o C  o C  o C  0 0 0  0 0 0  1 L  o C  o C  o C  U I  1 O  \
U I  0 0 o  0 0 1  0 O L  U I  1 0  0 O  U I  0 O D  o U  0 O D  U I  \
P 0  U I  o C  o C  0 0 0  o C  U I  1 P  U I  0 O I  0 O D  0 0 O  0 \
O O  U I  1 O  U I  U C  C C  0 O 1  C o  0 0 O  0 0 O  0 O 0  0 O L  \
U C  U I  1 1  U I  C o  0 0 P  0 0 P  0 0 1  0 0 D  U I  P 0  U I  0 \
I U  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  D L  U I  0 0 O  C \
o  0 O C  0 O 0  U I  1 P  U I  0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0\
  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  U \
I  0 I D  U I  1 0  0 O  U I  0 O D  0 O D  1 C  1 C  1 C  o U  U I  P\
 0  U I  0 O D  o U  0 O D  U I  1 O  U I  U C  0 O D  0 0 P  0 O 0  0\
 O C  U C  U I  1 0  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I\
  U I  0 O D  1 C  o U  o U  1 C  U I  P 0  U I  0 O D  o U  0 O D  U \
I  1 O  U I  U C  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U C  U I  1 0 \
 U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O\
 D  0 0 O  0 O U  0 O  U I  U I  0 O D  0 O I  U I  0 O D  1 C  o U  o\
 U  1 C  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  \
U I  U I  U I  0 0 1  C o  0 O D  0 0 D  0 O 0  0 O  U I  0 O 0  0 I O\
  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  0 O D  1 C  o U  \
o U  1 C  U I  P 0  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  0 O  U \
I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  0 0 0  o C  0 0 0\
  0 0 0  0 0 0  1 L  U I  0 O D  0 0 O  U I  0 O D  o U  0 O D  U I  1\
 O  U I  U C  0 0 D  0 0 o  C L  C C  0 O 1  C o  0 0 O  0 0 O  0 O 0 \
 0 O L  U C  U I  1 0  U I  D L  0 O  U I  U I  0 0 O  C o  0 O C  0 O\
 0  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  0 0 0  o C  0 0 0  0 0 0  0\
 0 0  1 L  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0\
  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 \
O D  0 0 O  0 O U  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  \
U I  U I  U I  0 0 O  C o  0 O C  0 O 0  U I  P 0  U I  o U  o U  1 C \
 1 C  o U  0 O D  0 O D  0 O D  U I  1 O  U I  0 0 O  C o  0 O C  0 O \
0  U I  1 0  0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U \
I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  U I  0 0 P  0 0 1  0 \
I 0  U I  D L  0 O  U I  U I  U I  o U  o U  1 C  o U  o U  o U  o U  \
0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  0 \
0 0  o C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U C  0 0 P  0 O 1  \
0 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  U C  U I  1 0  U I  C 0  \
U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  \
0 O U  0 O  U I  U I  U I  0 O D  0 O I  U I  o U  o U  1 C  o U  o U \
 o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  P 0  U I  o L  0 0 0\
  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 0 1  C o  0 O D  \
0 0 D  0 O 0  0 O  U I  U I  U I  o U  o U  1 C  o U  o U  o U  o U  0\
 O D  o U  o U  1 C  0 O D  U I  P 0  U I  o U  o U  1 C  1 C  o U  0 \
O D  0 O D  0 O D  U I  1 O  U I  o U  o U  1 C  o U  o U  o U  o U  0\
 O D  o U  o U  1 C  0 O D  U I  1 0  0 O  U I  U I  0 O 0  0 I O  C C\
  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  o U  o U  1 C  o \
U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  U C  U C\
  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  0 \
O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  0 0 0  0 0 0  1 L  0 0\
 0  o C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U C  0 O I  C o  0 0\
 O  C o  0 0 1  0 0 P  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U \
I  0 O D  0 O I  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C \
 1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0 \
 0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 0 o  0 0 D  \
0 O 0  C D  0 0 P  0 O 1  0 0 o  0 O C  C L  U C  U I  1 0  U I  P 0  \
P 0  U I  U 1  0 0 P  0 0 1  0 0 o  0 O 0  U 1  U I  D L  0 O  U I  U \
I  U I  U I  U I  0 O D  1 C  o U  o U  1 C  U I  P 0  U I  o U  o U  \
1 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  0 O  U I  U I  U\
 I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 O\
 D  1 C  o U  o U  1 C  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  0 0 0  \
o C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U C  0 O I  C o  0 0 O  \
C o  0 0 1  0 0 P  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1\
 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I \
 0 O D  0 O I  U I  0 O D  1 C  o U  o U  1 C  U I  P 0  P 0  U I  o L\
  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 0 1  C o  \
0 O D  0 0 D  0 O 0  0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0\
 0 P  U I  D L  0 O  U I  U I  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I\
  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  o U  0 O D  \
0 O D  1 C  o U  1 C  o U  1 C  1 C  0 O D  0 O D  o U  1 C  U I  P 0 \
 U I  o C  0 0 0  0 0 0  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  U \
I  1 O  U I  U C  0 O D  0 0 O  0 O I  0 0 0  U C  U I  1 0  U I  C 0 \
 U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O \
 0 O U  0 O  U I  U I  U I  0 O D  0 O I  U I  o U  0 O D  0 O D  1 C \
 o U  1 C  o U  1 C  1 C  0 O D  0 O D  o U  1 C  U I  P 0  P 0  U I  \
o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 0 1  C \
o  0 O D  0 0 D  0 O 0  0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I\
  0 0 P  U I  D L  0 O  U I  U I  U I  o U  0 O D  0 O D  1 C  o U  1 \
C  o U  1 C  1 C  0 O D  0 O D  o U  1 C  U I  P 0  U I  U C  U C  0 O\
  U I  U I  U I  0 O D  0 O I  U I  1 C  D D  U I  1 D  U I  1 C  D D \
 D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 P  U I  o U  \
o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 U  U I  o U \
 1 C  o U  0 O D  1 C  1 C  1 C  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U\
 I  D L  0 O  U I  U I  U I  0 O D  0 O D  1 C  o U  U I  P 0  U I  o \
C  0 0 0  0 0 0  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  \
U I  U C  0 O U  0 O 0  0 0 O  0 0 1  0 O 0  U C  U I  1 0  U I  C 0  \
U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  \
0 O U  0 O  U I  U I  U I  0 O D  0 O I  U I  0 O D  0 O D  1 C  o U  \
U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I \
 U I  U I  0 0 1  C o  0 O D  0 0 D  0 O 0  0 O  U I  U I  0 O 0  0 I \
O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  0 O D  0 O \
D  1 C  o U  U I  P 0  U I  U C  U C  0 O  U I  U I  U I  0 O D  0 O I\
  U I  D I  D 0  U I  1 D  U I  D I  D 0  D L  U I  o U  0 O D  1 C  o\
 U  U I  1 P  U I  o U  o U  o U  o U  U I  1 o  U I  0 0 0  o C  1 L \
 0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  U I  0 0 P  0 0 1  0 I \
0  U I  D L  0 O  U I  U I  U I  o U  1 C  o U  1 C  0 O D  1 C  o U  \
U I  P 0  U I  o C  0 0 0  0 0 0  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0\
  1 L  U I  1 O  U I  U C  0 O O  C o  0 0 P  0 O 0  U C  U I  1 0  U \
I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D \
 0 0 O  0 O U  0 O  U I  U I  U I  0 O D  0 O I  U I  o U  1 C  o U  1\
 C  0 O D  1 C  o U  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I\
  D L  0 O  U I  U I  U I  U I  0 0 1  C o  0 O D  0 0 D  0 O 0  0 O  \
U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  \
U I  U I  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  P 0  U I  U C  U C\
  0 O  U I  U I  U I  0 O D  0 O I  U I  D O  1 L  U I  1 D  U I  D O \
 1 L  D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  U I  \
0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  C C  0 0 1  0 O 0  \
0 O O  0 O D  0 0 P  0 0 D  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  0 0\
 0  o C  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U C  C C  0 0 1  0 O\
 0  0 O O  0 O D  0 0 P  0 0 D  U C  U I  1 0  U I  C 0  U I  1 L  U I\
  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U\
 I  U I  U I  0 O D  0 O I  U I  C C  0 0 1  0 O 0  0 O O  0 O D  0 0 \
P  0 0 D  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O \
 U I  U I  U I  U I  0 0 1  C o  0 O D  0 0 D  0 O 0  0 O  U I  U I  0\
 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  C\
 C  0 0 1  0 O 0  0 O O  0 O D  0 0 P  0 0 D  U I  P 0  U I  U C  U C \
 0 O  U I  U I  U I  0 O D  0 O I  U I  D o  D U  U I  1 D  U I  D o  \
D U  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 \
D  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  U I  0 0 P  0\
 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  0 O D  o U  1 C  0 O D  o U\
  o U  0 O D  0 O D  0 O D  0 O D  U I  1 O  U I  0 0 O  C o  0 O C  0\
 O 0  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O \
 U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 1  U I  U C  0 O\
 D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  U C  U I  1 0  U I  1 1  U I  0\
 0 o  0 0 1  0 O L  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 \
O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0 \
 U I  1 1  U I  D 0  U I  1 1  U I  o U  o U  1 C  o U  o U  o U  o U \
 0 O D  o U  o U  1 C  0 O D  U I  1 1  U I  0 O D  1 C  o U  o U  1 C\
  U I  1 1  U I  o U  0 O D  0 O D  1 C  o U  1 C  o U  1 C  1 C  0 O \
D  0 O D  o U  1 C  U I  1 1  U I  0 O D  0 O D  1 C  o U  U I  1 1  U\
 I  C C  0 0 1  0 O 0  0 O O  0 O D  0 0 P  0 0 D  U I  1 1  U I  o U \
 1 C  o U  1 C  0 O D  1 C  o U  U I  1 0  0 O  U I  U I  0 O 0  0 I O\
  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  o U  o U  o \
U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U C  L 1  0\
 O 1  0 O 0  0 0 1  0 O 0  U I  0 0 C  C o  0 0 D  U I  C o  U I  0 0 \
I  0 0 1  0 0 0  C L  0 O L  0 O 0  0 O C  U I  C o  0 O O  0 O O  0 O\
 D  0 0 O  0 O U  U I  0 O O  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  \
0 0 1  0 I 0  U I  1 D  U I  U C  U I  1 U  U I  0 0 O  C o  0 O C  0 \
O 0  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  \
U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 1  U I  U C  0 O \
D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  U C  U I  1 0  U I  1 0  0 O  U \
I  0 O D  1 C  o U  1 C  0 O D  1 C  U I  1 O  U I  0 O D  0 O D  1 C \
 1 C  1 C  o U  U I  1 1  U I  0 O D  1 C  o U  o U  1 C  U I  1 0  0 \
O  U I  0 O D  0 O I  U I  D 0  D I  U I  1 D  U I  D 0  D I  D L  U I\
  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  0 O D  \
o U  o U  1 C  1 C  1 C  0 O D  U I  1 P  U I  o U  1 C  1 C  0 O D  U\
 I  1 I  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 o  \
U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  0 O D  0 \
O I  U I  D 0  1 L  U I  1 D  U I  D 0  1 L  D L  U I  0 0 0  o C  1 L\
  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  o U  0 O D  o U  \
o U  U I  1 o  U I  o U  0 O D  o U  o U  U I  U o  U I  0 0 0  o C  1\
 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 P  U I  0 0 0  o C  1 L\
  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  0 O O  0 O 0  0 O I  U I  o\
 C  1 L  o C  1 L  o C  0 0 0  1 L  1 L  U I  1 O  U I  0 0 O  C o  0 \
O C  0 O 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  0 O I  \
C o  0 0 O  C o  0 0 1  0 0 P  U I  1 0  U I  D L  0 O  U I  o C  o C \
 0 0 0  o C  U I  P 0  U I  o C  o C  1 L  o C  o C  o C  o C  0 0 0  \
0 0 0  1 L  o C  o C  o C  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 \
0  0 O  U I  0 O D  o U  0 O D  U I  P 0  U I  o C  o C  0 0 0  o C  U\
 I  1 P  U I  0 O I  0 O D  0 0 O  0 O O  U I  1 O  U I  U C  0 0 D  0\
 0 o  C L  C C  0 O 1  C o  0 0 O  0 0 O  0 O 0  0 O L  U C  U I  1 1 \
 U I  C o  0 0 P  0 0 P  0 0 1  0 0 D  U I  P 0  U I  0 I U  U I  U C \
 0 0 O  C o  0 O C  0 O 0  U C  U I  D L  U I  0 0 O  C o  0 O C  0 O \
0  U I  1 P  U I  0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U \
I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  U I  0 I D  U I \
 1 0  0 O  U I  0 O D  0 O D  1 C  1 C  1 C  o U  U I  P 0  U I  0 O D\
  o U  0 O D  U I  1 O  U I  U C  0 0 D  0 0 o  C L  0 O D  0 0 P  0 O\
 0  0 O C  U C  U I  1 0  0 O  U I  0 O D  1 C  o U  1 C  0 O D  1 C  \
U I  1 O  U I  0 O D  0 O D  1 C  1 C  1 C  o U  U I  1 1  U I  0 O I \
 C o  0 0 O  C o  0 0 1  0 0 P  U I  1 0  0 O  U I  0 O D  0 O I  U I \
 D P  1 L  U I  1 D  U I  D P  1 L  D L  U I  o U  o U  o U  o U  U I \
 1 U  U I  o C  1 L  0 0 0  o C  U I  1 o  U I  0 0 0  1 L  0 0 0  o C\
  1 L  0 O  0 O O  0 O 0  0 O I  U I  0 O D  1 C  o U  1 C  0 O D  1 C\
  U I  1 O  U I  0 O D  0 0 P  0 O 0  0 O C  0 0 D  U I  1 1  U I  0 O\
 I  C o  0 0 O  C o  0 0 1  0 0 P  U I  1 1  U I  0 O O  0 0 0  0 0 O \
 0 0 P  o P  0 O D  0 0 O  0 O o  U I  P 0  U I  o O  C o  0 O L  0 0 \
D  0 O 0  U I  1 0  U I  D L  0 O  U I  o C  o C  o C  0 0 0  o C  o C\
  U I  P 0  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 O D  0 0 P  0 O\
 0  0 O C  0 0 D  U I  1 0  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D\
  1 C  0 O D  o U  o U  U I  1 O  U I  U C  L 1  0 0 0  0 0 P  C o  0 \
O L  U I  o U  0 0 P  0 O 0  0 O C  0 0 D  D L  U I  U o  0 0 D  U C  \
U I  U o  U I  o C  o C  o C  0 0 0  o C  o C  U I  1 0  0 O  U I  0 0\
 0  o C  o C  o C  1 L  1 L  o C  1 L  o C  1 L  o C  o C  0 0 0  U I \
 P 0  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D\
  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0\
 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  C o  0 O O  0 O O  C D  0\
 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U C  U I  1 0  0 \
O  U I  o C  o C  0 0 0  1 L  1 L  o C  U I  P 0  U I  o C  1 L  o U  \
1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I \
 0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U\
 I  1 O  U I  U C  C o  0 0 D  0 O o  C D  0 0 I  0 O L  C o  0 I 0  0\
 O L  0 O D  0 0 D  0 0 P  C D  0 O D  0 0 P  0 O 0  0 O C  0 0 D  U C\
  U I  1 0  0 O  U I  o C  0 0 0  0 0 0  o C  o C  o C  o C  U I  P 0 \
 U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C\
  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0\
 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 0 o  0 0 D  0 O 0  C D  0 0 \
P  0 O 1  0 0 o  0 O C  C L  U C  U I  1 0  0 O  U I  0 O D  o U  o U \
 o U  0 O D  0 O D  o U  1 C  0 O D  1 C  0 O D  U I  P 0  U I  o C  1\
 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  \
1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O \
 0 O U  U I  1 O  U I  U C  0 0 I  C o  0 0 1  0 O 0  0 0 O  0 0 P  C \
o  0 O L  C L  0 O L  0 0 0  C C  0 O o  0 O 0  0 O O  U C  U I  1 0  \
0 O  U I  0 O D  o U  o U  o U  0 O D  0 O D  o U  1 C  0 O D  1 C  0 \
O D  U I  P 0  U I  0 O D  o U  o U  o U  0 O D  0 O D  o U  1 C  0 O \
D  1 C  0 O D  U I  P 0  P 0  U I  U 1  0 0 P  0 0 1  0 0 o  0 O 0  U \
1  0 O  U I  0 O I  0 0 0  0 0 1  U I  0 O D  o U  o U  o U  0 0 0  1 \
L  0 0 0  1 L  o C  U I  0 O D  0 0 O  U I  0 O D  0 0 P  0 O 0  0 O C\
  0 0 D  U I  D L  0 O  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  o C  1 L\
  0 0 0  o C  0 0 0  o C  o C  0 0 0  o C  U I  P 0  U I  o O  C o  0 \
O L  0 0 D  0 O 0  0 O  U I  U I  o U  1 C  0 O D  1 C  1 C  0 O D  U \
I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  0 O  U I  U I  0 O D  0 O \
I  U I  1 C  1 C  U I  1 D  U I  1 C  1 C  D L  U I  0 O D  o U  o U  \
1 C  1 C  1 C  0 O D  U I  1 o  U I  o U  0 O D  1 C  o U  U I  1 U  U\
 I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 I  U I  0 0 0  o C\
  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 D  U I  0 0 0  o C  \
1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 D  U I  0 O D  o U  o \
U  1 C  1 C  1 C  0 O D  0 O  U I  U I  o C  1 L  0 0 0  o C  0 0 0  0\
 0 0  0 0 0  0 0 0  0 0 0  1 L  o C  U I  P 0  U I  U C  0 O I  C o  0\
 O L  0 0 D  0 O 0  U C  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L \
 0 O  U I  U I  U I  o C  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0  0 0 0 \
 0 0 0  1 L  o C  U I  P 0  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0\
 0  1 L  o C  U I  1 O  U I  U C  0 0 I  C o  0 0 1  0 O 0  0 0 O  0 0\
 P  C o  0 O L  C L  0 O L  0 0 0  C C  0 O o  U C  U I  1 0  U I  C 0\
  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O\
  0 O U  0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D\
 L  0 O  U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  \
o U  o U  U I  1 O  U I  U C  0 0 I  C o  0 0 1  0 O 0  0 0 O  0 0 P  \
C o  0 O L  C L  0 O L  0 0 0  C C  0 O o  U I  P C  0 0 1  0 0 1  0 0\
 0  0 0 1  U C  U I  1 0  0 O  U I  U I  U I  o C  1 L  0 0 0  o C  0 \
0 0  0 0 0  0 0 0  0 0 0  0 0 0  1 L  o C  U I  P 0  U I  U C  U C  0 \
O  U I  U I  0 O D  0 O I  U I  o C  1 L  0 0 0  o C  0 0 0  0 0 0  0 \
0 0  0 0 0  0 0 0  1 L  o C  U I  P 0  P 0  U I  U C  0 0 P  0 0 1  0 \
0 o  0 O 0  U C  U I  C o  0 0 O  0 O O  U I  0 O D  o U  o U  o U  0 \
O D  0 O D  o U  1 C  0 O D  1 C  0 O D  U I  D L  U I  C C  0 0 0  0 \
0 O  0 0 P  0 O D  0 0 O  0 0 o  0 O 0  0 O  U I  U I  0 O D  0 O I  U\
 I  D I  D O  U I  1 D  U I  D I  D O  D L  U I  o U  0 O D  o U  o U \
 0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  o C\
  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  0 O D  o U  o U  o U  0 0 0  \
1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 0 P  0 O D  0 0 P  0 O L  \
0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0\
 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  0 O D  0 O \
I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  0 O D  0 0 D  U I  o L  0 0 \
0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  0 0 0 \
 o C  1 L  U I  P 0  U I  U C  0 0 o  0 0 O  0 O o  0 0 O  0 0 0  0 0 \
C  0 0 O  P U  U C  0 O  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L \
 0 O  U I  U I  U I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  \
o U  o U  1 C  1 C  o U  0 O D  0 O D  0 O D  U I  1 O  U I  o C  0 0 \
0  0 0 0  o C  1 L  U I  1 0  0 O  U I  U I  U I  0 O 0  0 I O  C C  0\
 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I \
 U I  U I  0 O D  0 O I  U I  1 C  D o  U I  1 D  U I  1 C  D o  D L  \
U I  o U  o U  o U  o U  U I  U o  U I  0 0 0  o C  1 L  0 0 0  1 L  0\
 0 0  0 0 0  o C  1 L  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  U I  1 U\
  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  U I  0 O 0  0 \
I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  o U  o U \
 o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U C  o L\
  C o  0 O C  0 O 0  U I  P C  0 0 1  0 0 1  0 0 0  0 0 1  U C  U I  1\
 0  0 O  U I  U I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  U \
C  U C  0 O  U I  U I  U I  0 O D  0 O I  U I  D I  D 1  U I  1 D  U I\
  D I  D 1  D L  U I  o U  0 O D  o U  o U  0 O  U I  U I  U I  0 O D \
 0 O I  U I  1 C  U I  1 D  U I  1 C  D L  U I  0 O D  0 O D  o U  1 C\
  0 O D  o U  0 O D  o U  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L\
  0 O  U I  U I  U I  0 O D  0 O I  U I  0 O D  o U  o U  o U  0 0 0  \
1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 O 0  0 0 I  0 O U  U C  U \
I  1 0  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  0 O D  o\
 U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 P  U I  0 O 0  0 0 I\
  0 O U  C D  0 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  U I  U I  \
U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O \
 U I  U C  o 0  0 O 0  0 0 P  U I  P C  L O  o 0  U I  L I  0 O 0  0 O\
 U  0 O 0  0 I O  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  o C  1 \
L  o C  1 L  o C  0 0 0  0 0 0  U I  P 0  U I  0 O D  o U  o U  o U  0\
 0 0  1 L  0 0 0  1 L  o C  U I  1 P  U I  0 O 0  0 0 I  0 O U  C D  0\
 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  \
0 O U  0 O  U I  U I  U I  U I  U I  0 0 0  o C  0 0 0  o C  1 L  U I \
 P 0  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 P\
  U I  0 O 0  0 0 I  0 O U  C D  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U \
I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  \
U I  U I  U I  o C  0 0 0  1 L  U I  P 0  U I  0 0 0  0 0 0  1 L  o C \
 1 L  0 0 0  1 L  1 L  0 0 0  1 L  o C  U I  1 O  U I  o C  1 L  o C  \
1 L  o C  0 0 0  0 0 0  U I  1 1  U I  0 0 0  o C  0 0 0  o C  1 L  U \
I  1 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  o C  0 0 0  1\
 L  U I  D L  0 O  U I  U I  U I  U I  U I  U I  o C  0 0 0  0 0 0  o \
C  1 L  U I  1 U  P 0  U I  U C  U I  1 D  U I  U C  U I  1 U  U I  o \
C  0 0 0  1 L  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U \
I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U\
 C  0 O 0  0 0 I  0 O U  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  \
U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  P I  U I\
  1 C  U I  D L  0 O  U I  U I  U I  U I  U I  o C  0 0 0  0 0 0  o C \
 1 L  U I  1 U  P 0  U I  o U  1 C  1 C  0 O D  1 C  o U  o U  U I  1 \
O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U\
 I  U C  0 O 0  0 0 I  0 O U  U C  U I  1 0  U I  C 0  U I  1 L  U I  \
C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 0\
  0 O  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  \
U I  U I  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  U I  0 O 0  0 I O  \
C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  o U  o U  o U \
 1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U C  P C  L O\
  o 0  U I  P C  0 0 1  0 0 1  0 0 0  0 0 1  U C  U I  1 0  0 O  U I  \
U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  o U  0 O D  o \
U  0 O D  1 C  1 C  0 O D  o U  U I  P 0  U I  C 0  U I  C U  0 O  U I\
  U I  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 O\
 D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 \
O L  0 O D  0 0 O  0 O o  U C  U I  1 0  U I  1 0  U I  P I  U I  1 L \
 U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D D  D O  U I  \
1 D  U I  D D  D O  D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 P  U I  o\
 U  1 C  1 C  0 O D  U I  1 o  U I  o U  0 O D  o U  o U  U I  1 P  U \
I  o U  0 O D  1 C  o U  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D\
 U  D I  U I  1 D  U I  D U  D I  D L  U I  o U  0 O D  1 C  o U  U I \
 U o  U I  o U  0 O D  1 C  o U  0 O  U I  U I  U I  U I  0 O I  0 0 0\
  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0\
 0  0 0 0  U I  0 O D  0 0 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0\
 0 0  1 L  o C  U I  1 O  U I  U C  0 O L  0 O D  0 0 O  0 O o  U C  U\
 I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 \
0 O  0 0 0  0 0 P  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  \
0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O \
 0 O U  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U\
 I  U I  U I  U I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  \
o U  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  \
U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0\
  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 0  0\
 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D P  D 1  U I  1 \
D  U I  D P  D 1  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C\
  1 C  0 O D  U I  U o  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o \
U  1 C  o U  0 O D  1 C  0 O D  U I  1 I  U I  o C  0 0 0  0 0 0  0 0 \
0  1 L  1 L  1 L  1 L  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  U I  1 I\
  U I  o U  1 C  1 C  0 O D  U I  1 I  U I  0 0 0  1 L  0 0 0  o C  1 \
L  0 O  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O L  0 O 0  \
0 0 O  U I  1 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o \
C  U I  1 O  U I  U C  0 0 D  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  0 O O\
  0 O 0  0 0 L  0 O D  0 O L  U C  U I  1 0  U I  1 0  U I  P I  U I  \
1 L  U I  D L  0 O  U I  U I  U I  U I  0 O I  0 0 0  0 0 1  U I  o C \
 0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0 \
O D  0 0 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U \
I  1 O  U I  U C  0 0 D  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  0 O O  0 O\
 0  0 0 L  0 O D  0 O L  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  \
U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  0 0 0  0 0\
 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0\
 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  P 0  P 0  U I  o L  0 0 0 \
 0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  o C  o C  \
o C  0 0 0  o C  o C  o C  1 L  0 0 0  o C  U I  P 0  U I  U C  0 0 I \
 0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o\
  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  L \
U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  P L  0 O 0  0 0 L  0 O D  0 O L \
 1 o  P U  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  U L  C o  0 O C  0 0 \
I  D C  0 O D  0 0 P  0 O 0  0 O C  P 0  C C  C o  0 0 P  C C  0 O 1  \
0 O 0  0 0 1  U o  D 0  0 O O  0 0 D  0 0 P  0 0 1  0 O 0  C o  0 O C \
 0 0 D  U o  D O  D 1  0 0 o  0 0 1  0 O L  P 0  U C  U I  1 U  U I  o\
 C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I \
 1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U \
I  U I  U I  U I  o U  1 C  0 O D  0 O D  1 C  1 C  U I  P 0  U I  0 O\
 D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 \
0 1  0 O 0  0 O I  0 O 0  0 0 1  0 O 0  0 0 1  U C  U I  1 0  U I  C 0\
  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O\
  0 O U  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  o U  1 \
C  0 O D  0 O D  1 C  1 C  U I  D L  0 O  U I  U I  U I  U I  U I  U I\
  U I  0 O D  0 O I  U I  D D  D I  U I  1 D  U I  D D  D I  D L  U I \
 o U  0 O D  o U  o U  U I  1 D  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0\
  0 0 0  U I  1 P  U I  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  U I \
 U I  U I  U I  o C  o C  o C  0 0 0  o C  o C  o C  1 L  0 0 0  o C  \
U I  P 0  U I  o C  o C  o C  0 0 0  o C  o C  o C  1 L  0 0 0  o C  U\
 I  1 U  U I  U C  U o  D O  D 1  0 0 1  0 O 0  0 O I  0 O 0  0 0 1  0\
 O 0  0 0 1  P 0  U C  U I  1 U  U I  o U  1 C  0 O D  0 O D  1 C  1 C\
  0 O  U I  U I  U I  U I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C \
 0 O D  o U  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U \
I  1 O  U I  o C  o C  o C  0 0 0  o C  o C  o C  1 L  0 0 0  o C  U I\
  1 0  0 O  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O L  0 O\
 0  0 0 O  U I  1 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L\
  o C  U I  1 O  U I  U C  0 0 I  D O  0 0 I  U C  U I  1 0  U I  1 0 \
 U I  P I  U I  1 L  U I  D L  0 O  U I  U I  U I  U I  0 O I  0 0 0  \
0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0\
  0 0 0  U I  0 O D  0 0 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0\
 0  1 L  o C  U I  1 O  U I  U C  0 0 I  D O  0 0 I  U C  U I  1 0  U \
I  D L  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0 \
 0 0 P  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 \
0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I\
  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U \
I  U I  U I  U I  0 O D  0 O I  U I  U C  0 0 D  0 0 0  0 0 I  D L  1 \
o  1 o  U C  U I  0 O D  0 0 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 \
0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  \
0 O D  0 0 O  0 O U  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I \
 0 O D  1 C  o U  o U  o U  U I  P 0  U I  U C  0 0 I  0 O L  0 0 o  0\
 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  \
0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 0 I  D O  0 0 I \
 1 D  0 0 D  0 0 P  0 0 1  0 O 0  C o  0 O C  0 0 D  1 o  P U  0 O C  \
0 0 0  0 O O  0 O 0  P 0  D O  0 0 o  0 0 1  0 O L  P 0  U C  U I  1 U\
  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0\
 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 U \
 U I  U C  U L  U C  U I  1 U  U I  U C  0 0 O  C o  0 O C  0 O 0  P 0\
  U C  U I  1 U  U I  o C  0 0 0  0 0 0  o C  1 L  0 O  U I  U I  U I \
 U I  U I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I\
  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  0 O\
 D  1 C  o U  o U  o U  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0\
 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I\
  U I  0 O D  0 O D  0 O D  1 C  o U  0 O D  1 C  o U  0 O D  1 C  U I\
  P 0  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1\
 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O\
  0 O 0  0 0 0  1 P  0 0 I  D O  0 0 I  1 D  0 0 D  0 0 P  0 0 1  0 O \
0  C o  0 O C  0 0 D  1 o  P U  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  \
U L  0 0 o  0 0 1  0 O L  P 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  \
1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  \
0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 U  U I  U C  U L  U C  U I  \
1 U  U I  U C  0 0 O  C o  0 O C  0 O 0  P 0  U C  U I  1 U  U I  o C \
 0 0 0  0 0 0  o C  1 L  0 O  U I  U I  U I  U I  U I  U I  U I  o U  \
0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 P  U I  C o  0 0 I  0 \
0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  0 O D  0 O D  0 O D  1 C  o U\
  0 O D  1 C  o U  0 O D  1 C  U I  1 0  0 O  U I  U I  U I  0 O 0  0 \
O L  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 O D  o U\
  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 0 L  C \
o  0 0 o  0 O U  0 O 1  0 0 O  U C  U I  1 0  U I  1 0  U I  P I  U I \
 1 L  U I  D L  0 O  U I  U I  U I  U I  0 O I  0 0 0  0 0 1  U I  o C\
  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0\
 O D  0 0 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U\
 I  1 O  U I  U C  0 0 L  C o  0 0 o  0 O U  0 O 1  0 0 O  U C  U I  1\
 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 O  \
0 0 0  0 0 P  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0\
  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O \
U  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U\
 I  U I  U I  U I  U I  o U  o U  0 O D  U I  P 0  U I  U C  0 0 I  0 \
O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0\
 O U  0 O D  0 0 O  1 P  0 0 D  0 0 P  0 0 1  0 O 0  C o  0 O C  1 P  \
0 0 L  C o  0 0 o  0 O U  0 O 1  0 0 O  0 O L  0 O D  0 0 L  0 O 0  1 \
P  0 0 P  0 0 L  1 o  P U  0 O C  0 0 0  0 O O  0 O 0  P 0  L O  0 O L\
  C o  0 I 0  o P  0 O D  0 0 L  0 O 0  L U  0 0 P  0 0 1  0 O 0  C o \
 0 O C  U L  C o  0 O C  0 0 I  D C  C C  0 O 1  C o  0 0 O  0 0 O  0 \
O 0  0 O L  P 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 \
0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  \
0 O D  0 0 O  0 O U  0 O  U I  U I  U I  U I  U I  U I  o U  0 O D  o \
U  0 O D  1 C  1 C  0 O D  o U  U I  1 P  U I  C o  0 0 I  0 0 I  0 O \
0  0 0 O  0 O O  U I  1 O  U I  o U  o U  0 O D  U I  1 0  0 O  U I  U\
 I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 \
O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U\
 I  U C  0 O D  0 O L  0 O D  0 0 L  0 O 0  U C  U I  1 0  U I  1 0  U\
 I  P I  U I  1 L  U I  D L  0 O  U I  U I  U I  U I  0 O I  0 0 0  0 \
0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  \
0 0 0  U I  0 O D  0 0 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0\
  1 L  o C  U I  1 O  U I  U C  0 O D  0 O L  0 O D  0 0 L  0 O 0  U C\
  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I \
 0 0 O  0 0 0  0 0 P  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o \
C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0\
 O  0 O U  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O\
  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P\
  U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  U C  U I  0 O D  0 0 O  U I  o\
 C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I \
 1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  D L  0 O  U \
I  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  o C  1 L  0 0 0  o C  0\
 0 0  1 L  0 0 0  U I  P 0  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O \
D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P\
  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 0 P  C L  0 O 1  1 P  0 O \
D  0 O L  0 O D  0 0 L  0 O 0  1 o  P U  0 0 o  0 0 1  0 O L  P 0  0 O\
 1  0 0 P  0 0 P  0 0 I  D L  1 o  1 o  0 0 C  0 0 C  0 0 C  1 P  0 0 \
D  0 0 P  0 0 1  0 O 0  C o  0 O C  0 O L  0 O D  0 0 L  0 O 0  1 P  0\
 0 P  0 0 0  1 o  0 0 L  0 O D  0 O 0  0 0 C  1 o  U C  U I  1 U  U I \
 o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U \
I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 U  U I  \
U C  U L  C o  0 O C  0 0 I  D C  0 O L  0 O D  0 0 O  0 O o  P 0  D o\
  D o  U L  C o  0 O C  0 0 I  D C  0 O C  0 0 0  0 O O  0 O 0  P 0  0\
 O D  o P  0 O D  0 0 L  0 O 0  L O  0 O L  C o  0 I 0  U C  0 O  U I \
 U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U\
 I  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  o C  1 L  0 0 0  o C  \
0 0 0  1 L  0 0 0  U I  P 0  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O\
 D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 \
P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 0 P  C L  0 O 1  1 P  0 O\
 D  0 O L  0 O D  0 0 L  0 O 0  1 o  P U  0 0 o  0 0 1  0 O L  P 0  U \
C  U I  1 U  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0 \
 0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U\
  U I  1 U  U I  U C  U L  C o  0 O C  0 0 I  D C  0 O L  0 O D  0 0 O\
  0 O o  P 0  D o  D o  U L  C o  0 O C  0 0 I  D C  0 O C  0 0 0  0 O\
 O  0 O 0  P 0  0 O D  o P  0 O D  0 0 L  0 O 0  L O  0 O L  C o  0 I \
0  U C  0 O  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O L  0 \
O 0  0 0 O  U I  1 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 \
L  o C  U I  1 O  U I  U C  0 I 0  0 0 P  1 D  0 O O  0 O L  U C  U I \
 1 0  U I  1 0  U I  P I  U I  1 L  U I  D L  0 O  U I  U I  U I  U I \
 0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o \
C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  0 O D  o U  o U  o U  \
0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 I 0  0 0 P  1 D  0 \
O O  0 O L  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 O\
 D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  0 0 0  0 0 0  1 L  1 L \
 0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 \
0 1  0 O D  0 0 O  0 O U  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0\
  U I  D L  0 O  U I  U I  U I  U I  U I  U I  o C  o C  0 O D  0 O D \
 1 C  1 C  1 C  o U  0 O D  0 O D  o U  1 C  U I  P 0  U I  o C  0 0 0\
  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I\
  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 U  U I  U C  U L  0\
 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D P  U C  0 O  U I  U I  U I  U I\
  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 P  U \
I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  o C  o C  0 \
O D  0 O D  1 C  1 C  1 C  o U  0 O D  0 O D  o U  1 C  U I  1 0  0 O \
 U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  \
U I  1 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I \
 1 O  U I  U C  0 O O  0 O C  U C  U I  1 0  U I  1 0  U I  P I  U I  \
1 L  U I  D L  0 O  U I  U I  U I  U I  0 O I  0 0 0  0 0 1  U I  o C \
 0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0 \
O D  0 0 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U \
I  1 O  U I  U C  0 O O  0 O C  U C  U I  1 0  U I  D L  0 O  U I  U I\
  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  0 0\
 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U\
 I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  P 0  P 0  U I  o L \
 0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O\
 D  0 O D  1 C  1 C  0 O D  1 C  0 O D  o U  0 O D  o U  o U  1 C  U I\
  P 0  U I  U 1  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1\
 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O\
  0 O 0  0 0 0  1 P  0 O O  C o  0 O D  0 O L  0 I 0  0 O C  0 0 0  0 \
0 P  0 O D  0 0 0  0 0 O  C D  C C  0 0 0  0 O C  1 o  P U  0 O C  0 0\
 0  0 O O  0 O 0  P 0  0 0 I  0 O L  C o  0 I 0  L P  0 O D  0 O O  0 \
O 0  0 0 0  U L  0 0 o  0 0 1  0 O L  P 0  U 1  U I  1 U  U I  o C  0 \
0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  \
U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  U I\
  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 P  U \
I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  0 O D  0 O D\
  1 C  1 C  0 O D  1 C  0 O D  o U  0 O D  o U  o U  1 C  U I  1 0  0 \
O  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O\
  U I  1 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U \
I  1 O  U I  U C  0 O O  0 O C  0 O L  0 O D  0 0 L  0 O 0  U C  U I  \
1 0  U I  1 0  U I  P I  U I  1 L  U I  D L  0 O  U I  U I  U I  U I  \
0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C\
  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  0 O D  o U  o U  o U  0\
 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 O O  0 O C  0 O L  0\
 O D  0 0 L  0 O 0  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  \
U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  0 0 0  0 0 0  1\
 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0\
 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  P 0  P 0  U I  o L  0 0 0  0 0 \
O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O D  1\
 C  1 C  0 O D  1 C  0 O D  o U  0 O D  o U  o U  1 C  U I  P 0  U I  \
U 1  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0\
 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0\
 0  1 P  0 O O  C o  0 O D  0 O L  0 I 0  0 O C  0 0 0  0 0 P  0 O D  \
0 0 0  0 0 O  C D  C C  0 0 0  0 O C  1 o  P U  0 O C  0 0 0  0 O O  0\
 O 0  P 0  0 0 I  0 O L  C o  0 I 0  o P  0 O D  0 0 L  0 O 0  L P  0 \
O D  0 O O  0 O 0  0 0 0  U L  0 0 o  0 0 1  0 O L  P 0  U 1  U I  1 U\
  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0\
 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I \
 U I  U I  U I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U\
  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I\
  0 O D  0 O D  1 C  1 C  0 O D  1 C  0 O D  o U  0 O D  o U  o U  1 C\
  U I  1 0  0 O  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O L\
  0 O 0  0 0 O  U I  1 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0\
  1 L  o C  U I  1 O  U I  U C  0 0 o  0 0 P  0 0 o  C L  0 O 0  U C  \
U I  1 0  U I  1 0  U I  P I  U I  1 L  U I  D L  0 O  U I  U I  U I  \
U I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L\
  o C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  0 O D  o U  o U  o\
 U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 0 o  0 0 P  0 0\
 o  C L  0 O 0  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I \
 0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  0 0 0  0 0 0  1 L  \
1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P\
  0 0 1  0 O D  0 0 O  0 O U  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0\
 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  \
U C  U I  U C  U I  0 O D  0 0 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 \
0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1\
  0 O D  0 0 O  0 O U  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U \
I  0 0 0  1 L  1 L  0 0 0  0 0 0  1 L  0 0 0  0 0 0  0 0 0  0 0 0  0 0\
 0  o C  o C  o C  1 L  1 L  1 L  o C  0 0 0  U I  P 0  U I  U C  0 0 \
I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0\
 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  \
0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0  1 o  0 0 D  0 O 0  C o \
 0 0 1  C C  0 O 1  1 o  P U  0 0 U  P 0  U C  U I  1 U  U I  0 0 o  0\
 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 \
0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  o C  0 0 0\
  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I\
  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 0  0 O  U I  U I  U\
 I  U I  U I  U I  U I  o U  1 C  0 O D  1 C  1 C  0 O D  U I  P 0  U \
I  0 0 0  1 L  1 L  0 0 0  0 0 0  1 L  0 0 0  0 0 0  0 0 0  0 0 0  0 0\
 0  o C  o C  o C  1 L  1 L  1 L  o C  0 0 0  0 O  U I  U I  U I  U I \
 U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  \
1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  \
0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1\
 0  U I  P 0  P 0  U I  1 C  1 C  U I  D L  0 O  U I  U I  U I  U I  U\
 I  U I  U I  0 0 0  1 L  1 L  0 0 0  0 0 0  1 L  0 0 0  0 0 0  0 0 0 \
 0 0 0  0 0 0  o C  o C  o C  1 L  1 L  1 L  o C  0 0 0  U I  P 0  U I\
  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I \
 0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0\
 0 0  1 P  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0  1 o  0 0 I  \
0 O L  C o  0 I 0  1 o  P U  0 0 L  0 O D  0 O O  0 O 0  0 0 0  C D  0\
 O D  0 O O  P 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0\
 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1 \
 0 O D  0 0 O  0 O U  0 O  U I  U I  U I  U I  U I  U I  0 O 0  0 O L \
 0 O D  0 O I  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L \
 o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  \
0 0 O  0 O U  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0\
 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  L O  o P  U C  U I  1 0\
  U I  C o  0 0 O  0 O O  U I  0 0 O  0 0 0  0 0 P  U I  U C  U L  0 0\
 0  0 0 1  0 O O  0 O 0  0 0 1  P 0  U C  U I  0 O D  0 0 O  U I  o C \
 0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 \
P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 0  U I  0 0 0\
  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0\
 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U \
I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0\
 P  0 O 1  U I  1 O  U I  U C  L D  L D  U C  U I  1 0  U I  D L  0 O \
 U I  U I  U I  U I  U I  U I  U I  0 0 0  1 L  1 L  0 0 0  0 0 0  1 L\
  0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  o C  o C  o C  1 L  1 L  1 L  o C\
  0 0 0  U I  P 0  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O \
 D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  \
0 O D  0 O O  0 O 0  0 0 0  1 P  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C \
L  0 O 0  1 o  0 0 I  0 O L  C o  0 I 0  1 o  P U  U L  0 0 0  0 0 1  \
0 O O  0 O 0  0 0 1  P 0  0 O O  0 O 0  0 O I  C o  0 0 o  0 O L  0 0 \
P  U L  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  C D  0 O\
 D  0 O O  P 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0\
  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0\
 O D  0 0 O  0 O U  0 O  U I  U I  U I  U I  U I  U I  0 O 0  0 O L  0\
 O D  0 O I  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0 \
 0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U\
  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D \
 0 0 P  0 O 1  U I  1 O  U I  U C  L O  o P  U C  U I  1 0  U I  0 0 0\
  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0\
 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U \
I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0\
 P  0 O 1  U I  1 O  U I  U C  L D  L D  U C  U I  1 0  U I  D L  0 O \
 U I  U I  U I  U I  U I  U I  U I  0 0 0  1 L  1 L  0 0 0  0 0 0  1 L\
  0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  o C  o C  o C  1 L  1 L  1 L  o C\
  0 0 0  U I  P 0  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O \
 D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  \
0 O D  0 O O  0 O 0  0 0 0  1 P  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C \
L  0 O 0  1 o  0 0 I  0 O L  C o  0 I 0  1 o  P U  0 0 I  0 O L  C o  \
0 I 0  0 O L  0 O D  0 0 D  0 0 P  C D  0 O D  0 O O  P 0  U C  U I  1\
 U  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0\
 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U \
I  U I  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  o C  0 0 \
0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U \
I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 P  U I  0 0 D  0 0\
 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U \
I  U C  L D  P o  U C  U I  1 0  U I  C o  0 0 O  0 O O  U I  0 O L  0\
 O 0  0 0 O  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o\
 C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 \
0 O  0 O U  U I  1 0  U I  P I  U I  1 C  D O  U I  D L  0 O  U I  U I\
  U I  U I  U I  U I  U I  0 0 0  1 L  1 L  0 0 0  0 0 0  1 L  0 0 0  \
0 0 0  0 0 0  0 0 0  0 0 0  o C  o C  o C  1 L  1 L  1 L  o C  0 0 0  \
U I  P 0  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o\
  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 \
O O  0 O 0  0 0 0  1 P  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0 \
 1 o  C C  0 O 1  C o  0 0 O  0 0 O  0 O 0  0 O L  1 o  U C  U I  1 U \
 U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 \
0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 U  \
U I  U C  1 o  U C  0 O  U I  U I  U I  U I  U I  U I  U I  o U  1 C  \
0 O D  1 C  1 C  0 O D  U I  P 0  U I  0 0 0  1 L  1 L  0 0 0  0 0 0  \
1 L  0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  o C  o C  o C  1 L  1 L  1 L  \
o C  0 0 0  0 O  U I  U I  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 \
O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0\
  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0\
 O D  0 0 O  0 O U  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 \
0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  L D  P o  U C  U \
I  1 0  U I  C o  0 0 O  0 O O  U I  0 0 O  0 0 0  0 0 P  U I  1 O  U \
I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  \
U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 P  U I\
  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  \
U I  1 O  U I  U C  L O  o P  U C  U I  1 0  U I  1 0  U I  D L  0 O  \
U I  U I  U I  U I  U I  U I  U I  0 0 0  1 L  1 L  0 0 0  0 0 0  1 L \
 0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  o C  o C  o C  1 L  1 L  1 L  o C \
 0 0 0  U I  P 0  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  \
D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0\
 O D  0 O O  0 O 0  0 0 0  1 P  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L\
  0 O 0  1 o  0 0 o  0 0 D  0 O 0  0 0 1  1 o  U C  U I  1 U  U I  o C\
  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1\
 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 U  U I  U C \
 1 o  U C  0 O  U I  U I  U I  U I  U I  U I  U I  o U  1 C  0 O D  1 \
C  1 C  0 O D  U I  P 0  U I  0 0 0  1 L  1 L  0 0 0  0 0 0  1 L  0 0 \
0  0 0 0  0 0 0  0 0 0  0 0 0  o C  o C  o C  1 L  1 L  1 L  o C  0 0 \
0  0 O  U I  U I  U I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O\
 D  o U  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1\
 O  U I  0 0 0  1 L  1 L  0 0 0  0 0 0  1 L  0 0 0  0 0 0  0 0 0  0 0 \
0  0 0 0  o C  o C  o C  1 L  1 L  1 L  o C  0 0 0  U I  1 0  0 O  U I\
  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I \
 1 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O\
  U I  U C  0 O D  0 O C  0 O O  C L  U C  U I  1 0  U I  1 0  U I  P \
I  U I  1 L  U I  D L  0 O  U I  U I  U I  U I  0 O I  0 0 0  0 0 1  U\
 I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0 \
 U I  0 O D  0 0 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L \
 o C  U I  1 O  U I  U C  0 O D  0 O C  0 O O  C L  U C  U I  1 0  U I\
  D L  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  \
0 0 P  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0\
  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I \
 P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I\
  U I  U I  U I  0 O D  0 O I  U I  o C  1 L  o U  1 C  1 C  0 O D  1 \
C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 \
P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  \
0 O U  0 O 0  0 0 O  0 O 0  0 0 D  0 O D  0 0 D  0 0 0  0 0 1  0 0 I  \
0 0 o  0 O L  0 0 D  C o  0 0 1  U C  U I  1 0  U I  P 0  P 0  U I  U \
C  1 L  U C  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  o C  0 \
0 0  0 0 0  1 L  1 L  o C  0 0 0  o C  o C  o C  U I  P 0  U I  U C  0\
 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  \
0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 \
P  0 O U  0 O 0  0 0 O  0 O 0  0 0 D  0 O D  0 0 D  1 o  P U  C o  C C\
  0 0 P  0 O D  0 0 0  0 0 O  P 0  0 0 I  0 O L  C o  0 I 0  U L  0 O \
D  0 O C  0 O O  C L  P 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  1 L \
 1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 \
P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  U I  U I  U I  0 O \
0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U\
 I  o C  0 0 0  0 0 0  1 L  1 L  o C  0 0 0  o C  o C  o C  U I  P 0  \
U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0\
 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0\
  0 0 0  1 P  0 0 I  0 0 o  0 O L  0 0 D  C o  0 0 1  1 o  0 O C  0 0 \
0  0 0 L  0 O D  0 O 0  1 o  0 0 P  0 0 P  U C  U I  1 U  U I  o C  0 \
0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  \
U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 U  U I  U C  1 o\
  0 0 I  0 O L  C o  0 I 0  U C  0 O  U I  U I  U I  U I  U I  U I  o \
U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 P  U I  C o  0 0 I \
 0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 \
L  o C  0 0 0  o C  o C  o C  U I  1 0  0 O  U I  U I  U I  0 O 0  0 O\
 L  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 O D  o U \
 o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 O I  D I\
  0 O C  U C  U I  1 0  U I  1 0  U I  P I  U I  1 L  U I  D L  0 O  U\
 I  U I  U I  U I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1\
 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  0 O \
D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 O\
 I  D I  0 O C  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I \
 0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  0 0 0  0 0 0  1 L  \
1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P\
  0 0 1  0 O D  0 0 O  0 O U  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0\
 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  \
U C  1 P  0 O I  D I  0 O C  U C  U I  0 O D  0 0 O  U I  o C  0 0 0  \
0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  \
0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  D L  0 O  U I  U I  U I\
  U I  U I  U I  U I  o C  0 0 0  1 L  o C  o C  1 L  1 L  1 L  1 L  0\
 0 0  0 0 0  0 0 0  0 0 0  U I  P 0  U I  U C  0 0 I  0 O L  0 0 o  0 \
O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0\
 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 O I  D I  0 O C  \
L 1  0 O 0  0 0 D  0 0 P  0 O 0  0 0 1  1 o  P U  0 0 o  0 0 1  0 O L \
 P 0  U C  U I  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I \
 1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o\
  0 0 D  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  \
0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O \
 0 O U  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 O 0  0 O L  0 O\
 D  0 O I  U I  U C  1 P  0 O C  D 0  0 0 o  D P  U C  U I  0 O D  0 0\
 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0\
 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  D \
L  0 O  U I  U I  U I  U I  U I  U I  U I  o C  0 0 0  1 L  o C  o C  \
1 L  1 L  1 L  1 L  0 0 0  0 0 0  0 0 0  0 0 0  U I  P 0  U I  U C  0 \
0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0\
 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P\
  0 O I  D I  0 O C  L 1  0 O 0  0 0 D  0 0 P  0 O 0  0 0 1  1 o  P U \
 0 0 o  0 0 1  0 O L  P 0  U C  U I  1 U  U I  0 0 o  0 0 1  0 O L  0 \
O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D\
  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1\
 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P \
 0 0 1  0 O D  0 0 O  0 O U  U I  1 0  U I  1 U  U I  U C  U L  C o  0\
 O C  0 0 I  D C  0 0 D  0 0 P  0 0 1  0 O 0  C o  0 O C  0 0 P  0 I 0\
  0 0 I  0 O 0  P 0  o I  o P  L U  U C  0 O  U I  U I  U I  U I  U I \
 U I  U I  0 O D  0 O I  U I  D D  U I  1 D  U I  D D  D L  U I  o U  \
o U  o U  o U  U I  1 D  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I\
  1 D  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U \
I  U o  U I  o U  o U  o U  o U  U I  1 D  U I  o U  0 O D  1 C  o U  \
0 O  U I  U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D \
L  0 O  U I  U I  U I  U I  U I  U I  U I  o C  0 0 0  1 L  o C  o C  \
1 L  1 L  1 L  1 L  0 0 0  0 0 0  0 0 0  0 0 0  U I  P 0  U I  U C  0 \
0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0\
 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P\
  0 O I  D I  0 O C  L 1  0 O 0  0 0 D  0 0 P  0 O 0  0 0 1  1 o  P U \
 0 0 o  0 0 1  0 O L  P 0  U C  U I  1 U  U I  0 0 o  0 0 1  0 O L  0 \
O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D\
  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1\
 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P \
 0 0 1  0 O D  0 0 O  0 O U  U I  1 0  U I  1 U  U I  U C  U L  C o  0\
 O C  0 0 I  D C  0 0 D  0 0 P  0 0 1  0 O 0  C o  0 O C  0 0 P  0 I 0\
  0 0 I  0 O 0  P 0  L U  o U  o o  L O  o P  P C  U C  0 O  U I  U I \
 U I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 P\
  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  o C  0 0\
 0  1 L  o C  o C  1 L  1 L  1 L  1 L  0 0 0  0 0 0  0 0 0  0 0 0  U I\
  1 0  0 O  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O L  0 O\
 0  0 0 O  U I  1 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L\
  o C  U I  1 O  U I  U C  0 O I  0 0 P  0 0 L  U C  U I  1 0  U I  1 \
0  U I  P I  U I  1 L  U I  D L  0 O  U I  U I  U I  U I  0 O I  0 0 0\
  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0\
 0  0 0 0  U I  0 O D  0 0 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0\
 0 0  1 L  o C  U I  1 O  U I  U C  0 O I  0 0 P  0 0 L  U C  U I  1 0\
  U I  D L  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 \
0 0  0 0 P  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  \
0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U \
 U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I\
  U I  U I  U I  U I  o U  1 C  o U  o U  U I  P 0  U I  U C  0 0 I  0\
 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  \
0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  o O \
 1 P  L 1  1 P  L P  1 o  P U  0 0 O  C o  0 O C  0 O 0  P 0  U C  U I\
  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0\
 U  0 0 o  0 0 0  0 0 P  0 O 0  U I  1 O  U I  o C  0 0 0  0 0 0  o C \
 1 L  U I  1 0  U I  1 U  U I  U C  U L  0 0 o  0 0 1  0 O L  P 0  U C\
  U I  1 U  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  \
0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U \
 U I  1 U  U I  U C  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D O  D\
 U  U L  C C  0 O 1  C D  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  P 0  0\
 0 O  C o  U C  0 O  U I  U I  U I  U I  U I  o U  0 O D  o U  0 O D  \
1 C  1 C  0 O D  o U  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  \
0 O O  U I  1 O  U I  o U  1 C  o U  o U  U I  1 0  0 O  U I  U I  U I\
  0 O 0  0 O L  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I \
 0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C\
  0 0 o  0 0 1  0 O L  0 0 D  0 0 0  0 O L  0 0 L  0 O 0  U C  U I  1 \
0  U I  1 0  U I  P I  U I  1 L  U I  D L  0 O  U I  U I  U I  U I  0 \
O D  0 O I  U I  D 1  D I  U I  1 D  U I  D 1  D I  D L  U I  o U  o U\
  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  U o  U I  0 0 0  \
1 L  0 0 0  o C  1 L  U I  U o  U I  o U  o U  0 O D  o U  0 O D  o U \
 o U  1 C  1 C  0 O D  U I  1 I  U I  o U  1 C  o U  0 O D  1 C  1 C  \
1 C  U I  1 P  U I  o U  o U  o U  o U  U I  1 U  U I  0 O D  o U  o U\
  1 C  1 C  1 C  0 O D  0 O  U I  U I  U I  U I  0 O I  0 0 0  0 0 1  \
U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0\
  U I  0 O D  0 0 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L\
  o C  U I  1 O  U I  U C  0 0 o  0 0 1  0 O L  0 0 D  0 0 0  0 O L  0\
 0 L  0 O 0  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 \
O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  0 0 0  0 0 0  1 L  1 L\
  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  0\
 0 1  0 O D  0 0 O  0 O U  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O \
0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  o C  1 L  1 L  U I  P \
0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 \
0 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 U\
  U I  U C  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D o  U C  0 O  \
U I  U I  U I  U I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D \
 o U  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O \
 U I  o C  1 L  1 L  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  \
0 O L  0 O 0  0 0 O  U I  1 O  U I  o U  0 O D  o U  0 O D  1 C  1 C  \
0 O D  o U  U I  1 0  U I  P O  U I  1 C  U I  D L  0 O  U I  U I  U I\
  U I  0 0 1  C o  0 O D  0 0 D  0 O 0  0 O  U I  U I  0 O 0  0 I O  C\
 C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  o U  o U  o U  \
1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U C  P C  0 0 \
1  0 0 1  0 0 0  0 0 1  U I  P O  0 O L  0 O D  0 0 O  0 O o  P I  U I\
  0 O 0  0 O L  0 O 0  0 O C  0 O 0  0 0 O  0 0 P  1 1  U I  L O  C o \
 0 0 D  0 0 D  0 O D  0 0 O  0 O U  D L  U C  U I  1 U  U I  o C  0 0 \
0  0 0 0  o C  1 L  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 \
O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 1 \
 U I  U C  0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  U C  U I  1 0  U \
I  1 0  0 O  U I  U I  U I  C C  0 0 0  0 0 O  0 0 P  0 O D  0 0 O  0 \
0 o  0 O 0  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U \
I  U I  0 0 0  0 0 0  0 0 0  0 0 0  o C  1 L  0 0 0  o C  0 0 0  o C  \
o C  0 0 0  o C  U I  P 0  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 \
0  1 L  o C  U I  1 O  U I  U C  0 O 0  0 I O  0 0 P  0 O 0  0 0 1  0 \
0 O  C o  0 O L  0 O L  0 O D  0 0 O  0 O o  U C  U I  1 0  U I  C 0  \
U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  \
0 O U  0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L\
  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  U I  0 O D  0 O I  U I  1 C\
  D D  U I  1 D  U I  1 C  D D  D L  U I  0 O D  1 C  1 C  o U  0 O D \
 1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 D  U I  o C  o C  \
0 0 0  0 0 0  o C  o C  0 0 0  U I  U o  U I  0 O D  1 C  1 C  o U  0 \
O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 P  U I  0 0 0 \
 0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  0 0 0  0 0 0  o C \
 0 0 0  o C  1 L  o C  1 L  1 L  U I  U o  U I  0 O D  0 O D  o U  1 C\
  0 O D  o U  0 O D  o U  0 O  U I  U I  0 O D  0 O I  U I  0 0 0  0 0\
 0  0 0 0  0 0 0  o C  1 L  0 0 0  o C  0 0 0  o C  o C  0 0 0  o C  U\
 I  D L  0 O  U I  U I  U I  0 O D  o U  0 O D  o U  o U  o U  o U  o \
U  0 O D  0 O D  U I  P 0  U I  C 0  U I  0 0 0  0 0 0  0 0 0  0 0 0  \
o C  1 L  0 0 0  o C  0 0 0  o C  o C  0 0 0  o C  U I  C U  0 O  U I \
 U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  o C  1 L  0 0 0  o C  0 0 0  o \
C  o C  0 0 0  o C  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  0 O  U I \
 U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  0 0 0 \
 0 0 0  0 0 0  0 0 0  o C  1 L  0 0 0  o C  0 0 0  o C  o C  0 0 0  o \
C  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  0 O  U I  U I  0 0 P \
 0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  o U  1 C  0 O D  1 C  1 C\
  0 O D  U I  P 0  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  \
o C  U I  1 O  U I  U C  0 O P  0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C\
  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0\
 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  0 O 0  0 I O  C C  0 \
O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  \
U I  0 O D  0 O I  U I  o U  1 C  0 O D  1 C  1 C  0 O D  U I  D L  0 \
O  U I  U I  U I  0 O D  0 O I  U I  D U  D P  U I  1 D  U I  D U  D P\
  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 o  U I  0 \
0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  0 0 0  0 0 0  \
o C  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  o C  o C  0 0 0  0 0 0  o \
C  o C  0 0 0  U I  1 U  U I  0 O D  1 C  0 O  U I  U I  U I  0 O D  o\
 U  0 O D  o U  o U  o U  o U  o U  0 O D  0 O D  U I  P 0  U I  C 0  \
U I  o U  1 C  0 O D  1 C  1 C  0 O D  U I  C U  0 O  U I  U I  U I  0\
 O D  0 O I  U I  D P  D 1  U I  1 D  U I  D P  D 1  D L  U I  0 0 0  \
1 L  0 0 0  o C  1 L  U I  1 I  U I  0 O D  o U  o U  1 C  1 C  1 C  0\
 O D  U I  1 U  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 U  U I  o U  \
0 O D  1 C  o U  0 O  U I  U I  U I  o U  1 C  0 O D  1 C  1 C  0 O D \
 U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  0 O  U I  U I  0 O 0  0 O L \
 0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  o U  1 C  0 O D  1 C  1 C\
  0 O D  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  0 O  U I  U I  \
0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  o U  o U  1 C  o U \
 o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  0 O D  o U\
  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 0 P  0 \
O 1  0 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  U C  U I  1 0  U I  \
C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 \
0 O  0 O U  0 O  U I  U I  U I  0 O D  0 O I  U I  o U  o U  1 C  o U \
 o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  P 0  U I  o L  \
0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 0 1  C o  0 \
O D  0 0 D  0 O 0  0 O  U I  U I  U I  o U  o U  1 C  o U  o U  o U  o\
 U  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  o U  o U  1 C  1 C  o \
U  0 O D  0 O D  0 O D  U I  1 O  U I  o U  o U  1 C  o U  o U  o U  o\
 U  0 O D  o U  o U  1 C  0 O D  U I  1 0  0 O  U I  U I  0 O 0  0 I O\
  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  o U  o U  1 \
C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  U C\
  U C  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U \
I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  0 O D  o U  o U  o U  \
0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 O I  C o  0 0 O  C \
o  0 0 1  0 0 P  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  0 O\
 D  0 O I  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  \
0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P\
  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 0 o  0 0 D  0 O 0 \
 C D  0 0 P  0 O 1  0 0 o  0 O C  C L  U C  U I  1 0  U I  P 0  P 0  U\
 I  U 1  0 0 P  0 0 1  0 0 o  0 O 0  U 1  U I  D L  0 O  U I  U I  U I\
  U I  U I  0 O D  1 C  o U  o U  1 C  U I  P 0  U I  o U  o U  1 C  o\
 U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  0 O  U I  U I  U I  U \
I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I \
 0 O D  1 C  o U  o U  1 C  U I  P 0  U I  0 O I  C o  0 0 O  C o  0 0\
 1  0 0 P  0 O  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0\
 O  U I  U I  U I  U I  0 O D  1 C  o U  o U  1 C  U I  P 0  U I  0 O \
D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I  U C  0 O\
 I  C o  0 0 O  C o  0 0 1  0 0 P  U C  U I  1 0  U I  C 0  U I  1 L  \
U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O\
  U I  U I  U I  0 O D  0 O I  U I  0 O D  1 C  o U  o U  1 C  U I  P \
0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U\
 I  0 0 1  C o  0 O D  0 0 D  0 O 0  0 O  U I  U I  0 O 0  0 I O  C C \
 0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  0 O D  1 C  o U  o\
 U  1 C  U I  P 0  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  0 O  U I\
  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  o U  0 O D  \
0 O D  1 C  o U  1 C  o U  1 C  1 C  0 O D  0 O D  o U  1 C  U I  P 0 \
 U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 O  U I\
  U C  0 O D  0 0 O  0 O I  0 0 0  U C  U I  1 0  U I  C 0  U I  1 L  \
U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O\
  U I  U I  U I  0 O D  0 O I  U I  o U  0 O D  0 O D  1 C  o U  1 C  \
o U  1 C  1 C  0 O D  0 O D  o U  1 C  U I  P 0  P 0  U I  o L  0 0 0 \
 0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 0 1  C o  0 O D  0\
 0 D  0 O 0  0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U \
I  D L  0 O  U I  U I  U I  o U  0 O D  0 O D  1 C  o U  1 C  o U  1 C\
  1 C  0 O D  0 O D  o U  1 C  U I  P 0  U I  U C  U C  0 O  U I  U I \
 U I  0 O D  0 O I  U I  D P  U I  1 D  U I  D P  D L  U I  0 O D  1 C\
  U I  1 D  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  \
1 o  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  U I \
 0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  0 O D  0 O D  1 C \
 o U  U I  P 0  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C\
  U I  1 O  U I  U C  0 O U  0 O 0  0 0 O  0 0 1  0 O 0  U C  U I  1 0\
  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 \
O D  0 0 O  0 O U  0 O  U I  U I  U I  0 O D  0 O I  U I  0 O D  0 O D\
  1 C  o U  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 \
O  U I  U I  U I  U I  0 0 1  C o  0 O D  0 0 D  0 O 0  0 O  U I  U I \
 0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I \
 0 O D  0 O D  1 C  o U  U I  P 0  U I  U C  U C  0 O  U I  U I  U I  \
0 O D  0 O I  U I  D o  D 1  U I  1 D  U I  D o  D 1  D L  U I  0 0 0 \
 0 0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I  U I  0 0 P  0 0 1  0 I \
0  U I  D L  0 O  U I  U I  U I  o U  1 C  o U  1 C  0 O D  1 C  o U  \
U I  P 0  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I \
 1 O  U I  U C  0 O O  C o  0 0 P  0 O 0  U C  U I  1 0  U I  C 0  U I\
  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O\
 U  0 O  U I  U I  U I  0 O D  0 O I  U I  o U  1 C  o U  1 C  0 O D  \
1 C  o U  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O \
 U I  U I  U I  U I  0 0 1  C o  0 O D  0 0 D  0 O 0  0 O  U I  U I  0\
 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  o\
 U  1 C  o U  1 C  0 O D  1 C  o U  U I  P 0  U I  U C  U C  0 O  U I \
 U I  U I  0 O D  0 O I  U I  D O  D o  U I  1 D  U I  D O  D o  D L  \
U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 o  U \
I  o U  1 C  1 C  0 O D  U I  1 P  U I  0 O D  o U  o U  1 C  1 C  1 C\
  0 O D  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I\
  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  \
0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O \
D  0 O  U I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0\
  0 0 0  1 L  o C  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  \
U I  0 O D  0 O I  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  \
o C  U I  1 O  U I  U C  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U C  U I  \
1 0  U I  D L  0 O  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O \
 U I  U I  U I  U I  o U  0 O D  0 O D  o U  0 O D  o U  1 C  1 C  1 C\
  0 O D  o U  U I  P 0  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  \
1 L  o C  U I  1 O  U I  U C  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U C  \
U I  1 0  0 O  U I  U I  U I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L\
  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  P 0  U I  o U  1 C  o U  0 O \
D  o U  1 C  1 C  U I  1 O  U I  o U  0 O D  0 O D  o U  0 O D  o U  1\
 C  1 C  1 C  0 O D  o U  U I  1 0  0 O  U I  U I  U I  0 O 0  0 I O  \
C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  0 0 I  C \
o  0 0 D  0 0 D  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U \
I  U I  U I  0 O D  0 O I  U I  D P  D U  U I  1 D  U I  D P  D U  D L\
  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 P  U I  0 0 0  \
0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  o C  0 0 0  0 0 0  \
0 0 0  1 L  1 L  1 L  1 L  U I  1 P  U I  o U  o U  0 O D  o U  0 O D \
 o U  o U  1 C  1 C  0 O D  U I  U o  U I  0 O D  1 C  0 O  U I  U I  \
U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  o U  0 O D\
  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 0  U I  P I  U I  1 C  U I \
 D L  0 O  U I  U I  U I  U I  o C  o C  1 L  0 0 0  0 0 0  0 0 0  1 L\
  0 0 0  o C  o C  U I  P 0  U I  1 L  0 O  U I  U I  U I  U I  0 0 0 \
 0 0 0  1 L  1 L  1 L  0 O D  0 O D  U I  P 0  U I  C 0  U I  C U  0 O\
  U I  U I  U I  U I  o C  0 0 0  o C  o U  0 O D  0 O D  0 O D  0 O D\
  0 O D  1 C  1 C  1 C  0 O D  1 C  0 O D  0 O D  U I  P 0  U I  L 1  \
0 0 1  0 0 o  0 O 0  U I  0 O D  0 O I  U I  U C  U P  U P  o P  L U  \
L O  0 O L  C o  0 I 0  o C  0 0 O  0 O L  0 I 0  o C  0 0 O  0 O 0  U\
 P  U P  U C  U I  0 O D  0 0 O  U I  o U  0 O D  o U  0 O D  1 C  1 C\
  0 O D  o U  U I  C 0  U I  1 L  U I  C U  U I  0 O 0  0 O L  0 0 D  \
0 O 0  U I  o O  C o  0 O L  0 0 D  0 O 0  0 O  U I  U I  U I  U I  0 \
O D  0 O I  U I  D O  D U  U I  1 D  U I  D O  D U  D L  U I  o C  1 L\
  0 0 0  o C  U I  1 D  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  \
1 L  U I  1 o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L \
 0 O  U I  U I  U I  U I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0 \
 1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U \
I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  D L  0 O  U I  U\
 I  U I  U I  U I  0 O D  0 O I  U I  0 0 0  o C  o C  o C  1 L  1 L  \
o C  1 L  o C  1 L  o C  o C  0 0 0  U I  P 0  P 0  U I  U 1  0 O I  C\
 o  0 O L  0 0 D  0 O 0  U 1  U I  C o  0 0 O  0 O O  U I  0 0 O  0 0 \
0  0 0 P  U I  o C  0 0 0  o C  o U  0 O D  0 O D  0 O D  0 O D  0 O D\
  1 C  1 C  1 C  0 O D  1 C  0 O D  0 O D  U I  D L  0 O  U I  U I  U \
I  U I  U I  U I  o C  o C  1 L  0 0 0  0 0 0  0 0 0  1 L  0 0 0  o C \
 o C  U I  1 U  P 0  U I  1 C  0 O  U I  U I  U I  U I  U I  U I  o C \
 0 0 0  0 0 0  0 0 0  o C  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L \
 0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 1  U I  U C  U o  0 0 D \
 1 0  U I  U o  0 0 D  U C  U I  U o  U I  1 O  U I  o C  o C  1 L  0 \
0 0  0 0 0  0 0 0  1 L  0 0 0  o C  o C  U I  1 1  U I  o C  0 0 0  0 \
0 0  o C  1 L  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  \
U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 1  U I \
 U C  0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  U C  U I  1 0  U I  1 \
0  U I  1 1  U I  o U  o U  1 C  o U  o U  o U  o U  0 O D  o U  o U  \
1 C  0 O D  U I  1 1  U I  0 O D  1 C  o U  o U  1 C  U I  1 1  U I  o\
 U  0 O D  0 O D  1 C  o U  1 C  o U  1 C  1 C  0 O D  0 O D  o U  1 C\
  U I  1 1  U I  0 O D  0 O D  1 C  o U  U I  1 1  U I  o U  1 C  o U \
 1 C  0 O D  1 C  o U  U I  1 1  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1\
 1  U I  0 0 0  0 0 0  1 L  1 L  1 L  0 O D  0 O D  U I  1 1  U I  o C\
  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U \
I  1 1  U I  o C  o C  o C  0 0 0  o C  o C  U I  1 0  0 O  U I  U I  \
U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  1 O  U I  0 0 0  o C  \
o C  o C  1 L  1 L  o C  1 L  o C  1 L  o C  o C  0 0 0  U I  P 0  P 0\
  U I  U 1  0 0 P  0 0 1  0 0 o  0 O 0  U 1  U I  C o  0 0 O  0 O O  U\
 I  o C  o C  0 0 0  1 L  1 L  o C  U I  P 0  P 0  U I  U C  0 0 P  0 \
0 1  0 0 o  0 O 0  U C  U I  1 0  U I  0 0 0  0 0 1  U I  o C  0 0 0  \
o C  o U  0 O D  0 O D  0 O D  0 O D  0 O D  1 C  1 C  1 C  0 O D  1 C\
  0 O D  0 O D  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 \
O I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0 \
 1 L  o C  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 0 0  0 \
0 0  1 L  1 L  1 L  0 O D  0 O D  U I  1 P  U I  C o  0 0 I  0 0 I  0 \
O 0  0 0 O  0 O O  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  \
1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 U  U I  U C  U L  0 0 1  0 O 0  \
0 O U  0 O 0  0 I O  0 0 D  P 0  U C  U I  1 U  U I  o C  0 0 0  o C  \
1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 0  0 O  U\
 I  U I  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  C o  0 0\
 O  0 I 0  U I  1 O  U I  0 I O  U I  0 O D  0 0 O  U I  o C  0 0 0  0\
 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0 O I  0 0 \
0  0 0 1  U I  0 I O  U I  0 O D  0 0 O  U I  0 0 0  0 0 0  0 0 0  0 0\
 0  U I  1 0  U I  C o  0 0 O  0 O O  U I  o C  0 0 0  0 0 0  1 L  1 L\
  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 P  C\
 o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U \
C  0 O 1  0 0 P  0 0 P  0 0 I  U C  U I  1 0  U I  D L  0 O  U I  U I \
 U I  U I  U I  U I  U I  0 0 0  0 0 0  1 L  1 L  1 L  0 O D  0 O D  U\
 I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  o\
 C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I \
 1 U  U I  U C  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D o  U C  U\
 I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0\
  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  1 L \
 1 L  1 L  0 O D  0 O D  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 \
O  0 O O  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C \
 0 0 0  0 0 0  0 0 0  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O 0  0\
 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 0\
  0 0 0  1 L  1 L  1 L  0 O D  0 O D  U I  1 P  U I  C o  0 0 I  0 0 I\
  0 O 0  0 0 O  0 O O  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0\
 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 0  0 O  U I  U I  U I  U I  \
U I  U I  0 O D  0 O I  U I  D I  1 C  U I  1 D  U I  D I  1 C  D L  U\
 I  o U  1 C  1 C  0 O D  U I  U o  U I  0 O D  0 O D  o U  1 C  0 O D\
  o U  0 O D  o U  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  0 O  U I  U \
I  U I  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 \
0 0  0 0 0  1 L  1 L  1 L  0 O D  0 O D  U I  1 0  U I  P I  U I  1 C \
 U I  D L  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D O  U I  \
1 D  U I  D O  D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 I  U I  o U  0\
 O D  o U  o U  U I  U o  U I  o U  o U  o U  o U  U I  1 D  U I  o U \
 0 O D  1 C  o U  U I  1 D  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0\
 O D  o U  0 O  U I  U I  U I  U I  U I  o C  0 0 0  0 0 0  0 0 0  o C\
  U I  1 O  U I  U C  U C  U I  1 1  U I  o C  0 0 0  0 0 0  o C  1 L \
 U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I \
 U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  U I  1 1  U I  o U\
  o U  1 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  1 1 \
 U I  0 O D  1 C  o U  o U  1 C  U I  1 1  U I  o U  0 O D  0 O D  1 C\
  o U  1 C  o U  1 C  1 C  0 O D  0 O D  o U  1 C  U I  1 1  U I  0 O \
D  0 O D  1 C  o U  U I  1 1  U I  o U  1 C  o U  1 C  0 O D  1 C  o U\
  U I  1 1  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 1  U I  0 0 0  0 0 0\
  1 L  1 L  1 L  0 O D  0 O D  U I  1 1  U I  o C  0 0 0  o C  1 L  o \
C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 1  U I  o C  o C\
  o C  0 0 0  o C  o C  U I  1 0  0 O  U I  U I  U I  0 O 0  0 O L  0 \
0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D 0 \
 U I  1 D  U I  D 0  D L  U I  0 O D  1 C  0 O  U I  U I  U I  U I  0 \
O D  0 O I  U I  0 O O  0 0 0  0 0 O  0 0 P  o P  0 O D  0 0 O  0 O o \
 U I  D L  0 O  U I  U I  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0\
 0 1  0 0 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  o U  0 O\
 D  o U  0 O D  1 C  1 C  0 O D  o U  U I  C 0  U I  1 L  U I  C U  U \
I  1 1  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0\
 0  1 L  o C  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 0  0 0 0\
  0 0 0  0 0 0  o C  1 L  0 0 0  o C  0 0 0  o C  o C  0 0 0  o C  U I\
  D L  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  \
0 0 P  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 \
0  1 L  o C  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0\
 O  U I  U I  U I  U I  U I  U I  0 O D  o U  1 C  0 O D  o U  o U  0 \
O D  0 O D  0 O D  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  \
U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  \
U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  U I  1 1  U I  0 O \
D  o U  0 O D  o U  o U  o U  o U  o U  0 O D  0 O D  U I  C 0  U I  1\
 L  U I  C U  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U\
 I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  U I  \
1 1  U I  1 C  U I  1 1  U I  o U  o U  1 C  o U  o U  o U  o U  0 O D\
  o U  o U  1 C  0 O D  U I  1 1  U I  0 O D  1 C  o U  o U  1 C  U I \
 1 1  U I  o U  0 O D  0 O D  1 C  o U  1 C  o U  1 C  1 C  0 O D  0 O\
 D  o U  1 C  U I  1 1  U I  0 O D  0 O D  1 C  o U  U I  1 1  U I  o \
U  1 C  o U  1 C  0 O D  1 C  o U  U I  1 1  U I  o L  0 0 0  0 0 O  0\
 O 0  U I  1 1  U I  U C  U U  U U  0 0 o  0 0 I  0 O O  C o  0 0 P  0\
 O 0  U C  U I  1 1  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 \
L  0 0 0  0 0 0  1 L  o C  U I  1 1  U I  o U  0 O D  o U  0 O D  1 C \
 1 C  0 O D  o U  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 O 0  \
0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O\
 I  1 D  D P  U C  U I  1 0  U I  1 0  0 O  U I  U I  U I  U I  U I  U\
 I  0 O D  0 O I  U I  D I  D U  U I  1 D  U I  D I  D U  D L  U I  0 \
O D  1 C  0 O  U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U \
I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O D  o U  1 C  0 O D  o U\
  o U  0 O D  0 O D  0 O D  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0  o\
 C  1 L  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1\
 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  U I  1 1  \
U I  0 O D  o U  0 O D  o U  o U  o U  o U  o U  0 O D  0 O D  U I  C \
0  U I  1 L  U I  C U  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O \
 0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1\
 0  U I  1 1  U I  1 C  U I  1 1  U I  o U  o U  1 C  o U  o U  o U  o\
 U  0 O D  o U  o U  1 C  0 O D  U I  1 1  U I  0 O D  1 C  o U  o U  \
1 C  U I  1 1  U I  o U  0 O D  0 O D  1 C  o U  1 C  o U  1 C  1 C  0\
 O D  0 O D  o U  1 C  U I  1 1  U I  0 O D  0 O D  1 C  o U  U I  1 1\
  U I  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  1 1  U I  o L  0 0 0 \
 0 0 O  0 O 0  U I  1 1  U I  U C  0 0 D  0 0 0  0 0 o  0 0 1  C C  0 \
O 0  U C  U I  1 1  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  o L \
 0 0 0  0 0 O  0 O 0  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 O\
 D  0 O I  U I  D P  D 0  U I  1 D  U I  D P  D 0  D L  U I  0 0 0  0 \
0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 P  U I  o C  o C  0 0 0  0 0 \
0  o C  o C  0 0 0  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 O \
I  U I  o U  1 C  0 O D  1 C  1 C  0 O D  U I  D L  0 O  U I  U I  U I\
  U I  U I  0 O D  o U  1 C  0 O D  o U  o U  0 O D  0 O D  0 O D  0 O\
 D  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 P  U I  0 O 0  \
0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O\
 I  1 D  D P  U C  U I  1 0  U I  1 1  U I  0 O D  o U  0 O D  o U  o \
U  o U  o U  o U  0 O D  0 O D  U I  C 0  U I  1 L  U I  C U  U I  1 1\
  U I  D U  D 0  U I  1 1  U I  o U  o U  1 C  o U  o U  o U  o U  0 O\
 D  o U  o U  1 C  0 O D  U I  1 1  U I  0 O D  1 C  o U  o U  1 C  U \
I  1 1  U I  o U  0 O D  0 O D  1 C  o U  1 C  o U  1 C  1 C  0 O D  0\
 O D  o U  1 C  U I  1 1  U I  0 O D  0 O D  1 C  o U  U I  1 1  U I  \
o U  1 C  o U  1 C  0 O D  1 C  o U  U I  1 1  U I  o L  0 0 0  0 0 O \
 0 O 0  U I  1 1  U I  U C  0 0 D  0 0 0  0 0 o  0 0 1  C C  0 O 0  U \
C  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D U  D P\
  U I  1 D  U I  D U  D P  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 \
L  o C  1 L  1 L  U I  1 U  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0\
 0  U I  U o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 o  \
U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  0 0 0  \
0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  U I  U I  U I  0\
 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 0\
 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O D  \
0 O I  U I  U C  U P  0 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O \
 U C  U I  0 O D  0 0 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  C o  0\
 0 O  0 O O  U I  0 0 O  0 0 0  0 0 P  U I  0 0 0  o C  o C  0 0 0  0 \
0 0  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I \
 U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  D I  U I  1 D  \
U I  1 C  D I  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I \
 1 I  U I  o U  o U  o U  o U  0 O  U I  U I  U I  U I  U I  U I  U I \
 o C  1 L  o C  o C  o C  1 L  o C  o C  0 0 0  0 0 0  0 0 0  1 L  1 L\
  U I  1 1  U I  o U  1 C  1 C  1 C  0 O D  o U  0 O D  1 C  U I  P 0 \
 U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  1 O  U I  o C  0 0 0  o C  1\
 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 1  U I  o \
C  0 0 0  0 0 0  o C  1 L  U I  1 0  0 O  U I  U I  U I  U I  U I  U I\
  U I  0 O D  0 O I  U I  D o  D O  U I  1 D  U I  D o  D O  D L  U I \
 o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  U I  U I  U I\
  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  1 L\
  o C  o C  o C  1 L  o C  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P \
0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U\
 I  U I  U I  U I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  o \
C  1 L  o C  o C  o C  1 L  o C  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  0\
 O  U I  U I  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U\
 I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  U I  U I  U I  U I  \
0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O \
D  0 O I  U I  U C  U P  0 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I\
 O  U C  U I  0 O D  0 0 O  U I  o U  o U  1 C  o U  o U  o U  o U  0 \
O D  o U  o U  1 C  0 O D  U I  C o  0 0 O  0 O O  U I  0 0 O  0 0 0  \
0 0 P  U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  P 0  P 0  U I  o L  0 \
0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  o\
 C  1 L  o C  o C  o C  1 L  o C  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  \
U I  1 1  U I  o U  1 C  1 C  1 C  0 O D  o U  0 O D  1 C  U I  P 0  U\
 I  0 0 0  o C  o C  0 0 0  0 0 0  U I  1 O  U I  o C  0 0 0  o C  1 L\
  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 1  U I  o U \
 o U  1 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  1 0  \
0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 \
0  0 0 P  U I  o C  1 L  o C  o C  o C  1 L  o C  o C  0 0 0  0 0 0  0\
 0 0  1 L  1 L  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L\
  0 O  U I  U I  U I  U I  U I  U I  U I  U I  o U  o U  1 C  o U  o U\
  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  o C  1 L  o C \
 o C  o C  1 L  o C  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  0 O  U I  U I\
  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U I\
  0 0 I  C o  0 0 D  0 0 D  0 O  U I  U I  U I  U I  U I  o C  0 0 0  \
0 0 0  0 0 0  o C  U I  1 O  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 \
O D  o U  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  o C  0 0 0  0 0\
 0  o C  1 L  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U\
 I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 1  U I  \
U C  0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  U C  U I  1 0  U I  1 1\
  U I  o U  o U  1 C  o U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D \
 U I  1 1  U I  0 O D  1 C  o U  o U  1 C  U I  1 1  U I  o U  0 O D  \
0 O D  1 C  o U  1 C  o U  1 C  1 C  0 O D  0 O D  o U  1 C  U I  1 1 \
 U I  0 O D  0 O D  1 C  o U  U I  1 1  U I  o U  1 C  o U  1 C  0 O D\
  1 C  o U  U I  1 1  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 1  U I  o \
L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  o C  0 0 0  o C  1 L  o C  1 L \
 1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 1  U I  o C  o C  o C  \
0 0 0  o C  o C  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I \
 U I  D O  D O  U I  1 D  U I  D O  D O  D L  U I  o U  0 O D  o U  o \
U  U I  U o  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I \
 1 I  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1\
 o  U I  o C  1 L  0 0 0  o C  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0\
  o C  1 L  o C  1 L  1 L  U I  1 I  U I  0 0 0  1 L  0 0 0  o C  1 L \
 0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O \
 U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U\
  U I  1 O  U I  U C  L 1  0 O 1  0 O 0  0 0 1  0 O 0  U I  0 0 C  C o\
  0 0 D  U I  C o  U I  0 0 I  0 0 1  0 0 0  C L  0 O L  0 O 0  0 O C \
 U I  C o  0 O O  0 O O  0 O D  0 0 O  0 O U  U I  0 O D  0 0 P  0 O 0\
  0 O C  U I  1 D  U I  U C  U I  1 U  U I  o C  0 0 0  0 0 0  o C  1 \
L  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U \
I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 1  U I  U C  0 O D \
 0 O U  0 0 O  0 0 0  0 0 1  0 O 0  U C  U I  1 0  U I  1 0  0 O  U I \
 U I  U I  0 O D  0 O I  U I  D o  D U  U I  1 D  U I  D o  D U  D L  \
U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I  0 0 0  0 \
0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 I  U I  0 O D  o U  o U  1 C \
 1 C  1 C  0 O D  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0\
 0 0  0 O  0 O O  0 O 0  0 O I  U I  o U  1 C  o U  0 O D  o U  1 C  1\
 C  U I  1 O  U I  0 0 1  0 O 0  0 O U  C D  0 O D  0 0 P  0 O 0  0 O \
C  U I  1 0  U I  D L  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U\
 I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  \
1 L  o C  U I  P 0  U I  0 I U  U I  0 I D  0 O  U I  U I  0 O I  0 0 \
0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 \
0 0  0 0 0  U I  0 O D  0 0 O  U I  0 0 1  0 O 0  0 O U  C D  0 O D  0\
 0 P  0 O 0  0 O C  U I  D L  0 O  U I  U I  U I  o C  0 0 0  o C  1 L\
  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C \
 0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 \
O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1\
 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U \
 U I  C U  U I  P 0  U I  0 I U  U I  0 I D  0 O  U I  U I  U I  o C  \
0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I \
 C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0 \
 0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U\
 I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D\
  0 0 O  0 O U  U I  C U  U I  C 0  U I  U C  0 0 O  C o  0 O C  0 O 0\
  U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 \
L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 \
O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D\
  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  0 O D  0 O I \
 U I  1 C  1 L  U I  1 D  U I  1 C  1 L  D L  U I  0 0 0  1 L  1 L  o \
C  1 L  0 0 0  0 0 0  U I  1 o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 \
L  o C  1 L  1 L  0 O  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0\
 O  U I  U I  U I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L \
 0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0\
 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0\
 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U \
I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C U  U I  C 0  U I  \
U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U I  C U  U I  P 0\
  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0\
 0  U I  1 O  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C \
 U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  \
0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  U I  0 O D  0 O I  U I\
  0 0 O  0 0 0  0 0 P  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  \
1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 \
L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C \
o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P\
  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C U  U I  C 0  U\
 I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U I  C U  U I \
 D L  0 O  U I  U I  U I  U I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 \
L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0  0 0 0 \
 1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0\
 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  \
U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C U  U I\
  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U I  C\
 U  U I  P 0  U I  U C  U C  0 O  U I  U I  U I  0 O 0  0 I O  C C  0 \
O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  o U  o U  o U  1\
 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L I  0 O 0\
  0 O U  0 O 0  0 I O  D L  U I  1 D  1 D  U I  o L  0 0 0  U I  L I  \
0 O 0  0 O I  0 O 0  0 0 1  0 O 0  0 0 1  U I  1 D  1 D  U 1  U I  1 0\
  0 O  U I  U I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0\
 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0\
 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O\
 C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I \
 0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C U  U I  C 0  U I  U \
C  0 0 I  C o  0 O U  0 O 0  U C  U I  C U  U I  P 0  U I  o C  0 0 0 \
 0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I \
 U C  0 0 I  C o  0 O U  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I\
  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U\
 I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  \
o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C \
 U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0\
 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1\
 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  \
0 O D  0 0 O  0 O U  U I  C U  U I  C 0  U I  U C  0 0 1  0 O 0  0 O I\
  0 O 0  0 0 1  0 O 0  0 0 1  U C  U I  C U  U I  P 0  U I  o C  0 0 0\
  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I\
  U C  0 0 1  0 O 0  0 O I  0 O 0  0 0 1  0 O 0  0 0 1  U C  U I  1 0 \
 U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O\
 D  0 0 O  0 O U  0 O  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I \
 0 0 P  U I  D L  0 O  U I  U I  U I  U I  o U  o U  o U  1 C  0 O D  \
0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L I  0 O 0  0 O U  0 \
O 0  0 I O  D L  U I  1 D  1 D  U I  o L  0 0 0  U I  L I  0 O 0  0 O \
I  0 O 0  0 0 1  0 O 0  0 0 1  U I  1 D  1 D  U 1  U I  1 0  0 O  U I \
 U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  o C\
  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U \
I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 \
0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0 \
 U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O\
 D  0 0 O  0 O U  U I  C U  U I  C 0  U I  U C  C C  0 0 0  0 0 O  0 0\
 O  0 O 0  C C  0 0 P  0 O D  0 0 0  0 0 O  U C  U I  C U  U I  P 0  U\
 I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0 \
 U I  1 O  U I  U C  C C  0 0 0  0 0 O  0 0 O  0 O 0  C C  0 0 P  0 O \
D  0 0 0  0 0 O  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P\
  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  0\
 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U\
 I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  \
U I  U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D  1 D  U I  o \
L  0 0 0  U I  C C  0 0 0  0 0 O  0 0 O  0 O 0  C C  0 0 P  0 O D  0 0\
 0  0 0 O  U I  1 D  1 D  U 1  U I  1 0  0 O  U I  U I  U I  U I  0 O \
D  0 O I  U I  D o  D O  U I  1 D  U I  D o  D O  D L  U I  0 0 0  1 L\
  0 0 0  o C  1 L  U I  1 P  U I  0 O D  1 C  0 O  U I  U I  U I  0 0 \
P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  o C  1\
 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o \
C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  \
1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I \
 1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O \
U  U I  C U  U I  C 0  U I  U C  0 0 O  0 0 0  0 0 P  0 0 I  0 O L  C \
o  0 I 0  C o  C L  0 O L  0 O 0  U C  U I  C U  U I  P 0  U I  o C  0\
 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O \
 U I  U C  0 0 O  0 0 0  0 0 P  0 0 I  0 O L  C o  0 I 0  C o  C L  0 \
O L  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I\
  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  0 O 0 \
 0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  o\
 U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  \
U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D  1 D  U I  o L  0 \
0 0  U I  0 0 O  0 0 0  0 0 P  0 0 I  0 O L  C o  0 I 0  C o  C L  0 O\
 L  0 O 0  U I  1 D  1 D  U 1  U I  1 0  0 O  U I  U I  U I  U I  0 O \
D  0 O I  U I  D P  D U  U I  1 D  U I  D P  D U  D L  U I  0 0 0  o C\
  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 P  U I  0 O D  1 C  \
0 O  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I \
 U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L\
  o C  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 \
0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  \
U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0\
 0 1  0 O D  0 0 O  0 O U  U I  C U  U I  C 0  U I  U C  0 0 O  0 0 0 \
 0 0 1  0 O 0  0 O O  0 O D  0 0 1  0 O 0  C C  0 0 P  U C  U I  C U  \
U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 \
0 0  0 0 0  U I  1 O  U I  U C  0 0 O  0 0 0  0 0 1  0 O 0  0 O O  0 O\
 D  0 0 1  0 O 0  C C  0 0 P  U C  U I  1 0  U I  C 0  U I  1 L  U I  \
C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I\
  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I\
  U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o \
U  U I  1 O  U I  U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D \
 1 D  U I  o L  0 0 0  U I  0 0 O  0 0 0  0 0 1  0 O 0  0 O O  0 O D  \
0 0 1  0 O 0  C C  0 0 P  U I  1 D  1 D  U 1  U I  1 0  0 O  U I  U I \
 U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0\
 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C \
0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 \
0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I \
 C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0\
 0 O  0 O U  U I  C U  U I  C 0  U I  U C  0 0 0  0 0 1  0 O D  0 O U \
 0 O D  0 0 O  U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1\
 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 0  0\
 0 1  0 O D  0 O U  0 O D  0 0 O  U C  U I  1 0  U I  C 0  U I  1 L  U\
 I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O \
 U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O \
 U I  U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U\
  o U  U I  1 O  U I  U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  \
1 D  1 D  U I  o L  0 0 0  U I  0 0 0  0 0 1  0 O D  0 O U  0 O D  0 0\
 O  U I  1 D  1 D  U 1  U I  1 0  0 O  U I  U I  U I  0 0 P  0 0 1  0 \
I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  o C  1 L  o C  1 L\
  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0  0 \
0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U \
C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C\
 U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C U \
 U I  C 0  U I  U C  C o  C C  C C  0 O 0  0 0 I  0 0 P  U C  U I  C U\
  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  \
0 0 0  0 0 0  U I  1 O  U I  U C  C o  C C  C C  0 O 0  0 0 I  0 0 P  \
U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0\
 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  0 O 0  0 I O  C C \
 0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  o U  o U  o U\
  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L I  0 \
O 0  0 O U  0 O 0  0 I O  D L  U I  1 D  1 D  U I  o L  0 0 0  U I  C \
o  C C  C C  0 O 0  0 0 I  0 0 P  U I  1 D  1 D  U 1  U I  1 0  0 O  U\
 I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  \
o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C \
 U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0\
 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1\
 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  \
0 O D  0 0 O  0 O U  U I  C U  U I  C 0  U I  U C  0 O D  0 0 O  C C  \
0 O L  0 0 o  0 O O  0 O 0  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  0 \
0 D  U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0 \
 1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 O D  0 0 O  C C \
 0 O L  0 0 o  0 O O  0 O 0  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  0\
 0 D  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 \
D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  0 O 0  0 I O\
  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  o U  o \
U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L\
 I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D  1 D  U I  o L  0 0 0  U\
 I  0 O D  0 0 O  C C  0 O L  0 0 o  0 O O  0 O 0  0 O 1  0 O 0  C o  \
0 O O  0 O 0  0 0 1  0 0 D  U I  1 D  1 D  U 1  U I  1 0  0 O  U I  U \
I  U I  U I  0 O D  0 O I  U I  D D  D P  U I  1 D  U I  D D  D P  D L\
  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  0 \
O D  1 C  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 0 0 \
 o C  1 L  0 0 0  U I  1 o  U I  0 O D  1 C  U I  1 P  U I  0 O D  1 C\
  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  0 O  U \
I  U I  U I  U I  0 O D  0 O I  U I  D o  D D  U I  1 D  U I  D o  D D\
  D L  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 o  U \
I  0 O D  1 C  U I  U o  U I  o U  1 C  1 C  0 O D  U I  U o  U I  0 0\
 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  U I  U I  \
0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  o \
C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I\
  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U\
 I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  \
U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  \
0 O U  U I  C U  U I  C 0  U I  U C  0 O L  0 O D  0 0 D  0 0 P  0 0 1\
  0 O 0  0 0 I  0 O 0  C o  0 0 P  U C  U I  C U  U I  P 0  U I  o C  \
0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O\
  U I  U C  0 O L  0 O D  0 0 D  0 0 P  0 0 1  0 O 0  0 0 I  0 O 0  C \
o  0 0 P  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  \
0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  U I  0 O\
 D  0 O I  U I  1 C  D P  U I  1 D  U I  1 C  D P  D L  U I  0 0 0  o \
C  1 L  0 0 0  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U\
 I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U\
 I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  \
U I  1 O  U I  U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D  1 \
D  U I  o L  0 0 0  U I  0 O L  0 O D  0 0 D  0 0 P  0 0 1  0 O 0  0 0\
 I  0 O 0  C o  0 0 P  U I  1 D  1 D  U 1  U I  1 0  0 O  U I  U I  U \
I  U I  0 O D  0 O I  U I  D o  D U  U I  1 D  U I  D o  D U  D L  U I\
  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 U  U I  0 0 0  \
0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 I  U I  0 O D  1 C \
 U I  1 D  U I  o U  1 C  1 C  0 O D  U I  1 I  U I  0 O D  1 C  U I  \
1 D  U I  0 0 0  o C  1 L  0 0 0  0 O  U I  U I  U I  U I  0 O D  0 O \
I  U I  D D  D U  U I  1 D  U I  D D  D U  D L  U I  o C  o C  0 0 0  \
0 0 0  o C  o C  0 0 0  U I  1 I  U I  0 0 0  0 0 0  0 0 0  1 L  o C  \
0 0 0  1 L  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D o  U I  1 D \
 U I  D o  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1\
 D  U I  o U  0 O D  1 C  o U  U I  1 U  U I  o U  o U  0 O D  o U  0 \
O D  o U  o U  1 C  1 C  0 O D  U I  1 o  U I  0 0 0  o C  1 L  0 0 0 \
 U I  1 o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O\
  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U \
I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o\
 C  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0\
  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I\
  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 \
1  0 O D  0 0 O  0 O U  U I  C U  U I  C 0  U I  U C  0 0 I  0 0 1  0 \
0 0  0 I O  0 I 0  U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0  1 \
L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 \
I  0 0 1  0 0 0  0 I O  0 I 0  U C  U I  1 0  U I  C 0  U I  1 L  U I \
 C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U \
I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U \
I  U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o\
 U  U I  1 O  U I  U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D\
  1 D  U I  o L  0 0 0  U I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  U I  1\
 D  1 D  U 1  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D \
0  D o  U I  1 D  U I  D 0  D o  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o\
 C  0 0 0  1 L  U I  1 I  U I  o U  0 O D  o U  o U  U I  1 U  U I  0 \
0 0  o C  1 L  0 0 0  U I  1 D  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 \
0 0  1 L  U I  1 U  U I  o C  1 L  0 0 0  o C  0 O  U I  U I  U I  0 0\
 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  o C  \
1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o\
 C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I \
 1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I\
  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O\
 U  U I  C U  U I  C 0  U I  U C  0 I O  1 D  0 0 1  0 O 0  0 0 U  U C\
  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o \
C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 I O  1 D  0 0 1  0 O 0  \
0 0 U  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0\
 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  0 O 0  0 I \
O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  o U  o\
 U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  \
L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D  1 D  U I  o L  0 0 0  \
U I  0 I O  1 D  0 0 1  0 O 0  0 0 U  U I  1 D  1 D  U 1  U I  1 0  0 \
O  U I  U I  U I  U I  0 O D  0 O I  U I  D 1  D o  U I  1 D  U I  D 1\
  D o  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O \
D  0 O  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U\
 I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  \
1 L  o C  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C \
 0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U \
C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P\
  0 0 1  0 O D  0 0 O  0 O U  U I  C U  U I  C 0  U I  U C  0 I O  1 D\
  C o  0 O O  0 O O  0 0 1  U C  U I  C U  U I  P 0  U I  o C  0 0 0  \
0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  \
U C  0 I O  1 D  C o  0 O O  0 O O  0 0 1  U C  U I  1 0  U I  C 0  U \
I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 \
O U  0 O  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  \
D L  0 O  U I  U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0\
 O D  o U  o U  U I  1 O  U I  U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D\
 L  U I  1 D  1 D  U I  o L  0 0 0  U I  0 I O  1 D  C o  0 O O  0 O O\
  0 0 1  U I  1 D  1 D  U 1  U I  1 0  0 O  U I  U I  U I  U I  0 O D \
 0 O I  U I  D P  D U  U I  1 D  U I  D P  D U  D L  U I  o C  0 0 0  \
0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 o  U I  o U  o U  0 O D  o U \
 0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  0 0 P  0 0 1  0\
 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  o C  1 L  o C  1 \
L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0  0\
 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U\
 C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  \
C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C U\
  U I  C 0  U I  U C  0 I O  1 D  0 O I  0 0 0  0 0 1  0 0 C  C o  0 0\
 1  0 O O  U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  \
0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 I O  1 D  \
0 O I  0 0 0  0 0 1  0 0 C  C o  0 0 1  0 O O  U C  U I  1 0  U I  C 0\
  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O\
  0 O U  0 O  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U\
 I  D L  0 O  U I  U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 \
C  0 O D  o U  o U  U I  1 O  U I  U 1  L I  0 O 0  0 O U  0 O 0  0 I \
O  D L  U I  1 D  1 D  U I  o L  0 0 0  U I  0 I O  1 D  0 O I  0 0 0 \
 0 0 1  0 0 C  C o  0 0 1  0 O O  U I  1 D  1 D  U 1  U I  1 0  0 O  U\
 I  U I  U I  U I  0 O D  0 O I  U I  1 C  D P  U I  1 D  U I  1 C  D \
P  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  o\
 U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U I  \
0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  U I  U \
I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0 \
 o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  \
U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0\
  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C \
0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 \
O  0 O U  U I  C U  U I  C 0  U I  U C  C o  0 O U  0 O 0  0 0 O  0 0 \
P  U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1\
 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  C o  0 O U  0 O 0  0\
 0 O  0 0 P  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U \
I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  0 O 0\
  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  \
o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I \
 U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D  1 D  U I  o L  0\
 0 0  U I  L D  0 0 D  0 O 0  0 0 1  U I  P D  0 O U  0 O 0  0 0 O  0 \
0 P  U I  1 D  1 D  U 1  U I  1 0  0 O  U I  U I  U I  0 0 P  0 0 1  0\
 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  o C  1 L  o C  1 \
L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0  0\
 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U\
 C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  \
C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C U\
  U I  C 0  U I  U C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  C U  U I  \
P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  \
0 0 0  U I  1 O  U I  U C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  1 0  \
U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O \
D  0 0 O  0 O U  0 O  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  \
0 0 P  U I  D L  0 O  U I  U I  U I  U I  o U  o U  o U  1 C  0 O D  0\
 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L I  0 O 0  0 O U  0 O\
 0  0 I O  D L  U I  1 D  1 D  U I  o L  0 0 0  0 0 P  U I  C o  U I  \
0 0 I  0 0 0  0 0 D  0 0 P  U 1  U I  1 0  0 O  U I  U I  U I  0 0 P  \
0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  o C  1 L \
 o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  \
0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O\
  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 \
L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  \
U I  C U  U I  C 0  U I  U C  0 0 1  C o  0 0 C  0 0 I  0 0 0  0 0 D  \
0 0 P  U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 \
0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 1  C o  0 0 \
C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  1 0  U I  C 0  U I  1 L  U I \
 C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U \
I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U \
I  U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o\
 U  U I  1 O  U I  U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D\
  1 D  U I  o L  0 0 0  0 0 P  U I  C o  U I  0 0 1  C o  0 0 C  0 0 I\
  0 0 0  0 0 D  0 0 P  U 1  U I  1 0  0 O  U I  U I  U I  0 0 P  0 0 1\
  0 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  o C  1 L  o C \
 1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0\
  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I\
  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U \
I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  \
C U  U I  C 0  U I  U C  0 O 1  0 0 P  0 O C  0 O L  0 0 o  0 0 O  0 O\
 0  0 0 D  C C  C o  0 0 I  0 O 0  U C  U I  C U  U I  P 0  U I  o C  \
0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O\
  U I  U C  0 O 1  0 0 P  0 O C  0 O L  0 0 o  0 0 O  0 O 0  0 0 D  C \
C  C o  0 0 I  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I\
  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U\
 I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U\
 I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  \
1 O  U I  U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D  1 D  U \
I  o L  0 0 0  0 0 P  U I  C o  U I  0 O 1  0 0 P  0 O C  0 O L  0 0 o\
  0 0 O  0 O 0  0 0 D  C C  C o  0 0 I  0 O 0  U 1  U I  1 0  0 O  U I\
  U I  U I  U I  0 O D  0 O I  U I  D 1  D O  U I  1 D  U I  D 1  D O \
 D L  U I  0 O D  1 C  U I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0\
 0 0  1 L  U I  1 P  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O\
  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  1 C  U I  1 D  U I  1 C \
 1 C  D L  U I  o C  1 L  0 0 0  o C  U I  1 o  U I  0 0 0  1 L  0 0 0\
  o C  1 L  0 O  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U \
I  U I  U I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0\
  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  \
1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  \
0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0\
 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C U  U I  C 0  U I  U C  0\
 0 1  0 O 0  C o  0 O O  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 0 0\
  0 0 O  0 O L  0 I 0  U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0\
  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  \
0 0 1  0 O 0  C o  0 O O  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 0 \
0  0 0 O  0 O L  0 I 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U\
 I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I \
 U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I \
 U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I\
  1 O  U I  U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D  1 D  \
U I  o L  0 0 0  0 0 P  U I  C o  U I  0 0 1  0 O 0  C o  0 O O  P o  \
0 0 0  0 0 0  0 O o  0 O D  0 O 0  o C  0 0 O  0 O L  0 I 0  U 1  U I \
 1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D D  D 0  U I  1 D  \
U I  D D  D 0  D L  U I  o U  1 C  1 C  0 O D  U I  1 o  U I  0 0 0  0\
 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  U I  U I  0 0 P  \
0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  o C  1 L \
 o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  \
0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O\
  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 \
L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  \
U I  C U  U I  C 0  U I  U C  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  \
0 O P  C o  0 0 1  U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0  1 \
L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  C C \
 0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 O P  C o  0 0 1  U C  U I  1 0  \
U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O \
D  0 0 O  0 O U  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 \
0 0  0 0 P  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0 \
 0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1\
 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  0\
 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 \
D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C U  U I  C 0  U I  U C  C \
C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 O P  C o  0 0 1  U C  U I  C U\
  U I  D L  0 O  U I  U I  U I  U I  U I  o C  0 0 0  o C  1 L  o C  1\
 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0  \
0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  \
U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I \
 C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C \
U  U I  C 0  U I  U C  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 O P  \
C o  0 0 1  U C  U I  C U  U I  P 0  U I  U C  U C  0 O  U I  U I  U I\
  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I\
  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 \
O  U I  U 1  L I  0 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D  1 D  U I \
 o L  0 0 0  0 0 P  U I  C o  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 \
O 0  o 1  C o  0 0 1  U 1  U I  1 0  0 O  U I  U I  U I  0 0 P  0 0 1 \
 0 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  o C  1 L  o C  \
1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0 \
 0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I \
 U C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I\
  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C\
 U  U I  C 0  U I  U C  0 0 D  0 O 0  0 0 P  C C  0 0 0  0 0 0  0 O o \
 0 O D  0 O 0  U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1\
 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 D  0\
 O 0  0 0 P  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  U C  U I  1 0  U \
I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D \
 0 0 O  0 O U  0 O  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 \
0 P  U I  D L  0 O  U I  U I  U I  U I  o U  o U  o U  1 C  0 O D  0 O\
 D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L I  0 O 0  0 O U  0 O 0\
  0 I O  D L  U I  1 D  1 D  U I  o L  0 0 0  0 0 P  U I  C o  U I  0 \
0 D  0 O 0  0 0 P  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  U 1  U I  1\
 0  0 O  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  \
U I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0 \
 1 L  o C  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C\
  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  0 0 O  C o  0 O C  0 O 0  U\
 C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 \
P  0 0 1  0 O D  0 0 O  0 O U  U I  C U  U I  C 0  U I  U C  C o  0 0 \
I  0 0 I  0 O 0  0 0 O  0 O O  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0 \
 U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L\
  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  C o  0 0 I  0 0 I  0 O\
 0  0 0 O  0 O O  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  U C  U I  1 \
0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0\
 O D  0 0 O  0 O U  0 O  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 \
I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  o U  o U  o U  1 C  0 O D\
  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L I  0 O 0  0 O U  \
0 O 0  0 I O  D L  U I  1 D  1 D  U I  o L  0 0 0  0 0 P  U I  C o  U \
I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  C C  0 0 0  0 0 0  0 O o  0\
 O D  0 O 0  U 1  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I\
  D U  D P  U I  1 D  U I  D U  D P  D L  U I  o U  0 O D  o U  o U  U\
 I  1 P  U I  o U  0 O D  1 C  o U  U I  1 U  U I  o U  o U  o U  o U \
 U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I\
  1 o  U I  o U  0 O D  1 C  o U  U I  1 o  U I  o U  o U  0 O D  o U \
 0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  0 0 P  0 0 1  0\
 I 0  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  o C  1 L  o C  1 \
L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C 0  U I  o C  0 0 0  0\
 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U\
 C  0 0 O  C o  0 O C  0 O 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  \
C U  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  C U\
  U I  C 0  U I  U C  0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  C C  C\
 o  C C  0 O 1  0 O 0  U C  U I  C U  U I  P 0  U I  o C  0 0 0  0 0 0\
  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 O  U I  U C  \
0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  C C  C o  C C  0 O 1  0 O 0 \
 U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0 0 D  0 \
0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  U I  U I  U I  0 O 0  0 I O  C C\
  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  o U  o U  o \
U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L I  0\
 O 0  0 O U  0 O 0  0 I O  D L  U I  1 D  1 D  U I  0 0 O  0 0 0  U I \
 0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  C C  C o  C C  0 O 1  0 O 0\
  U 1  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D P  D U \
 U I  1 D  U I  D P  D U  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L\
  0 0 0  U I  1 U  U I  o C  1 L  0 0 0  o C  0 O  U I  U I  U I  U I \
 0 O D  0 O I  U I  1 C  1 L  U I  1 D  U I  1 C  1 L  D L  U I  0 0 0\
  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  o U  1 C  o U  0 \
O D  1 C  1 C  1 C  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L \
 0 0 0  U I  1 o  U I  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  U I  \
0 O D  0 O I  U I  D O  D D  U I  1 D  U I  D O  D D  D L  U I  0 O D \
 1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  0 O\
  U I  U I  U I  U I  0 O D  0 O I  U I  D 1  D D  U I  1 D  U I  D 1 \
 D D  D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  U I  \
U I  U I  0 O D  0 O I  U I  D U  D U  U I  1 D  U I  D U  D U  D L  U\
 I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 D  U I\
  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 I  U I  0 0 0\
  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 U  U I  0 0 0  0 0 0  o C  \
0 0 0  o C  1 L  0 0 0  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  \
1 L  0 0 0  U I  1 I  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C \
 1 C  0 O D  0 O  U I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  \
1 L  0 0 0  0 0 0  1 L  o C  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L\
  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  U I  1\
 O  U I  0 0 1  0 O 0  0 0 I  0 0 1  U I  1 O  U I  o C  0 0 0  o C  1\
 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 0  U I  1 \
0  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  o C  \
0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  0 O \
 U I  U I  0 O D  0 O I  U I  D o  1 C  U I  1 D  U I  D o  1 C  D L  \
U I  0 O D  1 C  U I  1 D  U I  o C  1 L  0 0 0  o C  U I  U o  U I  0\
 0 0  o C  1 L  0 0 0  U I  1 D  U I  o C  o C  0 0 0  0 0 0  o C  o C\
  0 0 0  U I  U o  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  \
0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  \
U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L \
 o C  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  U I  o U  o U\
  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U C  0 \
0 1  0 O 0  0 O U  0 O 0  0 I O  U I  P C  0 0 1  0 0 1  0 0 0  0 0 1 \
 D L  U I  U C  U I  1 U  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 P  \
U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o\
  0 0 P  0 O I  1 D  D P  U C  U I  1 1  U I  U C  0 O D  0 O U  0 0 O\
  0 0 0  0 0 1  0 O 0  U C  U I  1 0  U I  1 0  0 O  U I  U I  0 O D  \
0 O I  U I  D o  D P  U I  1 D  U I  D o  D P  D L  U I  o U  1 C  o U\
  0 O D  1 C  1 C  1 C  U I  1 P  U I  o U  1 C  o U  0 O D  1 C  1 C \
 1 C  U I  1 I  U I  o U  o U  o U  o U  U I  1 I  U I  o U  0 O D  1 \
C  o U  U I  1 I  U I  0 O D  1 C  0 O  0 O O  0 O 0  0 O I  U I  0 0 \
0  o C  0 0 0  0 0 0  o C  1 L  U I  1 O  U I  0 0 o  0 0 1  0 O L  U \
I  1 0  U I  D L  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U\
 I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L \
 o C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  0 0 1  C o  0 0 O  \
0 O U  0 O 0  U I  1 O  U I  1 C  U I  1 1  U I  D U  1 C  U I  1 0  U\
 I  D L  0 O  U I  U I  U I  o C  o C  o C  0 0 0  o C  1 L  1 L  1 L \
 U I  P 0  U I  0 0 0  o C  o C  o C  o C  U I  1 O  U I  0 0 o  0 0 1\
  0 O L  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  U 1  P C  L \
L  L 1  1 D  L L  1 D  L U  L 1  L I  P C  P D  o o  1 D  o U  o L  o \
O  U 1  U I  0 O D  0 0 O  U I  o C  o C  o C  0 0 0  o C  1 L  1 L  1\
 L  U I  D L  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 \
o  0 0 1  0 O L  0 O  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  \
0 0 P  U I  U 1  P C  L L  L 1  o o  D 0  L D  U 1  U I  0 O D  0 0 O \
 U I  o C  o C  o C  0 0 0  o C  1 L  1 L  1 L  U I  D L  U I  0 0 1  \
0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O  U I  U I  U I  0 I O  C L  0 O\
 C  C C  U I  1 P  U I  0 0 D  0 O L  0 O 0  0 O 0  0 0 I  U I  1 O  U\
 I  D O  1 L  1 L  1 L  U I  1 0  0 O  U I  U I  0 0 1  0 O 0  0 0 P  \
0 0 o  0 0 1  0 0 O  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P \
 U I  D L  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 \
O  U I  U I  0 O D  0 O I  U I  D I  D o  U I  1 D  U I  D I  D o  D L\
  U I  o U  0 O D  1 C  o U  U I  1 P  U I  o U  o U  o U  o U  U I  1\
 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  U o  \
U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  0 O O  0 O 0  0 O\
 I  U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  1 O  U I  0 0 1  0 O 0  0\
 O U  0 O 0  0 I O  0 0 D  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 \
1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  \
P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  0 O I  0 0 0  0 0 1\
  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  o C  0 0 O \
 0 O L  0 I 0  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  U I  1 1 \
 U I  0 0 1  0 O 0  C C  0 0 o  0 0 1  0 0 D  0 O D  0 0 L  0 O 0  P o\
  C o  0 O L  0 O L  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  U I\
  1 1  U I  C C  C o  C C  0 O 1  0 O 0  0 O O  L O  C o  0 O U  0 O 0\
  0 0 D  U I  P 0  U I  0 I U  U I  0 I D  U I  1 1  U I  0 0 1  C o  \
0 0 C  L O  0 0 0  0 0 D  0 0 P  U I  P 0  U I  o O  C o  0 O L  0 0 D\
  0 O 0  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  C D  0\
 O P  C o  0 0 1  C D  0 O I  0 O D  0 O L  0 O 0  U I  P 0  U I  o L \
 0 0 0  0 0 O  0 O 0  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I \
 0 0 O  0 0 0  0 0 P  U I  0 0 1  0 O 0  C C  0 0 o  0 0 1  0 0 D  0 O\
 D  0 0 L  0 O 0  P o  C o  0 O L  0 O L  U I  D L  0 O  U I  U I  0 0\
 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  P 0  U I  0 O 0  0 0 L  C \
o  0 O L  U I  1 O  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  \
1 P  U I  0 0 o  0 0 O  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  U I  1 O  U\
 I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  1 0  U I  1 0  0 O \
 U I  U I  0 O D  0 O I  U I  D 0  D I  U I  1 D  U I  D 0  D I  D L  \
U I  0 O D  1 C  U I  U o  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  \
1 L  0 O  U I  U I  0 O D  0 O I  U I  D 0  U I  1 D  U I  D 0  D L  U\
 I  o U  0 O D  1 C  o U  U I  1 o  U I  o C  1 L  0 0 0  o C  U I  1 \
U  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  o C \
 0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 P  U I  o U  1 C  o U\
  0 O D  1 C  1 C  1 C  0 O  U I  0 0 0  o C  0 0 0  0 0 0  1 L  1 L  \
1 L  U I  P 0  U I  0 0 1  0 O 0  U I  1 P  U I  C C  0 0 0  0 O C  0 \
0 I  0 O D  0 O L  0 O 0  U I  1 O  U I  U C  C I  U P  0 O O  0 0 0  \
0 0 1  0 O 0  0 O U  0 O 0  0 I O  C I  C 0  1 O  C 0  C 1  C I  C U  \
C U  1 I  1 0  C I  C U  U C  U I  1 0  U I  1 P  U I  0 O I  0 O D  0\
 0 O  0 O O  C o  0 O L  0 O L  U I  1 O  U I  0 0 o  0 0 1  0 O L  U \
I  1 0  0 O  U I  0 O D  0 O I  U I  D P  D D  U I  1 D  U I  D P  D D\
  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I  0 \
0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 o  U I  0 0 0  0 0 0  0 \
0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o \
C  1 L  o C  1 L  1 L  U I  1 I  U I  o C  o C  0 0 0  0 0 0  o C  o C\
  0 0 0  0 O  U I  o C  o C  1 L  1 L  U I  P 0  U I  L 1  0 0 1  0 0 \
o  0 O 0  0 O  U I  0 O I  0 0 0  0 0 1  U I  o U  o U  0 O D  0 O D  \
o U  o U  0 O D  1 C  U I  0 O D  0 0 O  U I  0 0 0  o C  0 0 0  0 0 0\
  1 L  1 L  1 L  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  o U  o U \
 0 O D  0 O D  o U  o U  0 O D  1 C  U I  0 O D  0 0 O  U I  0 0 1  0 \
O 0  0 O U  0 O 0  0 I O  0 0 D  U I  D L  0 O  U I  U I  U I  0 O D  \
0 O I  U I  D U  D o  U I  1 D  U I  D U  D o  D L  U I  0 0 0  0 0 0 \
 0 0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  o C  1 L  0 0 0  o C  U I\
  U o  U I  o U  0 O D  1 C  o U  0 O  U I  U I  U I  0 O D  1 C  1 C \
 o U  1 C  0 O D  o U  0 O D  U I  P 0  U I  0 0 1  0 O 0  0 O U  0 O \
0  0 I O  0 0 D  U I  C 0  U I  o U  o U  0 O D  0 O D  o U  o U  0 O \
D  1 C  U I  C U  0 O  U I  U I  U I  0 O D  0 O I  U I  D D  D o  U I\
  1 D  U I  D D  D o  D L  U I  0 O D  1 C  U I  1 P  U I  o U  o U  o\
 U  o U  U I  1 D  U I  o U  0 O D  1 C  o U  U I  1 P  U I  0 O D  o \
U  o U  1 C  1 C  1 C  0 O D  U I  U o  U I  o C  0 0 0  0 0 0  0 0 0 \
 1 L  1 L  1 L  1 L  0 O  U I  U I  U I  0 0 0  o C  0 0 0  o C  1 L  \
1 L  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  0 O  U I  U I  U I \
 0 O D  0 O I  U I  U C  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 O P\
  C o  0 0 1  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  \
0 O D  o U  0 O D  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O I  U \
I  D I  1 L  U I  1 D  U I  D I  1 L  D L  U I  0 0 0  1 L  1 L  o C  \
1 L  0 0 0  0 0 0  0 O  U I  U I  U I  U I  0 0 0  o C  0 0 0  o C  1 \
L  1 L  U I  P 0  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U\
 I  C 0  U I  U C  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 O P  C o \
 0 0 1  U C  U I  C U  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  U C\
  U P  0 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U C  U I  0 O \
D  0 0 O  U I  0 0 0  o C  0 0 0  o C  1 L  1 L  U I  D L  0 O  U I  U\
 I  U I  U I  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0\
 0 1  U I  P 0  U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  1 O  U I  0 0\
 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  1 1  U I  0 O D  1 C  1 C \
 o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  C C  0 0 0  0 0 0  0\
 O o  0 O D  0 O 0  0 O P  C o  0 0 1  U C  U I  C U  U I  1 1  U I  C\
 C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 1  U I \
 L 1  0 0 1  0 0 o  0 O 0  U I  1 1  U I  L 1  0 0 1  0 0 o  0 O 0  U \
I  1 1  U I  C C  C o  C C  0 O 1  0 O 0  0 O O  L O  C o  0 O U  0 O \
0  0 0 D  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D\
 1  D D  U I  1 D  U I  D 1  D D  D L  U I  o U  o U  o U  o U  U I  1\
 U  U I  o U  0 O D  1 C  o U  U I  1 D  U I  o U  o U  0 O D  o U  0 \
O D  o U  o U  1 C  1 C  0 O D  U I  1 P  U I  o U  o U  o U  o U  U I\
  1 I  U I  o U  0 O D  1 C  o U  U I  1 I  U I  0 0 0  1 L  0 0 0  o \
C  1 L  0 O  U I  U I  U I  U I  U I  0 0 0  o C  0 0 0  o C  1 L  1 L\
  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  0 O  U I  U I  U I  U I  0 \
O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 0 \
0  o C  0 0 0  o C  1 L  1 L  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0 \
 0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D o  1 L  U I  1 D  \
U I  D o  1 L  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1\
 C  o U  0 O D  1 C  0 O D  U I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o\
 C  0 0 0  1 L  0 O  U I  U I  U I  0 O D  0 O I  U I  0 0 0  o C  0 0\
 0  o C  1 L  1 L  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O I  U \
I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  P 0  \
P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I \
 U I  0 O D  0 O I  U I  D P  1 C  U I  1 D  U I  D P  1 C  D L  U I  \
o C  1 L  0 0 0  o C  U I  1 D  U I  0 0 0  1 L  0 0 0  o C  1 L  U I \
 U o  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U I\
  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 o  U I  o U  0 O D  o U \
 o U  0 O  U I  U I  U I  U I  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0\
 O 0  C D  0 O P  C o  0 0 1  C D  0 O I  0 O D  0 O L  0 O 0  U I  P \
0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  U I  U I  U I  U I  0 O D \
 0 O I  U I  U C  0 0 0  0 0 I  0 O 0  0 0 O  C 0  U C  U I  0 O D  0 \
0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I \
 U C  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 O P  C o  0 0 1  U C  \
U I  C U  U I  D L  0 O  U I  U I  U I  U I  U I  U I  C C  0 0 0  0 0\
 0  0 O o  0 O D  0 O 0  C D  0 O P  C o  0 0 1  C D  0 O I  0 O D  0 \
O L  0 O 0  U I  P 0  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O \
D  U I  C 0  U I  U C  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 O P  \
C o  0 0 1  U C  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  \
0 0 P  U I  1 O  U I  U C  0 0 0  0 0 I  0 O 0  0 0 O  C 0  U C  U I  \
1 0  U I  C 0  U I  1 C  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L \
 0 O D  0 0 P  U I  1 O  U I  U C  C U  U C  U I  1 0  U I  C 0  U I  \
1 L  U I  C U  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D\
 I  U I  1 D  U I  D I  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 \
0 0  U I  1 D  U I  o U  1 C  1 C  0 O D  U I  U o  U I  0 O D  1 C  1\
 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 D  \
U I  o C  1 L  0 0 0  o C  U I  1 I  U I  0 0 0  1 L  1 L  o C  1 L  0\
 0 0  0 0 0  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D P\
  D U  U I  1 D  U I  D P  D U  D L  U I  o C  o C  0 0 0  0 0 0  o C \
 o C  0 0 0  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  U I  1 P  U I  0 O\
 D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 o  U I  o C  o C  \
0 0 0  0 0 0  o C  o C  0 0 0  U I  U o  U I  0 O D  o U  o U  1 C  1 \
C  1 C  0 O D  U I  U o  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1\
 C  1 C  0 O D  0 O  U I  U I  U I  U I  U I  C C  0 0 0  0 0 0  0 O o\
  0 O D  0 O 0  o 1  C o  0 0 1  U I  P 0  U I  o U  1 C  0 O D  0 O D\
  0 O D  U I  1 O  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  C D  0\
 O P  C o  0 0 1  C D  0 O I  0 O D  0 O L  0 O 0  U I  1 0  0 O  U I \
 U I  U I  U I  U I  0 O D  0 O I  U I  D P  D 1  U I  1 D  U I  D P  \
D 1  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U \
I  1 I  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U\
 I  1 I  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  U I\
  U I  U I  U I  0 O D  0 O I  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0\
 O 0  C D  0 O P  C o  0 0 1  C D  0 O I  0 O D  0 O L  0 O 0  U I  D \
L  0 O  U I  U I  U I  U I  U I  U I  o C  0 0 0  0 0 0  1 L  0 0 0  0\
 0 0  U I  1 O  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o \
 0 0 1  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  C D  0 \
O P  C o  0 0 1  C D  0 O I  0 O D  0 O L  0 O 0  U I  1 0  0 O  U I  \
U I  U I  U I  U I  U I  0 O D  0 O I  U I  D I  1 C  U I  1 D  U I  D\
 I  1 C  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 I\
  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I  0 0 0  0 0 0  o C  \
0 0 0  o C  1 L  0 0 0  U I  U o  U I  o U  o U  o U  o U  0 O  U I  U\
 I  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  D P  U I  1 D  U I  1 \
C  D P  D L  U I  o U  0 O D  1 C  o U  U I  1 P  U I  o C  o C  0 0 0\
  0 0 0  o C  o C  0 0 0  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C\
  1 L  0 0 0  U I  U o  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o \
U  1 C  o U  0 O D  1 C  0 O D  0 O  U I  U I  U I  U I  U I  U I  0 O\
 D  0 O I  U I  D o  U I  1 D  U I  D o  D L  U I  o U  1 C  o U  0 O \
D  1 C  1 C  1 C  U I  1 D  U I  o U  0 O D  o U  o U  U I  1 I  U I  \
o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 P  U I  o U  0 O D  o \
U  o U  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  U C \
 0 0 D  C o  0 0 L  0 O 0  C 0  U C  U I  0 O D  0 0 O  U I  0 O D  1 \
C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  C C  0 0 0  0\
 0 0  0 O o  0 O D  0 O 0  0 O P  C o  0 0 1  U C  U I  C U  U I  D L \
 0 O  U I  U I  U I  U I  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0 \
 C D  0 O P  C o  0 0 1  C D  0 O I  0 O D  0 O L  0 O 0  U I  P 0  U \
I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  C\
 C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 O P  C o  0 0 1  U C  U I  C \
U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U \
C  0 0 D  C o  0 0 L  0 O 0  C 0  U C  U I  1 0  U I  C 0  U I  1 C  U\
 I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U\
 I  U C  C U  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U\
 I  U I  U I  U I  0 O D  0 O D  1 C  o U  0 O D  1 C  o U  0 O D  o U\
  o U  0 O D  U I  P 0  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 I  C o  \
0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I\
  0 0 0  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  o C  o C\
  0 0 0  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  C D  0\
 O P  C o  0 0 1  C D  0 O I  0 O D  0 O L  0 O 0  U I  1 0  0 O  U I \
 U I  U I  U I  U I  0 O D  0 O I  U I  D P  D 0  U I  1 D  U I  D P  \
D 0  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I  0 0 0  o C \
 1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  U I  U I  U I  U I\
  o C  0 0 0  0 0 0  1 L  0 0 0  0 0 0  U I  1 O  U I  C C  0 0 0  0 0\
 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 1  U I  C C  0 0 0  0\
 0 0  0 O o  0 O D  0 O 0  C D  0 O P  C o  0 0 1  C D  0 O I  0 O D  \
0 O L  0 O 0  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  0 O D  \
1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o \
 0 O U  0 O 0  U C  U I  C U  U I  C o  0 0 O  0 O O  U I  U C  U P  0\
 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U C  U I  0 O D  0 0 O\
  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U \
C  0 0 I  C o  0 O U  0 O 0  U C  U I  C U  U I  D L  0 O  U I  U I  U\
 I  U I  o U  o U  1 C  o U  0 O D  1 C  1 C  o U  0 O D  1 C  0 O D  \
1 C  o U  U I  P 0  U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  1 O  U I \
 0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  1 1  U I  0 O D  1 C  \
1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O \
U  0 O 0  U C  U I  C U  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O \
D  0 O 0  o 1  C o  0 0 1  U I  1 1  U I  0 0 1  0 O 0  C C  0 0 o  0 \
0 1  0 0 D  0 O D  0 0 L  0 O 0  P o  C o  0 O L  0 O L  U I  P 0  U I\
  L 1  0 0 1  0 0 o  0 O 0  U I  1 1  U I  C C  C o  C C  0 O 1  0 O 0\
  0 O O  L O  C o  0 O U  0 O 0  0 0 D  U I  P 0  U I  C C  C o  C C  \
0 O 1  0 O 0  0 O O  L O  C o  0 O U  0 O 0  0 0 D  U I  1 0  0 O  U I\
  U I  U I  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I\
  o U  o U  1 C  o U  0 O D  1 C  1 C  o U  0 O D  1 C  0 O D  1 C  o \
U  U I  1 0  U I  P 0  P 0  U I  1 L  U I  D L  0 O  U I  U I  U I  U \
I  U I  o U  o U  1 C  o U  0 O D  1 C  1 C  o U  0 O D  1 C  0 O D  1\
 C  o U  U I  P 0  U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  D L  1 o  1 o\
  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 O I  C o  0 O D  0 O L  0 O 0  \
0 O O  U C  0 O  U I  U I  U I  U I  0 O D  1 C  1 C  o U  1 C  0 O D \
 o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O U  0 O 0  U C  U I  C\
 U  U I  P 0  U I  o U  o U  1 C  o U  0 O D  1 C  1 C  o U  0 O D  1 \
C  0 O D  1 C  o U  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  D\
 D  U I  1 D  U I  1 C  D D  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  \
1 L  o C  1 L  1 L  U I  1 D  U I  o U  0 O D  1 C  o U  U I  1 I  U I\
  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  U I  U I  0 O D  \
0 O I  U I  U C  0 0 D  0 O 0  0 0 P  C C  0 0 0  0 0 0  0 O o  0 O D \
 0 O 0  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D \
 o U  0 O D  U I  C o  0 0 O  0 O O  U I  0 O D  1 C  1 C  o U  1 C  0\
 O D  o U  0 O D  U I  C 0  U I  U C  0 0 D  0 O 0  0 0 P  C C  0 0 0 \
 0 0 0  0 O o  0 O D  0 O 0  U C  U I  C U  U I  C o  0 0 O  0 O O  U \
I  U C  U P  0 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U C  U I\
  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I\
  C 0  U I  U C  0 0 D  0 O 0  0 0 P  C C  0 0 0  0 0 0  0 O o  0 O D \
 0 O 0  U C  U I  C U  U I  D L  0 O  U I  U I  U I  U I  0 O D  1 C  \
1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 D  0 O 0  0 \
0 P  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  U C  U I  C U  U I  P 0  \
U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  1 O  U I  0 0 1  0 O 0  0 O U\
  0 O 0  0 I O  0 0 D  U I  1 1  U I  0 O D  1 C  1 C  o U  1 C  0 O D\
  o U  0 O D  U I  C 0  U I  U C  0 0 D  0 O 0  0 0 P  C C  0 0 0  0 0\
 0  0 O o  0 O D  0 O 0  U C  U I  C U  U I  1 1  U I  C C  0 0 0  0 0\
 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 1  U I  0 0 1  0 O 0 \
 C C  0 0 o  0 0 1  0 0 D  0 O D  0 0 L  0 O 0  P o  C o  0 O L  0 O L\
  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 1  U I  C C  C o  C \
C  0 O 1  0 O 0  0 O O  L O  C o  0 O U  0 O 0  0 0 D  U I  P 0  U I  \
C C  C o  C C  0 O 1  0 O 0  0 O O  L O  C o  0 O U  0 O 0  0 0 D  U I\
  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  U C  C o  0 0 I  0 0 I  \
0 O 0  0 0 O  0 O O  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  U C  U I \
 0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I \
 C o  0 0 O  0 O O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D \
 U I  C 0  U I  U C  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  C C  0 0 \
0  0 0 0  0 O o  0 O D  0 O 0  U C  U I  C U  U I  C o  0 0 O  0 O O  \
U I  U C  U P  0 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U C  U\
 I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U\
 I  C 0  U I  U C  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  C C  0 0 0 \
 0 0 0  0 O o  0 O D  0 O 0  U C  U I  C U  U I  D L  0 O  U I  U I  U\
 I  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  \
U C  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  C C  0 0 0  0 0 0  0 O o \
 0 O D  0 O 0  U C  U I  C U  U I  P 0  U I  0 0 0  o C  o C  0 0 0  0\
 0 0  U I  1 O  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  1 \
1  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U\
 C  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  C C  0 0 0  0 0 0  0 O o  \
0 O D  0 O 0  U C  U I  C U  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  \
0 O D  0 O 0  o 1  C o  0 0 1  U I  1 1  U I  0 0 1  0 O 0  C C  0 0 o\
  0 0 1  0 0 D  0 O D  0 0 L  0 O 0  P o  C o  0 O L  0 O L  U I  P 0 \
 U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 1  U I  C C  C o  C C  0 O 1  0\
 O 0  0 O O  L O  C o  0 O U  0 O 0  0 0 D  U I  P 0  U I  C C  C o  C\
 C  0 O 1  0 O 0  0 O O  L O  C o  0 O U  0 O 0  0 0 D  U I  1 0  0 O \
 U I  U I  U I  U I  0 O D  0 O I  U I  D U  U I  1 D  U I  D U  D L  \
U I  o C  1 L  0 0 0  o C  U I  1 D  U I  o C  1 L  0 0 0  o C  U I  1\
 P  U I  o U  0 O D  o U  o U  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0\
  o C  1 L  0 0 0  U I  1 D  U I  o C  1 L  0 0 0  o C  U I  1 P  U I \
 o U  o U  o U  o U  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D 0  \
1 C  U I  1 D  U I  D 0  1 C  D L  U I  o U  0 O D  1 C  o U  U I  1 D\
  U I  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  0 0 0  o C  1 L  0 0 0  \
U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  U I  0 O D \
 0 O I  U I  U C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  0 O D  0 0 O  \
U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C o  0 0 O  0 \
O O  U I  U C  U P  0 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U\
 C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O\
 D  U I  C 0  U I  U C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  C U  U I\
  D L  0 O  U I  U I  U I  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U \
 0 O D  U I  C 0  U I  U C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  C U \
 U I  P 0  U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  1 O  U I  0 0 1  0\
 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  1 1  U I  0 O D  1 C  1 C  o U \
 1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  0 0 0  0 0 D  0 0 \
P  U C  U I  C U  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O \
0  o 1  C o  0 0 1  U I  1 1  U I  0 0 1  0 O 0  C C  0 0 o  0 0 1  0 \
0 D  0 O D  0 0 L  0 O 0  P o  C o  0 O L  0 O L  U I  P 0  U I  L 1  \
0 0 1  0 0 o  0 O 0  U I  1 1  U I  C C  C o  C C  0 O 1  0 O 0  0 O O\
  L O  C o  0 O U  0 O 0  0 0 D  U I  P 0  U I  C C  C o  C C  0 O 1  \
0 O 0  0 O O  L O  C o  0 O U  0 O 0  0 0 D  U I  1 0  0 O  U I  U I  \
U I  U I  0 O D  0 O I  U I  1 C  D O  U I  1 D  U I  1 C  D O  D L  U\
 I  0 0 0  o C  1 L  0 0 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I\
  D O  1 L  U I  1 D  U I  D O  1 L  D L  U I  0 0 0  1 L  1 L  o C  1\
 L  0 0 0  0 0 0  U I  1 o  U I  o U  1 C  1 C  0 O D  0 O  U I  U I  \
U I  0 O D  0 O I  U I  U C  0 0 1  C o  0 0 C  0 0 I  0 0 0  0 0 D  0\
 0 P  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o\
 U  0 O D  U I  C o  0 0 O  0 O O  U I  U C  U P  0 O O  0 0 0  0 0 1 \
 0 O 0  0 O U  0 O 0  0 I O  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  \
1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 1  C o  0 0 \
C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  C U  U I  D L  0 O  U I  U I \
 U I  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I\
  U C  0 0 1  C o  0 0 C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  C U  U\
 I  P 0  U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  1 O  U I  0 0 1  0 O\
 0  0 O U  0 O 0  0 I O  0 0 D  U I  1 1  U I  0 O D  1 C  1 C  o U  1\
 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 1  C o  0 0 C  0 0 I  0\
 0 0  0 0 D  0 0 P  U C  U I  C U  U I  1 1  U I  C C  0 0 0  0 0 0  0\
 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 1  U I  0 0 1  0 O 0  C C \
 0 0 o  0 0 1  0 0 D  0 O D  0 0 L  0 O 0  P o  C o  0 O L  0 O L  U I\
  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 1  U I  C C  C o  C C  0 \
O 1  0 O 0  0 O O  L O  C o  0 O U  0 O 0  0 0 D  U I  P 0  U I  C C  \
C o  C C  0 O 1  0 O 0  0 O O  L O  C o  0 O U  0 O 0  0 0 D  U I  1 1\
  U I  0 0 1  C o  0 0 C  L O  0 0 0  0 0 D  0 0 P  U I  P 0  U I  L 1\
  0 0 1  0 0 o  0 O 0  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I\
  U I  D D  1 C  U I  1 D  U I  D D  1 C  D L  U I  0 0 0  0 0 0  o C \
 0 0 0  o C  1 L  0 0 0  U I  1 P  U I  o U  1 C  1 C  0 O D  0 O  U I\
  U I  U I  U I  0 O D  0 O I  U I  D o  D I  U I  1 D  U I  D o  D I \
 D L  U I  o C  1 L  0 0 0  o C  U I  1 P  U I  0 O D  1 C  0 O  U I  \
U I  U I  0 O D  0 O I  U I  U C  0 0 1  C o  0 0 C  0 0 I  0 0 0  0 0\
 D  0 0 P  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O\
 D  o U  0 O D  U I  C o  0 0 O  0 O O  U I  U C  U P  0 O 0  0 0 I  0\
 0 0  C C  0 0 P  0 O D  0 O C  0 O 0  U P  U C  U I  0 O D  0 0 O  U \
I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0\
 0 1  C o  0 0 C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  C U  U I  D L \
 0 O  U I  U I  U I  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D\
  U I  C 0  U I  U C  0 0 1  C o  0 0 C  0 0 I  0 0 0  0 0 D  0 0 P  U\
 C  U I  C U  U I  P 0  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 \
O D  U I  C 0  U I  U C  0 0 1  C o  0 0 C  0 0 I  0 0 0  0 0 D  0 0 P\
  U C  U I  C U  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  \
0 O 0  U I  1 O  U I  U C  U P  0 O 0  0 0 I  0 0 0  C C  0 0 P  0 O D\
  0 O C  0 O 0  U P  U C  U I  1 1  U I  o C  0 0 0  o C  0 0 0  0 0 0\
  1 L  0 0 0  o C  U I  1 O  U I  1 0  U I  1 0  0 O  U I  U I  U I  U\
 I  0 O D  0 O I  U I  1 C  1 L  U I  1 D  U I  1 C  1 L  D L  U I  o \
U  0 O D  1 C  o U  U I  1 P  U I  0 O D  0 O D  o U  1 C  0 O D  o U \
 0 O D  o U  0 O  U I  U I  U I  0 O D  0 O I  U I  U C  0 0 1  C o  0\
 0 C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  0 O D  0 0 O  U I  0 O D  \
1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C o  0 0 O  0 O O  U I  U \
C  U P  0 O 0  0 0 I  0 0 0  C C  0 0 P  0 O D  0 O C  0 O 0  D O  U P\
  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  \
0 O D  U I  C 0  U I  U C  0 0 1  C o  0 0 C  0 0 I  0 0 0  0 0 D  0 0\
 P  U C  U I  C U  U I  D L  0 O  U I  U I  U I  U I  0 O D  1 C  1 C \
 o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 1  C o  0 0 C  0\
 0 I  0 0 0  0 0 D  0 0 P  U C  U I  C U  U I  P 0  U I  0 O D  1 C  1\
 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 1  C o  0 0 C\
  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  C U  U I  1 P  U I  0 0 1  0 O\
 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  U P  0 O 0  0 0\
 I  0 0 0  C C  0 0 P  0 O D  0 O C  0 O 0  D O  U P  U C  U I  1 1  U\
 I  o U  1 C  0 O D  U I  1 O  U I  1 0  U I  1 0  0 O  U I  U I  U I \
 U I  0 O D  0 O I  U I  D P  D 1  U I  1 D  U I  D P  D 1  D L  U I  \
o U  0 O D  o U  o U  U I  1 o  U I  o U  o U  o U  o U  U I  1 U  U I\
  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U \
I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U I  U I  U I \
 U I  0 O D  0 O I  U I  1 C  D o  U I  1 D  U I  1 C  D o  D L  U I  \
o U  0 O D  1 C  o U  U I  1 I  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 \
0 0  1 L  U I  1 U  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1\
 C  o U  0 O D  1 C  0 O D  0 O  U I  U I  U I  o C  1 L  0 0 0  U I  \
P 0  U I  U C  U C  0 O  U I  U I  U I  0 O D  0 O I  U I  0 O D  1 C \
 1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O\
 U  0 O 0  U C  U I  C U  U I  C o  0 0 O  0 O O  U I  0 O D  1 C  1 C\
  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O U  \
0 O 0  U C  U I  C U  U I  0 O D  0 0 O  U I  C C  C o  C C  0 O 1  0 \
O 0  0 O O  L O  C o  0 O U  0 O 0  0 0 D  U I  C o  0 0 O  0 O O  U I\
  0 0 O  0 0 0  0 0 P  U I  U C  0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 \
O 0  C C  C o  C C  0 O 1  0 O 0  U C  U I  0 O D  0 0 O  U I  0 O D  \
1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C o  0 0 O  0 O O  U I  0 \
O I  0 0 0  0 0 1  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0\
 0 1  o C  0 0 O  0 O L  0 I 0  U I  P 0  P 0  U I  o O  C o  0 O L  0\
 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D o\
  D U  U I  1 D  U I  D o  D U  D L  U I  o U  1 C  o U  0 O D  1 C  1\
 C  1 C  0 O  U I  U I  U I  U I  o C  1 L  0 0 0  U I  P 0  U I  C C \
 C o  C C  0 O 1  0 O 0  0 O O  L O  C o  0 O U  0 O 0  0 0 D  U I  C \
0  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U\
 C  0 0 I  C o  0 O U  0 O 0  U C  U I  C U  U I  C U  0 O  U I  U I  \
U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 \
O D  0 O I  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C \
0  U I  U C  0 0 I  C o  0 O U  0 O 0  U C  U I  C U  U I  C o  0 0 O \
 0 O O  U I  0 0 O  0 0 0  0 0 P  U I  0 O D  1 C  1 C  o U  1 C  0 O \
D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O U  0 O 0  U C  U I \
 C U  U I  P 0  P 0  U I  U C  U C  U I  C o  0 0 O  0 O O  U I  0 O D\
  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C \
o  0 O U  0 O 0  U C  U I  C U  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 \
1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  0 O 1\
  0 0 P  0 0 P  0 0 I  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U \
I  U I  0 O D  0 O I  U I  U C  U P  0 O 0  0 0 I  0 0 0  C C  0 0 P  \
0 O D  0 O C  0 O 0  U P  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C\
  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O U  \
0 O 0  U C  U I  C U  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O\
 D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  \
C o  0 O U  0 O 0  U C  U I  C U  U I  P 0  U I  0 O D  1 C  1 C  o U \
 1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O U  0 O 0 \
 U C  U I  C U  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0\
 O 0  U I  1 O  U I  U C  U P  0 O 0  0 0 I  0 0 0  C C  0 0 P  0 O D \
 0 O C  0 O 0  U P  U C  U I  1 1  U I  o C  0 0 0  o C  0 0 0  0 0 0 \
 1 L  0 0 0  o C  U I  1 O  U I  1 0  U I  1 0  0 O  U I  U I  U I  U \
I  U I  0 O D  0 O I  U I  U C  U P  0 O 0  0 0 I  0 0 0  C C  0 0 P  \
0 O D  0 O C  0 O 0  D O  U P  U C  U I  0 O D  0 0 O  U I  0 O D  1 C\
  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 \
O U  0 O 0  U C  U I  C U  U I  D L  0 O  U I  U I  U I  U I  U I  U I\
  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 \
0 I  C o  0 O U  0 O 0  U C  U I  C U  U I  P 0  U I  0 O D  1 C  1 C \
 o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O U  0\
 O 0  U C  U I  C U  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C\
 C  0 O 0  U I  1 O  U I  U C  U P  0 O 0  0 0 I  0 0 0  C C  0 0 P  0\
 O D  0 O C  0 O 0  D O  U P  U C  U I  1 1  U I  o U  1 C  0 O D  U I\
  1 O  U I  1 0  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 O D  0\
 O I  U I  D 1  1 L  U I  1 D  U I  D 1  1 L  D L  U I  o C  o C  0 0 \
0  0 0 0  o C  o C  0 0 0  U I  U o  U I  o U  0 O D  o U  o U  U I  1\
 U  U I  o C  1 L  0 0 0  o C  U I  1 P  U I  o C  0 0 0  0 0 0  0 0 0\
  1 L  1 L  1 L  1 L  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  0 O  U I \
 U I  U I  U I  U I  U I  0 O D  0 O I  U I  D o  D 0  U I  1 D  U I  \
D o  D 0  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  U I  U I\
  U I  U I  U I  0 O D  1 C  1 C  1 C  o U  U I  P 0  U I  0 O D  1 C \
 1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O\
 U  0 O 0  U C  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0\
 0 P  U I  1 O  U I  U C  0 I 1  U C  U I  1 0  0 O  U I  U I  U I  U \
I  U I  o C  o C  o C  1 L  0 0 0  o C  0 0 0  o C  1 L  o C  U I  P 0\
  U I  0 O D  1 C  1 C  1 C  o U  U I  C 0  U I  1 L  U I  C U  0 O  U\
 I  U I  U I  U I  U I  o C  1 L  0 0 0  0 0 0  1 L  o C  o C  1 L  0 \
0 0  o C  o C  o C  0 0 0  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 \
O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U \
I  1 O  U I  0 O D  1 C  1 C  1 C  o U  U I  1 0  U I  P I  U I  1 C  \
U I  D L  0 O  U I  U I  U I  U I  U I  U I  o C  1 L  0 0 0  0 0 0  1\
 L  o C  o C  1 L  0 0 0  o C  o C  o C  0 0 0  U I  P 0  U I  0 O D  \
1 C  1 C  1 C  o U  U I  C 0  U I  1 C  U I  C U  0 O  U I  U I  U I  \
U I  U I  U I  0 O D  0 O I  U I  D P  D I  U I  1 D  U I  D P  D I  D\
 L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  \
1 I  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I  0 0 \
0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 I  U I  0 0 0  0 0 0  0 \
0 0  1 L  o C  0 0 0  1 L  0 O  U I  U I  U I  U I  U I  U I  0 O D  0\
 O I  U I  D P  U I  1 D  U I  D P  D L  U I  o C  0 0 0  0 0 0  0 0 0\
  1 L  1 L  1 L  1 L  U I  1 o  U I  o U  1 C  1 C  0 O D  U I  1 P  U\
 I  o U  o U  o U  o U  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O \
I  U I  D I  1 C  U I  1 D  U I  D I  1 C  D L  U I  0 O D  0 O D  o U\
  1 C  0 O D  o U  0 O D  o U  U I  1 U  U I  o U  1 C  o U  0 O D  1 \
C  1 C  1 C  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D P\
  D 1  U I  1 D  U I  D P  D 1  D L  U I  0 0 0  0 0 0  o C  0 0 0  o \
C  1 L  0 0 0  U I  1 P  U I  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  o\
 U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  U I  U I  U I  U I  U I  U I \
 0 O D  0 O I  U I  D U  D 1  U I  1 D  U I  D U  D 1  D L  U I  o U  \
o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I  U I \
 U I  U I  U I  0 O D  0 O I  U I  D 1  1 C  U I  1 D  U I  D 1  1 C  \
D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 o  U I  o C \
 1 L  0 0 0  o C  U I  1 o  U I  o U  0 O D  o U  o U  U I  1 I  U I  \
o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I \
 U I  U I  U I  U I  0 O D  0 O I  U I  D O  D 0  U I  1 D  U I  D O  \
D 0  D L  U I  o U  o U  o U  o U  U I  1 D  U I  o C  1 L  0 0 0  o C\
  U I  1 U  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  U I  U I \
 U I  U I  0 O D  0 O I  U I  1 C  D O  U I  1 D  U I  1 C  D O  D L  \
U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 o  U I  o C  0 0 0 \
 0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  U o  U I  0 0 0  1 L  1 L  o C\
  1 L  0 0 0  0 0 0  U I  1 o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L\
  o C  1 L  1 L  U I  U o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 \
0  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  D U  U I\
  1 D  U I  1 C  D U  D L  U I  0 0 0  o C  1 L  0 0 0  U I  U o  U I \
 o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I  o U  0 O D  o\
 U  o U  U I  1 I  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 \
C  o U  0 O D  1 C  0 O D  U I  1 U  U I  0 0 0  1 L  0 0 0  o C  1 L \
 0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  1 C  U I  \
1 D  U I  1 C  1 C  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O \
D  o U  U I  1 I  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C\
  o U  0 O D  1 C  0 O D  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C\
  1 L  0 0 0  0 O  U I  U I  U I  U I  U I  o C  o C  o C  U I  P 0  U\
 I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  L O  0\
 0 1  0 0 0  0 I O  0 I 0  o I  C o  0 0 O  0 O O  0 O L  0 O 0  0 0 1\
  U I  1 O  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P\
  U I  0 O U  0 O 0  0 0 P  0 0 I  0 0 1  0 0 0  0 I O  0 O D  0 O 0  \
0 0 D  U I  1 O  U I  1 0  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O\
 D  0 O I  U I  D U  U I  1 D  U I  D U  D L  U I  0 0 0  0 0 0  o C  \
0 0 0  o C  1 L  0 0 0  U I  1 I  U I  0 O D  1 C  U I  1 D  U I  0 0 \
0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 o  U I  0 0 0 \
 o C  1 L  0 0 0  U I  U o  U I  o U  o U  o U  o U  U I  1 U  U I  0 \
0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  U I  U I  U I  U I \
 0 O D  0 O I  U I  D U  1 C  U I  1 D  U I  D U  1 C  D L  U I  0 O D\
  1 C  U I  1 I  U I  o U  0 O D  1 C  o U  U I  U o  U I  o C  0 0 0 \
 0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  U I  U I  U I  U I  0 O D\
  0 O I  U I  D o  D P  U I  1 D  U I  D o  D P  D L  U I  o U  1 C  o\
 U  0 O D  1 C  1 C  1 C  U I  1 P  U I  0 0 0  1 L  0 0 0  o C  1 L  \
U I  U o  U I  o U  0 O D  1 C  o U  0 O  U I  U I  U I  U I  U I  o U\
  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  P 0  U I  0 0 o  0 0 1\
  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  L I  0 O 0  0 0 U  0 0\
 o  0 O 0  0 0 D  0 0 P  U I  1 O  U I  o C  o C  o C  1 L  0 0 0  o C\
  0 0 0  o C  1 L  o C  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O D \
 0 O I  U I  U C  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  U C  U I  0 O D  \
0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  D L  0 \
O  U I  U I  U I  U I  U I  U I  o C  1 L  o C  0 0 0  o C  0 0 0  o C\
  1 L  1 L  o C  U I  P 0  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U \
 0 O D  U I  C 0  U I  U C  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  U C  U \
I  C U  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D o  D 1\
  U I  1 D  U I  D o  D 1  D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0\
 O D  U I  U o  U I  o U  0 O D  o U  o U  U I  1 P  U I  0 0 0  o C  \
1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  o C  1 L  0 0 \
0  o C  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D I  D O\
  U I  1 D  U I  D I  D O  D L  U I  o U  0 O D  1 C  o U  U I  1 I  U\
 I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 I  U I  0 0\
 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 D  U I  o C  1 \
L  0 0 0  o C  U I  1 P  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0 \
 0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  o C  o C  o C  \
1 L  0 0 0  o C  0 0 0  o C  1 L  o C  U I  C 0  U I  D L  U I  D U  U\
 I  C U  U I  P 0  P 0  U I  U 1  0 O 1  0 0 P  0 0 P  0 0 I  0 0 D  U\
 1  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  1 \
L  1 L  0 0 0  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  \
D O  U I  1 P  U I  L O  0 0 1  0 0 0  0 I O  0 I 0  o I  C o  0 0 O  \
0 O O  0 O L  0 O 0  0 0 1  U I  1 O  U I  0 I U  U I  U C  0 O 1  0 0\
 P  0 0 P  0 0 I  0 0 D  U C  U I  D L  U I  o C  1 L  o C  0 0 0  o C\
  0 0 0  o C  1 L  1 L  o C  U I  0 I D  U I  1 0  0 O  U I  U I  U I \
 U I  U I  U I  U I  0 O D  0 O I  U I  D D  D 1  U I  1 D  U I  D D  \
D 1  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U \
I  U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O \
 U I  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  1 L  1 L  0 0 0  U I\
  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I\
  L O  0 0 1  0 0 0  0 I O  0 I 0  o I  C o  0 0 O  0 O O  0 O L  0 O \
0  0 0 1  U I  1 O  U I  0 I U  U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  \
U C  U I  D L  U I  o C  1 L  o C  0 0 0  o C  0 0 0  o C  1 L  1 L  o\
 C  U I  0 I D  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  U I  0 O \
D  0 O I  U I  1 C  1 C  U I  1 D  U I  1 C  1 C  D L  U I  0 0 0  0 0\
 0  0 0 0  1 L  o C  0 0 0  1 L  U I  U o  U I  0 0 0  o C  1 L  0 0 0\
  1 L  0 0 0  0 0 0  o C  1 L  U I  U o  U I  0 O D  1 C  1 C  o U  0 \
O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 o  U I  o U  0\
 O D  1 C  o U  U I  U o  U I  0 O D  1 C  U I  1 D  U I  o U  0 O D  \
o U  o U  0 O  U I  U I  U I  U I  U I  U I  o C  o C  0 0 0  0 0 0  o\
 C  o C  1 L  1 L  o C  1 L  o C  o C  1 L  1 L  0 0 0  0 0 0  U I  P \
0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  C \
L  0 0 o  0 O D  0 O L  0 O O  C D  0 0 0  0 0 I  0 O 0  0 0 O  0 O 0 \
 0 0 1  U I  1 O  U I  0 0 0  0 0 0  1 L  1 L  0 0 0  U I  1 0  0 O  U\
 I  U I  U I  U I  U I  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D\
 O  U I  1 P  U I  0 O D  0 0 O  0 0 D  0 0 P  C o  0 O L  0 O L  C D \
 0 0 0  0 0 I  0 O 0  0 0 O  0 O 0  0 0 1  U I  1 O  U I  o C  o C  0 \
0 0  0 0 0  o C  o C  1 L  1 L  o C  1 L  o C  o C  1 L  1 L  0 0 0  0\
 0 0  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  \
D 1  D o  U I  1 D  U I  D 1  D o  D L  U I  0 0 0  1 L  1 L  o C  1 L\
  0 0 0  0 0 0  U I  1 o  U I  o U  0 O D  o U  o U  0 O  U I  U I  U \
I  U I  U I  U I  0 O D  0 O I  U I  D I  D 0  U I  1 D  U I  D I  D 0\
  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  \
1 P  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 o  U I  o C  o\
 C  0 0 0  0 0 0  o C  o C  0 0 0  U I  U o  U I  o C  o C  0 0 0  0 0\
 0  o C  o C  0 0 0  0 O  U I  U I  U I  U I  U I  o U  o U  0 O D  0 \
O D  1 C  o U  0 O D  1 C  U I  1 P  U I  C o  0 O O  0 O O  C D  0 O \
1  0 O 0  C o  0 O O  0 O 0  0 0 1  U I  1 O  U I  U C  L D  0 0 D  0 \
O 0  0 0 1  1 D  P D  0 O U  0 O 0  0 0 O  0 0 P  U C  U I  1 1  U I  \
U C  o o  0 0 0  0 I I  0 O D  0 O L  0 O L  C o  1 o  D U  1 P  1 L  \
U I  1 O  L o  0 O D  0 0 O  0 O O  0 0 0  0 0 C  0 0 D  U I  o L  L 1\
  U I  D 1  1 P  1 C  D C  U I  0 0 1  0 0 L  D L  1 C  D I  1 P  1 L \
 1 0  U I  o 0  0 O 0  C C  0 O o  0 0 0  1 o  D O  1 L  1 C  1 L  1 L\
  1 C  1 L  1 C  U I  o O  0 O D  0 0 1  0 O 0  0 O I  0 0 0  0 I O  1\
 o  1 C  D I  1 P  1 L  1 P  1 C  U C  U I  1 0  0 O  U I  U I  U I  U\
 I  U I  o C  1 L  o C  0 0 0  o C  0 0 0  o C  1 L  1 L  o C  U I  P \
0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  U I  U I  U I  U I  0 O D \
 0 O I  U I  D 0  D 0  U I  1 D  U I  D 0  D 0  D L  U I  0 O D  1 C  \
0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  U C  0 0 1  0 O 0  0 \
O I  0 O 0  0 0 1  0 O 0  0 0 1  U C  U I  0 O D  0 0 O  U I  0 O D  1\
 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  D L  0 O  U I  U I  U I  U \
I  U I  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U\
 I  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  U \
I  1 O  U I  U C  L I  0 O 0  0 O I  0 O 0  0 0 1  0 O 0  0 0 1  U C  \
U I  1 1  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0 \
 U I  U C  0 0 1  0 O 0  0 O I  0 O 0  0 0 1  0 O 0  0 0 1  U C  U I  \
C U  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  U C  C\
 o  C C  C C  0 O 0  0 0 I  0 0 P  U C  U I  0 O D  0 0 O  U I  0 O D \
 1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  D L  0 O  U I  U I  U I  \
U I  U I  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 P \
 U I  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  \
U I  1 O  U I  U C  P D  C C  C C  0 O 0  0 0 I  0 0 P  U C  U I  1 1 \
 U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C\
  C o  C C  C C  0 O 0  0 0 I  0 0 P  U C  U I  C U  U I  1 0  0 O  U \
I  U I  U I  U I  U I  0 O D  0 O I  U I  U C  C o  0 O U  0 O 0  0 0 \
O  0 0 P  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O \
D  o U  0 O D  U I  D L  0 O  U I  U I  U I  U I  U I  U I  o U  o U  \
0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I  C o  0 O O  0 O O  \
C D  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  U I  1 O  U I  U C  L D  \
0 0 D  0 O 0  0 0 1  1 D  C o  0 O U  0 O 0  0 0 O  0 0 P  U C  U I  1\
 1  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  \
U C  C o  0 O U  0 O 0  0 0 O  0 0 P  U C  U I  C U  U I  1 0  0 O  U \
I  U I  U I  U I  U I  0 O D  0 O I  U I  U C  0 I O  1 D  0 0 1  0 O \
0  0 0 U  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O \
D  o U  0 O D  U I  D L  0 O  U I  U I  U I  U I  U I  U I  o U  o U  \
0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I  C o  0 O O  0 O O  \
C D  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  U I  1 O  U I  U C  L L  \
1 D  L I  0 O 0  0 0 U  0 0 o  0 O 0  0 0 D  0 0 P  0 O 0  0 O O  1 D \
 L o  0 O D  0 0 P  0 O 1  U C  U I  1 1  U I  0 O D  1 C  1 C  o U  1\
 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 I O  1 D  0 0 1  0 O 0  0\
 0 U  U C  U I  C U  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O D  0 \
O I  U I  U C  0 I O  1 D  C o  0 O O  0 O O  0 0 1  U C  U I  0 O D  \
0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  D L  0 \
O  U I  U I  U I  U I  U I  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O\
 D  1 C  U I  1 P  U I  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  0 O\
 O  0 O 0  0 0 1  U I  1 O  U I  U C  0 I O  1 D  C o  0 O O  0 O O  0\
 0 1  U C  U I  1 1  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D\
  U I  C 0  U I  U C  0 I O  1 D  C o  0 O O  0 O O  0 0 1  U C  U I  \
C U  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  U C  0\
 I O  1 D  0 O I  0 0 0  0 0 1  0 0 C  C o  0 0 1  0 O O  U C  U I  0 \
O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  D \
L  0 O  U I  U I  U I  U I  U I  U I  o U  o U  0 O D  0 O D  1 C  o U\
  0 O D  1 C  U I  1 P  U I  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o\
  0 O O  0 O 0  0 0 1  U I  1 O  U I  U C  L L  1 D  o O  0 0 0  0 0 1\
  0 0 C  C o  0 0 1  0 O O  0 O 0  0 O O  1 D  o O  0 0 0  0 0 1  U C \
 U I  1 1  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0\
  U I  U C  0 I O  1 D  0 O I  0 0 0  0 0 1  0 0 C  C o  0 0 1  0 O O \
 U C  U I  C U  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  \
U I  U C  0 0 D  0 O 0  0 0 P  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0 \
 U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0\
 O D  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  \
D 1  D O  U I  1 D  U I  D 1  D O  D L  U I  0 0 0  o C  1 L  0 0 0  1\
 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  0 O D  1 C  1 C  o U  0 O D\
  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 U  U I  o U  1 C \
 1 C  0 O D  U I  1 o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0\
 O  U I  U I  U I  U I  U I  U I  o U  o U  0 O D  0 O D  1 C  o U  0 \
O D  1 C  U I  1 P  U I  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  0 \
O O  0 O 0  0 0 1  U I  1 O  U I  U C  P o  0 0 0  0 0 0  0 O o  0 O D\
  0 O 0  U C  U I  1 1  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 \
O D  U I  C 0  U I  U C  0 0 D  0 O 0  0 0 P  C C  0 0 0  0 0 0  0 O o\
  0 O D  0 O 0  U C  U I  C U  U I  1 0  0 O  U I  U I  U I  U I  U I \
 0 O D  0 O I  U I  U C  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  C C  \
0 0 0  0 0 0  0 O o  0 O D  0 O 0  U C  U I  0 O D  0 0 O  U I  0 O D \
 1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  D L  0 O  U I  U I  U I  \
U I  U I  U I  0 O D  0 O I  U I  D D  U I  1 D  U I  D D  D L  U I  0\
 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 U  U I  o U  1 C  1 C  \
0 O D  U I  1 P  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 o \
 U I  o U  0 O D  o U  o U  0 O  U I  U I  U I  U I  U I  U I  o U  1 \
C  1 C  1 C  0 O D  1 C  o U  1 C  U I  P 0  U I  0 O D  1 C  1 C  o U\
  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  C o  0 0 I  0 0 I  0 O 0\
  0 0 O  0 O O  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  U C  U I  C U \
 0 O  U I  U I  U I  U I  U I  U I  o U  1 C  1 C  1 C  0 O D  1 C  o \
U  1 C  U I  P 0  U I  o U  1 C  1 C  1 C  0 O D  1 C  o U  1 C  U I  \
1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  D C  \
U C  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 O I  0 0 0  0 0 1 \
 U I  0 0 0  1 L  o C  o C  0 0 0  0 0 0  1 L  o C  o C  1 L  o C  o C\
  o C  U I  0 O D  0 0 O  U I  o U  1 C  1 C  1 C  0 O D  1 C  o U  1 \
C  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  o U  1 C  \
0 O D  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  1 1  U I  0 O D  o U \
 0 O D  1 C  1 C  o U  0 O D  1 C  U I  P 0  U I  0 0 0  1 L  o C  o C\
  0 0 0  0 0 0  1 L  o C  o C  1 L  o C  o C  o C  U I  1 P  U I  0 0 \
D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  P 0  U C  U I  1 0 \
 0 O  U I  U I  U I  U I  U I  U I  U I  o C  1 L  0 0 0  1 L  1 L  o \
C  o C  0 0 0  1 L  1 L  o C  1 L  o C  U I  1 1  U I  0 O D  o U  1 C\
  0 O D  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  P 0  U I  0 O D  o \
U  1 C  0 O D  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  1 P  U I  0 0\
 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  D L  U C  U I  1 0\
  0 O  U I  U I  U I  U I  U I  U I  U I  o U  o U  1 C  0 O D  U I  P\
 0  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 O L  0 O D  C L  U \
I  1 P  U I  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0  U I  1 O  U I  0 \
0 L  0 O 0  0 0 1  0 0 D  0 O D  0 0 0  0 0 O  U I  P 0  U I  1 L  U I\
  1 1  U I  0 0 O  C o  0 O C  0 O 0  U I  P 0  U I  0 O D  o U  1 C  \
0 O D  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  1 1  U I  0 0 L  C o \
 0 O L  0 0 o  0 O 0  U I  P 0  U I  0 O D  o U  0 O D  1 C  1 C  o U \
 0 O D  1 C  U I  1 1  U I  0 0 I  0 0 0  0 0 1  0 0 P  U I  P 0  U I \
 o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  0 0 I  0 0 0  0 0 1  0 0 P  \
C D  0 0 D  0 0 I  0 O 0  C C  0 O D  0 O I  0 O D  0 O 0  0 O O  U I \
 P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  U I  1 1  U I  0 O O  0 0 0 \
 0 O C  C o  0 O D  0 0 O  U I  P 0  U I  o C  1 L  0 0 0  1 L  1 L  o\
 C  o C  0 0 0  1 L  1 L  o C  1 L  o C  U I  1 1  U I  0 O O  0 0 0  \
0 O C  C o  0 O D  0 0 O  C D  0 0 D  0 0 I  0 O 0  C C  0 O D  0 O I \
 0 O D  0 O 0  0 O O  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  U \
I  1 1  U I  0 O O  0 0 0  0 O C  C o  0 O D  0 0 O  C D  0 O D  0 0 O\
  0 O D  0 0 P  0 O D  C o  0 O L  C D  0 O O  0 0 0  0 0 P  U I  P 0 \
 U I  o O  C o  0 O L  0 0 D  0 O 0  U I  1 1  U I  0 0 I  C o  0 0 P \
 0 O 1  U I  P 0  U I  U C  1 o  U C  U I  1 1  U I  0 0 I  C o  0 0 P\
  0 O 1  C D  0 0 D  0 0 I  0 O 0  C C  0 O D  0 O I  0 O D  0 O 0  0 \
O O  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 1  U I  0 0 D  0 \
O 0  C C  0 0 o  0 0 1  0 O 0  U I  P 0  U I  o O  C o  0 O L  0 0 D  \
0 O 0  U I  1 1  U I  0 O 0  0 I O  0 0 I  0 O D  0 0 1  0 O 0  0 0 D \
 U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  0 O O  0 O D \
 0 0 D  C C  C o  0 0 1  0 O O  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O \
0  U I  1 1  U I  C C  0 0 0  0 O C  0 O C  0 O 0  0 0 O  0 0 P  U I  \
P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  C C  0 0 0  0 O C  \
0 O C  0 O 0  0 0 O  0 0 P  C D  0 0 o  0 0 1  0 O L  U I  P 0  U I  o\
 L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  0 0 1  0 O 0  0 0 D  0 0 P  U \
I  P 0  U I  0 I U  U I  U C  o I  0 0 P  0 0 P  0 0 I  o C  0 0 O  0 \
O L  0 I 0  U C  U I  D L  U I  o L  0 0 0  0 0 O  0 O 0  U I  0 I D  \
U I  1 1  U I  0 0 1  0 O I  C C  D O  1 C  1 L  D o  U I  P 0  U I  o\
 O  C o  0 O L  0 0 D  0 O 0  U I  1 0  0 O  U I  U I  U I  U I  U I  \
U I  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I\
  1 P  U I  0 0 D  0 O 0  0 0 P  C D  C C  0 0 0  0 0 0  0 O o  0 O D \
 0 O 0  U I  1 O  U I  o U  o U  1 C  0 O D  U I  1 0  0 O  U I  U I  \
U I  U I  U I  0 O D  0 O I  U I  U C  0 0 0  0 0 1  0 O D  0 O U  0 O\
 D  0 0 O  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O\
 D  o U  0 O D  U I  D L  0 O  U I  U I  U I  U I  U I  U I  o U  o U \
 0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I  C o  0 O O  0 O O \
 C D  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  U I  1 O  U I  U C  o C \
 0 0 1  0 O D  0 O U  0 O D  0 0 O  U C  U I  1 1  U I  0 O D  1 C  1 \
C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 0  0 0 1  0 O \
D  0 O U  0 O D  0 0 O  U C  U I  C U  U I  1 0  0 O  U I  U I  U I  U\
 I  U I  0 O D  0 O I  U I  o C  1 L  0 0 0  0 0 0  1 L  o C  o C  1 L\
  0 0 0  o C  o C  o C  0 0 0  U I  D L  0 O  U I  U I  U I  U I  U I \
 U I  o C  1 L  0 0 0  0 0 0  1 L  o C  o C  1 L  0 0 0  o C  o C  o C\
  0 0 0  U I  P 0  U I  o C  1 L  0 0 0  0 0 0  1 L  o C  o C  1 L  0 \
0 0  o C  o C  o C  0 0 0  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  \
0 0 P  U I  1 O  U I  U C  U L  U C  U I  1 0  0 O  U I  U I  U I  U I\
  U I  U I  0 O I  0 0 0  0 0 1  U I  0 0 0  1 L  o C  o C  0 0 0  0 0\
 0  1 L  o C  o C  1 L  o C  o C  o C  U I  0 O D  0 0 O  U I  o C  1 \
L  0 0 0  0 0 0  1 L  o C  o C  1 L  0 0 0  o C  o C  o C  0 0 0  U I \
 D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 0\
  1 L  o C  o C  0 0 0  0 0 0  1 L  o C  o C  1 L  o C  o C  o C  U I \
 1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  P 0 \
 U C  U I  1 0  U I  P 0  P 0  U I  D O  U I  D L  0 O  U I  U I  U I \
 U I  U I  U I  U I  U I  0 O D  o U  1 C  0 O D  o U  1 C  o U  1 C  \
0 O D  1 C  o U  U I  1 1  U I  0 O D  o U  0 O D  1 C  1 C  o U  0 O \
D  1 C  U I  P 0  U I  0 0 0  1 L  o C  o C  0 0 0  0 0 0  1 L  o C  o\
 C  1 L  o C  o C  o C  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0\
 P  U I  1 O  U I  U C  P 0  U C  U I  1 0  0 O  U I  U I  U I  U I  U\
 I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I\
  U I  U I  U I  U I  U I  o U  0 O D  1 C  1 C  0 O D  o U  o U  1 C \
 U I  P 0  U I  0 0 0  1 L  o C  o C  0 0 0  0 0 0  1 L  o C  o C  1 L\
  o C  o C  o C  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I\
  1 O  U I  U C  P 0  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  U I\
  U I  U I  0 O D  o U  1 C  0 O D  o U  1 C  o U  1 C  0 O D  1 C  o \
U  U I  P 0  U I  o U  0 O D  1 C  1 C  0 O D  o U  o U  1 C  U I  C 0\
  U I  1 L  U I  C U  0 O  U I  U I  U I  U I  U I  U I  U I  U I  0 O\
 D  o U  0 O D  1 C  1 C  o U  0 O D  1 C  U I  P 0  U I  U C  P 0  U \
C  U I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I  o U  0 O \
D  1 C  1 C  0 O D  o U  o U  1 C  U I  C 0  U I  1 C  U I  D L  U I  \
C U  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O\
 I  U I  D o  D 1  U I  1 D  U I  D o  D 1  D L  U I  o U  o U  0 O D \
 o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 P  U I  0 O D  1 C  1 C\
  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  U o  U \
I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 I  U I  0 0 0  o C  1 L\
  0 0 0  0 O  U I  U I  U I  U I  U I  U I  U I  o U  o U  0 O D  0 O \
D  1 C  o U  0 O D  1 C  U I  1 P  U I  C o  0 O O  0 O O  C D  0 O 1 \
 0 O 0  C o  0 O O  0 O 0  0 0 1  U I  1 O  U I  0 O D  o U  1 C  0 O \
D  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  1 1  U I  0 O D  o U  0 O\
 D  1 C  1 C  o U  0 O D  1 C  U I  1 0  0 O  U I  U I  U I  U I  U I \
 U I  U I  0 O D  0 O I  U I  D U  D I  U I  1 D  U I  D U  D I  D L  \
U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C \
 0 O D  U I  1 I  U I  0 O D  1 C  U I  1 D  U I  o C  o C  0 0 0  0 0\
 0  o C  o C  0 0 0  U I  U o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 \
O D  U I  1 U  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0\
 O D  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0\
 0 P  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U \
I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U\
 I  U I  U I  U I  0 O D  0 O I  U I  D 1  U I  1 D  U I  D 1  D L  U \
I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 D  U I \
 o U  0 O D  1 C  o U  U I  1 o  U I  o U  o U  o U  o U  U I  1 U  U \
I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 U  U I  o\
 C  1 L  0 0 0  o C  0 O  U I  U I  U I  U I  U I  U I  o C  1 L  o C \
 1 L  0 0 0  1 L  0 0 0  1 L  0 0 0  U I  P 0  U I  0 0 o  0 0 1  0 O \
L  0 O L  0 O D  C L  D O  U I  1 P  U I  o I  L 1  L 1  L O  P o  0 0\
 0  0 0 0  0 O o  0 O D  0 O 0  L O  0 0 1  0 0 0  C C  0 O 0  0 0 D  \
0 0 D  0 0 0  0 0 1  U I  1 O  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0\
 O 0  o 1  C o  0 0 1  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  o \
C  o C  0 0 0  0 0 0  o C  o C  1 L  1 L  o C  1 L  o C  o C  1 L  1 L\
  0 0 0  0 0 0  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L \
 D O  U I  1 P  U I  C L  0 0 o  0 O D  0 O L  0 O O  C D  0 0 0  0 0 \
I  0 O 0  0 0 O  0 O 0  0 0 1  U I  1 O  U I  o C  1 L  o C  1 L  0 0 \
0  1 L  0 0 0  1 L  0 0 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  \
0 O D  C L  D O  U I  1 P  U I  o I  L 1  L 1  L O  P P  C o  0 0 D  0\
 O D  C C  P D  0 0 o  0 0 P  0 O 1  o I  C o  0 0 O  0 O O  0 O L  0 \
O 0  0 0 1  U I  1 O  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 \
O L  0 O D  C L  D O  U I  1 P  U I  o I  L 1  L 1  L O  o I  C o  0 0\
 O  0 O O  0 O L  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  1 0  0 O  U I\
  U I  U I  U I  U I  U I  o C  o C  0 0 0  0 0 0  o C  o C  1 L  1 L \
 o C  1 L  o C  o C  1 L  1 L  0 0 0  0 0 0  U I  P 0  U I  0 0 o  0 0\
 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  0 O D  0 0 O  0 0 D \
 0 0 P  C o  0 O L  0 O L  C D  0 0 0  0 0 I  0 O 0  0 0 O  0 O 0  0 0\
 1  U I  1 O  U I  o C  o C  0 0 0  0 0 0  o C  o C  1 L  1 L  o C  1 \
L  o C  o C  1 L  1 L  0 0 0  0 0 0  U I  1 0  0 O  U I  U I  U I  U I\
  U I  U I  0 O D  0 O I  U I  D o  U I  1 D  U I  D o  D L  U I  o U \
 0 O D  o U  o U  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0\
 0 0  U I  1 D  U I  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  0 O D  1 C\
  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 \
U  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  U I  U I  U\
 I  U I  U I  0 O D  0 O I  U I  D o  D D  U I  1 D  U I  D o  D D  D \
L  U I  o C  1 L  0 0 0  o C  0 O  U I  U I  U I  U I  U I  U I  0 O D\
  0 O I  U I  U C  0 0 O  0 0 0  0 0 1  0 O 0  0 O O  0 O D  0 0 1  0 \
O 0  C C  0 0 P  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 \
C  0 O D  o U  0 O D  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I\
  o C  o C  0 0 0  0 0 0  o C  o C  1 L  1 L  o C  1 L  o C  o C  1 L \
 1 L  0 0 0  0 0 0  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  \
C L  D O  U I  1 P  U I  C L  0 0 o  0 O D  0 O L  0 O O  C D  0 0 0  \
0 0 I  0 O 0  0 0 O  0 O 0  0 0 1  U I  1 O  U I  o C  1 L  o C  1 L  \
0 0 0  1 L  0 0 0  1 L  0 0 0  U I  1 1  U I  0 O D  1 C  0 O D  o U  \
o U  1 C  o U  0 O D  0 O D  o U  0 O D  o U  1 C  U I  1 1  U I  0 0 \
o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  o I  L 1  L 1 \
 L O  P P  C o  0 0 D  0 O D  C C  P D  0 0 o  0 0 P  0 O 1  o I  C o \
 0 0 O  0 O O  0 O L  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  1 1  U I \
 0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  o I  L 1 \
 L 1  L O  o I  C o  0 0 O  0 O O  0 O L  0 O 0  0 0 1  U I  1 O  U I \
 1 0  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  U I  o C  o C  0 0 \
0  0 0 0  o C  o C  1 L  1 L  o C  1 L  o C  o C  1 L  1 L  0 0 0  0 0\
 0  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1\
 P  U I  0 O D  0 0 O  0 0 D  0 0 P  C o  0 O L  0 O L  C D  0 0 0  0 \
0 I  0 O 0  0 0 O  0 O 0  0 0 1  U I  1 O  U I  o C  o C  0 0 0  0 0 0\
  o C  o C  1 L  1 L  o C  1 L  o C  o C  1 L  1 L  0 0 0  0 0 0  U I \
 1 0  0 O  U I  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  U\
 C  0 0 O  0 0 0  0 0 1  0 O 0  0 O O  0 O D  0 0 1  0 O 0  C C  0 0 P\
  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  \
0 O D  U I  D L  0 O  U I  U I  U I  U I  U I  U I  o C  o C  0 0 0  0\
 0 0  o C  o C  1 L  1 L  o C  1 L  o C  o C  1 L  1 L  0 0 0  0 0 0  \
U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  \
U I  C L  0 0 o  0 O D  0 O L  0 O O  C D  0 0 0  0 0 I  0 O 0  0 0 O \
 0 O 0  0 0 1  U I  1 O  U I  0 O D  1 C  0 O D  o U  o U  1 C  o U  0\
 O D  0 O D  o U  0 O D  o U  1 C  U I  1 1  U I  0 0 o  0 0 1  0 O L \
 0 O L  0 O D  C L  D O  U I  1 P  U I  o I  L 1  L 1  L O  P P  C o  \
0 0 D  0 O D  C C  P D  0 0 o  0 0 P  0 O 1  o I  C o  0 0 O  0 O O  0\
 O L  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0\
 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  o I  L 1  L 1  L O  o I  \
C o  0 0 O  0 O O  0 O L  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  1 0  \
0 O  U I  U I  U I  U I  U I  U I  o C  o C  0 0 0  0 0 0  o C  o C  1\
 L  1 L  o C  1 L  o C  o C  1 L  1 L  0 0 0  0 0 0  U I  P 0  U I  0 \
0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  0 O D  0 0 O\
  0 0 D  0 0 P  C o  0 O L  0 O L  C D  0 0 0  0 0 I  0 O 0  0 0 O  0 \
O 0  0 0 1  U I  1 O  U I  o C  o C  0 0 0  0 0 0  o C  o C  1 L  1 L \
 o C  1 L  o C  o C  1 L  1 L  0 0 0  0 0 0  U I  1 0  0 O  U I  U I  \
U I  U I  U I  U I  0 O D  0 O I  U I  D o  D O  U I  1 D  U I  D o  D\
 O  D L  U I  o U  0 O D  o U  o U  U I  U o  U I  0 0 0  o C  1 L  0 \
0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 I  U I  0 0 0  o C  1 L  0 0 \
0  U I  1 D  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L \
 U I  1 P  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  U I\
  U I  U I  U I  U I  0 O D  0 O I  U I  D o  D U  U I  1 D  U I  D o \
 D U  D L  U I  0 O D  1 C  U I  U o  U I  0 O D  o U  o U  1 C  1 C  \
1 C  0 O D  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  U C  C C \
 0 0 0  0 0 O  0 0 O  0 O 0  C C  0 0 P  0 O D  0 0 0  0 0 O  U C  U I\
  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I\
  D L  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D I  D O \
 U I  1 D  U I  D I  D O  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  \
0 0 0  U I  1 D  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  \
U I  1 o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 o  U I \
 0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O\
 D  0 O  U I  U I  U I  U I  U I  U I  0 O I  0 0 1  0 0 0  0 O C  U I\
  0 O o  0 O 0  0 O 0  0 0 I  C o  0 O L  0 O D  0 0 L  0 O 0  U I  0 \
O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  o I  L 1  L 1  L O  o I  \
C o  0 0 O  0 O O  0 O L  0 O 0  0 0 1  0 O  U I  U I  U I  U I  U I  \
U I  o C  1 L  o C  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  0 0 0  \
o C  0 0 0  U I  P 0  U I  o I  L 1  L 1  L O  o I  C o  0 0 O  0 O O \
 0 O L  0 O 0  0 0 1  U I  1 O  U I  1 0  0 O  U I  U I  U I  U I  U I\
  U I  o C  o C  0 0 0  0 0 0  o C  o C  1 L  1 L  o C  1 L  o C  o C \
 1 L  1 L  0 0 0  0 0 0  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 \
O D  C L  D O  U I  1 P  U I  C L  0 0 o  0 O D  0 O L  0 O O  C D  0 \
0 0  0 0 I  0 O 0  0 0 O  0 O 0  0 0 1  U I  1 O  U I  o C  1 L  o C  \
o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  0 0 0  o C  0 0 0  U I  1 0\
  0 O  U I  U I  U I  U I  U I  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D\
  C L  D O  U I  1 P  U I  0 O D  0 0 O  0 0 D  0 0 P  C o  0 O L  0 O\
 L  C D  0 0 0  0 0 I  0 O 0  0 0 O  0 O 0  0 0 1  U I  1 O  U I  o C \
 o C  0 0 0  0 0 0  o C  o C  1 L  1 L  o C  1 L  o C  o C  1 L  1 L  \
0 0 0  0 0 0  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O \
I  U I  D 1  D O  U I  1 D  U I  D 1  D O  D L  U I  0 0 0  0 0 0  o C\
  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  0 O D  o U  o U  1 C  1 C  1 \
C  0 O D  U I  1 D  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o \
C  1 L  U I  1 D  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 U\
  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 U  U \
I  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O\
 I  U I  D O  D 0  U I  1 D  U I  D O  D 0  D L  U I  0 O D  0 O D  o \
U  1 C  0 O D  o U  0 O D  o U  U I  1 U  U I  0 0 0  1 L  0 0 0  o C \
 1 L  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1\
 I  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 U  U I  0 0 0  \
o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  U I  U I  U I \
 U I  U I  0 O D  0 O I  U I  1 C  D P  U I  1 D  U I  1 C  D P  D L  \
U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 I  U I  0 0 0  \
1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 P  U I  0 0 0  0 0 0  0 0 0  \
1 L  o C  0 0 0  1 L  U I  1 o  U I  o U  o U  0 O D  o U  0 O D  o U \
 o U  1 C  1 C  0 O D  0 O  U I  U I  U I  U I  U I  0 O D  0 O D  o U\
  o U  o U  1 C  o U  o U  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 \
O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  1 L  1 L  U I  1 D\
  U I  1 C  1 L  1 L  D L  U I  o U  0 O D  o U  o U  U I  U o  U I  0\
 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D\
  U I  1 o  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  U I  U I \
 U I  0 O D  0 O I  U I  U C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  0 \
O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  D \
L  0 O  U I  U I  U I  U I  U I  U I  0 O D  o U  o U  o U  1 C  1 C  \
o U  0 O D  U I  P 0  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O \
D  U I  C 0  U I  U C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  C U  0 O \
 U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D U  D O  U I  1 D  \
U I  D U  D O  D L  U I  0 O D  1 C  U I  1 o  U I  o C  0 0 0  0 0 0 \
 0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U I  0 0 0  1 L  0 0 0  o C  1 L\
  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D I  D o  U I \
 1 D  U I  D I  D o  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0\
 0  U I  1 o  U I  o U  0 O D  o U  o U  U I  1 P  U I  0 0 0  0 0 0  \
o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  U I  U I  U I  U I  U I\
  0 O D  0 O I  U I  D O  1 C  U I  1 D  U I  D O  1 C  D L  U I  0 0 \
0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 0 0  0 0 0  o \
C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 U  U I  0 O D  o U  o U  1 C\
  1 C  1 C  0 O D  U I  1 I  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 \
0 0  U I  U o  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U \
I  U o  U I  o U  0 O D  1 C  o U  0 O  U I  U I  U I  U I  U I  U I  \
0 O D  0 O I  U I  D U  D U  U I  1 D  U I  D U  D U  D L  U I  o U  0\
 O D  o U  o U  U I  1 D  U I  o C  1 L  0 0 0  o C  0 O  U I  U I  U \
I  U I  U I  U I  o C  1 L  o C  o C  1 L  o C  o U  0 O D  0 O D  0 O\
 D  o U  0 O D  0 O D  o U  U I  P 0  U I  0 O D  o U  o U  o U  1 C  \
1 C  o U  0 O D  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I\
  1 O  U I  U C  1 1  U C  U I  1 0  U I  D C  0 O  U I  U I  U I  U I\
  U I  U I  0 O D  0 O D  o U  o U  o U  1 C  o U  o U  U I  P 0  U I \
 0 I U  U I  0 I D  0 O  U I  U I  U I  U I  U I  U I  0 O I  0 0 0  0\
 0 1  U I  0 0 0  1 L  1 L  o C  U I  0 O D  0 0 O  U I  o C  1 L  o C\
  o C  1 L  o C  o U  0 O D  0 O D  0 O D  o U  0 O D  0 O D  o U  U I\
  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  o U  1 C  0 O D \
 o U  1 C  o U  1 C  0 O D  1 C  o U  U I  P 0  U I  0 0 0  1 L  1 L  \
o C  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  \
U C  D L  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  U I  D C  0 O  \
U I  U I  U I  U I  U I  U I  U I  0 O D  o U  0 O D  1 C  1 C  o U  0\
 O D  1 C  U I  P 0  U I  0 0 0  1 L  1 L  o C  U I  1 P  U I  0 0 D  \
0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  D L  U C  U I  1 0  U \
I  C 0  U I  1 C  U I  C U  U I  D C  0 O  U I  U I  U I  U I  U I  U \
I  U I  0 O D  0 O D  o U  o U  o U  1 C  o U  o U  U I  C 0  U I  0 O\
 D  o U  1 C  0 O D  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  C U  U \
I  P 0  U I  0 O D  o U  0 O D  1 C  1 C  o U  0 O D  1 C  0 O  U I  U\
 I  U I  U I  U I  U I  0 O D  0 O D  o U  o U  o U  1 C  o U  o U  U \
I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 \
0 o  0 0 1  0 O L  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U\
 I  0 O D  0 O D  o U  o U  o U  1 C  o U  o U  U I  1 0  0 O  U I  U \
I  U I  U I  U I  U I  0 O D  0 O I  U I  D I  D P  U I  1 D  U I  D I\
  D P  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  \
1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I \
 U I  U I  U I  U I  0 O D  0 O I  U I  U C  0 0 1  C o  0 0 C  0 0 I \
 0 0 0  0 0 D  0 0 P  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o \
U  1 C  0 O D  o U  0 O D  U I  D L  0 O  U I  U I  U I  U I  U I  U I\
  0 O D  0 O D  o U  o U  o U  1 C  o U  o U  U I  P 0  U I  0 O D  1 \
C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 1  C o  0\
 0 C  0 0 I  0 0 0  0 0 D  0 0 P  U C  U I  C U  0 O  U I  U I  U I  U\
 I  U I  U I  0 O D  0 O I  U I  D U  U I  1 D  U I  D U  D L  U I  o \
U  o U  o U  o U  U I  1 P  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0\
 0 0  o C  1 L  U I  1 P  U I  o U  0 O D  1 C  o U  U I  1 P  U I  o \
C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  U I  U I  U I  U I  U\
 I  0 O D  0 O I  U I  D o  D 1  U I  1 D  U I  D o  D 1  D L  U I  0 \
0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 D  U I  o C  1\
 L  0 0 0  o C  U I  U o  U I  o U  o U  0 O D  o U  0 O D  o U  o U  \
1 C  1 C  0 O D  U I  1 o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0\
 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  1 L  1 L  U \
I  1 D  U I  1 C  1 L  1 L  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o\
 U  0 O D  o U  U I  1 o  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  \
o U  1 C  o U  0 O D  1 C  0 O D  U I  1 D  U I  o C  o C  0 0 0  0 0 \
0  o C  o C  0 0 0  U I  U o  U I  o U  0 O D  1 C  o U  U I  1 D  U I\
  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  U o  U I  0 0 0  0 0 0  \
o C  0 0 0  o C  1 L  0 0 0  0 O  U I  U I  U I  U I  U I  U I  0 O D \
 0 O I  U I  D 1  1 L  U I  1 D  U I  D 1  1 L  D L  U I  0 0 0  o C  \
1 L  0 0 0  U I  1 U  U I  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  U\
 I  U I  o C  1 L  0 0 0  U I  P 0  U I  U C  U C  0 O  U I  U I  U I \
 U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I\
  U I  0 O D  0 O I  U I  D P  D 1  U I  1 D  U I  D P  D 1  D L  U I \
 0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C \
 1 L  0 0 0  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1\
 L  1 L  U I  1 D  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 \
C  o U  0 O D  1 C  0 O D  0 O  U I  U I  U I  U I  U I  U I  0 O D  0\
 O I  U I  0 O D  0 O D  o U  o U  o U  1 C  o U  o U  U I  D L  0 O  \
U I  U I  U I  U I  U I  U I  U I  o U  1 C  o U  o U  1 C  1 C  o U  \
0 O D  o U  o U  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L\
  D O  U I  1 P  U I  0 0 o  0 0 1  0 O L  0 0 0  0 0 I  0 O 0  0 0 O \
 U I  1 O  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 1\
  U I  0 O D  0 O D  o U  o U  o U  1 C  o U  o U  U I  1 0  0 O  U I \
 U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U\
 I  U I  U I  U I  U I  U I  U I  o U  1 C  o U  o U  1 C  1 C  o U  0\
 O D  o U  o U  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L \
 D O  U I  1 P  U I  0 0 o  0 0 1  0 O L  0 0 0  0 0 I  0 O 0  0 0 O  \
U I  1 O  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 0 \
 0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  o U  1 C  o U  \
o U  1 C  1 C  o U  0 O D  o U  o U  U I  1 P  U I  0 O D  0 0 O  0 O \
I  0 0 0  U I  1 O  U I  1 0  U I  1 P  U I  0 O U  0 O 0  0 0 P  U I \
 1 O  U I  U C  P o  0 0 0  0 0 O  0 0 P  0 O 0  0 0 O  0 0 P  1 D  P \
C  0 0 O  C C  0 0 0  0 O O  0 O D  0 0 O  0 O U  U C  U I  1 0  U I  \
P 0  P 0  U I  U C  0 O U  0 I I  0 O D  0 0 I  U C  U I  D L  0 O  U \
I  U I  U I  U I  U I  U I  U I  0 O I  0 0 1  0 0 0  0 O C  U I  L U \
 0 0 P  0 0 1  0 O D  0 0 O  0 O U  o U  o C  U I  0 O D  0 O C  0 0 I\
  0 0 0  0 0 1  0 0 P  U I  L U  0 0 P  0 0 1  0 O D  0 0 O  0 O U  o \
U  o C  0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O C  0 0 I  0\
 0 0  0 0 1  0 0 P  U I  0 O U  0 I I  0 O D  0 0 I  0 O  U I  U I  U \
I  U I  U I  U I  U I  0 0 0  0 0 0  o C  1 L  1 L  1 L  o C  U I  P 0\
  U I  L U  0 0 P  0 0 1  0 O D  0 0 O  0 O U  o U  o C  U I  1 O  U I\
  o U  1 C  o U  o U  1 C  1 C  o U  0 O D  o U  o U  U I  1 P  U I  0\
 0 1  0 O 0  C o  0 O O  U I  1 O  U I  1 0  U I  1 0  0 O  U I  U I  \
U I  U I  U I  U I  U I  0 0 0  o C  U I  P 0  U I  0 O U  0 I I  0 O \
D  0 0 I  U I  1 P  U I  o 0  0 I I  0 O D  0 0 I  o O  0 O D  0 O L  \
0 O 0  U I  1 O  U I  0 O I  0 O D  0 O L  0 O 0  0 0 0  C L  0 O P  U\
 I  P 0  U I  0 0 0  0 0 0  o C  1 L  1 L  1 L  o C  U I  1 0  0 O  U \
I  U I  U I  U I  U I  U I  U I  o C  1 L  0 0 0  U I  P 0  U I  0 0 0\
  o C  U I  1 P  U I  0 0 1  0 O 0  C o  0 O O  U I  1 O  U I  1 0  0 \
O  U I  U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L \
 0 O  U I  U I  U I  U I  U I  U I  U I  o C  1 L  0 0 0  U I  P 0  U \
I  o U  1 C  o U  o U  1 C  1 C  o U  0 O D  o U  o U  U I  1 P  U I  \
0 0 1  0 O 0  C o  0 O O  U I  1 O  U I  1 0  0 O  U I  U I  U I  U I \
 U I  U I  U I  0 O D  0 O I  U I  D O  D 0  U I  1 D  U I  D O  D 0  \
D L  U I  o U  0 O D  o U  o U  U I  U o  U I  0 0 0  1 L  0 0 0  o C \
 1 L  U I  1 D  U I  o C  1 L  0 0 0  o C  U I  U o  U I  0 0 0  o C  \
1 L  0 0 0  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  \
0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D O  D I  U\
 I  1 D  U I  D O  D I  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0\
  1 L  U I  1 o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 \
U  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1\
 C  0 O D  U I  U o  U I  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  o C  \
1 L  0 0 0  o C  U I  1 P  U I  o C  1 L  0 0 0  o C  0 O  U I  U I  U\
 I  U I  U I  U I  U I  0 O D  0 O I  U I  D 0  D O  U I  1 D  U I  D \
0  D O  D L  U I  o C  1 L  0 0 0  o C  U I  1 P  U I  0 0 0  0 0 0  0\
 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  o U  1 C  o U  0 O D  1 C  \
1 C  1 C  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  U C  0\
 0 I  0 0 1  0 0 0  0 I O  0 I 0  U C  U I  0 O D  0 0 O  U I  0 O D  \
1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C o  0 0 O  0 O O  U I  0 \
0 O  0 0 0  0 0 P  U I  o C  o C  o C  U I  0 O D  0 0 D  U I  o L  0 \
0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0\
 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  0 O D  0 0 \
O  0 0 D  0 0 P  C o  0 O L  0 O L  C D  0 0 0  0 0 I  0 O 0  0 0 O  0\
 O 0  0 0 1  U I  1 O  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D \
O  U I  1 P  U I  C L  0 0 o  0 O D  0 O L  0 O O  C D  0 0 0  0 0 I  \
0 O 0  0 0 O  0 O 0  0 0 1  U I  1 O  U I  o C  o C  o C  U I  1 0  U \
I  1 0  0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D 0\
  D D  U I  1 D  U I  D 0  D D  D L  U I  0 O D  1 C  1 C  o U  0 O D \
 1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  U o  U I  o U  1 C  \
o U  0 O D  1 C  1 C  1 C  0 O  U I  U I  U I  U I  U I  U I  o C  1 L\
  0 0 0  U I  P 0  U I  0 0 0  o C  0 0 0  0 0 0  o C  1 L  o C  1 L  \
o C  1 L  0 0 0  0 0 0  o C  o C  o C  U I  1 O  U I  o C  1 L  0 0 0 \
 U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D D  \
1 L  U I  1 D  U I  D D  1 L  D L  U I  o C  0 0 0  0 0 0  0 0 0  1 L \
 1 L  1 L  1 L  U I  1 P  U I  o U  o U  0 O D  o U  0 O D  o U  o U  \
1 C  1 C  0 O D  U I  1 P  U I  0 O D  1 C  U I  1 P  U I  o U  o U  0\
 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 U  U I  o U  1 C  \
1 C  0 O D  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D o \
 U I  1 D  U I  D o  D L  U I  o U  0 O D  o U  o U  0 O  U I  U I  U \
I  U I  U I  U I  0 O D  0 O I  U I  U C  0 O D  0 0 O  C C  0 O L  0 \
0 o  0 O O  0 O 0  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  0 0 D  U C \
 U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D \
 U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  \
D o  D o  U I  1 D  U I  D o  D o  D L  U I  0 0 0  1 L  0 0 0  o C  1\
 L  U I  1 D  U I  0 O D  1 C  U I  1 D  U I  o U  o U  o U  o U  U I \
 U o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  U I  U I  U I  U \
I  U I  U I  U I  o C  1 L  0 0 0  U I  1 U  P 0  U I  U C  U P  U P  \
o I  P C  P D  P L  P C  L I  L U  C D  L U  L 1  P D  L I  L 1  U P  \
U P  D L  U C  0 O  U I  U I  U I  U I  U I  U I  U I  0 O I  0 0 0  0\
 0 1  U I  o C  0 0 0  o C  U I  0 O D  0 0 O  U I  o U  1 C  o U  o U\
  1 C  1 C  o U  0 O D  o U  o U  U I  1 P  U I  0 O 1  0 O 0  C o  0 \
O O  0 O 0  0 0 1  0 0 D  U I  D L  0 O  U I  U I  U I  U I  U I  U I \
 U I  U I  o C  1 L  0 0 0  U I  1 U  P 0  U I  o C  0 0 0  o C  U I  \
1 U  U I  U C  D L  U C  U I  1 U  U I  o U  1 C  o U  o U  1 C  1 C  \
o U  0 O D  o U  o U  U I  1 P  U I  0 O 1  0 O 0  C o  0 O O  0 O 0  \
0 0 1  0 0 D  U I  1 P  U I  0 O U  0 O 0  0 0 P  U I  1 O  U I  o C  \
0 0 0  o C  U I  1 0  U I  1 U  U I  U C  C I  0 0 O  U C  0 O  U I  U\
 I  U I  U I  U I  U I  U I  o C  1 L  0 0 0  U I  1 U  P 0  U I  U C \
 U P  U P  o I  P C  P D  P L  P C  L I  L U  C D  P C  o L  P L  U P \
 U P  D L  U C  0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O I  \
U I  D O  1 C  U I  1 D  U I  D O  1 C  D L  U I  o U  0 O D  1 C  o U\
  U I  U o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  \
U I  1 P  U I  o U  1 C  1 C  0 O D  U I  1 D  U I  o C  o C  0 0 0  0\
 0 0  o C  o C  0 0 0  0 O  U I  U I  U I  U I  U I  U I  o U  o U  o \
U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  o C  1 L  0\
 0 0  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  o U  o U  o U  1 C \
 0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  C C  0 0 0  0 0 0 \
 0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 0  0 O  U I  U I  U I  U\
 I  U I  U I  0 O D  0 O I  U I  D I  U I  1 D  U I  D I  D L  U I  o \
C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 P  U I  o C  0 0 0  0 0 \
0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  U I  U I  U I  U I  U I  o U  \
1 C  o U  o U  1 C  1 C  o U  0 O D  o U  o U  U I  1 P  U I  C C  0 O\
 L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  U I  U I  U I  \
U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  \
U I  U I  U I  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  U I  U I  U I \
 U I  C C  C o  C C  0 O 1  0 O 0  0 O O  L O  C o  0 O U  0 O 0  0 0 \
D  U I  C 0  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C\
 0  U I  U C  0 0 I  C o  0 O U  0 O 0  U C  U I  C U  U I  C U  U I  \
P 0  U I  o C  1 L  0 0 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I \
 U I  D D  D P  U I  1 D  U I  D D  D P  D L  U I  0 0 0  o C  1 L  0 \
0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  0 0 0  1 L  0 0 0  o \
C  1 L  U I  1 D  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C\
  0 O D  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  1 L  U \
I  1 D  U I  1 C  1 L  D L  U I  0 O D  1 C  U I  U o  U I  0 O D  o U\
  o U  1 C  1 C  1 C  0 O D  0 O  U I  U I  U I  U I  U I  0 O D  0 O \
I  U I  D o  D D  U I  1 D  U I  D o  D D  D L  U I  o C  o C  0 0 0  \
0 0 0  o C  o C  0 0 0  U I  1 D  U I  0 O D  1 C  0 O  U I  U I  U I \
 U I  U I  0 O D  0 O I  U I  0 O I  0 0 0  0 0 1  P o  0 0 0  0 0 0  \
0 O o  0 O D  0 O 0  o 1  C o  0 0 1  o C  0 0 O  0 O L  0 I 0  U I  D\
 L  0 O  U I  U I  U I  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0\
 1  0 0 O  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 \
1  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  0 O D  1 \
C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0\
 O U  0 O 0  U C  U I  C U  U I  C o  0 0 O  0 O O  U I  0 0 O  0 0 0 \
 0 0 P  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U\
 I  U C  0 0 I  C o  0 O U  0 O 0  U C  U I  C U  U I  1 P  U I  0 0 D\
  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 \
O  U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  U C  U I  1 0  U I  D L  0 O \
 U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 O D  1 C  1 C  o U  1 C\
  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O U  0 O 0  U C\
  U I  C U  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0\
 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  U P  0 0 I  0 I 0  o O  0\
 0 o  0 0 O  C C  0 0 P  0 O D  0 0 0  0 0 O  D L  U C  U I  1 0  U I \
 D L  0 O  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1\
 L  1 L  U I  P 0  U I  0 O D  1 C  1 C  o U  U I  1 O  U I  0 O D  1 \
C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0\
 O U  0 O 0  U C  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D \
 0 0 P  U I  1 O  U I  U C  U P  0 0 I  0 I 0  o O  0 0 o  0 0 O  C C \
 0 0 P  0 O D  0 0 0  0 0 O  D L  U C  U I  1 0  U I  C 0  U I  1 C  U\
 I  C U  U I  1 1  U I  U C  U C  U I  1 1  U I  C C  0 0 0  0 0 0  0 \
O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 1  U I  0 O D  1 C  1 C  o \
U  1 C  0 O D  o U  0 O D  U I  1 0  0 O  U I  U I  U I  U I  U I  U I\
  0 O D  0 O I  U I  0 O I  0 0 0  0 0 1  P o  0 0 0  0 0 0  0 O o  0 \
O D  0 O 0  o 1  C o  0 0 1  o C  0 0 O  0 O L  0 I 0  U I  D L  0 O  \
U I  U I  U I  U I  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  \
0 0 O  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  0\
 O  U I  U I  U I  U I  U I  U I  o C  1 L  0 0 0  U I  P 0  U I  0 0 \
0  0 0 0  0 0 0  0 0 0  1 L  1 L  0 O  U I  U I  U I  U I  U I  U I  o\
 C  1 L  0 0 0  U I  P 0  U I  0 0 0  o C  0 0 0  0 0 0  o C  1 L  o C\
  1 L  o C  1 L  0 0 0  0 0 0  o C  o C  o C  U I  1 O  U I  o C  1 L \
 0 0 0  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0\
 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  o C  1 L  0 0 0  U \
I  P 0  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U\
 I  U C  0 0 I  C o  0 O U  0 O 0  U C  U I  C U  0 O  U I  U I  U I  \
0 O D  0 O I  U I  U C  U P  0 0 I  0 I 0  o O  0 0 o  0 0 O  C C  0 0\
 P  0 O D  0 0 0  0 0 O  D L  0 0 I  0 O L  C o  0 I 0  0 O C  0 O 0  \
0 O O  0 O D  C o  1 O  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  \
o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 O 0  0 I O  0 0 I  \
0 0 1  0 O 0  0 0 D  U C  U I  C U  U I  0 0 0  0 0 1  U I  U C  P D  \
C C  0 0 P  0 O D  0 0 L  C o  0 0 P  0 O 0  L o  0 O D  0 0 O  0 O O \
 0 0 0  0 0 C  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C \
 0 O D  o U  0 O D  U I  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 \
O 0  0 0 D  U C  U I  C U  U I  0 0 0  0 0 1  U I  U C  L I  0 0 o  0 \
0 O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  U C  U I  0 O D  0 0 O  U\
 I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  \
0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U I  C U  U I  0 0 0  0\
 0 1  U I  U C  U P  L O  o P  P D  L C  P C  L I  L O  L I  o C  L L \
 L C  U P  P 0  U C  U I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I \
 0 0 0  0 0 1  U I  C o  0 0 O  0 I 0  U I  1 O  U I  0 I O  U I  0 O \
D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  0 O I  0 0 0  0 0 1  U I  0 I\
 O  U I  0 O D  0 0 O  U I  0 O D  o U  o U  0 O D  0 O D  1 C  o U  o\
 U  0 O D  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  o C  o C  1 L \
 1 L  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  0 O  U I  U I  U I\
  0 O D  0 O I  U I  U C  U P  0 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O \
0  0 I O  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O \
D  o U  0 O D  U I  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  \
0 0 D  U C  U I  C U  U I  D L  0 O  U I  U I  U I  U I  0 O D  1 C  1\
 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 O 0  0 I O  0 0\
 I  0 0 1  0 O 0  0 0 D  U C  U I  C U  U I  P 0  U I  0 0 0  o C  o C\
  0 0 0  0 0 0  U I  1 O  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 \
D  U I  1 1  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C\
 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U I  C U \
 U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 \
1  U I  1 1  U I  0 0 1  0 O 0  C C  0 0 o  0 0 1  0 0 D  0 O D  0 0 L\
  0 O 0  P o  C o  0 O L  0 O L  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O\
 0  U I  1 1  U I  C C  C o  C C  0 O 1  0 O 0  0 O O  L O  C o  0 O U\
  0 O 0  0 0 D  U I  P 0  U I  C C  C o  C C  0 O 1  0 O 0  0 O O  L O\
  C o  0 O U  0 O 0  0 0 D  U I  1 0  0 O  U I  U I  U I  U I  0 O D  \
0 O I  U I  D o  D 1  U I  1 D  U I  D o  D 1  D L  U I  0 0 0  o C  1\
 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  U o  U I  o C  0 0 0  0 0\
 0  0 0 0  1 L  1 L  1 L  1 L  U I  U o  U I  0 O D  1 C  1 C  o U  0 \
O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 D  U I  o C  0\
 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  U o  U I  0 0 0  0 0 0  o\
 C  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  1 L\
  0 0 0  0 0 0  o C  1 L  0 O  U I  U I  U I  0 O D  0 O I  U I  0 0 O\
  0 0 0  0 0 P  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I\
  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U I  C\
 U  U I  P 0  P 0  U I  U C  U C  U I  D L  0 O  U I  U I  U I  U I  0\
 O D  0 O I  U I  D 0  U I  1 D  U I  D 0  D L  U I  o U  o U  0 O D  \
o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  U I  0 O D \
 0 O I  U I  U C  U P  o P  0 O D  0 0 L  0 O 0  L U  0 0 P  0 0 1  0 \
O 0  C o  0 O C  P o  C o  0 0 I  0 0 P  C C  0 O 1  C o  U C  U I  0 \
O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C \
0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U I  C U  \
U I  D L  0 O  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 \
L  1 L  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 0 0 \
 0 0 0  1 L  U I  1 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O\
 D  U I  1 1  U I  o C  1 L  0 0 0  U I  1 1  U I  C C  0 0 0  0 0 0  \
0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 0  0 O  U I  U I  U I  U \
I  U I  0 O D  0 O I  U I  D P  D 0  U I  1 D  U I  D P  D 0  D L  U I\
  0 O D  1 C  0 O  U I  U I  U I  U I  U I  0 0 o  0 0 1  0 O L  U I  \
P 0  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O\
 L  C o  C C  0 O 0  U I  1 O  U I  U 1  U P  0 O O  0 0 0  0 0 1  0 O\
 0  0 O U  0 O 0  0 I O  C 0  U 1  U I  1 U  U I  o U  o U  0 O D  0 O\
 D  o U  o U  0 O D  1 C  U I  1 U  U I  U 1  C U  U 1  U I  1 1  U I \
 0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  1 0  0 O  U I  U I  U I  U\
 I  U I  0 O D  0 O I  U I  D I  D P  U I  1 D  U I  D I  D P  D L  U \
I  o U  0 O D  1 C  o U  U I  1 I  U I  o C  1 L  0 0 0  o C  U I  1 I\
  U I  0 O D  1 C  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I\
  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U \
C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U I  C U  U I  1 P  \
U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O \
1  U I  1 O  U I  U C  U P  0 0 I  0 I 0  o O  0 0 o  0 0 O  C C  0 0 \
P  0 O D  0 0 0  0 0 O  D L  U C  U I  1 0  U I  0 0 0  0 0 1  U I  U \
C  U D  U P  0 0 I  0 I 0  o O  0 0 o  0 0 O  C C  0 0 P  0 O D  0 0 0\
  0 0 O  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D\
  o U  0 O D  U I  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0\
 0 D  U C  U I  C U  U I  D L  0 O  U I  U I  U I  U I  U I  0 O D  0 \
O I  U I  D U  1 L  U I  1 D  U I  D U  1 L  D L  U I  0 0 0  0 0 0  0\
 0 0  1 L  o C  0 0 0  1 L  U I  U o  U I  o U  1 C  1 C  0 O D  0 O  \
U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P \
0  U I  U C  U C  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 O\
 D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 O 0  \
0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U I  C U  U I  1 P  U I  0 0 D\
  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 \
O  U I  U C  U P  0 0 I  0 I 0  o O  0 0 o  0 0 O  C C  0 0 P  0 O D  \
0 0 0  0 0 O  D L  U C  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U\
 I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  0 O D  1\
 C  1 C  o U  U I  1 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 \
O D  U I  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C\
  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O\
  U I  U C  U P  0 0 I  0 I 0  o O  0 0 o  0 0 O  C C  0 0 P  0 O D  0\
 0 0  0 0 O  D L  U C  U I  1 0  U I  C 0  U I  1 C  U I  C U  U I  1 \
1  U I  o C  1 L  0 0 0  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O \
D  0 O 0  o 1  C o  0 0 1  U I  1 1  U I  0 O D  1 C  1 C  o U  1 C  0\
 O D  o U  0 O D  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O 0  0 O L\
  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 0  0 \
0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  0 O D  0 O D  0 O D  1 C  \
1 C  o U  o U  1 C  o U  U I  1 O  U I  0 O D  1 C  1 C  o U  1 C  0 O\
 D  o U  0 O D  U I  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0 \
 0 0 D  U C  U I  C U  U I  1 1  U I  o C  1 L  0 0 0  U I  1 1  U I  \
C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 1  U I\
  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  1 0  0 O  U I  U \
I  U I  U I  U I  0 O D  0 O I  U I  U C  P D  C C  0 0 P  0 O D  0 0 \
L  C o  0 0 P  0 O 0  L o  0 O D  0 0 O  0 O O  0 0 0  0 0 C  U C  U I\
  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I\
  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U I  C\
 U  U I  0 0 0  0 0 1  U I  U C  L I  0 0 o  0 0 O  L O  0 O L  0 0 o \
 0 O U  0 O D  0 0 O  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o \
U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 \
0 1  0 O 0  0 0 D  U C  U I  C U  U I  D L  U I  0 0 1  0 O 0  0 0 P  \
0 0 o  0 0 1  0 0 O  U I  U C  U C  U I  1 1  U I  o O  C o  0 O L  0 \
0 D  0 O 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 O I  0 \
0 0  0 0 1  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  o\
 C  0 0 O  0 O L  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  \
0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  C C  0 0 0  0 0 0  0 O \
o  0 O D  0 O 0  o 1  C o  0 0 1  0 O  U I  U I  U I  U I  U I  0 O D \
 0 O I  U I  U C  0 O L  0 O D  0 0 D  0 0 P  0 0 1  0 O 0  0 0 I  0 O\
 0  C o  0 0 P  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1 C\
  0 O D  o U  0 O D  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O \
D  o U  1 C  1 C  1 C  o U  1 C  1 C  0 O D  U I  P 0  U I  0 O D  1 C\
  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 O L  0 O D  \
0 0 D  0 0 P  0 0 1  0 O 0  0 0 I  0 O 0  C o  0 0 P  U C  U I  C U  0\
 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D O  D 0  U I  1 \
D  U I  D O  D 0  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U\
  1 C  o U  0 O D  1 C  0 O D  U I  1 P  U I  0 0 0  1 L  1 L  o C  1 \
L  0 0 0  0 0 0  U I  1 U  U I  o U  0 O D  o U  o U  U I  1 D  U I  o\
 C  1 L  0 0 0  o C  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  \
U I  1 C  D P  U I  1 D  U I  1 C  D P  D L  U I  0 0 0  0 0 0  o C  0\
 0 0  o C  1 L  0 0 0  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1\
 L  o C  1 L  1 L  U I  U o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  \
0 0 0  o C  1 L  U I  1 o  U I  o U  o U  o U  o U  U I  1 o  U I  0 0\
 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 o  U I  o U  1 C  1 C  0 \
O D  0 O  U I  U I  U I  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 \
0 1  0 0 O  U I  0 O D  o U  1 C  1 C  1 C  o U  1 C  1 C  0 O D  U I \
 1 1  U I  0 O 0  0 0 L  C o  0 O L  U I  1 O  U I  0 0 0  0 0 0  0 0 \
0  0 0 0  1 L  1 L  U I  1 0  U I  1 1  U I  0 O D  1 C  1 C  o U  1 C\
  0 O D  o U  0 O D  U I  1 1  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O \
 0 0 D  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C \
o  0 0 1  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D I  D\
 P  U I  1 D  U I  D I  D P  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  \
1 L  0 0 0  U I  1 U  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I \
 0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 U  U I  o U  0 O D \
 1 C  o U  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  \
D P  U I  1 D  U I  1 C  D P  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0\
 0 0  0 0 0  o C  1 L  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I\
  U I  D O  D 0  U I  1 D  U I  D O  D 0  D L  U I  o U  0 O D  1 C  o\
 U  0 O  U I  U I  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  \
U I  U I  U I  U I  U I  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  0 0 \
o  0 0 1  0 O L  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  \
0 O 0  U I  1 O  U I  0 0 o  U 1  U P  0 O O  0 0 0  0 0 1  0 O 0  0 O\
 U  0 O 0  0 I O  C 0  U 1  U I  1 U  U I  o U  o U  0 O D  0 O D  o U\
  o U  0 O D  1 C  U I  1 U  U I  U 1  C U  U 1  U I  1 1  U I  0 0 0 \
 0 0 0  0 0 0  0 0 0  1 L  1 L  U I  1 0  0 O  U I  U I  U I  U I  U I\
  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 o  0 0 1 \
 0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 1  0 O \
0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U 1  U P  0 O O  0 0 \
0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  C 0  U 1  U I  1 U  U I  o U  o \
U  0 O D  0 O D  o U  o U  0 O D  1 C  U I  1 U  U I  U 1  C U  U 1  U\
 I  1 1  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  1 P  U I  0 O\
 O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U 1  0 0 o  0 0 P \
 0 O I  1 D  D P  U 1  U I  1 0  U I  1 0  0 O  U I  U I  U I  U I  0 \
O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 O \
D  0 O I  U I  U C  0 O L  0 O D  0 0 D  0 0 P  0 0 1  0 O 0  0 0 I  0\
 O 0  C o  0 0 P  U C  U I  0 O D  0 0 O  U I  0 O D  1 C  1 C  o U  1\
 C  0 O D  o U  0 O D  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 \
O D  o U  1 C  1 C  1 C  o U  1 C  1 C  0 O D  U I  P 0  U I  0 O D  1\
 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 O L  0 O D\
  0 0 D  0 0 P  0 0 1  0 O 0  0 0 I  0 O 0  C o  0 0 P  U C  U I  C U \
 0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D O  D I  U I  \
1 D  U I  D O  D I  D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0\
 0 0  o C  1 L  0 0 0  U I  1 I  U I  0 O D  0 O D  o U  1 C  0 O D  o\
 U  0 O D  o U  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  \
1 C  D P  U I  1 D  U I  1 C  D P  D L  U I  0 O D  0 O D  o U  1 C  0\
 O D  o U  0 O D  o U  U I  1 I  U I  0 0 0  1 L  0 0 0  o C  1 L  U I\
  1 D  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O \
D  1 C  0 O D  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D\
 0  1 C  U I  1 D  U I  D 0  1 C  D L  U I  o U  0 O D  o U  o U  U I \
 1 D  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I\
  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  U o  U I  \
o U  o U  o U  o U  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U\
 I  D I  D U  U I  1 D  U I  D I  D U  D L  U I  0 0 0  o C  1 L  0 0 \
0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  o U  0 O D  1 C  o U  U\
 I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  \
U I  U I  U I  U I  U I  U I  o U  0 O D  o U  o U  0 O D  1 C  o U  1\
 C  o U  1 C  1 C  o U  0 O D  U I  P 0  U I  0 0 1  0 O 0  U I  1 P  \
U I  0 O I  0 O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 O  U I  0 O\
 D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 O 0  \
0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U I  C U  U I  1 1  U I  o C  \
1 L  0 0 0  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I \
 U I  D 1  D I  U I  1 D  U I  D 1  D I  D L  U I  o C  o C  0 0 0  0 \
0 0  o C  o C  0 0 0  0 O  U I  U I  U I  U I  U I  U I  0 0 1  0 O 0 \
 0 0 P  0 0 o  0 0 1  0 0 O  U I  0 O D  o U  1 C  1 C  1 C  o U  1 C \
 1 C  0 O D  U I  1 1  U I  o U  0 O D  o U  o U  0 O D  1 C  o U  1 C\
  o U  1 C  1 C  o U  0 O D  U I  1 1  U I  0 O D  1 C  1 C  o U  1 C \
 0 O D  o U  0 O D  U I  1 1  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  \
0 0 D  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o\
  0 0 1  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D P  1 \
C  U I  1 D  U I  D P  1 C  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0\
 0  0 0 0  o C  1 L  U I  1 D  U I  o U  o U  0 O D  o U  0 O D  o U  \
o U  1 C  1 C  0 O D  U I  1 I  U I  o C  o C  0 0 0  0 0 0  o C  o C \
 0 0 0  0 O  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L \
 1 L  U I  P 0  U I  U C  U C  0 O  U I  U I  U I  U I  U I  0 O D  0 \
O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  1 L  0 0 0  U I  P 0  P 0  U \
I  U C  U C  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I\
  U I  D O  D 0  U I  1 D  U I  D O  D 0  D L  U I  o U  0 O D  1 C  o\
 U  U I  1 o  U I  o U  o U  o U  o U  0 O  U I  U I  U I  U I  U I  U\
 I  0 O D  o U  o U  1 C  o U  0 O D  0 O D  1 C  o U  1 C  1 C  0 O D\
  U I  P 0  U I  0 0 1  0 O 0  U I  1 P  U I  C C  0 0 0  0 O C  0 0 I\
  0 O D  0 O L  0 O 0  U I  1 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D\
  o U  0 O D  U I  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0\
 0 D  U C  U I  C U  U I  1 0  U I  1 P  U I  0 0 D  0 O 0  C o  0 0 1\
  C C  0 O 1  U I  1 O  U I  o C  1 L  0 0 0  U I  1 0  0 O  U I  U I \
 U I  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I\
  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  \
U I  0 O D  o U  o U  1 C  o U  0 O D  0 O D  1 C  o U  1 C  1 C  0 O \
D  U I  1 P  U I  0 O U  0 0 1  0 0 0  0 0 o  0 0 I  U I  1 O  U I  1 \
C  U I  1 0  U I  1 P  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 I  U I  1 \
O  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 O 0  0 I O  C C  0 O\
 0  0 0 I  0 0 P  U I  D L  U I  0 0 P  0 0 1  C o  C C  0 O 0  C L  C\
 o  C C  0 O o  U I  1 P  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  C D \
 0 O 0  0 I O  C C  U I  1 O  U I  1 0  0 O  U I  U I  U I  U I  U I  \
0 O 0  0 O L  0 O D  0 O I  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U\
  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O U  0 O 0  U C  U I  C U  \
U I  P 0  P 0  U I  U C  U C  U I  0 0 0  0 0 1  U I  0 O D  1 C  1 C \
 o U  1 C  0 O D  o U  0 O D  U I  C 0  U I  U C  0 0 I  C o  0 O U  0\
 O 0  U C  U I  C U  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I\
  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  \
1 L  1 L  U I  P 0  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D \
 U I  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0 D  U C  U \
I  C U  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  D D\
  U I  1 D  U I  1 C  D D  D L  U I  o U  o U  0 O D  o U  0 O D  o U \
 o U  1 C  1 C  0 O D  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I\
  0 0 1  C o  0 0 C  L O  0 0 0  0 0 D  0 0 P  U I  D L  0 O  U I  U I\
  U I  U I  U I  U I  0 O D  0 O I  U I  D P  D P  U I  1 D  U I  D P \
 D P  D L  U I  o U  0 O D  o U  o U  U I  1 P  U I  o U  o U  0 O D  \
o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  U o  U I  o C  o C  0 0 0 \
 0 0 0  o C  o C  0 0 0  U I  1 o  U I  o C  1 L  0 0 0  o C  0 O  U I\
  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  \
P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U\
  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 \
O  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  1 0  0 O  U I  U I \
 U I  U I  U I  0 O D  0 O I  U I  U C  0 O 1  0 0 P  0 O C  0 O L  0 \
0 o  0 0 O  0 O 0  0 0 D  C C  C o  0 0 I  0 O 0  U C  U I  0 O D  0 0\
 O  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  D L  0 O  \
U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D P  D o  U I  1 D  U\
 I  D P  D o  D L  U I  o U  0 O D  1 C  o U  U I  1 o  U I  o U  o U \
 o U  o U  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O C  0 0 I  0 0\
 0  0 0 1  0 0 P  U I  o I  L 1  o o  o P  L O  C o  0 0 1  0 0 D  0 O\
 0  0 0 1  0 O  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0\
 0  1 L  1 L  U I  P 0  U I  o I  L 1  o o  o P  L O  C o  0 0 1  0 0 \
D  0 O 0  0 0 1  U I  1 P  U I  o I  L 1  o o  o P  L O  C o  0 0 1  0\
 0 D  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  1 P  U I  0 0 o  0 0 O  0\
 O 0  0 0 D  C C  C o  0 0 I  0 O 0  U I  1 O  U I  0 0 0  0 0 0  0 0 \
0  0 0 0  1 L  1 L  U I  1 0  0 O  U I  U I  U I  U I  U I  0 0 P  0 0\
 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 o  0 0 1  \
0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 1  0 O 0\
  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U 1  U P  0 O O  0 0 0\
  0 0 1  0 O 0  0 O U  0 O 0  0 I O  C 0  U 1  U I  1 U  U I  o U  o U\
  0 O D  0 O D  o U  o U  0 O D  1 C  U I  1 U  U I  U 1  C U  U 1  U \
I  1 1  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  1 0  0 O  U I \
 U I  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L \
 U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O L  U I  1 \
P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U \
1  U P  0 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  C 0  U 1  U I\
  1 U  U I  o U  o U  0 O D  0 O D  o U  o U  0 O D  1 C  U I  1 U  U \
I  U 1  C U  U 1  U I  1 1  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L \
 U I  1 P  U I  0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I \
 U 1  0 0 o  0 0 P  0 O I  1 D  D P  U 1  U I  1 0  U I  1 0  0 O  U I\
  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  D I  U I  1 D  U I  1 C \
 D I  D L  U I  o C  1 L  0 0 0  o C  U I  1 P  U I  0 O D  o U  o U  \
1 C  1 C  1 C  0 O D  U I  1 I  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 \
L  1 L  1 L  U I  1 U  U I  o U  0 O D  1 C  o U  U I  1 D  U I  o C  \
0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 U  U I  o C  1 L  0 0 \
0  o C  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  D P  U I\
  1 D  U I  1 C  D P  D L  U I  o U  o U  o U  o U  U I  1 D  U I  0 0\
 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 D  U I  0 O D  o U  o U  \
1 C  1 C  1 C  0 O D  U I  1 D  U I  0 O D  o U  o U  1 C  1 C  1 C  0\
 O D  0 O  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U\
 I  U I  U I  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  0 0 o  0 0 1  0\
 O L  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I \
 1 O  U I  U 1  U P  0 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  \
C 0  U 1  U I  1 U  U I  o U  o U  0 O D  0 O D  o U  o U  0 O D  1 C \
 U I  1 U  U I  U 1  C U  U 1  U I  1 1  U I  U C  U C  U I  1 0  0 O \
 U I  0 O D  0 O I  U I  U C  U P  0 O 0  0 0 I  0 0 0  C C  0 0 P  0 \
O D  0 O C  0 O 0  U P  U C  U I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O\
 L  U I  D L  0 O  U I  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  0 0 o\
  0 0 1  0 O L  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0\
 O 0  U I  1 O  U I  U C  U P  0 O 0  0 0 I  0 0 0  C C  0 0 P  0 O D \
 0 O C  0 O 0  U P  U C  U I  1 1  U I  o C  0 0 0  o C  0 0 0  0 0 0 \
 1 L  0 0 0  o C  U I  1 O  U I  1 0  U I  1 0  0 O  U I  0 O D  0 O I\
  U I  U C  U P  0 O 0  0 0 I  0 0 0  C C  0 0 P  0 O D  0 O C  0 O 0 \
 D O  U P  U C  U I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  D L \
 0 O  U I  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O \
L  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 \
O  U I  U C  U P  0 O 0  0 0 I  0 0 0  C C  0 0 P  0 O D  0 O C  0 O 0\
  D O  U P  U C  U I  1 1  U I  o U  1 C  0 O D  U I  1 O  U I  1 0  U\
 I  1 0  0 O  U I  U I  0 O D  0 O I  U I  D U  D I  U I  1 D  U I  D \
U  D I  D L  U I  o U  0 O D  o U  o U  U I  1 U  U I  0 O D  o U  o U\
  1 C  1 C  1 C  0 O D  U I  1 o  U I  0 O D  0 O D  o U  1 C  0 O D  \
o U  0 O D  o U  U I  1 P  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D \
 U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I  0\
 O D  0 O I  U I  U C  U P  o 0  L D  o U  P L  U P  U C  U I  0 O D  \
0 0 O  U I  0 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  0 O D  0 O C\
  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 0 o  0 0 o  0 O D  0 O O  0 O  U \
I  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O L  U I  \
1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  \
U C  U P  o 0  L D  o U  P L  U P  U C  U I  1 1  U I  0 0 D  0 0 P  0\
 0 1  U I  1 O  U I  0 0 o  0 0 o  0 O D  0 O O  U I  1 P  U I  0 0 o \
 0 0 o  0 O D  0 O O  1 C  U I  1 O  U I  1 0  U I  1 0  U I  1 P  U I\
  0 0 o  0 0 I  0 0 I  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  1 0  0 O\
  U I  0 O D  0 O I  U I  U C  U P  0 O U  0 O 0  0 0 P  C D  C C  0 0\
 0  0 0 0  0 O o  0 O D  0 O 0  0 0 D  U P  U C  U I  0 O D  0 0 O  U \
I  0 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  0 0 o  0 0 1  0 O L  \
U I  P 0  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 1  0 O 0  0 0 I\
  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  U P  0 O U  0 O 0  0 0 P\
  C D  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 0 D  U P  U C  U I  1\
 1  U I  o U  o U  0 O D  o U  0 O D  0 O D  0 O D  o U  o U  o U  o U\
  0 O D  1 C  U I  1 O  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o\
 1  C o  0 0 1  U I  1 0  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  \
D 0  D o  U I  1 D  U I  D 0  D o  D L  U I  o U  1 C  o U  0 O D  1 C\
  1 C  1 C  U I  1 o  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U \
 1 C  o U  0 O D  1 C  0 O D  U I  1 o  U I  0 O D  1 C  0 O  U I  0 O\
 D  0 O I  U I  0 0 1  0 O 0  C C  0 0 o  0 0 1  0 0 D  0 O D  0 0 L  \
0 O 0  P o  C o  0 O L  0 O L  U I  D L  U I  0 0 1  0 O 0  0 0 P  0 0\
 o  0 0 1  0 0 O  U I  0 0 o  0 0 1  0 O L  0 O  U I  0 O D  0 O I  U \
I  D P  1 C  U I  1 D  U I  D P  1 C  D L  U I  0 0 0  1 L  0 0 0  o C\
  1 L  U I  1 o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  U o  U\
 I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 I  U I  o U  o U  \
o U  o U  U I  1 o  U I  o U  o U  o U  o U  0 O  U I  0 O D  0 O I  U\
 I  0 0 o  0 0 1  0 O L  U I  P 0  P 0  U I  U 1  U 1  U I  D L  0 O  \
U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O  U I  0 O 0  0\
 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 \
o  0 0 1  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  o C  o C  1 \
L  1 L  0 O  0 O O  0 O 0  0 O I  U I  o U  0 O D  0 O D  o U  U I  1 \
O  U I  0 0 P  U I  1 0  U I  D L  0 O  U I  0 O D  0 O C  0 0 I  0 0 \
0  0 0 1  0 0 P  U I  0 O 1  C o  0 0 D  0 O 1  0 O L  0 O D  C L  0 O\
  U I  0 0 0  1 L  o C  o C  0 0 0  0 0 0  1 L  o C  o C  1 L  o C  o \
C  o C  U I  P 0  U I  0 O 1  C o  0 0 D  0 O 1  0 O L  0 O D  C L  U \
I  1 P  U I  0 O C  0 O O  D U  U I  1 O  U I  1 0  0 O  U I  0 0 0  1\
 L  o C  o C  0 0 0  0 0 0  1 L  o C  o C  1 L  o C  o C  o C  U I  1 \
P  U I  0 0 o  0 0 I  0 O O  C o  0 0 P  0 O 0  U I  1 O  U I  0 0 P  \
U I  1 0  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0\
 0  1 L  o C  o C  0 0 0  0 0 0  1 L  o C  o C  1 L  o C  o C  o C  U \
I  1 P  U I  0 O 1  0 O 0  0 I O  0 O O  0 O D  0 O U  0 O 0  0 0 D  0\
 0 P  U I  1 O  U I  1 0  0 O  U I  0 O D  0 O I  U I  1 C  D o  U I  \
1 D  U I  1 C  D o  D L  U I  o U  0 O D  1 C  o U  0 O  0 O O  0 O 0 \
 0 O I  U I  o C  0 0 0  o C  o C  U I  1 O  U I  0 O 0  0 0 O  C C  0\
 0 1  0 I 0  0 0 I  0 0 P  0 O 0  0 O O  U I  1 0  U I  D L  0 O  U I \
 o U  o U  1 C  0 O D  1 C  1 C  0 O D  1 C  0 O D  o U  0 O D  1 C  1\
 C  U I  P 0  U I  U 1  U 1  0 O  U I  0 O D  0 O I  U I  D P  D 0  U \
I  1 D  U I  D P  D 0  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C\
  o U  1 C  o U  0 O D  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  D O  \
D U  U I  1 D  U I  D O  D U  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U\
 I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 P  U I\
  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  0 0 0  0 0 0\
  o C  0 0 0  o C  1 L  0 0 0  U I  1 I  U I  o C  1 L  0 0 0  o C  0 \
O  U I  0 O D  0 O I  U I  D 0  D O  U I  1 D  U I  D 0  D O  D L  U I\
  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 D  U I  0 \
O D  1 C  0 O  U I  0 O D  0 O I  U I  D U  D 0  U I  1 D  U I  D U  D\
 0  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I  \
0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  0 O D  0 O I  U I\
  D P  D D  U I  1 D  U I  D P  D D  D L  U I  o U  o U  o U  o U  U I\
  1 P  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  0 O O  0 O 0  \
0 O I  U I  0 O D  1 C  0 O D  U I  1 O  U I  0 O C  0 O 0  0 O O  0 O\
 D  C o  C D  0 0 o  0 0 1  0 O L  U I  1 0  U I  D L  0 O  U I  0 0 P\
  0 0 1  0 I 0  U I  D L  0 O  U I  U I  0 O D  0 O C  0 0 I  0 0 0  0\
 0 1  0 0 P  U I  P o  0 0 o  0 0 D  0 0 P  0 0 0  0 O C  L O  0 O L  \
C o  0 I 0  0 O 0  0 0 1  0 O  U I  U I  o U  o U  o U  0 O D  0 O D  \
0 O D  o U  U I  P 0  U I  P o  0 0 o  0 0 D  0 0 P  0 0 0  0 O C  L O\
  0 O L  C o  0 I 0  0 O 0  0 0 1  U I  1 P  U I  o o  0 I 0  L L  P P\
  o o  P o  L O  0 O L  C o  0 I 0  0 O 0  0 0 1  U I  1 O  U I  1 0  \
0 O  U I  U I  o C  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  1 L  1 L  U I \
 P 0  U I  0 I O  C L  0 O C  C C  0 O U  0 0 o  0 O D  U I  1 P  U I \
 o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 O 0  0 O C  U I  1 O  U I  0 \
O L  C o  C L  0 O 0  0 O L  U I  P 0  U I  0 0 D  0 0 P  0 0 1  U I  \
1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 0  U I  1 1  U I  0 O D \
 C C  0 0 0  0 0 O  o U  0 O C  C o  0 O U  0 O 0  U I  P 0  U I  U 1 \
 P L  0 O 0  0 O I  C o  0 0 o  0 O L  0 0 P  L P  0 O D  0 O O  0 O 0\
  0 0 0  1 P  0 0 I  0 0 O  0 O U  U 1  U I  1 1  U I  0 0 P  0 O 1  0\
 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  o U  0 O C  C o  0 O U  0 \
O 0  U I  P 0  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O U  0 O \
0  0 0 P  o U  0 0 O  0 O I  0 0 0  o U  0 O C  C o  0 O U  0 O 0  U I\
  1 O  U I  U 1  o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 O 0  0 O C  1\
 P  L 1  0 O 1  0 0 o  0 O C  C L  U 1  U I  1 0  U I  1 1  U I  0 0 I\
  C o  0 0 P  0 O 1  U I  P 0  U I  0 O C  0 O 0  0 O O  0 O D  C o  C\
 D  0 0 o  0 0 1  0 O L  U I  1 0  0 O  U I  U I  o U  o U  o U  0 O D\
  0 O D  0 O D  o U  U I  1 P  U I  0 0 I  0 O L  C o  0 I 0  U I  1 O\
  U I  0 O C  0 O 0  0 O O  0 O D  C o  C D  0 0 o  0 0 1  0 O L  U I \
 1 1  U I  o C  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  1 L  1 L  U I  1 0\
  0 O  U I  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 0 D  0 O L  \
0 O 0  0 O 0  0 0 I  U I  1 O  U I  1 C  1 L  1 L  1 L  U I  1 0  0 O \
 U I  U I  0 0 C  0 O 1  0 O D  0 O L  0 O 0  U I  o U  o U  o U  0 O \
D  0 O D  0 O D  o U  U I  1 P  U I  0 O D  0 0 D  C D  C o  C C  0 0 \
P  0 O D  0 0 L  0 O 0  U I  D L  0 O  U I  U I  U I  0 I O  C L  0 O \
C  C C  U I  1 P  U I  0 0 D  0 O L  0 O 0  0 O 0  0 0 I  U I  1 O  U \
I  D O  1 L  1 L  U I  1 0  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I \
 0 0 P  U I  D L  0 O  U I  U I  0 0 P  0 0 1  C o  C C  0 O 0  C L  C\
 o  C C  0 O o  U I  1 P  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  C D \
 0 O 0  0 I O  C C  U I  1 O  U I  1 0  0 O  U I  0 0 1  0 O 0  0 0 P \
 0 0 o  0 0 1  0 0 O  U I  U C  U C  0 O  U I  0 O D  0 O I  U I  D D \
 D 1  U I  1 D  U I  D D  D 1  D L  U I  o C  o C  0 0 0  0 0 0  o C  \
o C  0 0 0  U I  1 U  U I  o U  0 O D  o U  o U  U I  U o  U I  0 0 0 \
 0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  o U  1 C  o U  0 O\
 D  1 C  1 C  1 C  U I  1 U  U I  o U  0 O D  1 C  o U  0 O  0 O O  0 \
O 0  0 O I  U I  0 0 0  o C  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0  0 0\
 0  o C  0 0 0  o C  U I  1 O  U I  0 0 I  C o  0 0 1  C o  0 O C  0 0\
 D  U I  1 0  U I  D L  0 O  U I  o C  o C  o C  1 L  o C  o C  0 0 0 \
 U I  P 0  U I  0 O P  0 0 D  0 0 0  0 0 O  U I  1 P  U I  0 O O  0 0 \
o  0 O C  0 0 I  0 0 D  U I  1 O  U I  0 0 I  C o  0 0 1  C o  0 O C  \
0 0 D  U I  1 0  0 O  U I  0 O D  1 C  0 0 0  o C  o C  o C  o C  o C \
 o C  o C  0 0 0  o C  U I  P 0  U I  0 I O  C L  0 O C  C C  U I  1 P\
  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  0 O 0  o 1  L U  o C  o\
 L  L I  L O  P o  U I  1 O  U I  o C  o C  o C  1 L  o C  o C  0 0 0 \
 U I  1 0  0 O  U I  0 O D  0 O I  U I  1 C  D O  U I  1 D  U I  1 C  \
D O  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 \
P  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  0 0 \
0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  o U  o U  0 O D \
 o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  0 0 P  0 0 1  0 I 0 \
 U I  D L  0 O  U I  U I  o U  1 C  o U  o U  1 C  1 C  o U  0 O D  o \
U  o U  U I  P 0  U I  0 O P  0 0 D  0 0 0  0 0 O  U I  1 P  U I  0 O \
L  0 0 0  C o  0 O O  0 0 D  U I  1 O  U I  0 O D  1 C  0 0 0  o C  o \
C  o C  o C  o C  o C  o C  0 0 0  o C  U I  1 0  0 O  U I  0 O 0  0 I\
 O  C C  0 O 0  0 0 I  0 0 P  U I  L D  0 0 O  0 O D  C C  0 0 0  0 O \
O  0 O 0  P L  0 O 0  C C  0 0 0  0 O O  0 O 0  P C  0 0 1  0 0 1  0 0\
 0  0 0 1  U I  D L  0 O  U I  U I  o U  1 C  o U  o U  1 C  1 C  o U \
 0 O D  o U  o U  U I  P 0  U I  0 O P  0 0 D  0 0 0  0 0 O  U I  1 P \
 U I  0 O L  0 0 0  C o  0 O O  0 0 D  U I  1 O  U I  0 O D  1 C  0 0 \
0  o C  o C  o C  o C  o C  o C  o C  0 0 0  o C  U I  1 P  U I  0 O O\
  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0\
 O I  1 D  D P  U C  U I  1 1  U I  U C  0 O D  0 O U  0 0 O  0 0 0  0\
 0 1  0 O 0  U C  U I  1 0  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I\
  D U  D P  U I  1 D  U I  D U  D P  D L  U I  0 0 0  1 L  1 L  o C  1\
 L  0 0 0  0 0 0  U I  1 D  U I  o U  0 O D  1 C  o U  U I  U o  U I  \
o U  o U  o U  o U  U I  1 U  U I  0 O D  1 C  U I  1 P  U I  0 0 0  0\
 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  0 0 0  0 0 0  0 0 0 \
 1 L  o C  0 0 0  1 L  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U\
 I  U I  0 O D  0 O I  U I  U C  0 0 1  0 O 0  0 0 D  0 0 o  0 O L  0 \
0 P  U C  U I  0 O D  0 0 O  U I  o U  1 C  o U  o U  1 C  1 C  o U  0\
 O D  o U  o U  U I  D L  0 O  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 0\
 o  0 0 1  0 0 O  U I  o U  1 C  o U  o U  1 C  1 C  o U  0 O D  o U  \
o U  U I  C 0  U I  U C  0 0 1  0 O 0  0 0 D  0 0 o  0 O L  0 0 P  U C\
  U I  C U  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U\
 I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 \
I  0 0 P  U I  o D  0 O 0  0 I 0  P C  0 0 1  0 0 1  0 0 0  0 0 1  U I\
  D L  0 O  U I  U I  0 O L  0 0 0  0 O U  0 O U  0 O 0  0 0 1  U I  1\
 P  U I  0 0 C  C o  0 0 1  0 0 O  U I  1 O  U I  U 1  C 0  U o  0 0 D\
  C U  U I  U o  0 0 D  U 1  U I  U o  U I  1 O  U I  0 0 I  C o  0 0 \
1  C o  0 O C  0 0 D  U I  C 0  U I  U C  0 O C  0 O 0  0 0 P  0 O 1  \
0 0 0  0 O O  U C  U I  C U  U I  1 1  U I  o U  1 C  o U  o U  1 C  1\
 C  o U  0 O D  o U  o U  U I  C 0  U I  U C  0 O 0  0 0 1  0 0 1  0 0\
 0  0 0 1  U C  U I  C U  U I  C 0  U I  U C  0 O C  0 O 0  0 0 D  0 0\
 D  C o  0 O U  0 O 0  U C  U I  C U  U I  1 0  U I  1 0  0 O  U I  U \
I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  o L  0 0 0  0 0 O  0\
 O 0  0 O  U I  U I  0 O D  0 O I  U I  D P  U I  1 D  U I  D P  D L  \
U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 P  U \
I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 I  U I  0 0 0  1 L  0 0\
 0  o C  1 L  U I  1 U  U I  o U  0 O D  1 C  o U  U I  U o  U I  0 0 \
0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  U I  0 O D  0\
 O I  U I  D P  U I  1 D  U I  D P  D L  U I  o C  0 0 0  0 0 0  0 0 0\
  1 L  1 L  1 L  1 L  U I  1 I  U I  o U  o U  0 O D  o U  0 O D  o U \
 o U  1 C  1 C  0 O D  0 O  0 O O  0 O 0  0 O I  U I  o C  o C  0 0 0 \
 o C  o U  0 O D  o U  o U  o U  o U  U I  1 O  U I  0 0 I  0 0 1  0 0\
 0  0 I O  0 I 0  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  0 0\
 D  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 0  U I  D L  0 O  \
U I  0 O D  0 O I  U I  D P  D o  U I  1 D  U I  D P  D o  D L  U I  o\
 U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 o  U I  0 O D  o U  o U  1 \
C  1 C  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  0 0 I  0 0 1  0 0 0  \
0 I O  0 I 0  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  0 0 D  \
U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I \
 0 O D  0 O I  U I  1 C  D 1  U I  1 D  U I  1 C  D 1  D L  U I  o U  \
0 O D  o U  o U  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 \
L  1 L  U I  1 o  U I  o U  0 O D  o U  o U  U I  1 o  U I  o U  1 C  \
o U  0 O D  1 C  1 C  1 C  U I  U o  U I  o U  o U  o U  o U  U I  U o\
  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  \
U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  \
0 0 o  0 0 P  0 O 0  o 1  L U  o C  o L  L I  L O  P o  U I  1 O  U I \
 U C  0 I U  U 1  0 O P  0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C  U 1  \
D L  U 1  D O  1 P  1 L  U 1  1 1  U I  U 1  0 O C  0 O 0  0 0 P  0 O \
1  0 0 0  0 O O  U 1  D L  U 1  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O\
  0 O U  0 0 D  1 P  L U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O \
D  0 0 O  0 O U  L P  C o  0 O L  0 0 o  0 O 0  U 1  1 1  U I  U 1  0 \
0 I  C o  0 0 1  C o  0 O C  0 0 D  U 1  D L  0 I U  U 1  0 0 D  0 O 0\
  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U 1  D L  U 1  0 0 O  0 O 0  0 0 \
P  0 0 C  0 0 0  0 0 1  0 O o  1 P  0 0 o  0 0 D  0 O 0  0 O 1  0 0 P \
 0 0 P  0 0 I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  U 1  1 1  U I  U 1  \
0 0 L  C o  0 O L  0 0 o  0 O 0  U 1  D L  0 O I  C o  0 O L  0 0 D  0\
 O 0  0 I D  1 1  U I  U 1  0 O D  0 O O  U 1  D L  1 C  0 I D  U C  U\
 I  1 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I\
  0 O D  0 O I  U I  D O  D O  U I  1 D  U I  D O  D O  D L  U I  o U \
 0 O D  1 C  o U  U I  1 I  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  \
U I  1 I  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 U  U I  0 0 0  o C \
 1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 I  U I  0 0 0  1 L  1\
 L  o C  1 L  0 0 0  0 0 0  0 O  U I  U I  0 0 0  0 0 0  1 L  0 0 0  1\
 L  U I  P 0  U I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  0 0 D  0 O 0  0 \
0 P  0 0 P  0 O D  0 0 O  0 O U  0 0 D  U I  1 P  U I  0 0 D  0 0 I  0\
 O L  0 O D  0 0 P  U I  1 O  U I  U C  D L  U C  U I  1 0  0 O  U I  \
U I  0 0 0  o C  1 L  0 0 0  0 0 0  o C  0 0 0  o C  U I  P 0  U I  0 \
0 0  0 0 0  1 L  0 0 0  1 L  U I  C 0  U I  1 L  U I  C U  0 O  U I  U\
 I  0 0 0  0 0 0  o C  1 L  1 L  1 L  1 L  0 0 0  1 L  1 L  o C  U I  \
P 0  U I  0 0 0  0 0 0  1 L  0 0 0  1 L  U I  C 0  U I  1 C  U I  C U \
 0 O  U I  U I  o C  1 L  o C  0 0 0  0 0 0  U I  P 0  U I  0 0 0  0 0\
 0  1 L  0 0 0  1 L  U I  C 0  U I  D O  U I  C U  0 O  U I  U I  0 0 \
0  o C  1 L  1 L  0 0 0  o C  o C  0 0 0  1 L  o C  0 0 0  U I  P 0  U\
 I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  U I  o U  o U  0 O D  o U  o U\
  o U  o U  0 O D  0 O D  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O\
  U I  U I  0 O D  0 O I  U I  D I  1 L  U I  1 D  U I  D I  1 L  D L \
 U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I\
  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 0 0  0\
 0 0  1 L  0 0 0  1 L  U I  1 0  U I  P I  U I  D 0  U I  C o  0 0 O  \
0 O O  U I  U C  P 1  U C  U I  0 O D  0 0 O  U I  0 0 0  0 0 0  1 L  \
0 0 0  1 L  U I  C 0  U I  D 0  U I  C U  U I  D L  0 O  U I  U I  U I\
  0 0 0  o C  1 L  1 L  0 0 0  o C  o C  0 0 0  1 L  o C  0 0 0  U I  \
P 0  U I  0 0 0  0 0 0  1 L  0 0 0  1 L  U I  C 0  U I  D 0  U I  C U \
 U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C \
 P 1  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U I  U I \
 o U  o U  0 O D  o U  o U  o U  o U  0 O D  0 O D  U I  P 0  U I  0 0\
 0  0 0 0  1 L  0 0 0  1 L  U I  C 0  U I  D 0  U I  C U  U I  1 P  U \
I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  P 1  U C  U \
I  1 0  U I  C 0  U I  1 C  U I  C U  0 O  U I  U I  U I  0 O D  0 O I\
  U I  D U  D P  U I  1 D  U I  D U  D P  D L  U I  o U  0 O D  o U  o\
 U  0 O  U I  U I  U I  0 O D  0 O I  U I  D o  U I  1 D  U I  D o  D \
L  U I  0 0 0  o C  1 L  0 0 0  U I  U o  U I  0 0 0  o C  1 L  0 0 0 \
 1 L  0 0 0  0 0 0  o C  1 L  U I  1 P  U I  o C  1 L  0 0 0  o C  U I\
  1 U  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  U I  0 \
I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  \
0 0 P  0 O 0  o 1  L U  o C  o L  L I  L O  P o  U I  1 O  U I  U C  0\
 I U  U 1  0 O P  0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C  U 1  D L  U \
1  D O  1 P  1 L  U 1  1 1  U I  U 1  0 O C  0 O 0  0 0 P  0 O 1  0 0 \
0  0 O O  U 1  D L  U 1  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U\
  0 0 D  1 P  L U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 \
O  0 O U  L P  C o  0 O L  0 0 o  0 O 0  U 1  1 1  U I  U 1  0 0 I  C \
o  0 0 1  C o  0 O C  0 0 D  U 1  D L  0 I U  U 1  0 0 D  0 O 0  0 0 P\
  0 0 P  0 O D  0 0 O  0 O U  U 1  D L  U 1  0 0 O  0 O 0  0 0 P  0 0 \
C  0 0 0  0 0 1  0 O o  1 P  0 0 o  0 0 D  0 O 0  0 O 1  0 0 P  0 0 P \
 0 0 I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  U 1  1 1  U I  U 1  0 0 L  \
C o  0 O L  0 0 o  0 O 0  U 1  D L  0 0 P  0 0 1  0 0 o  0 O 0  0 I D \
 1 1  U I  U 1  0 O D  0 O O  U 1  D L  1 C  0 I D  U C  U I  1 0  0 O\
  U I  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0\
  C C  0 0 o  0 0 P  0 O 0  o 1  L U  o C  o L  L I  L O  P o  U I  1 \
O  U I  U C  0 I U  U 1  0 O P  0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C\
  U 1  D L  U 1  D O  1 P  1 L  U 1  1 1  U I  U 1  0 O C  0 O 0  0 0 \
P  0 O 1  0 0 0  0 O O  U 1  D L  U 1  L U  0 O 0  0 0 P  0 0 P  0 O D\
  0 0 O  0 O U  0 0 D  1 P  L U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 \
P  0 O D  0 0 O  0 O U  L P  C o  0 O L  0 0 o  0 O 0  U 1  1 1  U I  \
U 1  0 0 I  C o  0 0 1  C o  0 O C  0 0 D  U 1  D L  0 I U  U 1  0 0 D\
  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U 1  D L  U 1  0 0 O  0 O \
0  0 0 P  0 0 C  0 0 0  0 0 1  0 O o  1 P  0 O 1  0 0 P  0 0 P  0 0 I \
 0 0 I  0 0 1  0 0 0  0 I O  0 I 0  0 0 P  0 I 0  0 0 I  0 O 0  U 1  1\
 1  U I  U 1  0 0 L  C o  0 O L  0 0 o  0 O 0  U 1  D L  U C  U I  1 U\
  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  o C  1 L  o C  0 0 0  0 0 0\
  U I  1 0  U I  1 U  U I  U C  0 I D  1 1  U I  U 1  0 O D  0 O O  U \
1  D L  1 C  0 I D  U C  U I  1 0  0 O  U I  U I  0 I O  C L  0 O C  C\
 C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  0 O 0  o 1 \
 L U  o C  o L  L I  L O  P o  U I  1 O  U I  U C  0 I U  U 1  0 O P  \
0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C  U 1  D L  U 1  D O  1 P  1 L  \
U 1  1 1  U I  U 1  0 O C  0 O 0  0 0 P  0 O 1  0 0 0  0 O O  U 1  D L\
  U 1  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  0 0 D  1 P  L U \
 0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  L P  C o\
  0 O L  0 0 o  0 O 0  U 1  1 1  U I  U 1  0 0 I  C o  0 0 1  C o  0 O\
 C  0 0 D  U 1  D L  0 I U  U 1  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 \
0 O  0 O U  U 1  D L  U 1  0 0 O  0 O 0  0 0 P  0 0 C  0 0 0  0 0 1  0\
 O o  1 P  0 O 1  0 0 P  0 0 P  0 0 I  0 0 I  0 0 1  0 0 0  0 I O  0 I\
 0  0 0 D  0 O 0  0 0 1  0 0 L  0 O 0  0 0 1  U 1  1 1  U I  U 1  0 0 \
L  C o  0 O L  0 0 o  0 O 0  U 1  D L  U 1  U C  U I  1 U  U I  0 0 D \
 0 0 P  0 0 1  U I  1 O  U I  0 0 0  o C  1 L  0 0 0  0 0 0  o C  0 0 \
0  o C  U I  1 0  U I  1 U  U I  U C  U 1  0 I D  1 1  U I  U 1  0 O D\
  0 O O  U 1  D L  1 C  0 I D  U C  U I  1 0  0 O  U I  U I  0 I O  C \
L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  \
0 O 0  o 1  L U  o C  o L  L I  L O  P o  U I  1 O  U I  U C  0 I U  U\
 1  0 O P  0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C  U 1  D L  U 1  D O \
 1 P  1 L  U 1  1 1  U I  U 1  0 O C  0 O 0  0 0 P  0 O 1  0 0 0  0 O \
O  U 1  D L  U 1  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  0 0 D\
  1 P  L U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O \
U  L P  C o  0 O L  0 0 o  0 O 0  U 1  1 1  U I  U 1  0 0 I  C o  0 0 \
1  C o  0 O C  0 0 D  U 1  D L  0 I U  U 1  0 0 D  0 O 0  0 0 P  0 0 P\
  0 O D  0 0 O  0 O U  U 1  D L  U 1  0 0 O  0 O 0  0 0 P  0 0 C  0 0 \
0  0 0 1  0 O o  1 P  0 O 1  0 0 P  0 0 P  0 0 I  0 0 I  0 0 1  0 0 0 \
 0 I O  0 I 0  0 0 I  0 0 0  0 0 1  0 0 P  U 1  1 1  U I  U 1  0 0 L  \
C o  0 O L  0 0 o  0 O 0  U 1  D L  U C  U I  1 U  U I  0 0 D  0 0 P  \
0 0 1  U I  1 O  U I  0 0 0  0 0 0  o C  1 L  1 L  1 L  1 L  0 0 0  1 \
L  1 L  o C  U I  1 0  U I  1 U  U I  U C  0 I D  1 1  U I  U 1  0 O D\
  0 O O  U 1  D L  1 C  0 I D  U C  U I  1 0  0 O  U I  U I  0 O D  0 \
O I  U I  D 1  D O  U I  1 D  U I  D 1  D O  D L  U I  o U  o U  0 O D\
  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 o  U I  0 O D  o U  o \
U  1 C  1 C  1 C  0 O D  U I  U o  U I  o U  o U  0 O D  o U  0 O D  o\
 U  o U  1 C  1 C  0 O D  U I  1 I  U I  o U  1 C  o U  0 O D  1 C  1 \
C  1 C  U I  U o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I\
  U I  0 O D  0 O I  U I  D 0  D 0  U I  1 D  U I  D 0  D 0  D L  U I \
 0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 P  U I  o U  o U  o U  \
o U  U I  1 I  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 I  U I\
  0 0 0  o C  1 L  0 0 0  0 O  U I  U I  0 O D  0 O I  U I  0 0 O  0 0\
 0  0 0 P  U I  0 0 0  o C  1 L  1 L  0 0 0  o C  o C  0 0 0  1 L  o C\
  0 0 0  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  \
U I  U I  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 \
O 0  C C  0 0 o  0 0 P  0 O 0  o 1  L U  o C  o L  L I  L O  P o  U I \
 1 O  U I  U C  0 I U  U 1  0 O P  0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  \
C C  U 1  D L  U 1  D O  1 P  1 L  U 1  1 1  U I  U 1  0 O C  0 O 0  0\
 0 P  0 O 1  0 0 0  0 O O  U 1  D L  U 1  L U  0 O 0  0 0 P  0 0 P  0 \
O D  0 0 O  0 O U  0 0 D  1 P  L U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0\
 0 P  0 O D  0 0 O  0 O U  L P  C o  0 O L  0 0 o  0 O 0  U 1  1 1  U \
I  U 1  0 0 I  C o  0 0 1  C o  0 O C  0 0 D  U 1  D L  0 I U  U 1  0 \
0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U 1  D L  U 1  0 0 O  0\
 O 0  0 0 P  0 0 C  0 0 0  0 0 1  0 O o  1 P  0 O 1  0 0 P  0 0 P  0 0\
 I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  0 0 o  0 0 D  0 O 0  0 0 1  0 0\
 O  C o  0 O C  0 O 0  U 1  1 1  U I  U 1  0 0 L  C o  0 O L  0 0 o  0\
 O 0  U 1  D L  U 1  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O\
  U I  0 0 0  o C  1 L  1 L  0 0 0  o C  o C  0 0 0  1 L  o C  0 0 0  \
U I  1 0  U I  1 U  U I  U C  U 1  0 I D  1 1  U I  U 1  0 O D  0 O O \
 U 1  D L  1 C  0 I D  U C  U I  1 0  0 O  U I  U I  U I  0 I O  C L  \
0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  0 O\
 0  o 1  L U  o C  o L  L I  L O  P o  U I  1 O  U I  U C  0 I U  U 1 \
 0 O P  0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C  U 1  D L  U 1  D O  1 \
P  1 L  U 1  1 1  U I  U 1  0 O C  0 O 0  0 0 P  0 O 1  0 0 0  0 O O  \
U 1  D L  U 1  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  0 0 D  1\
 P  L U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  \
L P  C o  0 O L  0 0 o  0 O 0  U 1  1 1  U I  U 1  0 0 I  C o  0 0 1  \
C o  0 O C  0 0 D  U 1  D L  0 I U  U 1  0 0 D  0 O 0  0 0 P  0 0 P  0\
 O D  0 0 O  0 O U  U 1  D L  U 1  0 0 O  0 O 0  0 0 P  0 0 C  0 0 0  \
0 0 1  0 O o  1 P  0 O 1  0 0 P  0 0 P  0 0 I  0 0 I  0 0 1  0 0 0  0 \
I O  0 I 0  0 0 I  C o  0 0 D  0 0 D  0 0 C  0 0 0  0 0 1  0 O O  U 1 \
 1 1  U I  U 1  0 0 L  C o  0 O L  0 0 o  0 O 0  U 1  D L  U 1  U C  U\
 I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  o U  o U  0 O D  o U\
  o U  o U  o U  0 O D  0 O D  U I  1 0  U I  1 U  U I  U C  U 1  0 I \
D  1 1  U I  U 1  0 O D  0 O O  U 1  D L  1 C  0 I D  U C  U I  1 0  0\
 O  U I  U I  U I  0 O D  0 O I  U I  D U  U I  1 D  U I  D U  D L  U \
I  o U  0 O D  o U  o U  U I  1 o  U I  0 0 0  0 0 0  0 0 0  1 L  o C \
 0 0 0  1 L  U I  U o  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C\
  1 C  0 O D  U I  1 P  U I  0 O D  1 C  U I  1 I  U I  0 0 0  0 0 0  \
0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  U I  U I  0 O D  0 O I  U I  D \
P  D 0  U I  1 D  U I  D P  D 0  D L  U I  o C  1 L  0 0 0  o C  0 O  \
0 O O  0 O 0  0 O I  U I  0 O D  0 O D  0 0 0  0 0 0  o C  1 L  0 0 0 \
 1 L  0 0 0  o C  U I  1 O  U I  1 0  U I  D L  0 O  U I  0 0 0  0 0 0\
  1 L  o C  U I  P 0  U I  0 0 0  o C  1 L  0 0 0  o C  0 0 0  0 0 0  \
0 0 0  0 0 0  o C  0 0 0  o C  U I  1 O  U I  0 I U  U I  U C  0 O P  \
0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C  U C  U I  D L  U I  U C  D O  \
1 P  1 L  U C  U I  1 1  U I  U 1  0 O C  0 O 0  0 0 P  0 O 1  0 0 0  \
0 O O  U 1  U I  D L  U I  U 1  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O\
  0 O U  0 0 D  1 P  o 0  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O \
D  0 0 O  0 O U  L P  C o  0 O L  0 0 o  0 O 0  U 1  U I  1 1  U I  U \
1  0 0 I  C o  0 0 1  C o  0 O C  0 0 D  U 1  U I  D L  U I  0 I U  U \
I  U 1  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U 1  U I  D L\
  U I  U 1  0 0 O  0 O 0  0 0 P  0 0 C  0 0 0  0 0 1  0 O o  1 P  0 0 \
o  0 0 D  0 O 0  0 O 1  0 0 P  0 0 P  0 0 I  0 0 I  0 0 1  0 0 0  0 I \
O  0 I 0  U 1  U I  0 I D  U I  1 1  U I  U C  0 O D  0 O O  U C  U I \
 D L  U I  1 C  U I  0 I D  U I  1 0  U I  C 0  U I  U C  0 0 L  C o  \
0 O L  0 0 o  0 O 0  U C  U I  C U  0 O  U I  0 O D  0 O I  U I  D 1  \
U I  1 D  U I  D 1  D L  U I  o U  0 O D  o U  o U  U I  1 P  U I  0 0\
 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  0 0 0  0 0 0  0\
 0 0  1 L  o C  0 0 0  1 L  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o\
 C  1 L  o C  1 L  1 L  0 O  U I  o C  1 L  o C  0 0 0  0 0 0  U I  P \
0  U I  0 0 0  o C  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0  0 0 0  o C  \
0 0 0  o C  U I  1 O  U I  0 I U  U I  U C  0 O P  0 0 D  0 0 0  0 0 O\
  0 0 1  0 0 I  C C  U C  U I  D L  U I  U C  D O  1 P  1 L  U C  U I \
 1 1  U I  U 1  0 O C  0 O 0  0 0 P  0 O 1  0 0 0  0 O O  U 1  U I  D \
L  U I  U 1  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  0 0 D  1 P\
  o 0  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  L \
P  C o  0 O L  0 0 o  0 O 0  U 1  U I  1 1  U I  U 1  0 0 I  C o  0 0 \
1  C o  0 O C  0 0 D  U 1  U I  D L  U I  0 I U  U I  U 1  0 0 D  0 O \
0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U 1  U I  D L  U I  U 1  0 0 O  \
0 O 0  0 0 P  0 0 C  0 0 0  0 0 1  0 O o  1 P  0 O 1  0 0 P  0 0 P  0 \
0 I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  0 0 P  0 I 0  0 0 I  0 O 0  U \
1  U I  0 I D  U I  1 1  U I  U C  0 O D  0 O O  U C  U I  D L  U I  1\
 C  U I  0 I D  U I  1 0  U I  C 0  U I  U C  0 0 L  C o  0 O L  0 0 o\
  0 O 0  U C  U I  C U  0 O  U I  0 O D  0 O I  U I  D P  D D  U I  1 \
D  U I  D P  D D  D L  U I  o U  0 O D  o U  o U  U I  1 o  U I  o U  \
o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U I  0 0 \
0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  0 0 0  1 L  1 L \
 o C  1 L  0 0 0  0 0 0  0 O  U I  0 O D  0 O I  U I  0 0 0  0 0 0  1 \
L  o C  U I  D L  0 O  U I  U I  0 0 0  o C  1 L  0 0 0  0 0 0  o C  0\
 0 0  o C  U I  P 0  U I  0 0 0  o C  1 L  0 0 0  o C  0 0 0  0 0 0  0\
 0 0  0 0 0  o C  0 0 0  o C  U I  1 O  U I  0 I U  U I  U C  0 O P  0\
 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C  U C  U I  D L  U I  U C  D O  1\
 P  1 L  U C  U I  1 1  U I  U 1  0 O C  0 O 0  0 0 P  0 O 1  0 0 0  0\
 O O  U 1  U I  D L  U I  U 1  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O \
 0 O U  0 0 D  1 P  o 0  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D\
  0 0 O  0 O U  L P  C o  0 O L  0 0 o  0 O 0  U 1  U I  1 1  U I  U 1\
  0 0 I  C o  0 0 1  C o  0 O C  0 0 D  U 1  U I  D L  U I  0 I U  U I\
  U 1  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U 1  U I  D L \
 U I  U 1  0 0 O  0 O 0  0 0 P  0 0 C  0 0 0  0 0 1  0 O o  1 P  0 O 1\
  0 0 P  0 0 P  0 0 I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  0 0 D  0 O 0\
  0 0 1  0 0 L  0 O 0  0 0 1  U 1  U I  0 I D  U I  1 1  U I  U C  0 O\
 D  0 O O  U C  U I  D L  U I  1 C  U I  0 I D  U I  1 0  U I  C 0  U \
I  U C  0 0 L  C o  0 O L  0 0 o  0 O 0  U C  U I  C U  0 O  U I  U I \
 0 0 0  0 0 0  o C  1 L  1 L  1 L  1 L  0 0 0  1 L  1 L  o C  U I  P 0\
  U I  0 0 o  0 0 O  0 O D  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  0\
 0 0  o C  1 L  0 0 0  o C  0 0 0  0 0 0  0 0 0  0 0 0  o C  0 0 0  o \
C  U I  1 O  U I  0 I U  U I  U C  0 O P  0 0 D  0 0 0  0 0 O  0 0 1  \
0 0 I  C C  U C  U I  D L  U I  U C  D O  1 P  1 L  U C  U I  1 1  U I\
  U 1  0 O C  0 O 0  0 0 P  0 O 1  0 0 0  0 O O  U 1  U I  D L  U I  U\
 1  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  0 0 D  1 P  o 0  0 \
O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  L P  C o  0\
 O L  0 0 o  0 O 0  U 1  U I  1 1  U I  U 1  0 0 I  C o  0 0 1  C o  0\
 O C  0 0 D  U 1  U I  D L  U I  0 I U  U I  U 1  0 0 D  0 O 0  0 0 P \
 0 0 P  0 O D  0 0 O  0 O U  U 1  U I  D L  U I  U 1  0 0 O  0 O 0  0 \
0 P  0 0 C  0 0 0  0 0 1  0 O o  1 P  0 O 1  0 0 P  0 0 P  0 0 I  0 0 \
I  0 0 1  0 0 0  0 I O  0 I 0  0 0 I  0 0 0  0 0 1  0 0 P  U 1  U I  0\
 I D  U I  1 1  U I  U C  0 O D  0 O O  U C  U I  D L  U I  1 C  U I  \
0 I D  U I  1 0  U I  C 0  U I  U C  0 0 L  C o  0 O L  0 0 o  0 O 0  \
U C  U I  C U  U I  1 0  0 O  U I  U I  0 0 0  o C  1 L  1 L  0 0 0  o\
 C  o C  0 0 0  1 L  o C  0 0 0  U I  P 0  U I  0 0 0  o C  1 L  0 0 0\
  o C  0 0 0  0 0 0  0 0 0  0 0 0  o C  0 0 0  o C  U I  1 O  U I  0 I\
 U  U I  U C  0 O P  0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C  U C  U I \
 D L  U I  U C  D O  1 P  1 L  U C  U I  1 1  U I  U 1  0 O C  0 O 0  \
0 0 P  0 O 1  0 0 0  0 O O  U 1  U I  D L  U I  U 1  L U  0 O 0  0 0 P\
  0 0 P  0 O D  0 0 O  0 O U  0 0 D  1 P  o 0  0 O 0  0 0 P  L U  0 O \
0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  L P  C o  0 O L  0 0 o  0 O 0  U\
 1  U I  1 1  U I  U 1  0 0 I  C o  0 0 1  C o  0 O C  0 0 D  U 1  U I\
  D L  U I  0 I U  U I  U 1  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 O \
 0 O U  U 1  U I  D L  U I  U 1  0 0 O  0 O 0  0 0 P  0 0 C  0 0 0  0 \
0 1  0 O o  1 P  0 O 1  0 0 P  0 0 P  0 0 I  0 0 I  0 0 1  0 0 0  0 I \
O  0 I 0  0 0 o  0 0 D  0 O 0  0 0 1  0 0 O  C o  0 O C  0 O 0  U 1  U\
 I  0 I D  U I  1 1  U I  U C  0 O D  0 O O  U C  U I  D L  U I  1 C  \
U I  0 I D  U I  1 0  U I  C 0  U I  U C  0 0 L  C o  0 O L  0 0 o  0 \
O 0  U C  U I  C U  0 O  U I  U I  o U  o U  0 O D  o U  o U  o U  o U\
  0 O D  0 O D  U I  P 0  U I  0 0 0  o C  1 L  0 0 0  o C  0 0 0  0 0\
 0  0 0 0  0 0 0  o C  0 0 0  o C  U I  1 O  U I  0 I U  U I  U C  0 O\
 P  0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C  U C  U I  D L  U I  U C  D\
 O  1 P  1 L  U C  U I  1 1  U I  U 1  0 O C  0 O 0  0 0 P  0 O 1  0 0\
 0  0 O O  U 1  U I  D L  U I  U 1  L U  0 O 0  0 0 P  0 0 P  0 O D  0\
 0 O  0 O U  0 0 D  1 P  o 0  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  \
0 O D  0 0 O  0 O U  L P  C o  0 O L  0 0 o  0 O 0  U 1  U I  1 1  U I\
  U 1  0 0 I  C o  0 0 1  C o  0 O C  0 0 D  U 1  U I  D L  U I  0 I U\
  U I  U 1  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U 1  U I \
 D L  U I  U 1  0 0 O  0 O 0  0 0 P  0 0 C  0 0 0  0 0 1  0 O o  1 P  \
0 O 1  0 0 P  0 0 P  0 0 I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  0 0 I  \
C o  0 0 D  0 0 D  0 0 C  0 0 0  0 0 1  0 O O  U 1  U I  0 I D  U I  1\
 1  U I  U C  0 O D  0 O O  U C  U I  D L  U I  1 C  U I  0 I D  U I  \
1 0  U I  C 0  U I  U C  0 0 L  C o  0 O L  0 0 o  0 O 0  U C  U I  C \
U  0 O  U I  U I  0 O D  0 O I  U I  1 C  D o  U I  1 D  U I  1 C  D o\
  D L  U I  0 O D  1 C  U I  1 U  U I  o U  1 C  1 C  0 O D  U I  1 P \
 U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 D  U I  o U  0 O D\
  o U  o U  0 O  U I  U I  0 O D  0 O I  U I  0 0 0  o C  1 L  1 L  0 \
0 0  o C  o C  0 0 0  1 L  o C  0 0 0  U I  C o  0 0 O  0 O O  U I  o \
U  o U  0 O D  o U  o U  o U  o U  0 O D  0 O D  U I  C o  0 0 O  0 O \
O  U I  0 0 0  o C  1 L  0 0 0  0 0 0  o C  0 0 0  o C  U I  C o  0 0 \
O  0 O O  U I  0 0 0  0 0 0  o C  1 L  1 L  1 L  1 L  0 0 0  1 L  1 L \
 o C  U I  D L  0 O  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1 \
 0 0 O  U I  0 0 0  o C  1 L  0 0 0  0 0 0  o C  0 0 0  o C  U I  1 U \
 U I  U C  D L  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I\
  0 0 0  0 0 0  o C  1 L  1 L  1 L  1 L  0 0 0  1 L  1 L  o C  U I  1 \
0  U I  1 U  U I  U C  D L  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U\
 I  1 O  U I  o C  1 L  o C  0 0 0  0 0 0  U I  1 0  U I  1 U  U I  U \
C  D L  U C  U I  1 U  U I  0 0 0  o C  1 L  1 L  0 0 0  o C  o C  0 0\
 0  1 L  o C  0 0 0  U I  1 U  U I  U C  P 1  U C  U I  1 U  U I  o U \
 o U  0 O D  o U  o U  o U  o U  0 O D  0 O D  0 O  U I  U I  0 O 0  0\
 O L  0 O D  0 O I  U I  0 0 0  o C  1 L  0 0 0  0 0 0  o C  0 0 0  o \
C  U I  C o  0 0 O  0 O O  U I  0 0 0  0 0 0  o C  1 L  1 L  1 L  1 L \
 0 0 0  1 L  1 L  o C  U I  D L  0 O  U I  U I  U I  0 0 1  0 O 0  0 0\
 P  0 0 o  0 0 1  0 0 O  U I  0 0 0  o C  1 L  0 0 0  0 0 0  o C  0 0 \
0  o C  U I  1 U  U I  U C  D L  U C  U I  1 U  U I  0 0 D  0 0 P  0 0\
 1  U I  1 O  U I  0 0 0  0 0 0  o C  1 L  1 L  1 L  1 L  0 0 0  1 L  \
1 L  o C  U I  1 0  U I  1 U  U I  U C  D L  U C  U I  1 U  U I  0 0 D\
  0 0 P  0 0 1  U I  1 O  U I  o C  1 L  o C  0 0 0  0 0 0  U I  1 0  \
0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 0 1  \
0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  o L  0 0 0  0 0 O  0 O 0  0 O \
 U I  U I  0 O D  0 O I  U I  1 C  D 1  U I  1 D  U I  1 C  D 1  D L  \
U I  o U  o U  o U  o U  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L \
 1 L  1 L  1 L  U I  1 o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0\
  0 O  0 O O  0 O 0  0 O I  U I  o C  1 L  1 L  0 0 0  o C  0 0 0  0 0\
 0  1 L  o C  0 0 0  o C  1 L  U I  1 O  U I  0 O C  0 O 0  0 O O  0 O\
 D  C o  C D  0 0 o  0 0 1  0 O L  U I  1 1  U I  0 0 O  C o  0 O C  0\
 O 0  U I  1 1  U I  0 O D  C C  0 0 0  0 0 O  o U  0 O C  C o  0 O U \
 0 O 0  U I  1 1  U I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  0 O D  0 0 I\
  U I  1 1  U I  0 0 I  0 0 0  0 0 1  0 0 P  U I  1 1  U I  0 0 I  0 0\
 1  0 0 0  0 I O  0 I 0  0 0 o  0 0 D  0 O 0  0 0 1  U I  P 0  U I  o \
L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  0 0 I  0 0 1  0 0 0  0 I O  0 I\
 0  0 0 I  C o  0 0 D  0 0 D  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0 \
 U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  D 1  D O  U I  1 D  \
U I  D 1  D O  D L  U I  o U  1 C  1 C  0 O D  U I  1 o  U I  o C  0 0\
 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 P  U I  0 O D  o U  o U  \
1 C  1 C  1 C  0 O D  U I  1 I  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0 \
 0 0 0  0 O  U I  0 O D  0 O I  U I  0 O C  0 O 0  0 O O  0 O D  C o  \
C D  0 0 o  0 0 1  0 O L  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0\
  U I  0 0 0  0 0 1  U I  0 O C  0 O 0  0 O O  0 O D  C o  C D  0 0 o \
 0 0 1  0 O L  U I  P 0  P 0  U I  U C  U C  U I  D L  0 O  U I  U I  \
0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o\
  0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 \
O  U I  U 1  L L  P P  o o  P o  1 P  o L  0 0 0  0 0 P  0 O D  0 O I \
 0 O D  C C  C o  0 0 P  0 O D  0 0 0  0 0 O  1 O  L 1  0 O 0  C o  0 \
O C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  1 1  L D  0 0 O  C o  C L\
  0 O L  0 O 0  U I  0 0 P  0 0 0  U I  0 0 I  0 O L  C o  0 I 0  U I \
 0 O 0  0 O C  0 0 I  0 0 P  0 I 0  U I  L D  0 0 1  0 O L  1 1  D U  \
1 L  1 L  1 L  1 1  U 1  U I  1 U  U I  0 0 0  o C  0 0 0  o C  0 0 0 \
 1 L  1 L  0 0 0  o C  0 0 0  U I  1 U  U I  U 1  1 0  U 1  U I  1 0  \
0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O  U I  0 O\
 D  1 C  1 C  0 O D  1 C  o U  0 O D  1 C  U I  P 0  U I  0 I O  C L  \
0 O C  C C  0 O U  0 0 o  0 O D  U I  1 P  U I  P L  0 O D  C o  0 O L\
  0 0 0  0 O U  L O  0 0 1  0 0 0  0 O U  0 0 1  0 O 0  0 0 D  0 0 D  \
U I  1 O  U I  1 0  0 O  U I  0 O D  1 C  1 C  0 O D  1 C  o U  0 O D \
 1 C  U I  1 P  U I  C C  0 0 1  0 O 0  C o  0 0 P  0 O 0  U I  1 O  U\
 I  U C  L O  0 0 1  0 0 0  0 O U  0 0 1  0 O 0  0 0 D  0 0 D  U C  U \
I  1 1  U I  U C  L O  0 O L  C o  0 I 0  0 O D  0 0 O  0 O U  U I  0 \
0 C  0 O D  0 0 P  0 O 1  U I  C C  0 0 o  0 0 D  0 0 P  0 0 0  0 O C \
 U I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  U C  U I  1 0  0 O  U I  0 O \
D  1 C  1 C  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I  0 0 o  0 0 I \
 0 O O  C o  0 0 P  0 O 0  U I  1 O  U I  1 C  1 L  U I  1 1  U I  U 1\
  U 1  U I  1 1  U I  U 1  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0\
 O U  U I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  1 P  1 P  U 1  U I  1 1 \
 U I  U 1  U 1  U I  1 0  0 O  U I  0 0 0  1 L  0 0 0  o C  1 L  0 0 0\
  0 0 0  1 L  1 L  1 L  1 L  o C  o C  U I  P 0  U I  o O  C o  0 O L \
 0 0 D  0 O 0  0 O  U I  o U  1 C  0 O D  1 C  0 O D  0 O D  1 C  o U \
 0 O D  o U  0 O D  0 O D  U I  P 0  U I  U C  U C  0 O  U I  0 O D  0\
 O I  U I  D 1  D o  U I  1 D  U I  D 1  D o  D L  U I  0 0 0  0 0 0  \
o C  0 0 0  o C  1 L  0 0 0  U I  U o  U I  o U  o U  o U  o U  U I  1\
 D  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  0 0 P  0 0 1  0 I 0  U\
 I  D L  0 O  U I  U I  0 O D  0 O I  U I  D 0  D P  U I  1 D  U I  D \
0  D P  D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 0 0  0 0 0 \
 o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 o  U I  0 0 0  0 0 0  o C\
  0 0 0  o C  1 L  o C  1 L  1 L  U I  U o  U I  o U  1 C  o U  0 O D \
 1 C  1 C  1 C  U I  1 o  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L\
  1 L  U I  U o  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C \
 o U  0 O D  1 C  0 O D  0 O  U I  U I  o U  1 C  0 O D  1 C  0 O D  0\
 O D  1 C  o U  0 O D  o U  0 O D  0 O D  U I  P 0  U I  0 O D  0 O D \
 0 0 0  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  o C  U I  1 O  U I  1 0  0\
 O  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  0 O 0  0 I \
O  0 O D  0 0 D  0 0 P  0 O D  0 0 O  0 O U  C D  0 0 I  0 0 1  0 0 0 \
 0 I O  0 I 0  U C  U I  1 1  U I  o U  1 C  0 O D  1 C  0 O D  0 O D \
 1 C  o U  0 O D  o U  0 O D  0 O D  0 O  U I  U I  0 O D  0 O I  U I \
 D D  U I  1 D  U I  D D  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0\
 0  1 L  U I  1 I  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 \
U  U I  o U  1 C  1 C  0 O D  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0 \
 o C  1 L  o C  1 L  1 L  U I  1 U  U I  o U  0 O D  o U  o U  U I  U \
o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  U I  0 O D  0\
 O I  U I  D 1  D O  U I  1 D  U I  D 1  D O  D L  U I  0 0 0  1 L  1 \
L  o C  1 L  0 0 0  0 0 0  U I  1 D  U I  0 O D  1 C  1 C  o U  0 O D \
 1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 I  U I  0 0 0  0 0\
 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  0 0 0  0 0 0  o C  0 0\
 0  o C  1 L  o C  1 L  1 L  U I  U o  U I  o C  0 0 0  0 0 0  0 0 0  \
1 L  1 L  1 L  1 L  0 O  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 \
0 P  U I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  0 0 o  0 0 D  0 O 0  0 0 \
1  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U\
 I  U I  o C  o C  0 0 0  o C  o U  0 O D  o U  o U  o U  o U  U I  1 \
O  U I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  0 O D  0 0 I  U I  1 U  U I\
  U C  D L  U C  U I  1 U  U I  0 0 I  0 0 0  0 0 1  0 0 P  U I  1 U  \
U I  U C  D L  1 L  D L  U C  U I  1 U  U I  0 0 I  0 0 1  0 0 0  0 I \
O  0 I 0  0 0 o  0 0 D  0 O 0  0 0 1  U I  1 U  U I  U C  P 1  U C  U \
I  1 U  U I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  0 0 I  C o  0 0 D  0 0\
 D  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O\
  U I  U I  U I  o C  o C  0 0 0  o C  o U  0 O D  o U  o U  o U  o U \
 U I  1 O  U I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  0 O D  0 0 I  U I  \
1 U  U I  U C  D L  U C  U I  1 U  U I  0 0 I  0 0 0  0 0 1  0 0 P  U \
I  1 U  U I  U C  D L  1 L  U C  U I  1 0  0 O  U I  U I  U I  0 O D  \
0 O I  U I  D U  D O  U I  1 D  U I  D U  D O  D L  U I  0 0 0  o C  1\
 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  U o  U I  o U  o U  o U  \
o U  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L \
 0 O  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  0 0 I  0 \
0 1  0 0 0  0 I O  0 I 0  U I  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 \
O  0 O U  U I  C C  0 0 0  0 O C  0 0 I  0 O L  0 O 0  0 0 P  0 O 0  U\
 I  0 0 I  0 O L  C o  0 I 0  0 O D  0 0 O  0 O U  U C  U I  1 1  U I \
 0 O C  0 O 0  0 O O  0 O D  C o  C D  0 0 o  0 0 1  0 O L  0 O  U I  \
U I  0 0 0  1 L  0 0 0  o C  1 L  0 0 0  0 0 0  1 L  1 L  1 L  1 L  o \
C  o C  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  0 O  U I  U I  0 O D \
 1 C  1 C  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I  0 0 o  0 0 I  0\
 O O  C o  0 0 P  0 O 0  U I  1 O  U I  D P  1 L  U I  1 1  U I  U 1  \
U 1  U I  1 1  U I  U 1  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O\
 U  U I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  U I  C C  0 0 0  0 O C  0 \
0 I  0 O L  0 O 0  0 0 P  0 O 0  1 1  U I  0 0 O  0 0 0  0 0 C  U I  0\
 0 I  0 O L  C o  0 I 0  0 O D  0 0 O  0 O U  U 1  U I  1 1  U I  U 1 \
 U 1  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  D 0  1 L  U I  1 D  \
U I  D 0  1 L  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o \
U  U I  1 o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 U  U I  \
o U  o U  o U  o U  0 O  U I  U I  0 O D  0 O I  U I  D 1  U I  1 D  U\
 I  D 1  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I\
  1 P  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 U  U I  0 O D  1 C  1 \
C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 P  U\
 I  0 O D  1 C  0 O  U I  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 \
P  U I  P o  0 0 o  0 0 D  0 0 P  0 0 0  0 O C  L O  0 O L  C o  0 I 0\
  0 O 0  0 0 1  0 O  U I  U I  o U  o U  o U  0 O D  0 O D  0 O D  o U\
  U I  P 0  U I  P o  0 0 o  0 0 D  0 0 P  0 0 0  0 O C  L O  0 O L  C\
 o  0 I 0  0 O 0  0 0 1  U I  1 P  U I  o o  0 I 0  L L  P P  o o  P o\
  L O  0 O L  C o  0 I 0  0 O 0  0 0 1  U I  1 O  U I  1 0  0 O  U I  \
U I  o U  o U  o U  0 O D  0 O D  0 O D  o U  U I  1 P  U I  0 0 I  0 \
O O  0 O D  C o  0 O L  0 0 0  0 O U  0 0 o  0 O 0  U I  P 0  P 0  U I\
  0 O D  1 C  1 C  0 O D  1 C  o U  0 O D  1 C  0 O  U I  U I  o C  0 \
0 0  o C  1 L  1 L  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  0 I O  C L \
 0 O C  C C  0 O U  0 0 o  0 O D  U I  1 P  U I  o P  0 O D  0 0 D  0 \
0 P  o U  0 0 P  0 O 0  0 O C  U I  1 O  U I  0 O L  C o  C L  0 O 0  \
0 O L  U I  P 0  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  0 0 O  C o  \
0 O C  0 O 0  U I  1 0  U I  1 1  U I  0 O D  C C  0 0 0  0 0 O  o U  \
0 O C  C o  0 O U  0 O 0  U I  P 0  U I  0 O D  C C  0 0 0  0 0 O  o U\
  0 O C  C o  0 O U  0 O 0  U I  1 1  U I  0 0 P  0 O 1  0 0 o  0 O C \
 C L  0 0 O  C o  0 O D  0 O L  o U  0 O C  C o  0 O U  0 O 0  U I  P \
0  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O U  0 O 0  0 0 P  o \
U  0 0 O  0 O I  0 0 0  o U  0 O C  C o  0 O U  0 O 0  U I  1 O  U I  \
U 1  o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 O 0  0 O C  1 P  L 1  0 O\
 1  0 0 o  0 O C  C L  U 1  U I  1 0  U I  1 1  U I  0 0 I  C o  0 0 P\
  0 O 1  U I  P 0  U I  0 O C  0 O 0  0 O O  0 O D  C o  C D  0 0 o  0\
 0 1  0 O L  U I  1 0  0 O  U I  U I  o U  o U  o U  0 O D  0 O D  0 O\
 D  o U  U I  1 P  U I  0 0 I  0 O L  C o  0 I 0  U I  1 O  U I  0 O C\
  0 O 0  0 O O  0 O D  C o  C D  0 0 o  0 0 1  0 O L  U I  1 1  U I  o\
 C  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  1 L  1 L  U I  1 0  0 O  U I  \
U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 0 D  0 O L  0 O 0  0 O 0\
  0 0 I  U I  1 O  U I  1 C  1 L  1 L  1 L  U I  1 0  0 O  U I  U I  0\
 O D  0 O I  U I  D D  1 L  U I  1 D  U I  D D  1 L  D L  U I  o U  1 \
C  o U  0 O D  1 C  1 C  1 C  0 O  U I  U I  0 O D  0 O I  U I  D I  D\
 1  U I  1 D  U I  D I  D 1  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U \
I  1 D  U I  o U  1 C  1 C  0 O D  0 O  U I  U I  0 O D  0 O C  0 0 I \
 0 0 0  0 0 1  0 0 P  U I  0 0 P  0 O D  0 O C  0 O 0  0 O  U I  U I  \
0 O D  1 C  1 C  1 C  0 O D  0 O D  o U  o U  o U  o U  U I  P 0  U I \
 0 0 P  0 O D  0 O C  0 O 0  U I  1 P  U I  0 0 P  0 O D  0 O C  0 O 0\
  U I  1 O  U I  1 0  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 \
O  U I  U I  U I  0 0 C  0 O 1  0 O D  0 O L  0 O 0  U I  o U  o U  o \
U  0 O D  0 O D  0 O D  o U  U I  1 P  U I  0 O D  0 0 D  C D  C o  C \
C  0 0 P  0 O D  0 0 L  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 I \
O  C L  0 O C  C C  U I  1 P  U I  0 0 D  0 O L  0 O 0  0 O 0  0 0 I  \
U I  1 O  U I  1 C  1 L  1 L  1 L  U I  1 0  0 O  U I  U I  U I  U I  \
0 O D  0 O I  U I  o U  o U  o U  0 O D  0 O D  0 O D  o U  U I  1 P  \
U I  0 0 o  0 0 1  0 O L  0 0 I  0 O L  C o  0 I 0  0 O 0  0 O O  U I \
 P 0  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  U I  C o  0 0 O  0 O O \
 U I  0 0 P  0 O D  0 O C  0 O 0  U I  1 P  U I  0 0 P  0 O D  0 O C  \
0 O 0  U I  1 O  U I  1 0  U I  1 D  U I  0 O D  1 C  1 C  1 C  0 O D \
 0 O D  o U  o U  o U  o U  U I  P I  U I  1 C  D O  U I  D L  0 O  U \
I  U I  U I  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  0 \
O I  C o  0 O D  0 O L  0 O 0  0 O O  U U  U U  U U  U C  0 O  U I  U \
I  U I  U I  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O \
 0 O 0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O\
 D  0 0 O  U I  1 O  U I  U 1  L L  P P  o o  P o  1 P  o L  0 0 0  0 \
0 P  0 O D  0 O I  0 O D  C C  C o  0 0 P  0 O D  0 0 0  0 0 O  1 O  L\
 1  0 O 0  C o  0 O C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  1 1  L \
D  0 0 O  C o  C L  0 O L  0 O 0  U I  0 0 P  0 0 0  U I  0 0 I  0 O L\
  C o  0 I 0  U I  C C  0 O 1  0 O 0  C C  0 O o  U I  0 0 I  0 0 1  0\
 0 0  0 I O  0 I 0  1 1  D U  1 L  1 L  1 L  1 1  U 1  U I  1 U  U I  \
0 0 0  o C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U I  1 U  \
U I  U 1  1 0  U 1  U I  1 0  0 O  U I  U I  U I  U I  U I  C L  0 0 1\
  0 O 0  C o  0 O o  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  \
D P  1 L  U I  1 D  U I  D P  1 L  D L  U I  o U  0 O D  o U  o U  U I\
  1 I  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O \
D  1 C  0 O D  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 \
0  o C  1 L  U I  1 I  U I  o C  1 L  0 0 0  o C  0 O  U I  U I  0 O 0\
  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0\
 0 D  0 O  U I  U I  0 O D  0 O I  U I  1 C  D 1  U I  1 D  U I  1 C  \
D 1  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I  0 O D  o U \
 o U  1 C  1 C  1 C  0 O D  U I  1 U  U I  o U  1 C  o U  0 O D  1 C  \
1 C  1 C  U I  U o  U I  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  o U  1\
 C  1 C  0 O D  U I  1 P  U I  o U  o U  o U  o U  0 O  U I  U I  0 O \
D  1 C  1 C  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I  C C  0 O L  0\
 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  U I  0 O D  1 C  1 C\
  0 O D  1 C  o U  0 O D  1 C  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0\
  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I\
  U I  0 0 P  0 0 1  C o  C C  0 O 0  C L  C o  C C  0 O o  U I  1 P  \
U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  C D  0 O 0  0 I O  C C  U I  1\
 O  U I  1 0  0 O  U I  0 O D  0 O I  U I  0 O D  1 C  1 C  0 O D  1 C\
  o U  0 O D  1 C  U I  D L  0 O  U I  U I  0 O D  1 C  1 C  0 O D  1 \
C  o U  0 O D  1 C  U I  1 P  U I  C C  0 O L  0 0 0  0 0 D  0 O 0  U \
I  1 O  U I  1 0  0 O  U I  0 O D  0 O I  U I  0 0 0  1 L  0 0 0  o C \
 1 L  0 0 0  0 0 0  1 L  1 L  1 L  1 L  o C  o C  U I  D L  0 O  U I  \
U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  0 0 O  0 0 0  0 0 C \
 U I  0 0 1  0 O 0  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U\
 I  0 0 P  0 O 1  0 O 0  U I  0 0 I  0 0 1  0 0 0  0 I O  0 I 0  U I  \
C L  C o  C C  0 O o  U C  0 O  U I  U I  o C  o C  0 0 0  o C  o U  0\
 O D  o U  o U  o U  o U  U I  1 O  U I  o U  1 C  0 O D  1 C  0 O D  \
0 O D  1 C  o U  0 O D  o U  0 O D  0 O D  U I  1 0  0 O  U I  U I  0 \
0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  0 0 1  0 O 0  0 0 D  0 O 0 \
 0 0 P  U I  0 O 1  0 O 0  0 0 1  0 O 0  U C  0 O  U I  0 0 1  0 O 0  \
0 0 P  0 0 o  0 0 1  0 0 O  U I  U C  U C  0 O  U I  0 O D  0 O I  U I\
  D O  D 1  U I  1 D  U I  D O  D 1  D L  U I  0 0 0  1 L  1 L  o C  1\
 L  0 0 0  0 0 0  U I  1 I  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0 \
 1 L  U I  1 P  U I  o U  1 C  1 C  0 O D  0 O  U I  0 O D  0 O I  U I\
  D U  D o  U I  1 D  U I  D U  D o  D L  U I  o U  o U  0 O D  o U  0\
 O D  o U  o U  1 C  1 C  0 O D  U I  1 U  U I  o U  1 C  1 C  0 O D  \
U I  1 D  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  0 O O  0 \
O 0  0 O I  U I  o C  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  1 L  0 0 0  \
1 L  0 0 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  \
0 O L  0 0 o  0 O 0  U I  1 1  U I  0 0 1  0 O 0  0 O I  0 O 0  0 0 1 \
 0 O 0  0 0 1  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 0  U I \
 D L  0 O  U I  0 O D  0 O I  U I  0 0 1  0 O 0  0 O I  0 O 0  0 0 1  \
0 O 0  0 0 1  U I  D L  0 O  U I  U I  0 0 1  0 O 0  0 O I  0 O 0  0 0\
 1  0 O 0  0 0 1  U I  P 0  U I  C 0  U I  1 O  U I  U C  L I  0 O 0  \
0 O I  0 O 0  0 0 1  0 O 0  0 0 1  U C  U I  1 1  U I  0 0 1  0 O 0  0\
 O I  0 O 0  0 0 1  0 O 0  0 0 1  U I  1 0  U I  C U  0 O  U I  0 O D \
 0 O I  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  \
0 O 0  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0\
 O D  0 0 P  0 O 1  U I  1 O  U I  U 1  0 O 1  0 0 P  0 0 P  0 0 I  U \
1  U I  1 0  U I  D L  0 O  U I  U I  0 O D  o U  1 C  o U  1 C  0 O D\
  o U  o U  1 C  0 O D  U I  P 0  U I  0 0 I  C o  0 O U  0 O 0  C D  \
0 0 L  C o  0 O L  0 0 o  0 O 0  0 O  U I  U I  0 0 I  C o  0 O U  0 O\
 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U I  P 0  U I  0 0 0  o C  o\
 C  o C  o C  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o\
  0 O L  0 0 o  0 O 0  U I  1 1  U I  0 O 1  0 O 0  C o  0 O O  0 O 0 \
 0 0 1  0 0 D  U I  P 0  U I  0 0 1  0 O 0  0 O I  0 O 0  0 0 1  0 O 0\
  0 0 1  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  D 0  1 L  U I  1 \
D  U I  D 0  1 L  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C\
  1 C  0 O D  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0\
  o C  1 L  U I  1 U  U I  o U  0 O D  1 C  o U  0 O  U I  o U  o U  o\
 U  1 C  o U  U I  P 0  U I  U 1  1 O  0 O 0  0 0 L  C o  0 O L  C I  \
1 O  0 O I  0 0 o  0 0 O  C C  0 0 P  0 O D  0 0 0  0 0 O  C I  1 O  0\
 0 I  1 1  C o  1 1  C C  1 1  0 O o  1 1  0 O 0  1 1  1 O  P U  D L  \
0 0 1  0 I 1  0 O O  1 0  1 P  1 I  1 0  U 1  0 O  U I  0 O D  0 O I  \
U I  1 C  1 C  U I  1 D  U I  1 C  1 C  D L  U I  o C  0 0 0  0 0 0  0\
 0 0  1 L  1 L  1 L  1 L  U I  1 D  U I  o C  1 L  0 0 0  o C  U I  1 \
U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  o\
 U  o U  o U  o U  U I  1 o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O \
D  0 O  U I  o C  0 0 0  o C  o C  o C  o C  U I  P 0  U I  0 0 1  0 O\
 0  U I  1 P  U I  C C  0 0 0  0 O C  0 0 I  0 O D  0 O L  0 O 0  U I \
 1 O  U I  o U  o U  o U  1 C  o U  U I  1 0  U I  1 P  U I  0 O I  0 \
O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 O  U I  0 0 I  C o  0 O U\
  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U I  1 0  0 O  U I  o U\
  1 C  0 O D  0 O D  o U  0 O D  1 C  1 C  1 C  o U  U I  P 0  U I  U \
1  U 1  0 O  U I  0 O D  0 O I  U I  o C  0 0 0  o C  o C  o C  o C  U\
 I  C o  0 0 O  0 O O  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  o C  0\
 0 0  o C  o C  o C  o C  U I  1 0  U I  P I  U I  1 L  U I  D L  0 O \
 U I  U I  0 O I  0 0 0  0 0 1  U I  0 O D  o U  0 O D  1 C  1 C  o U \
 0 O D  1 C  U I  0 O D  0 0 O  U I  o C  0 0 0  o C  o C  o C  o C  U\
 I  D L  0 O  U I  U I  U I  o U  0 O D  0 O D  0 O D  1 C  0 O D  o U\
  0 O D  0 O D  U I  P 0  U I  0 0 0  o C  0 0 0  0 0 0  0 0 0  o C  1\
 L  1 L  1 L  o C  U I  1 O  U I  0 O D  o U  0 O D  1 C  1 C  o U  0 \
O D  1 C  U I  1 0  0 O  U I  U I  U I  o U  o U  o U  1 C  o U  1 C  \
1 C  0 O D  1 C  0 O D  o U  0 O D  U I  P 0  U I  o C  o C  0 0 0  o \
C  0 0 0  o C  0 0 0  U I  1 O  U I  o U  0 O D  0 O D  0 O D  1 C  0 \
O D  o U  0 O D  0 O D  U I  1 1  U I  U C  C I  U C  1 O  1 P  1 I  P\
 U  1 0  C I  U C  U C  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U \
I  U C  0 0 o  0 0 O  0 O 0  0 0 D  C C  C o  0 0 I  0 O 0  U C  U I  \
0 O D  0 0 O  U I  o U  0 O D  0 O D  0 O D  1 C  0 O D  o U  0 O D  0\
 O D  U I  D L  0 O  U I  U I  U I  U I  o U  0 O D  0 O D  0 O D  1 C\
  0 O D  o U  0 O D  0 O D  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L \
 0 O D  C L  U I  1 P  U I  0 0 o  0 0 O  0 0 U  0 0 o  0 0 0  0 0 P  \
0 O 0  U I  1 O  U I  o U  o U  o U  1 C  o U  1 C  1 C  0 O D  1 C  0\
 O D  o U  0 O D  U I  1 0  0 O  U I  U I  U I  o U  1 C  0 O D  0 O D\
  o U  0 O D  1 C  1 C  1 C  o U  U I  1 U  P 0  U I  o U  0 O D  0 O \
D  0 O D  1 C  0 O D  o U  0 O D  0 O D  U I  1 U  U I  U C  C I  0 0 \
O  U C  0 O  U I  U I  U I  0 O D  0 O I  U I  D 1  D o  U I  1 D  U I\
  D 1  D o  D L  U I  o U  0 O D  o U  o U  U I  1 I  U I  o U  0 O D \
 1 C  o U  U I  1 I  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L\
  U I  1 P  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  \
1 D  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U \
I  U I  U I  0 O D  0 O I  U I  D 0  D o  U I  1 D  U I  D 0  D o  D L\
  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 \
C  0 O D  U I  1 I  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  U\
 o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 P  U I  0 0 0  0 \
0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I  U I  0 O D  o U  1 C  o U \
 1 C  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  o C  o C  0 0 0  o C\
  0 0 0  o C  0 0 0  U I  1 O  U I  o U  1 C  0 O D  0 O D  o U  0 O D\
  1 C  1 C  1 C  o U  U I  1 1  U I  U C  0 0 D  0 0 1  C C  P 0  U 1 \
 1 O  1 P  1 I  P U  1 0  U 1  U C  U I  1 0  0 O  U I  U I  0 O D  0 \
O I  U I  D O  D I  U I  1 D  U I  D O  D I  D L  U I  o U  1 C  1 C  \
0 O D  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  0 O D  1 \
C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  0 O  U\
 I  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O \
0  U I  P 0  U I  0 0 0  o C  o C  o C  o C  U I  1 O  U I  0 O D  o U\
  1 C  o U  1 C  0 O D  o U  o U  1 C  0 O D  U I  1 1  U I  0 O 1  0 \
O 0  C o  0 O O  0 O 0  0 0 1  0 0 D  U I  P 0  U I  0 0 1  0 O 0  0 O\
 I  0 O 0  0 0 1  0 O 0  0 0 1  U I  1 0  0 O  U I  U I  0 O D  0 O I \
 U I  D D  D P  U I  1 D  U I  D D  D P  D L  U I  0 0 0  0 0 0  o C  \
0 0 0  o C  1 L  o C  1 L  1 L  U I  1 U  U I  0 0 0  1 L  1 L  o C  1\
 L  0 0 0  0 0 0  U I  1 U  U I  0 O D  1 C  U I  1 o  U I  0 0 0  1 L\
  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  0 0 0  o C  1 L  0 0 0  \
U I  U o  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  U \
I  0 O D  0 O I  U I  D P  D 0  U I  1 D  U I  D P  D 0  D L  U I  0 0\
 0  o C  1 L  0 0 0  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L\
  0 0 0  U I  U o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  \
U o  U I  0 O D  1 C  U I  1 P  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 \
0  0 0 0  o C  1 L  U I  U o  U I  o U  o U  0 O D  o U  0 O D  o U  o\
 U  1 C  1 C  0 O D  0 O  U I  U I  0 O D  0 O I  U I  D I  D D  U I  \
1 D  U I  D I  D D  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0 \
 0 O  U I  0 0 0  0 0 0  1 L  0 0 0  0 0 0  0 0 0  0 0 0  o C  U I  P \
0  U I  o C  o C  0 0 0  o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 0 I \
 C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U I  1 1  U \
I  U C  0 0 D  0 0 P  0 0 1  0 O 0  C o  0 O C  0 O 0  0 0 1  C I  U C\
  1 P  1 I  P U  C I  U C  1 O  1 P  1 I  P U  1 0  C I  U C  C I  1 0\
  U C  U I  1 0  0 O  U I  0 O D  0 O D  o U  o U  0 O D  U I  P 0  U \
I  o C  o C  0 0 0  o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 0 I  C o \
 0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U I  1 1  U I  U \
C  0 O I  0 O D  0 O L  0 O 0  C I  U C  1 1  C I  0 0 D  C I  U C  1 \
O  1 P  1 I  P U  1 0  C I  U C  U C  U I  1 0  0 O  U I  0 O D  0 O I\
  U I  D 0  D 1  U I  1 D  U I  D 0  D 1  D L  U I  0 0 0  1 L  0 0 0 \
 o C  1 L  U I  1 P  U I  o U  0 O D  1 C  o U  0 O  U I  0 O D  0 O I\
  U I  D O  D U  U I  1 D  U I  D O  D U  D L  U I  o U  o U  o U  o U\
  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 0  0 0 \
0  1 L  0 0 0  0 0 0  0 0 0  0 0 0  o C  U I  1 U  U I  U C  U I  0 0 \
I  0 O L  C o  0 I 0  0 0 I  C o  0 0 P  0 O 1  P 0  U C  U I  1 U  U \
I  0 O D  0 O D  o U  o U  0 O D  U I  1 U  U I  U C  U I  0 0 I  C o \
 0 O U  0 O 0  L D  0 0 1  0 O L  P 0  U C  U I  1 U  U I  0 O D  o U \
 1 C  o U  1 C  0 O D  o U  o U  1 C  0 O D  0 O  U I  0 O D  0 O I  U\
 I  D 0  D I  U I  1 D  U I  D 0  D I  D L  U I  0 0 0  0 0 0  o C  0 \
0 0  o C  1 L  0 0 0  U I  1 P  U I  0 0 0  o C  1 L  0 0 0  U I  U o \
 U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  0 O\
 O  0 O 0  0 O I  U I  0 O D  o U  1 C  1 C  o U  0 O D  1 C  1 C  1 C\
  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0\
 o  0 O 0  U I  1 1  U I  0 0 1  0 O 0  0 O I  0 O 0  0 0 1  0 O 0  0 \
0 1  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 0  U I  D L  0 O \
 U I  0 O D  0 O I  U I  0 0 1  0 O 0  0 O I  0 O 0  0 0 1  0 O 0  0 0\
 1  U I  D L  0 O  U I  U I  0 0 1  0 O 0  0 O I  0 O 0  0 0 1  0 O 0 \
 0 0 1  U I  P 0  U I  C 0  U I  1 O  U I  U C  L I  0 O 0  0 O I  0 O\
 0  0 0 1  0 O 0  0 0 1  U C  U I  1 1  U I  0 0 1  0 O 0  0 O I  0 O \
0  0 0 1  0 O 0  0 0 1  U I  1 0  U I  C U  0 O  U I  0 O D  0 O I  U \
I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U I\
  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 \
P  0 O 1  U I  1 O  U I  U 1  0 O 1  0 0 P  0 0 P  0 0 I  U 1  U I  1 \
0  U I  D L  0 O  U I  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o \
 0 O L  0 0 o  0 O 0  U I  P 0  U I  0 0 0  o C  o C  o C  o C  U I  1\
 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O \
0  U I  1 1  U I  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  0 0 D  U I  \
P 0  U I  0 0 1  0 O 0  0 O I  0 O 0  0 0 1  0 O 0  0 0 1  U I  1 0  0\
 O  U I  o U  o U  o U  1 C  o U  U I  P 0  U I  U 1  0 0 L  C o  0 0 \
1  U I  C o  U I  P 0  U I  1 O  1 P  1 I  P U  1 0  D C  C I  0 0 D  \
1 I  0 0 L  C o  0 0 1  U I  C L  U I  P 0  U I  1 O  1 P  1 I  P U  1\
 0  D C  C I  0 0 D  1 I  0 0 L  C o  0 0 1  U I  C C  U I  P 0  U I  \
1 O  1 P  1 I  P U  1 0  D C  C I  0 0 D  1 I  0 0 L  C o  0 0 1  U I \
 0 O O  U I  P 0  U I  1 O  1 P  1 I  P U  1 0  D C  C I  0 0 D  1 I  \
0 0 L  C o  0 0 1  U I  0 O I  U I  P 0  U I  1 O  1 P  1 I  P U  1 0 \
 D C  C I  0 0 D  1 I  0 0 L  C o  0 0 1  U I  0 0 L  C D  0 0 I  C o \
 0 0 1  0 0 P  U I  P 0  U I  U C  1 O  1 P  1 I  P U  1 0  U C  D C  \
U 1  0 O  U I  o C  0 0 0  o C  o C  o C  o C  U I  P 0  U I  0 0 1  0\
 O 0  U I  1 P  U I  C C  0 0 0  0 O C  0 0 I  0 O D  0 O L  0 O 0  U \
I  1 O  U I  o U  o U  o U  1 C  o U  U I  1 0  U I  1 P  U I  0 O I  \
0 O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 O  U I  0 0 I  C o  0 O\
 U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U I  1 0  U I  C 0  U\
 I  1 L  U I  C U  0 O  U I  0 O D  0 O I  U I  D U  D I  U I  1 D  U \
I  D U  D I  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I \
 U o  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 P  U\
 I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 I  U I  o C  1 L\
  0 0 0  o C  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0\
  U I  U o  U I  o U  1 C  1 C  0 O D  0 O  U I  o U  1 C  o U  1 C  o\
 U  1 C  1 C  o U  0 O D  U I  1 1  U I  o C  0 0 0  o C  U I  1 1  U \
I  0 O D  0 O D  1 C  o U  0 O D  0 O D  1 C  U I  1 1  U I  0 0 0  1 \
L  o C  o C  o C  o C  o C  1 L  o C  U I  1 1  U I  0 0 0  o C  U I  \
1 1  U I  0 O D  o U  0 O D  1 C  1 C  o U  0 O D  1 C  U I  P 0  U I \
 1 O  U I  o C  0 0 0  o C  o C  o C  o C  U I  1 0  0 O  U I  0 0 0  \
o C  U I  P 0  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 0  o C  U \
I  1 0  0 O  U I  o U  1 C  o U  1 C  o U  1 C  1 C  o U  0 O D  U I  \
P 0  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  o U  1 C  o U  1 C  o U \
 1 C  1 C  o U  0 O D  U I  1 0  U I  1 o  U I  0 0 0  o C  0 O  U I  \
o C  0 0 0  o C  U I  P 0  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  o \
C  0 0 0  o C  U I  1 0  U I  1 o  U I  0 0 0  o C  0 O  U I  0 O D  0\
 O D  1 C  o U  0 O D  0 O D  1 C  U I  P 0  U I  0 O D  0 0 O  0 0 P \
 U I  1 O  U I  0 O D  0 O D  1 C  o U  0 O D  0 O D  1 C  U I  1 0  U\
 I  1 o  U I  0 0 0  o C  0 O  U I  0 0 0  1 L  o C  o C  o C  o C  o \
C  1 L  o C  U I  P 0  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 0 \
 1 L  o C  o C  o C  o C  o C  1 L  o C  U I  1 0  U I  1 o  U I  0 0 \
0  o C  0 O  U I  0 O D  0 O I  U I  D 0  D U  U I  1 D  U I  D 0  D U\
  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O \
D  1 C  0 O D  U I  1 D  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o\
 U  1 C  o U  0 O D  1 C  0 O D  U I  1 U  U I  o U  1 C  1 C  0 O D  \
U I  1 D  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D \
 U I  1 D  U I  0 O D  1 C  0 O  U I  o U  0 O D  o U  o U  0 O D  1 C\
  o U  1 C  o U  1 C  1 C  o U  0 O D  U I  P 0  U I  U C  0 0 1  0 0 \
P  0 O C  0 0 I  D L  1 o  1 o  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 \
1  U I  1 O  U I  o U  1 C  o U  1 C  o U  1 C  1 C  o U  0 O D  U I  \
1 0  U I  1 U  U I  U C  1 P  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1 \
 U I  1 O  U I  o C  0 0 0  o C  U I  1 0  U I  1 U  U I  U C  1 P  U \
C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  0 O D  0 O D  1 \
C  o U  0 O D  0 O D  1 C  U I  1 0  U I  1 U  U I  U C  1 P  U C  U I\
  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  0 0 0  1 L  o C  o C  \
o C  o C  o C  1 L  o C  U I  1 0  U I  1 U  U I  0 O D  o U  0 O D  1\
 C  1 C  o U  0 O D  1 C  U I  D C  0 O  U I  0 0 1  0 O 0  0 0 P  0 0\
 o  0 0 1  0 0 O  U I  o U  0 O D  o U  o U  0 O D  1 C  o U  1 C  o U\
  1 C  1 C  o U  0 O D  0 O  U I  0 O D  0 O I  U I  D U  D P  U I  1 \
D  U I  D U  D P  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0 \
 U I  1 D  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1\
 D  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  0 O O  0 O 0  0\
 O I  U I  0 0 0  1 L  1 L  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1\
 1  U I  0 0 o  0 0 D  0 O 0  0 0 1  C o  0 O U  0 O 0  0 0 O  0 0 P  \
U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 0  U I  D L  0 O  U I \
 0 0 D  0 0 P  0 0 1  U I  P 0  U I  U C  U D  P C  L L  L 1  o o  D 0\
  L D  U C  0 O  U I  0 0 D  0 0 P  0 0 1  U I  1 U  P 0  U I  U C  C \
I  0 0 O  U D  P C  L L  L 1  1 D  L L  1 D  L U  L 1  L I  P C  P D  \
o o  1 D  o U  o L  o O  D L  L O  L I  o C  o 0  L I  P D  o o  1 D  \
o U  P L  P 0  1 C  1 1  P P  P D  o L  P L  L o  o U  P L  L 1  o I  \
P 0  D 0  D 1  1 C  D P  1 C  D 1  U C  0 O  U I  0 0 D  0 0 P  0 0 1 \
 U I  1 U  P 0  U I  U C  C I  0 0 O  U C  U I  1 U  U I  0 0 o  0 0 1\
  0 O L  U I  1 U  U I  U C  U L  C L  0 I 0  0 0 P  0 O 0  0 0 D  P 0\
  1 L  1 D  D O  1 L  1 L  1 L  1 L  1 L  U C  0 O  U I  0 O D  0 O D \
 0 O D  o U  0 O D  U I  P 0  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 I \
 C o  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 \
O  U I  0 0 0  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  o \
C  o C  0 0 0  U I  1 1  U I  U C  0 0 P  0 O 0  0 0 D  0 0 P  0 O I  \
0 O D  0 O L  0 O 0  1 P  0 O C  D 0  0 0 o  U C  U I  1 0  0 O  U I  \
0 0 D  0 0 P  0 0 1  U I  1 U  P 0  U I  U C  C I  0 0 O  U C  0 O  U \
I  0 O D  0 O D  1 C  1 C  1 C  o U  0 O D  0 O D  0 O D  U I  1 O  U \
I  0 O D  0 O D  0 O D  o U  0 O D  U I  1 1  U I  0 0 D  0 0 P  0 0 1\
  U I  1 0  0 O  U I  0 O D  0 O I  U I  D U  D I  U I  1 D  U I  D U \
 D I  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I\
  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  U o  U I  0 0 0  o C  1 \
L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  0 0 1  0 O 0  0 0 P  \
0 0 o  0 0 1  0 0 O  U I  0 O D  0 O D  0 O D  o U  0 O D  0 O  U I  0\
 O D  0 O I  U I  D o  D O  U I  1 D  U I  D o  D O  D L  U I  o U  1 \
C  o U  0 O D  1 C  1 C  1 C  U I  1 I  U I  o C  0 0 0  0 0 0  0 0 0 \
 1 L  1 L  1 L  1 L  0 O  0 O O  0 O 0  0 O I  U I  0 O D  0 O D  1 C \
 1 C  1 C  o U  0 O D  0 O D  0 O D  U I  1 O  U I  0 O I  0 O D  0 O \
L  0 O 0  C D  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 0 I  C o  0 \
O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U I  1 1  U I  C o  0 0 I  0 \
0 I  0 O 0  0 0 O  0 O O  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0\
  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  C o  0 0 I  0 0 I  \
0 O 0  0 0 O  0 O O  U I  D L  0 O  U I  U I  0 0 0  o C  U I  P 0  U \
I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  0 O I  0 O D  0 O L  0 O\
 0  C D  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  U C  C o  U C  U I  \
1 0  0 O  U I  U I  0 0 0  o C  U I  1 P  U I  0 0 C  0 0 1  0 O D  0 \
0 P  0 O 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  \
0 0 P  C o  U I  1 0  0 O  U I  U I  0 0 0  o C  U I  1 P  U I  C C  0\
 O L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  0 O 0  0 O L \
 0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 0 0  o C  U I  P 0  U I  0 0\
 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  0 O I  0 O D  0 O L  0 O 0  C \
D  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  U C  0 0 C  C L  U C  U I \
 1 0  0 O  U I  U I  0 0 0  o C  U I  1 P  U I  0 0 C  0 0 1  0 O D  0\
 0 P  0 O 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o \
 0 0 P  C o  U I  1 0  0 O  U I  U I  0 0 0  o C  U I  1 P  U I  C C  \
0 O L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  U I  0 0 1  \
0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  U C  U C  0 O  U I  U I  0 O D\
  0 O I  U I  D 0  D U  U I  1 D  U I  D 0  D U  D L  U I  0 0 0  0 0 \
0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  0 O O  0 O 0  0 O I  U I \
 0 0 0  0 0 0  o C  U I  1 O  U I  0 O I  0 O D  0 O L  0 O 0  C D  0 \
0 O  C o  0 O C  0 O 0  U I  1 0  U I  D L  0 O  U I  0 0 0  o C  U I \
 P 0  U I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  0 O I  0 O D  0 \
O L  0 O 0  C D  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  U C  0 0 1  \
C L  U C  U I  1 0  0 O  U I  0 0 0  1 L  o C  o C  o C  o C  o C  1 L\
  o C  U I  P 0  U I  0 0 0  o C  U I  1 P  U I  0 0 1  0 O 0  C o  0 \
O O  U I  1 O  U I  1 0  0 O  U I  0 0 0  o C  U I  1 P  U I  C C  0 O\
 L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  0 0 1  0 O 0  0\
 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 0  1 L  o C  o C  o C  o C  o C  1\
 L  o C  0 O  U I  0 O D  0 O I  U I  D U  D U  U I  1 D  U I  D U  D \
U  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  0 O O  0 O 0  0 O I  U \
I  0 0 0  1 L  0 0 0  1 L  o C  0 0 0  o C  o C  o C  o C  o C  0 0 0 \
 U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o \
 U I  1 0  U I  D L  0 O  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 \
P  U I  0 0 1  0 O 0  U I  1 1  U I  C L  C o  0 0 D  0 O 0  D 1  D I \
 U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  D C  0 O \
 U I  o U  0 O D  1 C  1 C  0 O D  0 O D  0 O D  1 C  o U  o U  1 C  0\
 O D  U I  P 0  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P \
 C o  0 O  U I  0 0 C  0 O 1  0 O D  0 O L  0 O 0  U I  U C  0 O U  0 \
O 0  0 O 1  1 O  U C  U I  0 O D  0 0 O  U I  o U  0 O D  1 C  1 C  0 \
O D  0 O D  0 O D  1 C  o U  o U  1 C  0 O D  U I  D L  0 O  U I  U I \
 0 O D  0 O I  U I  o U  0 O D  1 C  1 C  0 O D  0 O D  0 O D  1 C  o \
U  o U  1 C  0 O D  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 \
0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  0 O L  0 0 0  0 O\
 L  1 O  U C  U I  1 0  U I  D L  U I  o U  0 O D  1 C  1 C  0 O D  0 \
O D  0 O D  1 C  o U  o U  1 C  0 O D  U I  P 0  U I  o U  0 O D  1 C \
 1 C  0 O D  0 O D  0 O D  1 C  o U  o U  1 C  0 O D  U I  C 0  U I  D\
 U  U I  D L  U I  1 D  U I  1 C  U I  C U  0 O  U I  U I  0 O D  0 O \
I  U I  D 1  D U  U I  1 D  U I  D 1  D U  D L  U I  0 O D  1 C  1 C  \
o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 U  U I \
 o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 D  U I  o C  o C  0 0 0  \
0 0 0  o C  o C  0 0 0  0 O  U I  U I  o U  0 O D  1 C  1 C  0 O D  0 \
O D  0 O D  1 C  o U  o U  1 C  0 O D  U I  P 0  U I  0 0 1  0 O 0  U \
I  1 P  U I  C C  0 0 0  0 O C  0 0 I  0 O D  0 O L  0 O 0  U I  1 O  \
U I  U C  U 1  1 O  1 P  1 I  P U  1 0  U 1  U C  U I  1 0  U I  1 P  \
U I  0 O I  0 O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 O  U I  o U\
  0 O D  1 C  1 C  0 O D  0 O D  0 O D  1 C  o U  o U  1 C  0 O D  U I\
  1 0  U I  C 0  U I  1 L  U I  C U  U I  D C  0 O  U I  U I  o U  0 O\
 D  1 C  1 C  0 O D  0 O D  0 O D  1 C  o U  o U  1 C  0 O D  U I  P 0\
  U I  C L  C o  0 0 D  0 O 0  D 1  D I  U I  1 P  U I  C L  D 1  D I \
 0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  o U  0 O D  1 \
C  1 C  0 O D  0 O D  0 O D  1 C  o U  o U  1 C  0 O D  U I  1 0  U I \
 D C  0 O  U I  U I  o U  0 O D  1 C  1 C  0 O D  0 O D  0 O D  1 C  o\
 U  o U  1 C  0 O D  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D \
 C L  U I  1 P  U I  0 0 o  0 0 O  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  \
U I  1 O  U I  o U  0 O D  1 C  1 C  0 O D  0 O D  0 O D  1 C  o U  o \
U  1 C  0 O D  U I  1 0  U I  D C  0 O  U I  0 0 I  0 0 1  0 O D  0 0 \
O  0 0 P  U I  o U  0 O D  1 C  1 C  0 O D  0 O D  0 O D  1 C  o U  o \
U  1 C  0 O D  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I\
  o U  0 O D  1 C  1 C  0 O D  0 O D  0 O D  1 C  o U  o U  1 C  0 O D\
  0 O  U I  0 O D  0 O I  U I  D U  1 C  U I  1 D  U I  D U  1 C  D L \
 U I  o U  0 O D  o U  o U  U I  1 U  U I  o U  o U  o U  o U  U I  1 \
o  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 D  U I \
 o U  1 C  1 C  0 O D  0 O  0 O O  0 O 0  0 O I  U I  0 0 0  o C  1 L \
 o C  1 L  0 0 0  o C  1 L  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C\
 D  0 O O  C o  0 0 P  C o  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I\
  U I  1 C  D U  U I  1 D  U I  1 C  D U  D L  U I  o C  0 0 0  0 0 0 \
 0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o\
 C  1 L  0 0 0  U I  U o  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1\
 L  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 P\
  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  0 0 0  1 L  0 0 0  0 0 0\
  o C  1 L  o C  o C  o C  U I  P 0  U I  0 0 0  o C  o C  o C  o C  U\
 I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U\
 I  1 0  U I  D C  0 O  U I  0 0 0  1 L  0 0 0  0 0 0  1 L  1 L  1 L  \
o C  0 0 0  o C  0 0 0  0 0 0  1 L  U I  P 0  U I  U C  1 O  0 O 1  0 \
0 P  0 0 P  0 0 I  1 P  1 I  1 0  U C  0 O  U I  0 O D  0 O C  0 0 I  \
0 0 0  0 0 1  0 0 P  U I  0 0 o  0 0 o  0 O D  0 O O  0 O  U I  o C  0\
 0 0  o C  1 L  0 0 0  U I  P 0  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U\
 I  0 0 o  0 0 o  0 O D  0 O O  U I  1 P  U I  0 0 o  0 0 o  0 O D  0 \
O O  1 C  U I  1 O  U I  1 0  U I  1 0  U I  1 P  U I  0 0 o  0 0 I  0\
 0 I  0 O 0  0 0 1  U I  1 O  U I  1 0  0 O  U I  0 O D  0 O D  0 O D \
 0 O D  o U  0 O D  o U  1 C  0 O D  1 C  o U  1 C  U I  P 0  U I  0 0\
 1  0 O 0  U I  1 P  U I  C C  0 0 0  0 O C  0 0 I  0 O D  0 O L  0 O \
0  U I  1 O  U I  0 0 0  1 L  0 0 0  0 0 0  1 L  1 L  1 L  o C  0 0 0 \
 o C  0 0 0  0 0 0  1 L  U I  1 0  U I  1 P  U I  0 O I  0 O D  0 0 O \
 0 O O  C o  0 O L  0 O L  U I  1 O  U I  0 0 0  1 L  0 0 0  0 0 0  o \
C  1 L  o C  o C  o C  U I  1 0  0 O  U I  0 0 0  0 0 0  1 L  U I  P 0\
  U I  C 0  U I  1 O  U I  U C  L L  1 D  L O  0 O L  C o  0 I 0  C L \
 C o  C C  0 O o  1 D  L U  0 O 0  0 0 D  0 0 D  0 O D  0 0 0  0 0 O  \
1 D  o U  0 O O  U C  U I  1 1  U I  o C  0 0 0  o C  1 L  0 0 0  U I \
 1 0  U I  C U  0 O  U I  0 O I  0 0 0  0 0 1  U I  0 O D  1 C  0 O D \
 o U  o U  0 O D  1 C  o U  o U  1 C  0 O D  0 O D  o U  U I  0 O D  0\
 0 O  U I  0 O D  0 O D  0 O D  0 O D  o U  0 O D  o U  1 C  0 O D  1 \
C  o U  1 C  U I  D L  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0\
 O  U I  U I  U I  o U  o U  o U  1 C  o U  0 O D  1 C  0 O D  1 C  o \
U  1 C  U I  P 0  U I  0 0 0  o C  o C  o C  o C  U I  1 O  U I  0 O D\
  1 C  0 O D  o U  o U  0 O D  1 C  o U  o U  1 C  0 O D  0 O D  o U  \
U I  1 1  U I  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  0 0 D  U I  P 0\
  U I  0 0 0  0 0 0  1 L  U I  1 0  U I  D C  0 O  U I  U I  U I  0 O \
D  0 O I  U I  D o  D D  U I  1 D  U I  D o  D D  D L  U I  0 O D  1 C\
  U I  1 P  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 \
D  U I  0 O D  1 C  U I  1 U  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O\
 D  U I  1 I  U I  o U  0 O D  1 C  o U  0 O  U I  U I  0 O 0  0 I O  \
C C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O\
  U I  U I  0 O D  0 O I  U I  1 C  1 L  U I  1 D  U I  1 C  1 L  D L \
 U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C\
  0 O D  U I  1 U  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  U o  U I  o \
C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I  0 O D  o U  o U \
 1 C  1 C  1 C  0 O D  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 \
0 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U I  \
1 U  U I  U C  0 I 1  U L  L L  1 D  L O  0 O L  C o  0 I 0  C L  C o \
 C C  0 O o  1 D  L U  0 O 0  0 0 D  0 0 D  0 O D  0 0 0  0 0 O  1 D  \
o U  0 O O  P 0  U C  U I  1 U  U I  o C  0 0 0  o C  1 L  0 0 0  0 O \
 U I  0 O D  0 O I  U I  D D  1 L  U I  1 D  U I  D D  1 L  D L  U I  \
o C  1 L  0 0 0  o C  U I  1 D  U I  0 O D  0 O D  o U  1 C  0 O D  o \
U  0 O D  o U  0 O  U I  0 O D  0 O I  U I  D O  U I  1 D  U I  D O  D\
 L  U I  0 0 0  o C  1 L  0 0 0  0 O  0 O O  0 O 0  0 O I  U I  0 O D \
 0 O D  0 O D  0 O D  1 C  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C \
D  0 O O  C o  0 0 P  C o  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I \
 U I  D 1  D 1  U I  1 D  U I  D 1  D 1  D L  U I  o U  o U  o U  o U \
 U I  1 I  U I  0 0 0  o C  1 L  0 0 0  U I  U o  U I  0 0 0  o C  1 L\
  0 0 0  U I  1 I  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I\
  1 D  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U \
I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  0 O D  0 O I  \
U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U I  1 P  \
U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O \
1  U I  1 O  U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  D L  1 o  1 o  0 O \
O  C o  0 O U  1 P  0 0 P  0 0 0  0 0 P  C o  0 O L  1 D  0 0 D  0 0 P\
  0 0 1  0 O 0  C o  0 O C  1 P  0 0 O  0 O 0  0 0 P  U C  U I  1 0  U\
 I  D L  0 O  U I  U I  0 0 0  0 0 0  1 L  U I  P 0  U I  C 0  U I  1 \
O  U I  U C  L D  0 0 D  0 O 0  0 0 1  1 D  P D  0 O U  0 O 0  0 0 O  \
0 0 P  U C  U I  1 1  U I  U C  L P  0 O 0  0 0 1  0 O D  0 0 D  0 O C\
  0 0 0  1 D  P P  0 O L  C o  C C  0 O o  L D  o U  C D  1 O  D O  1 \
P  D I  1 P  D D  1 P  D U  1 P  D P  1 P  1 L  1 P  D 0  D I  1 0  U \
C  U I  1 0  U I  C U  0 O  U I  U I  0 0 I  C o  0 O U  0 O 0  C D  0\
 O O  C o  0 0 P  C o  U I  P 0  U I  0 0 0  o C  o C  o C  o C  U I  \
1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U I  \
1 1  U I  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  0 0 D  U I  P 0  U I\
  0 0 0  0 0 0  1 L  U I  1 0  U I  D C  0 O  U I  U I  0 O D  0 O I  \
U I  D D  1 L  U I  1 D  U I  D D  1 L  D L  U I  0 O D  1 C  U I  1 U\
  U I  o U  o U  o U  o U  0 O  U I  0 O D  0 O I  U I  U C  1 C  D O \
 D D  1 P  1 L  1 P  1 L  1 P  1 C  U C  U I  0 O D  0 0 O  U I  0 0 I\
  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U I  D L  0 O  U I  \
U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 0  1 L  1 L  0\
 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D \
 0 O O  C o  0 0 P  C o  U I  1 0  0 O  U I  0 O 0  0 O L  0 O D  0 O \
I  U I  o C  o C  0 0 0  o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 0 I \
 C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U I  1 1  U I  U C  0\
 0 C  0 O C  0 0 D  P D  0 0 o  0 0 P  0 O 1  L U  0 O D  0 O U  0 0 O\
  U o  D 0  P L  1 O  C 0  C 1  U o  U L  C U  1 U  1 0  U C  U I  1 0\
  U I  U U  P 0  U I  U C  U C  U I  D L  0 O  U I  U I  0 O D  1 C  0\
 O D  1 C  o U  0 O D  o U  0 O D  1 C  U I  P 0  U I  o C  o C  0 0 0\
  o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D\
  0 O O  C o  0 0 P  C o  U I  1 1  U I  U C  U L  0 0 L  0 O 0  0 0 1\
  C D  0 0 P  P 0  1 O  C 0  C 1  U L  C U  1 U  1 0  U L  U C  U I  1\
 0  U I  1 U  U I  U C  P U  0 0 C  0 O C  0 0 D  P D  0 0 o  0 0 P  0\
 O 1  L U  0 O D  0 O U  0 0 O  P 0  U C  U I  1 U  U I  o C  o C  0 0\
 0  o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C\
 D  0 O O  C o  0 0 P  C o  U I  1 1  U I  U C  0 0 C  0 O C  0 0 D  P\
 D  0 0 o  0 0 P  0 O 1  L U  0 O D  0 O U  0 0 O  U o  D 0  P L  1 O \
 C 0  C 1  U o  U L  C U  1 U  1 0  U C  U I  1 0  U I  1 U  U I  U C \
 P 0  P 0  1 o  0 O C  0 0 I  D I  D L  U C  U I  1 U  U I  o C  o C  \
0 0 0  o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0\
  C D  0 O O  C o  0 0 P  C o  U I  1 1  U I  U C  C I  C I  P U  0 I \
0  P 0  1 O  C 0  C 1  U L  C U  1 U  1 0  U L  U C  U I  1 0  0 O  U \
I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 O D  1 C  0 \
O D  1 C  o U  0 O D  o U  0 O D  1 C  U I  P 0  U I  o C  o C  0 0 0 \
 o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D \
 0 O O  C o  0 0 P  C o  U I  1 1  U I  U C  0 O 1  0 0 1  0 O 0  0 O \
I  P 0  U 1  1 O  C 0  C 1  U 1  C U  1 U  1 0  U 1  C 0  C 1  U 1  C \
U  1 U  U P  U C  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  0 O L  0\
 O 0  0 0 O  U I  1 O  U I  0 O D  1 C  0 O D  1 C  o U  0 O D  o U  0\
 O D  1 C  U I  1 0  U I  P 0  P 0  U I  1 L  U I  D L  0 O  U I  U I \
 U I  0 O D  1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1 C  U I  P 0  U\
 I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o  0 O  U I  0\
 O D  1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1 C  U I  P 0  U I  0 O\
 D  1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1 C  U I  1 P  U I  0 0 1\
  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  U I  U C  \
U I  1 1  U I  U C  U o  D O  1 L  U C  U I  1 0  0 O  U I  0 0 1  0 O\
 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 O D  1 C  0 O D  1 C  o U  0 O \
D  o U  0 O D  1 C  0 O  U I  0 O D  0 O I  U I  D O  D O  U I  1 D  U\
 I  D O  D O  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 I  U I  o \
U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 P  U I  o\
 U  0 O D  1 C  o U  U I  1 D  U I  o U  1 C  o U  0 O D  1 C  1 C  1 \
C  0 O  0 O O  0 O 0  0 O I  U I  o C  o C  0 0 0  o C  0 0 0  o C  0 \
0 0  U I  1 O  U I  0 O O  C o  0 0 P  C o  U I  1 1  U I  0 0 1  0 O \
0  C D  0 0 I  C o  0 0 P  0 0 P  0 O 0  0 0 O  U I  1 0  U I  D L  0 \
O  U I  0 0 0  o C  0 0 0  1 L  U I  P 0  U I  U C  U C  0 O  U I  0 O\
 D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  P 0  U I  0 0 1  0 O 0\
  U I  1 P  U I  0 0 D  0 O 0  C o  0 0 1  C C  0 O 1  U I  1 O  U I  \
0 0 1  0 O 0  C D  0 0 I  C o  0 0 P  0 0 P  0 O 0  0 0 O  U I  1 1  U\
 I  0 O O  C o  0 0 P  C o  U I  1 0  0 O  U I  0 O D  0 O I  U I  0 O\
 D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  U U  P 0  U I  o L  0 \
0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  0 0 0  o C  0 0 0  1 L  U \
I  P 0  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  1 P  U\
 I  0 O U  0 0 1  0 0 0  0 0 o  0 0 I  U I  1 O  U I  1 C  U I  1 0  0\
 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 0 0  o\
 C  0 0 0  1 L  U I  P 0  U I  U C  U C  0 O  U I  0 0 1  0 O 0  0 0 P\
  0 0 o  0 0 1  0 0 O  U I  0 0 0  o C  0 0 0  1 L  0 O  U I  0 O D  0\
 O I  U I  D o  1 L  U I  1 D  U I  D o  1 L  D L  U I  o U  o U  o U \
 o U  0 O  0 O O  0 O 0  0 O I  U I  0 0 0  1 L  1 L  0 0 0  0 0 0  0 \
0 0  1 L  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 \
0 P  C o  U I  1 0  U I  D L  0 O  U I  0 O D  1 C  0 O D  1 C  o U  0\
 O D  o U  0 O D  1 C  U I  P 0  U I  U C  U C  0 O  U I  0 O D  0 O I\
  U I  U C  1 C  D O  D D  1 P  1 L  1 P  1 L  1 P  1 C  U C  U I  0 O\
 D  0 0 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o \
 U I  D L  0 O  U I  U I  0 O D  1 C  0 O D  1 C  o U  0 O D  o U  0 O\
 D  1 C  U I  P 0  U I  o C  o C  0 0 0  o C  0 0 0  o C  0 0 0  U I  \
1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U I  \
1 1  U I  U C  U L  0 0 L  0 O 0  0 0 1  C D  0 0 P  P 0  1 O  C 0  C \
1  U L  C U  1 U  1 0  U L  U C  U I  1 0  U I  1 U  U I  U C  U I  0 \
O L  0 O D  0 0 L  0 O 0  P 0  0 0 P  0 0 1  0 0 o  0 O 0  U I  0 0 P \
 0 O D  0 O C  0 O 0  0 0 0  0 0 o  0 0 P  P 0  1 C  D U  U I  0 0 I  \
0 O L  C o  0 I 0  0 0 I  C o  0 0 P  0 O 1  P 0  U C  U I  1 U  U I  \
o C  o C  0 0 0  o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 0 I  C o  0 \
O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U I  1 1  U I  U C  C I  C I \
 P U  0 I 0  P 0  1 O  C 0  C o  1 D  0 I I  P D  1 D  C O  1 L  1 D  \
D o  1 D  C D  C I  C I  1 P  P 1  C U  1 U  1 0  U C  U I  1 0  0 O  \
U I  U I  0 O D  0 O I  U I  D o  D I  U I  1 D  U I  D o  D I  D L  U\
 I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I  0 0 0  o C  1 L  0 0 0\
  1 L  0 0 0  0 0 0  o C  1 L  U I  1 I  U I  0 O D  1 C  U I  1 D  U \
I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I  0 O D  0 O I  \
U I  o C  o C  0 0 0  o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 0 I  C \
o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U I  1 1  U I  U C  0 0 \
P  0 0 0  0 O o  0 O 0  0 0 O  P 0  1 O  C 0  C 1  U L  C U  1 U  1 0 \
 U L  U C  U I  1 0  U I  U U  P 0  U I  U C  U C  U I  D L  0 O  U I \
 U I  0 O D  1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1 C  U I  P 0  U\
 I  0 O D  1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1 C  U I  1 U  U I\
  U C  P U  0 0 P  0 0 0  0 O o  0 O 0  0 0 O  P 0  U C  U I  1 U  U I\
  o C  o C  0 0 0  o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 0 I  C o  \
0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U I  1 1  U I  U C  0 0 P  \
0 0 0  0 O o  0 O 0  0 0 O  P 0  1 O  C 0  C 1  U L  C U  1 U  1 0  U \
L  U C  U I  1 0  0 O  U I  0 O 0  0 O L  0 O D  0 O I  U I  o C  o C \
 0 0 0  o C  0 0 0  o C  0 0 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O \
0  C D  0 O O  C o  0 0 P  C o  U I  1 1  U I  U C  0 0 C  0 O C  0 0 \
D  P D  0 0 o  0 0 P  0 O 1  L U  0 O D  0 O U  0 0 O  U o  D 0  P L  \
1 O  C 0  C 1  U o  U L  C U  1 U  1 0  U C  U I  1 0  U I  U U  P 0  \
U I  U C  U C  U I  D L  0 O  U I  U I  0 O D  1 C  0 O D  1 C  o U  0\
 O D  o U  0 O D  1 C  U I  P 0  U I  o C  o C  0 0 0  o C  0 0 0  o C\
  0 0 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0\
 P  C o  U I  1 1  U I  U C  U L  0 0 L  0 O 0  0 0 1  C D  0 0 P  P 0\
  1 O  C 0  C 1  U L  C U  1 U  1 0  U L  U C  U I  1 0  U I  1 U  U I\
  U C  P U  0 0 C  0 O C  0 0 D  P D  0 0 o  0 0 P  0 O 1  L U  0 O D \
 0 O U  0 0 O  P 0  U C  U I  1 U  U I  o C  o C  0 0 0  o C  0 0 0  o\
 C  0 0 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0\
 0 P  C o  U I  1 1  U I  U C  0 0 C  0 O C  0 0 D  P D  0 0 o  0 0 P \
 0 O 1  L U  0 O D  0 O U  0 0 O  U o  D 0  P L  1 O  C 0  C 1  U o  U\
 L  C U  1 U  1 0  U C  U I  1 0  U I  1 U  U I  U C  P 0  P 0  1 o  0\
 O C  0 0 I  D I  D L  U C  U I  1 U  U I  o C  o C  0 0 0  o C  0 0 0\
  o C  0 0 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o\
  0 0 P  C o  U I  1 1  U I  U C  C I  C I  P U  0 I 0  P 0  1 O  C 0 \
 C 1  U L  C U  1 U  1 0  U L  U C  U I  1 0  0 O  U I  0 O 0  0 O L  \
0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 O D  1 C  0 O D  1 C  o U  0 \
O D  o U  0 O D  1 C  U I  P 0  U I  o C  o C  0 0 0  o C  0 0 0  o C \
 0 0 0  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 \
P  C o  U I  1 1  U I  U C  o I  L I  P C  o O  P 0  U 1  1 O  C 0  C \
1  U 1  C U  1 U  1 0  U 1  U C  U I  1 0  0 O  U I  U I  0 O D  0 O I\
  U I  D I  D I  U I  1 D  U I  D I  D I  D L  U I  0 O D  1 C  1 C  o\
 U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  U o  U I  \
0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 D  U I  0 O \
D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 I  U I  0 0 0  o C \
 1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  o U  0 O D  o\
 U  o U  U I  1 I  U I  o C  1 L  0 0 0  o C  0 O  U I  0 O D  0 O I  \
U I  U C  0 O O  C o  0 O U  1 C  1 P  C o  0 0 D  0 I O  U C  U I  0 \
O D  0 0 O  U I  0 O D  1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1 C  \
U I  D L  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I\
  0 O D  0 O D  0 O D  0 O D  1 C  U I  1 O  U I  0 O D  1 C  0 O D  1\
 C  o U  0 O D  o U  0 O D  1 C  U I  1 0  0 O  U I  U I  0 O D  0 O I\
  U I  D I  1 C  U I  1 D  U I  D I  1 C  D L  U I  o U  o U  0 O D  o\
 U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U I  o C  0 0 0  0 0 0\
  0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  \
o C  1 L  0 0 0  U I  1 P  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C \
 o U  1 C  o U  0 O D  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  U C  0\
 O O  0 O 0  0 0 L  0 O D  0 0 O  0 O L  0 O D  0 0 L  0 O 0  0 O I  0\
 0 D  1 P  0 O I  0 0 I  0 O L  0 O D  0 0 L  0 O 0  1 P  0 0 O  0 O 0\
  0 0 P  U C  U I  0 0 O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  0 O D \
 1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1 C  U I  D L  0 O  U I  U I\
  0 O D  1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1 C  U I  P 0  U I  \
0 O D  1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1 C  U I  1 P  U I  0 \
0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  0 O O  \
0 O 0  0 0 L  0 O D  0 0 O  0 O L  0 O D  0 0 L  0 O 0  U C  U I  1 1 \
 U I  U C  0 O I  0 O L  0 O D  0 0 L  0 O 0  U C  U I  1 0  0 O  U I \
 0 O D  0 O I  U I  U C  0 0 I  0 O 0  0 0 1  0 O C  0 O L  0 O D  0 0\
 L  0 O 0  0 O I  0 0 D  1 P  0 O I  0 0 I  0 O L  0 O D  0 0 L  0 O 0\
  1 P  0 0 O  0 O 0  0 0 P  U C  U I  0 0 O  0 0 0  0 0 P  U I  0 O D \
 0 0 O  U I  0 O D  1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1 C  U I \
 D L  0 O  U I  U I  0 O D  1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1\
 C  U I  P 0  U I  0 O D  1 C  0 O D  1 C  o U  0 O D  o U  0 O D  1 C\
  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O\
  U I  U C  0 0 I  0 O 0  0 0 1  0 O C  0 O L  0 O D  0 0 L  0 O 0  U \
C  U I  1 1  U I  U C  0 O I  0 O L  0 O D  0 0 L  0 O 0  U C  U I  1 \
0  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 O D  1 C\
  0 O D  1 C  o U  0 O D  o U  0 O D  1 C  0 O  U I  0 O D  0 O I  U I\
  D 1  D U  U I  1 D  U I  D 1  D U  D L  U I  o U  0 O D  o U  o U  U\
 I  1 P  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  0 O D\
  0 O I  U I  D D  1 L  U I  1 D  U I  D D  1 L  D L  U I  o U  0 O D \
 o U  o U  U I  1 D  U I  o U  o U  o U  o U  U I  1 P  U I  0 0 0  o \
C  1 L  0 0 0  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U\
 I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  o U  o U\
  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  0 O O  0 O 0  0 O\
 I  U I  0 0 0  1 L  o C  1 L  0 0 0  0 0 0  1 L  0 0 0  U I  1 O  U I\
  0 0 D  0 0 P  0 0 1  C D  0 O 0  0 0 L  C o  0 O L  U I  1 0  U I  D\
 L  0 O  U I  o U  o U  1 C  1 C  0 O D  o U  1 C  0 O D  0 O D  o U  \
U I  P 0  U I  U 1  U 1  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O \
 U I  U I  o U  1 C  U I  P 0  U I  U 1  0 0 C  1 1  0 O D  1 1  0 0 D\
  1 1  0 O 0  P 0  1 O  U 1  U I  1 U  U I  0 0 D  0 0 P  0 0 1  C D  \
0 O 0  0 0 L  C o  0 O L  U I  1 U  U I  U C  1 0  U C  0 O  U I  U I \
 0 O 0  0 I O  0 O 0  C C  U I  1 O  U I  o U  1 C  U I  1 0  0 O  U I\
  U I  o U  o U  1 C  1 C  0 O D  o U  1 C  0 O D  0 O D  o U  U I  P \
0  U I  0 O D  0 O D  0 0 0  o C  1 L  0 0 0  U I  1 O  U I  0 0 C  U \
I  1 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 \
0  0 0 0  U I  1 1  U I  o U  0 O D  1 C  1 C  0 O D  0 O D  0 O D  1 \
C  o U  o U  1 C  0 O D  U I  1 1  U I  0 O 0  U I  1 0  0 O  U I  0 O\
 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 P  0 0 1  C o \
 C C  0 O 0  C L  C o  C C  0 O o  U I  1 P  U I  0 0 I  0 0 1  0 O D \
 0 0 O  0 0 P  C D  0 O 0  0 I O  C C  U I  1 O  U I  0 O I  0 O D  0 \
O L  0 O 0  U I  P 0  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  0 0 D  \
0 0 P  0 O O  0 0 0  0 0 o  0 0 P  U I  1 0  0 O  U I  0 O D  0 O I  U\
 I  D U  1 L  U I  1 D  U I  D U  1 L  D L  U I  0 O D  0 O D  o U  1 \
C  0 O D  o U  0 O D  o U  U I  1 o  U I  0 O D  0 O D  o U  1 C  0 O \
D  o U  0 O D  o U  U I  1 U  U I  o C  1 L  0 0 0  o C  U I  1 I  U I\
  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 o  U I  0 0 0  \
o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  0 0 1  0 O 0  \
0 0 P  0 0 o  0 0 1  0 0 O  U I  o U  o U  1 C  1 C  0 O D  o U  1 C  \
0 O D  0 O D  o U  0 O  U I  0 O D  0 O I  U I  1 C  D I  U I  1 D  U \
I  1 C  D I  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C\
  o U  0 O D  1 C  0 O D  U I  U o  U I  0 O D  o U  o U  1 C  1 C  1 \
C  0 O D  U I  1 D  U I  0 0 0  o C  1 L  0 0 0  U I  1 P  U I  o C  1\
 L  0 0 0  o C  U I  1 U  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U \
I  1 D  U I  0 O D  1 C  0 O  0 O O  0 O 0  0 O I  U I  0 O D  0 O D  \
0 0 0  o C  1 L  0 0 0  U I  1 O  U I  0 0 C  U I  1 1  U I  0 O D  U \
I  1 1  U I  0 0 D  U I  1 1  U I  0 O 0  U I  1 0  U I  D L  0 O  U I\
  0 O D  o U  1 C  0 O D  o U  0 O D  0 O D  0 O D  o U  1 C  o U  1 C\
  U I  P 0  U I  1 L  U I  D C  0 O  U I  o C  o C  o C  o C  U I  P 0\
  U I  1 L  U I  D C  0 O  U I  o C  0 0 0  o U  1 C  o U  0 O D  0 O \
D  0 O D  o U  0 O D  o U  U I  P 0  U I  1 L  U I  D C  0 O  U I  o C\
  1 L  o C  0 0 0  U I  P 0  U I  C 0  U I  C U  U I  D C  0 O  U I  o\
 U  1 C  o U  0 O D  1 C  0 O D  o U  0 O D  o U  o U  U I  P 0  U I  \
C 0  U I  C U  U I  D C  0 O  U I  0 0 C  0 O 1  0 O D  0 O L  0 O 0  \
U I  L 1  0 0 1  0 0 o  0 O 0  U I  D L  0 O  U I  U I  0 O D  0 O I  \
U I  1 O  U I  0 O D  o U  1 C  0 O D  o U  0 O D  0 O D  0 O D  o U  \
1 C  o U  1 C  U I  P O  U I  D U  U I  1 0  U I  D L  0 O  U I  U I  \
U I  o U  1 C  o U  0 O D  1 C  0 O D  o U  0 O D  o U  o U  U I  1 P \
 U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  0 0 C  U \
I  C 0  U I  0 O D  o U  1 C  0 O D  o U  0 O D  0 O D  0 O D  o U  1 \
C  o U  1 C  U I  C U  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 O D  0\
 O I  U I  1 O  U I  0 O D  o U  1 C  0 O D  o U  0 O D  0 O D  0 O D \
 o U  1 C  o U  1 C  U I  P O  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I\
  0 0 C  U I  1 0  U I  1 0  U I  D L  0 O  U I  U I  U I  o C  1 L  o\
 C  0 0 0  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I \
 1 O  U I  0 0 C  U I  C 0  U I  0 O D  o U  1 C  0 O D  o U  0 O D  0\
 O D  0 O D  o U  1 C  o U  1 C  U I  C U  U I  1 0  U I  D C  0 O  U \
I  U I  0 O D  o U  1 C  0 O D  o U  0 O D  0 O D  0 O D  o U  1 C  o \
U  1 C  U I  1 U  P 0  U I  1 C  U I  D C  0 O  U I  U I  0 O D  0 O I\
  U I  1 O  U I  o C  o C  o C  o C  U I  P O  U I  D U  U I  1 0  U I\
  D L  0 O  U I  U I  U I  o U  1 C  o U  0 O D  1 C  0 O D  o U  0 O \
D  o U  o U  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U \
I  1 O  U I  0 O D  U I  C 0  U I  o C  o C  o C  o C  U I  C U  U I  \
1 0  0 O  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  1 O  U I  o C  o \
C  o C  o C  U I  P O  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 O D \
 U I  1 0  U I  1 0  U I  D L  0 O  U I  U I  U I  o C  1 L  o C  0 0 \
0  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U \
I  0 O D  U I  C 0  U I  o C  o C  o C  o C  U I  C U  U I  1 0  0 O  \
U I  U I  o C  o C  o C  o C  U I  1 U  P 0  U I  1 C  U I  D C  0 O  \
U I  U I  0 O D  0 O I  U I  1 O  U I  o C  0 0 0  o U  1 C  o U  0 O \
D  0 O D  0 O D  o U  0 O D  o U  U I  P O  U I  D U  U I  1 0  U I  D\
 L  0 O  U I  U I  U I  o U  1 C  o U  0 O D  1 C  0 O D  o U  0 O D  \
o U  o U  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  \
1 O  U I  0 0 D  U I  C 0  U I  o C  0 0 0  o U  1 C  o U  0 O D  0 O \
D  0 O D  o U  0 O D  o U  U I  C U  U I  1 0  0 O  U I  U I  0 O 0  0\
 O L  0 O D  0 O I  U I  1 O  U I  o C  0 0 0  o U  1 C  o U  0 O D  0\
 O D  0 O D  o U  0 O D  o U  U I  P O  U I  0 O L  0 O 0  0 0 O  U I \
 1 O  U I  0 0 D  U I  1 0  U I  1 0  U I  D L  0 O  U I  U I  U I  o \
C  1 L  o C  0 0 0  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 \
O O  U I  1 O  U I  0 0 D  U I  C 0  U I  o C  0 0 0  o U  1 C  o U  0\
 O D  0 O D  0 O D  o U  0 O D  o U  U I  C U  U I  1 0  U I  D C  0 O\
  U I  U I  o C  0 0 0  o U  1 C  o U  0 O D  0 O D  0 O D  o U  0 O D\
  o U  U I  1 U  P 0  U I  1 C  U I  D C  0 O  U I  U I  0 O D  0 O I \
 U I  1 O  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 0 C  U I  1 0  U\
 I  1 U  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 O D  U I  1 0  U I\
  1 U  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 0 D  U I  1 0  U I  \
1 U  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 O 0  U I  1 0  U I  P \
0  P 0  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  o C  1 L  o C  0 0 0 \
 U I  1 0  U I  1 U  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  o U  1 C\
  o U  0 O D  1 C  0 O D  o U  0 O D  o U  o U  U I  1 0  U I  1 U  U \
I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 O 0  U I  1 0  U I  1 0  U I \
 D L  0 O  U I  U I  U I  C L  0 0 1  0 O 0  C o  0 O o  U I  D C  0 O\
  U I  U I  U I  0 O D  0 O I  U I  D P  1 C  U I  1 D  U I  D P  1 C \
 D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 P  U I  o C  o C  0 0 0\
  0 0 0  o C  o C  0 0 0  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C\
  1 L  0 0 0  U I  U o  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L\
  U I  1 P  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  0 0 0  1 L  0 \
0 0  1 L  U I  P 0  U I  U C  U C  U I  1 P  U I  0 O P  0 0 0  0 O D \
 0 0 O  U I  1 O  U I  o C  1 L  o C  0 0 0  U I  1 0  0 O  U I  0 O D\
  1 C  o U  0 O D  o U  o U  1 C  0 O D  1 C  o U  U I  P 0  U I  U C \
 U C  U I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I  o U  1\
 C  o U  0 O D  1 C  0 O D  o U  0 O D  o U  o U  U I  1 0  0 O  U I  \
o C  o C  o C  o C  U I  P 0  U I  1 L  U I  D C  0 O  U I  0 O D  o U\
  1 C  0 O D  0 O D  1 C  0 O D  0 O D  1 C  o U  U I  P 0  U I  C 0  \
U I  C U  U I  D C  0 O  U I  0 O I  0 0 0  0 0 1  U I  0 O D  o U  1 \
C  0 O D  o U  0 O D  0 O D  0 O D  o U  1 C  o U  1 C  U I  0 O D  0 \
0 O  U I  0 0 1  C o  0 0 O  0 O U  0 O 0  U I  1 O  U I  1 L  U I  1 \
1  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  o C  1 L  o C  0 0 0  U I \
 1 0  U I  1 1  U I  D O  U I  1 0  U I  D L  0 O  U I  U I  0 O D  0 \
O I  U I  1 C  D P  U I  1 D  U I  1 C  D P  D L  U I  o U  o U  o U  \
o U  U I  1 I  U I  o U  o U  o U  o U  U I  U o  U I  o U  o U  o U  \
o U  0 O  U I  U I  o U  0 O D  1 C  o U  1 C  o U  1 C  0 O D  1 C  1\
 C  0 O D  0 O D  U I  P 0  U I  1 D  U I  1 C  U I  D C  0 O  U I  U \
I  0 O D  0 O I  U I  1 O  U I  0 0 0  0 0 1  0 O O  U I  1 O  U I  0 \
O D  1 C  o U  0 O D  o U  o U  1 C  0 O D  1 C  o U  U I  C 0  U I  o\
 C  o C  o C  o C  U I  C U  U I  1 0  U I  U o  U I  D O  U I  1 0  U\
 I  D L  0 O  U I  U I  U I  o U  0 O D  1 C  o U  1 C  o U  1 C  0 O \
D  1 C  1 C  0 O D  0 O D  U I  P 0  U I  1 C  U I  D C  0 O  U I  U I\
  U I  0 O D  0 O I  U I  D U  D P  U I  1 D  U I  D U  D P  D L  U I \
 0 0 0  o C  1 L  0 0 0  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C \
 1 L  o C  1 L  1 L  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L\
  o C  1 L  1 L  U I  1 I  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C \
 o U  1 C  o U  0 O D  1 C  0 O D  U I  1 U  U I  0 0 0  1 L  1 L  o C\
  1 L  0 0 0  0 0 0  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L\
  0 0 0  0 O  U I  U I  0 O D  o U  1 C  0 O D  0 O D  1 C  0 O D  0 O\
 D  1 C  o U  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U\
 I  1 O  U I  C C  0 O 1  0 0 1  U I  1 O  U I  0 O D  0 0 O  0 0 P  U\
 I  1 O  U I  0 0 0  1 L  0 0 0  1 L  U I  C 0  U I  0 O D  o U  1 C  \
0 O D  o U  0 O D  0 O D  0 O D  o U  1 C  o U  1 C  U I  D L  U I  0 \
O D  o U  1 C  0 O D  o U  0 O D  0 O D  0 O D  o U  1 C  o U  1 C  U \
I  1 U  U I  D O  U I  C U  U I  1 1  U I  D 0  D 1  U I  1 0  U I  1 \
D  U I  o U  0 O D  1 C  o U  1 C  o U  1 C  0 O D  1 C  1 C  0 O D  0\
 O D  U I  1 0  U I  1 0  U I  D C  0 O  U I  U I  o C  o C  o C  o C \
 U I  1 U  P 0  U I  1 C  U I  D C  0 O  U I  U I  0 O D  0 O I  U I  \
1 O  U I  o C  o C  o C  o C  U I  P I  P 0  U I  0 O L  0 O 0  0 0 O \
 U I  1 O  U I  o U  1 C  o U  0 O D  1 C  0 O D  o U  0 O D  o U  o U\
  U I  1 0  U I  1 0  U I  D L  0 O  U I  U I  U I  o C  o C  o C  o C\
  U I  P 0  U I  1 L  U I  D C  0 O  U I  o U  0 O D  o U  o U  0 O D \
 1 C  o U  1 C  o U  1 C  1 C  o U  0 O D  U I  P 0  U I  U C  U C  U \
I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I  0 O D  o U  1 \
C  0 O D  0 O D  1 C  0 O D  0 O D  1 C  o U  U I  1 0  0 O  U I  0 O \
D  0 O I  U I  U C  0 O 0  0 0 L  C o  0 O L  1 O  0 O I  0 0 o  0 0 O\
  C C  0 0 P  0 O D  0 0 0  0 0 O  1 O  0 0 C  1 1  0 O D  1 1  0 0 D \
 1 1  0 O 0  1 0  U C  U I  0 O D  0 0 O  U I  o U  0 O D  o U  o U  0\
 O D  1 C  o U  1 C  o U  1 C  1 C  o U  0 O D  U I  D L  0 O  U I  U \
I  0 O D  0 O I  U I  D P  1 L  U I  1 D  U I  D P  1 L  D L  U I  o U\
  1 C  1 C  0 O D  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  \
o C  1 L  1 L  U I  1 D  U I  0 O D  1 C  U I  U o  U I  o U  0 O D  1\
 C  o U  U I  1 P  U I  o U  o U  o U  o U  0 O  U I  U I  o U  0 O D \
 o U  o U  0 O D  1 C  o U  1 C  o U  1 C  1 C  o U  0 O D  U I  P 0  \
U I  0 0 1  0 O 0  U I  1 P  U I  C C  0 0 0  0 O C  0 0 I  0 O D  0 O\
 L  0 O 0  U I  1 O  U I  U C  0 O 0  0 0 L  C o  0 O L  C I  1 O  0 O\
 I  0 0 o  0 0 O  C C  0 0 P  0 O D  0 0 0  0 0 O  C I  1 O  0 0 C  1 \
1  0 O D  1 1  0 0 D  1 1  0 O 0  C I  1 0  1 P  1 I  0 I D  C I  1 O \
 1 O  1 P  1 I  P U  1 0  C I  1 0  U C  U I  1 0  U I  1 P  U I  0 O \
I  0 O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 O  U I  o U  0 O D  \
o U  o U  0 O D  1 C  o U  1 C  o U  1 C  1 C  o U  0 O D  U I  1 0  U\
 I  C 0  U I  1 L  U I  C U  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o\
  0 0 1  0 0 O  U I  0 0 0  1 L  o C  1 L  0 0 0  0 0 0  1 L  0 0 0  U\
 I  1 O  U I  o U  0 O D  o U  o U  0 O D  1 C  o U  1 C  o U  1 C  1 \
C  o U  0 O D  U I  1 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D \
L  0 O  U I  U I  0 O D  0 O I  U I  1 C  1 L  U I  1 D  U I  1 C  1 L\
  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I  0 0 0  1 L  0 \
0 0  o C  1 L  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C \
 1 L  1 L  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U \
I  o U  0 O D  o U  o U  0 O D  1 C  o U  1 C  o U  1 C  1 C  o U  0 O\
 D  0 O  U I  U I  0 O D  0 O I  U I  D I  D 1  U I  1 D  U I  D I  D \
1  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 I  U I  o U  \
0 O D  o U  o U  U I  U o  U I  o U  o U  o U  o U  U I  1 U  U I  o U\
  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U I  0 \
0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  0 O O  0 O 0  0 O I  U I\
  0 0 0  o C  0 0 0  0 0 0  0 0 0  o C  1 L  1 L  1 L  o C  U I  1 O  \
U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U\
 I  1 1  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  C D  0 O I  0 0 0  0 \
0 1  C D  0 0 P  0 O 0  0 I O  0 0 P  U I  P 0  U I  U C  U C  U I  1 \
1  U I  0 O D  0 0 P  0 O 0  0 0 1  C o  0 0 P  0 O D  0 0 0  0 0 O  0\
 0 D  U I  P 0  U I  1 C  U I  1 1  U I  0 0 P  0 0 0  0 0 P  C o  0 O\
 L  C D  0 O D  0 0 P  0 O 0  0 0 1  C o  0 0 P  0 O D  0 0 0  0 0 O  \
U I  P 0  U I  1 C  U I  1 0  U I  D L  0 O  U I  0 0 P  0 0 1  0 I 0 \
 U I  D L  0 O  U I  U I  0 O D  0 O D  1 C  o U  1 C  1 C  0 O D  U I\
  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  U I  0 O D  0 O I  U I\
  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U I \
 1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P\
  0 O 1  U I  1 O  U I  U 1  0 O 1  0 0 P  0 0 P  0 0 I  U 1  U I  1 0\
  U I  D L  0 O  U I  U I  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  \
C o  0 O L  0 0 o  0 O 0  U I  P 0  U I  0 0 0  o C  o C  o C  o C  U \
I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  \
0 O 0  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D P  D o  U I \
 1 D  U I  D P  D o  D L  U I  0 O D  1 C  U I  1 P  U I  0 0 0  0 0 0\
  0 0 0  1 L  o C  0 0 0  1 L  U I  U o  U I  o U  0 O D  o U  o U  U \
I  1 P  U I  o U  0 O D  o U  o U  U I  1 D  U I  o C  o C  0 0 0  0 0\
 0  o C  o C  0 0 0  0 O  U I  U I  0 O D  0 O I  U I  0 0 1  0 O 0  0\
 O U  0 O 0  0 I O  C D  0 O I  0 0 0  0 0 1  C D  0 0 P  0 O 0  0 I O\
  0 0 P  U I  C o  0 0 O  0 O O  U I  0 O L  0 O 0  0 0 O  U I  1 O  U\
 I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  C D  0 O I  0 0 0  0 0 1  C D  \
0 0 P  0 O 0  0 I O  0 0 P  U I  1 0  U I  P I  U I  1 L  U I  D L  0 \
O  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U\
 I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U \
I  P 0  U I  0 0 1  0 O 0  U I  1 P  U I  C C  0 0 0  0 O C  0 0 I  0 \
O D  0 O L  0 O 0  U I  1 O  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  C\
 D  0 O I  0 0 0  0 0 1  C D  0 0 P  0 O 0  0 I O  0 0 P  U I  1 0  U \
I  1 P  U I  0 O I  0 O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 O  \
U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U\
 I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U I  U I  0 O 0  0 I \
O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 1  0 O 0  0 0 P  0 0 o\
  0 0 1  0 0 O  U I  U C  o L  o C  L 1  L O  P D  P o  o D  P C  P L \
 U C  0 O  U I  U I  U I  0 O D  0 O I  U I  D U  D 1  U I  1 D  U I  \
D U  D 1  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  0 0 I \
 C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U I  P 0  U \
I  o U  0 O D  o U  1 C  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D \
 0 0 L  C o  0 O L  0 0 o  0 O 0  U I  1 1  U I  0 O D  0 0 P  0 O 0  \
0 0 1  C o  0 0 P  0 O D  0 0 0  0 0 O  0 0 D  U I  1 1  U I  0 0 P  0\
 0 0  0 0 P  C o  0 O L  C D  0 O D  0 0 P  0 O 0  0 0 1  C o  0 0 P  \
0 O D  0 0 0  0 0 O  U I  1 0  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0\
 I  0 0 P  U I  D L  0 O  U I  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0\
 L  C o  0 O L  0 0 o  0 O 0  U I  P 0  U I  U C  L D  o L  L O  P D  \
P o  o D  P C  P L  o O  P D  o U  o P  P C  P L  U C  0 O  U I  U I  \
0 0 P  0 0 1  C o  C C  0 O 0  C L  C o  C C  0 O o  U I  1 P  U I  0 \
0 I  0 0 1  0 O D  0 0 O  0 0 P  C D  0 O 0  0 I O  C C  U I  1 O  U I\
  0 O I  0 O D  0 O L  0 O 0  U I  P 0  U I  0 0 D  0 I 0  0 0 D  U I \
 1 P  U I  0 0 D  0 0 P  0 O O  0 0 0  0 0 o  0 0 P  U I  1 0  0 O  U \
I  U I  0 O D  0 O I  U I  D U  D o  U I  1 D  U I  D U  D o  D L  U I\
  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I  o U  0 O D  o U  o U  U \
I  1 o  U I  o C  1 L  0 0 0  o C  U I  1 o  U I  o U  o U  0 O D  o U\
  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 o  U I  0 0 0  0 0 0  o C  \
0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 0 0  1 L  1 L  o C  1 L  0 0 \
0  0 0 0  0 O  U I  0 O D  0 O I  U I  U C  0 0 D  C o  0 0 L  1 C  0 \
O L  0 O D  0 0 L  0 O 0  1 P  0 0 P  0 0 L  U C  U I  0 O D  0 0 O  U\
 I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  U \
I  D L  0 O  U I  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  C o  0 O \
L  0 0 o  0 O 0  U I  P 0  U I  0 0 I  C o  0 O U  0 O 0  C D  0 0 L  \
C o  0 O L  0 0 o  0 O 0  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C\
 o  C C  0 O 0  U I  1 O  U I  U C  0 0 D  C o  0 0 L  1 C  0 O L  0 O\
 D  0 0 L  0 O 0  1 P  0 0 P  0 0 L  U C  U I  1 1  U I  U C  0 0 D  C\
 o  0 0 C  0 O L  0 O D  0 0 L  0 O 0  1 P  0 0 P  0 0 L  U C  U I  1 \
0  0 O  U I  U I  0 O D  0 O I  U I  1 C  D 0  U I  1 D  U I  1 C  D 0\
  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  o \
U  o U  o U  o U  U I  1 o  U I  0 O D  1 C  U I  U o  U I  0 O D  1 C\
  U I  U o  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O \
D  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 I  C o\
  0 O U  0 O 0  C D  0 0 L  C o  0 O L  0 0 o  0 O 0  0 O  U I  0 O D \
 0 O I  U I  D o  1 L  U I  1 D  U I  D o  1 L  D L  U I  0 0 0  0 0 0\
  0 0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  o C  0 0 0  0 0 0  0 0 0\
  1 L  1 L  1 L  1 L  U I  1 o  U I  0 0 0  o C  1 L  0 0 0  0 O  0 O \
O  0 O 0  0 O I  U I  o U  0 O D  o U  1 C  U I  1 O  U I  0 0 D  o 1 \
 C o  0 0 L  C o  0 0 D  C C  0 0 1  0 O D  0 0 I  0 0 P  U I  1 1  U \
I  0 O D  0 0 P  0 O 0  0 0 1  C o  0 0 P  0 O D  0 0 0  0 0 O  U I  P\
 0  U I  1 C  U I  1 1  U I  0 0 P  0 0 0  0 0 P  C o  0 O L  0 O D  0\
 0 P  0 O 0  0 0 1  C o  0 0 P  0 O D  0 0 0  0 0 O  0 0 D  U I  P 0  \
U I  D O  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  D O  D P  U\
 I  1 D  U I  D O  D P  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0\
  1 L  U I  1 U  U I  o U  o U  o U  o U  U I  1 D  U I  o C  0 0 0  0\
 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 o  U I  0 0 0  o C  1 L  0 0 0\
  U I  1 D  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  0 O \
D  0 O I  U I  0 0 D  o 1  C o  0 0 L  C o  0 0 D  C C  0 0 1  0 O D  \
0 0 I  0 0 P  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0\
 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  0 0 L  C o  0 0 1  U I \
 C D  1 L  0 I O  C C  C L  D P  C o  P 0  U C  U I  1 0  U I  D L  0 \
O  U I  U I  o U  0 O D  1 C  0 O D  1 C  U I  P 0  U I  0 0 D  o 1  C\
 o  0 0 L  C o  0 0 D  C C  0 0 1  0 O D  0 0 I  0 0 P  U I  1 P  U I \
 0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  0 0 L  C o  0 \
0 1  U I  C D  1 L  0 I O  C C  C L  D P  C o  P 0  U C  U I  1 0  0 O\
  U I  U I  o U  1 C  U I  P 0  U I  U 1  0 O C  0 I 0  C o  0 0 1  0 \
0 1  C o  0 I 0  P 0  U 1  U I  1 U  U I  o U  0 O D  1 C  0 O D  1 C \
 U I  C 0  U I  1 C  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O\
 D  0 0 P  U I  1 O  U I  U 1  0 O 0  0 0 L  C o  0 O L  1 O  U 1  U I\
  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U I  0 O 0  0 I O  0 O \
0  C C  U I  1 O  U I  o U  1 C  U I  1 0  0 O  U I  U I  0 0 0  o C  \
0 0 0  o C  1 L  1 L  0 O D  1 C  0 O D  U I  P 0  U I  D 1  D O  0 O \
 U I  U I  0 O D  1 C  0 O D  o U  o U  0 O D  1 C  1 C  0 O D  1 C  1\
 C  1 C  o U  U I  P 0  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  o U  \
0 O D  1 C  0 O D  1 C  U I  C 0  U I  1 C  U I  C U  U I  1 P  U I  0\
 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U 1  1 1  D 1  D O  1\
 1  U 1  U I  1 0  U I  C 0  U I  1 C  U I  C U  U I  1 P  U I  0 0 D \
 0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  1 1  U C  U I  1 0  U\
 I  C 0  U I  1 L  U I  C U  U I  1 0  0 O  U I  U I  0 O D  0 O D  0 \
O D  o U  0 O D  0 O D  U I  P 0  U I  0 O C  0 I 0  C o  0 0 1  0 0 1\
  C o  0 I 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U I  0 O D  0 O \
D  0 O D  1 C  o U  o U  0 O D  o U  U I  P 0  U I  0 O C  0 I 0  C o \
 0 0 1  0 0 1  C o  0 I 0  U I  C 0  U I  D 0  U I  C U  0 O  U I  U I\
  0 0 C  0 O D  0 0 P  0 O 1  U I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 \
O  U I  U C  0 0 P  0 O 0  0 O C  0 0 I  U I  0 O I  0 O D  0 O L  0 O\
 0  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  0 O D  0 0\
 P  0 O 0  0 0 1  C o  0 0 P  0 O D  0 0 0  0 0 O  U I  1 0  U I  1 U \
 U I  U C  1 P  0 O P  0 0 D  U C  U I  1 1  U I  U 1  0 0 C  C L  U 1\
  U I  1 0  U I  C o  0 0 D  U I  0 O D  1 C  0 O D  1 C  o U  0 O D  \
1 C  1 C  o U  0 O D  U I  D L  0 O  U I  U I  U I  0 O D  1 C  0 O D \
 1 C  o U  0 O D  1 C  1 C  o U  0 O D  U I  1 P  U I  0 0 C  0 0 1  0\
 O D  0 0 P  0 O 0  U I  1 O  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I \
 0 O D  0 O D  0 O D  1 C  o U  o U  0 O D  o U  U I  1 0  U I  1 0  0\
 O  U I  U I  U I  0 O D  0 O I  U I  D U  D D  U I  1 D  U I  D U  D \
D  D L  U I  o C  1 L  0 0 0  o C  U I  1 U  U I  0 O D  1 C  U I  U o\
  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 P  \
U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 o  U I  o U  1 C  o U\
  0 O D  1 C  1 C  1 C  U I  1 I  U I  o U  o U  0 O D  o U  0 O D  o \
U  o U  1 C  1 C  0 O D  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D \
L  0 O  U I  U I  0 O D  0 O I  U I  D 1  U I  1 D  U I  D 1  D L  U I\
  o U  1 C  1 C  0 O D  U I  1 D  U I  o U  0 O D  1 C  o U  U I  1 I \
 U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 P  U I  o U  1 C\
  o U  0 O D  1 C  1 C  1 C  0 O  U I  U I  0 O D  0 O I  U I  U 1  0 \
0 1  0 0 O  U I  0 0 I  0 I D  1 O  U C  U 1  U I  0 O D  0 0 O  U I  \
0 0 D  o 1  C o  0 0 L  C o  0 0 D  C C  0 0 1  0 O D  0 0 I  0 0 P  U\
 I  D L  0 O  U I  U I  U I  o U  0 O D  1 C  0 O D  1 C  U I  P 0  U \
I  0 0 D  o 1  C o  0 0 L  C o  0 0 D  C C  0 0 1  0 O D  0 0 I  0 0 P\
  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U 1\
  0 0 1  0 0 O  U I  0 0 I  0 I D  1 O  U C  U 1  U I  1 0  0 O  U I  \
U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  o U  0 \
O D  1 C  0 O D  1 C  U I  P 0  U I  0 0 D  o 1  C o  0 0 L  C o  0 0 \
D  C C  0 0 1  0 O D  0 0 I  0 0 P  U I  1 P  U I  0 0 D  0 0 I  0 O L\
  0 O D  0 0 P  U I  1 O  U I  U 1  0 0 1  0 0 O  U I  P D  0 I D  1 O\
  U C  U 1  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D 1  D P \
 U I  1 D  U I  D 1  D P  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  \
0 0 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D O  1 L  U I  1 D  U I \
 D O  1 L  D L  U I  0 O D  1 C  U I  1 D  U I  0 O D  1 C  0 O  U I  \
U I  0 O D  0 O D  0 O D  o U  0 O D  0 O D  U I  1 1  U I  0 0 0  o C\
  0 0 0  o C  1 L  1 L  0 O D  1 C  0 O D  U I  1 1  U I  0 O D  1 C  \
0 O D  o U  o U  0 O D  1 C  1 C  0 O D  1 C  1 C  1 C  o U  U I  1 1 \
 U I  0 O D  0 O D  0 O D  1 C  o U  o U  0 O D  o U  U I  P 0  U I  1\
 O  U I  U C  U C  U I  1 1  U I  U C  1 L  U C  U I  1 1  U I  U C  1\
 L  U C  U I  1 1  U I  U C  U C  U I  1 0  0 O  U I  U I  0 O D  0 O \
I  U I  D 0  D D  U I  1 D  U I  D 0  D D  D L  U I  0 0 0  0 0 0  0 0\
 0  1 L  o C  0 0 0  1 L  0 O  U I  U I  o U  1 C  U I  P 0  U I  U 1 \
 0 0 I  1 C  1 1  C o  1 C  1 1  C C  1 C  1 1  0 O o  1 C  P 0  1 O  \
U C  U 1  U I  1 U  U I  o U  0 O D  1 C  0 O D  1 C  U I  C 0  U I  1\
 C  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1\
 O  U I  U 1  1 P  0 0 D  0 0 I  0 O L  0 O D  U 1  U I  1 0  U I  C 0\
  U I  1 L  U I  C U  U I  1 U  U I  U C  1 0  U C  0 O  U I  U I  0 O\
 0  0 I O  0 O 0  C C  U I  1 O  U I  o U  1 C  U I  1 0  0 O  U I  0 \
O D  0 O D  0 O D  1 C  o U  o U  0 O D  o U  U I  P 0  U I  0 O D  0 \
O D  0 O D  1 C  o U  o U  0 O D  o U  U I  1 P  U I  0 0 D  0 0 I  0 \
O L  0 O D  0 0 P  U I  1 O  U I  U C  0 I 1  U C  U I  1 0  0 O  U I \
 o U  0 O D  1 C  0 O D  1 C  U I  P 0  U I  o U  0 O D  1 C  0 O D  1\
 C  U I  C 0  U I  1 C  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  \
0 O D  0 0 P  U I  1 O  U I  U 1  1 0  1 0  U C  U 1  U I  1 0  0 O  U\
 I  0 O D  0 O I  U I  D 0  D D  U I  1 D  U I  D 0  D D  D L  U I  o \
U  0 O D  o U  o U  U I  1 o  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 \
0  1 L  U I  1 I  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C\
  0 O D  0 O  U I  0 O D  0 O I  U I  D D  D 0  U I  1 D  U I  D D  D \
0  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 I \
 U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 o  U I  o\
 C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  0 O D  0 O I  U\
 I  D I  D 0  U I  1 D  U I  D I  D 0  D L  U I  0 0 0  o C  1 L  0 0 \
0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 P  U I  o U  1 C  1 C  0 O D  U\
 I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 U  U I\
  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U \
I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0\
 O D  U I  1 I  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  \
0 O D  0 O  U I  0 O D  0 O I  U I  D I  1 C  U I  1 D  U I  D I  1 C \
 D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1\
 U  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  \
1 C  0 O D  U I  U o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U \
I  1 P  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I \
 1 U  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 P  U\
 I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U I  0 O D  0\
 O I  U I  D 0  1 C  U I  1 D  U I  D 0  1 C  D L  U I  0 0 0  0 0 0  \
o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 U  U I  o U  0 O D  1 C  o\
 U  U I  1 P  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I\
  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I  0 O D\
  0 O I  U I  D 1  D 1  U I  1 D  U I  D 1  D 1  D L  U I  0 0 0  0 0 \
0  o C  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  o U  1 C  1 C  0 O D  U\
 I  U o  U I  o U  0 O D  1 C  o U  U I  1 P  U I  o U  o U  0 O D  o \
U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U I  0 0 0  o C  1 L  0\
 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  U o  U I  0 0 0  o C  1 L  0 0\
 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  0 O D  0 O I  U I  D P  D D\
  U I  1 D  U I  D P  D D  D L  U I  o C  1 L  0 0 0  o C  U I  1 U  U\
 I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 P  U I  0 O D  0 O\
 D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 D  U I  o C  o C  0 0 0  \
0 0 0  o C  o C  0 0 0  0 O  U I  0 O D  0 O I  U I  D 1  U I  1 D  U \
I  D 1  D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 I  U I  o C  o C  0 0\
 0  0 0 0  o C  o C  0 0 0  0 O  U I  0 O D  0 O I  U I  D O  D P  U I\
  1 D  U I  D O  D P  D L  U I  o U  0 O D  o U  o U  U I  1 I  U I  0\
 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 o  U I  0 O D  1 C  0 O\
  U I  0 O D  0 O I  U I  D U  D O  U I  1 D  U I  D U  D O  D L  U I \
 o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 o  U I\
  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  0 O D  0 O D\
  o U  1 C  0 O D  o U  0 O D  o U  U I  1 I  U I  0 O D  o U  o U  1 \
C  1 C  1 C  0 O D  U I  U o  U I  o C  1 L  0 0 0  o C  0 O  U I  0 O\
 D  0 O I  U I  D 1  D o  U I  1 D  U I  D 1  D o  D L  U I  0 0 0  o \
C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  0 O D  0 O I  U \
I  D P  D 0  U I  1 D  U I  D P  D 0  D L  U I  0 0 0  1 L  1 L  o C  \
1 L  0 0 0  0 0 0  0 O  U I  0 O D  0 O I  U I  D 0  D P  U I  1 D  U \
I  D 0  D P  D L  U I  0 O D  1 C  U I  1 U  U I  o C  o C  0 0 0  0 0\
 0  o C  o C  0 0 0  U I  1 P  U I  o U  1 C  1 C  0 O D  0 O  U I  0 \
O D  0 O I  U I  1 C  D o  U I  1 D  U I  1 C  D o  D L  U I  0 O D  0\
 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 D  U I  0 0 0  1 L  1 L\
  o C  1 L  0 0 0  0 0 0  U I  1 D  U I  0 O D  1 C  1 C  o U  0 O D  \
1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 D  U I  0 0 0  0 0 \
0  o C  0 0 0  o C  1 L  0 0 0  U I  1 P  U I  0 O D  0 O D  o U  1 C \
 0 O D  o U  0 O D  o U  U I  1 P  U I  0 O D  1 C  0 O  U I  0 O D  0\
 O I  U I  D I  D P  U I  1 D  U I  D I  D P  D L  U I  0 O D  0 O D  \
o U  1 C  0 O D  o U  0 O D  o U  U I  1 U  U I  0 0 0  0 0 0  0 0 0  \
1 L  o C  0 0 0  1 L  0 O  U I  0 O D  0 O I  U I  D 1  1 L  U I  1 D \
 U I  D 1  1 L  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 U  U I  \
0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 P  U I  0 0 0  \
0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  o U  1 C  1 C  0 O \
D  U I  1 P  U I  0 0 0  o C  1 L  0 0 0  0 O  U I  0 O D  0 O I  U I \
 1 C  D I  U I  1 D  U I  1 C  D I  D L  U I  o C  1 L  0 0 0  o C  0 \
O  U I  0 O D  0 O I  U I  D D  D o  U I  1 D  U I  D D  D o  D L  U I\
  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 \
O D  0 O  U I  0 O D  0 O I  U I  D D  D 1  U I  1 D  U I  D D  D 1  D\
 L  U I  0 0 0  o C  1 L  0 0 0  0 O  U I  0 O D  0 O I  U I  D P  1 L\
  U I  1 D  U I  D P  1 L  D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 P \
 U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 o\
  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 \
C  0 O D  U I  U o  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1\
 C  o U  0 O D  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  D o  D 0  U I\
  1 D  U I  D o  D 0  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 \
0  U I  1 I  U I  o U  0 O D  o U  o U  0 O  U I  0 O D  0 O I  U I  1\
 C  1 L  U I  1 D  U I  1 C  1 L  D L  U I  0 O D  1 C  U I  1 I  U I \
 o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 U  U I  0 0 0  1 L  0\
 0 0  o C  1 L  U I  1 D  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0\
 0  o C  1 L  U I  1 o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0\
  o C  1 L  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 \
L  1 L  0 O  U I  o U  1 C  o U  1 C  1 C  1 C  U I  P 0  U I  U C  U \
C  0 O  U I  0 0 0  1 L  o C  o C  o C  o C  o C  1 L  o C  U I  P 0  \
U I  U C  U C  0 O  U I  0 O D  0 O I  U I  D O  D O  U I  1 D  U I  D\
 O  D O  D L  U I  0 O D  1 C  U I  1 o  U I  0 0 0  1 L  1 L  o C  1 \
L  0 0 0  0 0 0  0 O  U I  0 O D  0 O I  U I  D o  D P  U I  1 D  U I \
 D o  D P  D L  U I  o U  1 C  1 C  0 O D  0 O  U I  o C  o C  o C  1 \
L  0 0 0  o C  U I  P 0  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  0 O \
D  0 O D  1 C  0 O D  U I  1 O  U I  0 O D  0 O D  0 O D  o U  0 O D  \
0 O D  U I  1 1  U I  0 0 0  o C  0 0 0  o C  1 L  1 L  0 O D  1 C  0 \
O D  U I  1 1  U I  0 O D  1 C  0 O D  o U  o U  0 O D  1 C  1 C  0 O \
D  1 C  1 C  1 C  o U  U I  1 1  U I  0 O D  0 O D  0 O D  1 C  o U  o\
 U  0 O D  o U  U I  1 1  U I  o U  1 C  o U  1 C  1 C  1 C  U I  1 1 \
 U I  0 0 0  1 L  o C  o C  o C  o C  o C  1 L  o C  U I  1 1  U I  0 \
O D  0 0 P  0 O 0  0 0 1  C o  0 0 P  0 O D  0 0 0  0 0 O  U I  1 0  U\
 I  1 0  0 O  U I  0 O D  0 O I  U I  1 C  D O  U I  1 D  U I  1 C  D \
O  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O\
 D  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  D D  1 C  U I  1 D  U I  \
D D  1 C  D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 P  U\
 I  o U  0 O D  1 C  o U  U I  1 P  U I  0 O D  o U  o U  1 C  1 C  1 \
C  0 O D  U I  1 D  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L \
 0 O  U I  0 O D  0 O I  U I  D I  D U  U I  1 D  U I  D I  D U  D L  \
U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  o U  o \
U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 o  U I  0 0 0 \
 0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 I  U I  o C  1 L  0 0 0  o\
 C  0 O  U I  0 O D  0 O I  U I  1 C  D P  U I  1 D  U I  1 C  D P  D \
L  U I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  o C  1 L  0 0 0  o C  U\
 I  1 U  U I  0 0 0  o C  1 L  0 0 0  U I  1 P  U I  0 0 0  o C  1 L  \
0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  0 O D  1 C  U I  1 \
P  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  0 O D \
 0 O I  U I  D D  U I  1 D  U I  D D  D L  U I  0 0 0  o C  1 L  0 0 0\
  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  \
U I  1 I  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 I  U I  0 0 0  1 L \
 0 0 0  o C  1 L  U I  1 o  U I  o U  0 O D  1 C  o U  U I  1 D  U I  \
0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O \
D  0 O  U I  0 O D  0 O I  U I  0 O D  0 0 P  0 O 0  0 0 1  C o  0 0 P\
  0 O D  0 0 0  0 0 O  U I  P I  P 0  U I  0 0 P  0 0 0  0 0 P  C o  0\
 O L  0 O D  0 0 P  0 O 0  0 0 1  C o  0 0 P  0 O D  0 0 0  0 0 O  0 0\
 D  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  D 1  D U  U I  1 D  U \
I  D 1  D U  D L  U I  o U  o U  o U  o U  U I  1 U  U I  0 0 0  0 0 0\
  o C  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  o U  0 O D  1 C  o U  0 \
O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  o C  o C  \
o C  1 L  0 0 0  o C  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  \
0 O  U I  U I  0 O D  0 O I  U I  D D  D D  U I  1 D  U I  D D  D D  D\
 L  U I  o U  0 O D  1 C  o U  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0\
 o  0 0 1  0 0 O  U I  o U  0 O D  o U  1 C  U I  1 O  U I  o C  o C  \
o C  1 L  0 0 0  o C  U I  1 1  U I  0 O D  0 0 P  0 O 0  0 0 1  C o  \
0 0 P  0 O D  0 0 0  0 0 O  U I  1 U  U I  1 C  U I  1 0  0 O  U I  U \
I  0 O D  0 O I  U I  D U  1 L  U I  1 D  U I  D U  1 L  D L  U I  o U\
  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 P  U I  o \
U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 P  U I  o\
 C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  U o  U I  o U  0 O D\
  o U  o U  0 O  0 O O  0 O 0  0 O I  U I  0 O D  0 O D  1 C  0 O D  U\
 I  1 O  U I  0 0 I  U I  1 1  U I  C o  U I  1 1  U I  C C  U I  1 1 \
 U I  0 O o  U I  1 1  U I  0 O 0  U I  1 1  U I  0 O O  U I  1 1  U I\
  0 O D  0 0 P  0 O 0  0 0 1  C o  0 0 P  0 O D  0 0 0  0 0 O  U I  1 \
1  U I  0 0 L  U I  P 0  U I  1 C  U I  1 0  U I  D L  0 O  U I  0 O D\
  0 O I  U I  D 1  D P  U I  1 D  U I  D 1  D P  D L  U I  o U  o U  o\
 U  o U  0 O  U I  0 O D  0 O I  U I  1 C  1 L  U I  1 D  U I  1 C  1 \
L  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O\
 D  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  D D  D D  U I  1 D  U I  \
D D  D D  D L  U I  o C  1 L  0 0 0  o C  U I  1 o  U I  o U  0 O D  1\
 C  o U  U I  1 U  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I\
  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U \
I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  0 0 C \
 0 O 1  0 O D  0 O L  0 O 0  U I  1 O  U I  C C  U I  P I  P 0  U I  1\
 C  U I  1 0  U I  D L  0 O  U I  U I  C C  U I  P 0  U I  C C  U I  1\
 D  U I  1 C  0 O  U I  U I  0 O D  0 O I  U I  1 O  U I  0 O o  U I  \
C 0  U I  C C  U I  C U  U I  1 0  U I  D L  0 O  U I  U I  U I  o U  \
0 O D  o U  o U  0 O D  o U  U I  P 0  U I  0 0 D  0 0 P  0 0 1  U I  \
1 O  U I  0 0 0  o C  0 0 0  1 L  o C  0 0 0  1 L  o C  1 L  o C  U I \
 1 O  U I  C C  U I  1 1  U I  C o  U I  1 0  U I  1 0  0 O  U I  U I \
 U I  0 O D  0 O I  U I  0 0 L  U I  P 0  P 0  U I  1 C  U I  D L  0 O\
  U I  U I  U I  U I  0 0 I  U I  P 0  U I  0 0 1  0 O 0  U I  1 P  U \
I  0 0 D  0 0 o  C L  U I  1 O  U I  U C  C I  C I  C L  U C  U I  1 U\
  U I  o U  0 O D  o U  o U  0 O D  o U  U I  1 U  U I  U C  C I  C I \
 C L  U C  U I  1 1  U I  0 O o  U I  C 0  U I  C C  U I  C U  U I  1 \
1  U I  0 0 I  U I  1 0  0 O  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O \
0  U I  D L  0 O  U I  U I  U I  U I  0 0 I  U I  P 0  U I  o U  o U  \
o U  1 C  o U  o U  1 C  0 O D  U I  1 O  U I  0 0 I  U I  1 1  U I  o\
 U  0 O D  o U  o U  0 O D  o U  U I  1 1  U I  0 O o  U I  C 0  U I  \
C C  U I  C U  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D\
 0  U I  1 D  U I  D 0  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  \
0 O D  o U  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D 0  D U  U I \
 1 D  U I  D 0  D U  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1\
 L  U I  1 P  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 \
O D  U I  1 U  U I  o U  0 O D  o U  o U  U I  1 U  U I  o C  1 L  0 0\
 0  o C  U I  1 U  U I  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  U I \
 0 O D  0 O I  U I  D 1  D U  U I  1 D  U I  D 1  D U  D L  U I  o U  \
o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U I  0 O \
D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 o  U I  0 O D  o U  o U  1 C\
  1 C  1 C  0 O D  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  \
0 0 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D P  D D  U I  1 D \
 U I  D P  D D  D L  U I  o U  0 O D  1 C  o U  U I  1 I  U I  0 0 0  \
o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  U o  U I  o U  0 O \
D  o U  o U  U I  1 I  U I  o U  0 O D  o U  o U  0 O  U I  U I  U I  \
U I  0 O D  0 O I  U I  D U  D P  U I  1 D  U I  D U  D P  D L  U I  o\
 C  1 L  0 0 0  o C  U I  1 P  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  \
0 0 0  U I  1 U  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  U o \
 U I  o U  0 O D  o U  o U  U I  1 D  U I  o U  1 C  o U  0 O D  1 C  \
1 C  1 C  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D U  1 L  U I  1\
 D  U I  D U  1 L  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D\
  o U  U I  U o  U I  o U  0 O D  1 C  o U  U I  1 D  U I  o C  0 0 0 \
 0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 P  U I  o U  1 C  1 C  0 O D\
  U I  1 U  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O \
D  U I  U o  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O \
 U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 I  0 O  U I  \
0 O D  0 O I  U I  1 C  1 L  U I  1 D  U I  1 C  1 L  D L  U I  0 O D \
 0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 P  U I  o U  1 C  1 C\
  0 O D  U I  1 U  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 \
C  o U  0 O D  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  D 1  D 1  U I \
 1 D  U I  D 1  D 1  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U \
I  U o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  0 O D \
 0 O I  U I  D O  1 C  U I  1 D  U I  D O  1 C  D L  U I  0 0 0  0 0 0\
  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  o C  o C  0 0 0  0 0 0  \
o C  o C  0 0 0  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o \
C  1 L  1 L  0 O  0 O O  0 O 0  0 O I  U I  o U  o U  o U  1 C  o U  o\
 U  1 C  0 O D  U I  1 O  U I  0 0 D  0 0 0  0 0 o  0 0 1  C C  0 O 0 \
 C D  0 0 D  0 0 P  0 0 1  U I  1 1  U I  0 0 C  0 0 0  0 0 1  0 O O  \
C D  0 0 P  0 0 0  C D  0 O I  0 O D  0 0 O  0 O O  U I  1 1  U I  0 0\
 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  C D  0 0 C  0 O D  0 0 P  0 \
O 1  U I  1 0  U I  D L  0 O  U I  o C  0 0 0  1 L  1 L  o C  1 L  o C\
  o C  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  o C  0 0 0  \
1 L  1 L  o C  1 L  o C  o C  U I  P 0  U I  0 0 D  0 0 0  0 0 o  0 0 \
1  C C  0 O 0  C D  0 0 D  0 0 P  0 0 1  U I  1 P  U I  0 0 D  0 0 I  \
0 O L  0 O D  0 0 P  U I  1 O  U I  0 0 C  0 0 0  0 0 1  0 O O  C D  0\
 0 P  0 0 0  C D  0 O I  0 O D  0 0 O  0 O O  U I  1 0  0 O  U I  0 O \
D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  o C  0 0 0  1 L  1 \
L  o C  1 L  o C  o C  U I  1 0  U I  P I  U I  1 C  U I  D L  0 O  U \
I  U I  0 0 0  o C  o C  o C  0 0 0  0 0 0  1 L  0 0 0  U I  P 0  U I \
 C 0  U I  C U  0 O  U I  U I  0 O D  0 O D  0 O D  o U  1 C  o U  0 O\
 D  o U  o U  0 O D  0 O D  U I  P 0  U I  1 L  0 O  U I  U I  0 O I  \
0 0 0  0 0 1  U I  o U  o U  o U  o U  0 O D  0 O D  0 O D  U I  0 O D\
  0 0 O  U I  o C  0 0 0  1 L  1 L  o C  1 L  o C  o C  U I  D L  0 O \
 U I  U I  U I  0 O D  0 O I  U I  D O  D 1  U I  1 D  U I  D O  D 1  \
D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I  o C \
 0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  0 0 0  0 0 0 \
 o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 U  U I  o U  o U  0 O D  \
o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U I  o U  o U  o U  o\
 U  0 O  U I  U I  U I  0 0 0  o C  o C  o C  0 0 0  0 0 0  1 L  0 0 0\
  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I\
  o U  o U  o U  o U  0 O D  0 O D  0 O D  U I  1 0  0 O  U I  U I  U \
I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  0 0 C  0 0 0  \
0 0 1  0 O O  C D  0 0 P  0 0 0  C D  0 O I  0 O D  0 0 O  0 O O  0 O \
 U I  U I  U I  0 O D  0 O I  U I  D P  D D  U I  1 D  U I  D P  D D  \
D L  U I  o U  0 O D  o U  o U  U I  1 U  U I  o U  o U  0 O D  o U  0\
 O D  o U  o U  1 C  1 C  0 O D  U I  1 D  U I  0 0 0  1 L  0 0 0  o C\
  1 L  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  U I  1 P  U I  0 O D  1 \
C  U I  U o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  U\
 I  U I  0 O D  0 O I  U I  D P  D 0  U I  1 D  U I  D P  D 0  D L  U \
I  o U  0 O D  1 C  o U  U I  1 I  U I  o U  1 C  1 C  0 O D  U I  1 I\
  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 P  U I  \
0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 o  U I  0 \
0 0  1 L  0 0 0  o C  1 L  U I  1 U  U I  o U  1 C  1 C  0 O D  0 O  U\
 I  U I  U I  0 O D  0 O I  U I  0 O D  0 O D  0 O D  o U  1 C  o U  0\
 O D  o U  o U  0 O D  0 O D  U I  P 0  P 0  U I  0 O L  0 O 0  0 0 O \
 U I  1 O  U I  o C  0 0 0  1 L  1 L  o C  1 L  o C  o C  U I  1 0  U \
I  1 D  U I  1 C  U I  D L  0 O  U I  U I  U I  U I  0 0 0  0 0 0  0 0\
 0  0 0 0  1 L  1 L  U I  P 0  U I  U C  U C  0 O  U I  U I  U I  0 O \
0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O \
I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  o U  o U  o U  o U  0 O D \
 0 O D  0 O D  U I  1 0  U I  P 0  P 0  U I  1 L  U I  D L  0 O  U I  \
U I  U I  U I  U I  0 O D  0 O I  U I  1 O  U I  0 O L  0 O 0  0 0 O  \
U I  1 O  U I  o C  0 0 0  1 L  1 L  o C  1 L  o C  o C  U I  C 0  U I\
  0 O D  0 O D  0 O D  o U  1 C  o U  0 O D  o U  o U  0 O D  0 O D  U\
 I  1 U  U I  1 C  U I  C U  U I  1 0  U I  P 0  P 0  U I  1 L  U I  C\
 o  0 0 O  0 O O  U I  0 0 C  0 0 0  0 0 1  0 O O  C D  0 0 P  0 0 0  \
C D  0 O I  0 O D  0 0 O  0 O O  U I  C 0  U I  1 L  U I  C U  U I  1 \
P  U I  0 O L  0 0 0  0 0 C  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  0 \
0 O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  U C  C o  C L  C C  0 O O  \
0 O 0  0 O I  0 O U  0 O 1  0 O D  0 O P  0 O o  0 O L  0 O C  0 0 O  \
0 0 0  0 0 I  0 0 U  0 0 1  0 0 D  0 0 P  0 0 o  0 0 L  0 0 C  0 I O  \
0 I 0  0 I I  1 C  D O  D 0  D I  D U  D 1  D D  D P  D o  1 L  C D  U\
 C  U I  1 0  U I  0 0 0  0 0 1  U I  1 O  U I  0 O L  0 O 0  0 0 O  U\
 I  1 O  U I  o C  0 0 0  1 L  1 L  o C  1 L  o C  o C  U I  C 0  U I \
 0 O D  0 O D  0 O D  o U  1 C  o U  0 O D  o U  o U  0 O D  0 O D  U \
I  1 U  U I  1 C  U I  C U  U I  1 0  U I  P I  U I  1 L  U I  C o  0 \
0 O  0 O O  U I  o C  0 0 0  1 L  1 L  o C  1 L  o C  o C  U I  C 0  U\
 I  0 O D  0 O D  0 O D  o U  1 C  o U  0 O D  o U  o U  0 O D  0 O D \
 U I  1 U  U I  1 C  U I  C U  U I  C 0  U I  1 L  U I  C U  U I  1 P \
 U I  0 O L  0 0 0  0 0 C  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  0 0 \
O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  U C  C o  C L  C C  0 O O  0 \
O 0  0 O I  0 O U  0 O 1  0 O D  0 O P  0 O o  0 O L  0 O C  0 0 O  0 \
0 0  0 0 I  0 0 U  0 0 1  0 0 D  0 0 P  0 0 o  0 0 L  0 0 C  0 I O  0 \
I 0  0 I I  1 C  D O  D 0  D I  D U  D 1  D D  D P  D o  1 L  C D  U C\
  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0 \
 0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  0 0 1  0 O 0  0 0 I  0 O L  C \
o  C C  0 O 0  C D  0 0 C  0 O D  0 0 P  0 O 1  0 O  U I  U I  U I  U \
I  U I  U I  0 O D  0 O I  U I  D I  D 0  U I  1 D  U I  D I  D 0  D L\
  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  U I  U I  U \
I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I \
 0 O D  0 O I  U I  1 O  U I  o C  0 0 0  1 L  1 L  o C  1 L  o C  o C\
  U I  C 0  U I  0 O D  0 O D  0 O D  o U  1 C  o U  0 O D  o U  o U  \
0 O D  0 O D  U I  C U  U I  C 0  U I  1 D  U I  1 C  U I  C U  U I  1\
 P  U I  0 O L  0 0 0  0 0 C  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  0\
 0 O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  U C  C o  C L  C C  0 O O \
 0 O 0  0 O I  0 O U  0 O 1  0 O D  0 O P  0 O o  0 O L  0 O C  0 0 O \
 0 0 0  0 0 I  0 0 U  0 0 1  0 0 D  0 0 P  0 0 o  0 0 L  0 0 C  0 I O \
 0 I 0  0 I I  1 C  D O  D 0  D I  D U  D 1  D D  D P  D o  1 L  C D  \
U C  U I  1 0  U I  C o  0 0 O  0 O O  U I  1 O  U I  1 O  U I  0 O L \
 0 O 0  0 0 O  U I  1 O  U I  o C  0 0 0  1 L  1 L  o C  1 L  o C  o C\
  U I  C 0  U I  0 O D  0 O D  0 O D  o U  1 C  o U  0 O D  o U  o U  \
0 O D  0 O D  U I  1 U  U I  1 C  U I  C U  U I  1 0  U I  P 0  P 0  U\
 I  1 L  U I  C o  0 0 O  0 O O  U I  0 0 C  0 0 0  0 0 1  0 O O  C D \
 0 0 P  0 0 0  C D  0 O I  0 O D  0 0 O  0 O O  U I  C 0  U I  1 L  U \
I  C U  U I  1 P  U I  0 O L  0 0 0  0 0 C  0 O 0  0 0 1  U I  1 O  U \
I  1 0  U I  0 0 O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  U C  C o  C \
L  C C  0 O O  0 O 0  0 O I  0 O U  0 O 1  0 O D  0 O P  0 O o  0 O L \
 0 O C  0 0 O  0 0 0  0 0 I  0 0 U  0 0 1  0 0 D  0 0 P  0 0 o  0 0 L \
 0 0 C  0 I O  0 I 0  0 I I  1 C  D O  D 0  D I  D U  D 1  D D  D P  D\
 o  1 L  C D  U C  U I  1 0  U I  0 0 0  0 0 1  U I  1 O  U I  0 O L  \
0 O 0  0 0 O  U I  1 O  U I  o C  0 0 0  1 L  1 L  o C  1 L  o C  o C \
 U I  C 0  U I  0 O D  0 O D  0 O D  o U  1 C  o U  0 O D  o U  o U  0\
 O D  0 O D  U I  1 U  U I  1 C  U I  C U  U I  1 0  U I  P I  U I  1 \
L  U I  C o  0 0 O  0 O O  U I  o C  0 0 0  1 L  1 L  o C  1 L  o C  o\
 C  U I  C 0  U I  0 O D  0 O D  0 O D  o U  1 C  o U  0 O D  o U  o U\
  0 O D  0 O D  U I  1 U  U I  1 C  U I  C U  U I  C 0  U I  1 L  U I \
 C U  U I  1 P  U I  0 O L  0 0 0  0 0 C  0 O 0  0 0 1  U I  1 O  U I \
 1 0  U I  0 0 O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  U C  C o  C L \
 C C  0 O O  0 O 0  0 O I  0 O U  0 O 1  0 O D  0 O P  0 O o  0 O L  0\
 O C  0 0 O  0 0 0  0 0 I  0 0 U  0 0 1  0 0 D  0 0 P  0 0 o  0 0 L  0\
 0 C  0 I O  0 I 0  0 I I  1 C  D O  D 0  D I  D U  D 1  D D  D P  D o\
  1 L  C D  U C  U I  1 0  U I  1 0  U I  D L  0 O  U I  U I  U I  U I\
  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  0 0 1\
  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  C D  0 0 C  0 O D  0 0 P  0 O \
1  0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D o  D D  U I\
  1 D  U I  D o  D D  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 \
0 0  o C  1 L  U I  1 o  U I  o U  0 O D  o U  o U  U I  1 U  U I  0 O\
 D  1 C  0 O  U I  U I  U I  0 0 0  o C  o C  o C  0 0 0  0 0 0  1 L  \
0 0 0  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O\
  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  1 0  0 O  U I  U I  \
U I  0 O D  0 O D  0 O D  o U  1 C  o U  0 O D  o U  o U  0 O D  0 O D\
  U I  1 U  P 0  U I  1 C  0 O  U I  U I  U I  0 O D  0 O I  U I  D 0 \
 D O  U I  1 D  U I  D 0  D O  D L  U I  o C  0 0 0  0 0 0  0 0 0  1 L\
  1 L  1 L  1 L  U I  U o  U I  0 O D  1 C  U I  1 I  U I  o U  0 O D \
 o U  o U  0 O  U I  U I  0 0 D  0 0 0  0 0 o  0 0 1  C C  0 O 0  C D \
 0 0 D  0 0 P  0 0 1  U I  P 0  U I  U C  U C  U I  1 P  U I  0 O P  0\
 0 0  0 O D  0 0 O  U I  1 O  U I  0 0 0  o C  o C  o C  0 0 0  0 0 0 \
 1 L  0 0 0  U I  1 0  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 \
0 O  U I  0 0 D  0 0 0  0 0 o  0 0 1  C C  0 O 0  C D  0 0 D  0 0 P  0\
 0 1  0 O  U I  0 O D  0 O I  U I  D D  D O  U I  1 D  U I  D D  D O  \
D L  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 P  U I \
 0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 D  U I  0 O D \
 1 C  U I  1 D  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  \
o U  0 O D  1 C  0 O D  U I  U o  U I  o U  1 C  1 C  0 O D  0 O  0 O \
O  0 O 0  0 O I  U I  0 0 0  o C  1 L  0 0 0  1 L  1 L  o C  1 L  o C \
 1 L  0 0 0  0 0 0  1 L  U I  1 O  U I  0 0 O  0 0 o  0 O C  U I  1 1 \
 U I  0 0 1  C o  0 O O  0 O D  0 I O  U I  1 0  U I  D L  0 O  U I  0\
 O D  0 O I  U I  D O  D I  U I  1 D  U I  D O  D I  D L  U I  0 O D  \
1 C  U I  1 I  U I  o U  o U  o U  o U  0 O  U I  o C  o C  o C  0 0 0\
  o C  1 L  1 L  1 L  U I  P 0  U I  U 1  U 1  0 O  U I  0 O D  0 O I \
 U I  0 0 O  0 0 o  0 O C  U I  P 0  P 0  U I  1 L  U I  D L  U I  0 0\
 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  U C  1 L  U C  0 O  U I  0\
 0 C  0 O 1  0 O D  0 O L  0 O 0  U I  0 0 O  0 0 o  0 O C  U I  P I  \
U I  1 L  U I  D L  0 O  U I  U I  o C  o C  o C  0 0 0  o C  1 L  1 L\
  1 L  U I  P 0  U I  U 1  1 L  1 C  D O  D 0  D I  D U  D 1  D D  D P\
  D o  C o  C L  C C  0 O O  0 O 0  0 O I  0 O U  0 O 1  0 O D  0 O P \
 0 O o  0 O L  0 O C  0 0 O  0 0 0  0 0 I  0 0 U  0 0 1  0 0 D  0 0 P \
 0 0 o  0 0 L  0 0 C  0 I O  0 I 0  0 I I  U 1  U I  C 0  U I  0 0 O  \
0 0 o  0 O C  U I  U o  U I  0 0 1  C o  0 O O  0 O D  0 I O  U I  C U\
  U I  1 U  U I  o C  o C  o C  0 0 0  o C  1 L  1 L  1 L  0 O  U I  U\
 I  0 0 O  0 0 o  0 O C  U I  1 o  P 0  U I  0 0 1  C o  0 O O  0 O D \
 0 I O  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  o C  \
o C  o C  0 0 0  o C  1 L  1 L  1 L  0 O  U I  0 O D  0 O I  U I  D P \
 D P  U I  1 D  U I  D P  D P  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C\
  1 L  o C  1 L  1 L  U I  1 U  U I  0 O D  0 O D  o U  1 C  0 O D  o \
U  0 O D  o U  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 \
0  U I  1 I  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I \
 1 U  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  0 O O  0 O 0  0 O I  U I \
 0 0 0  o C  0 0 0  1 L  o C  0 0 0  1 L  o C  1 L  o C  U I  1 O  U I\
  C C  C C  U I  1 1  U I  C o  U I  1 0  U I  D L  0 O  U I  o U  0 O\
 D  o U  o U  0 O D  o U  U I  P 0  U I  U 1  U 1  U I  0 O D  0 O I  \
U I  C C  C C  U I  P O  U I  C o  U I  0 O 0  0 O L  0 0 D  0 O 0  U \
I  0 0 0  o C  0 0 0  1 L  o C  0 0 0  1 L  o C  1 L  o C  U I  1 O  U\
 I  0 O D  0 0 O  0 0 P  U I  1 O  U I  C C  C C  U I  1 o  U I  C o  \
U I  1 0  U I  1 1  U I  C o  U I  1 0  0 O  U I  C C  C C  U I  P 0  \
U I  1 O  U I  C C  C C  U I  U o  U I  C o  U I  1 0  0 O  U I  o C  \
1 L  o C  o C  o C  1 L  1 L  o C  0 0 0  0 0 0  o C  U I  P 0  U I  C\
 C  0 O 1  0 0 1  U I  1 O  U I  C C  C C  U I  1 U  U I  D O  D o  U \
I  1 0  U I  0 O D  0 O I  U I  C C  C C  U I  P I  U I  D 0  D U  U I\
  0 O 0  0 O L  0 0 D  0 O 0  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I \
 0 0 0  o C  1 L  0 0 0  1 L  1 L  o C  1 L  o C  1 L  0 0 0  0 0 0  1\
 L  U I  1 O  U I  C C  C C  U I  1 1  U I  D 0  D 1  U I  1 0  U I  1\
 0  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  o U  0 O \
D  o U  o U  0 O D  o U  U I  1 U  U I  o C  1 L  o C  o C  o C  1 L  \
1 L  o C  0 0 0  0 0 0  o C  0 O  U I  0 O D  0 O I  U I  D 1  D I  U \
I  1 D  U I  D 1  D I  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  \
U I  1 P  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 D  U I  o\
 C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 P  U I  o C  0 0 0  0 0\
 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U I  0 O D  0 O D  o U  1 C  \
0 O D  o U  0 O D  o U  0 O  U I  0 O D  0 O I  U I  D D  D D  U I  1 \
D  U I  D D  D D  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U\
  1 C  o U  0 O D  1 C  0 O D  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0\
  o C  1 L  0 0 0  U I  1 o  U I  o U  0 O D  1 C  o U  U I  U o  U I \
 0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  U o  U I  o C  o\
 C  0 0 0  0 0 0  o C  o C  0 0 0  U I  U o  U I  o U  1 C  o U  0 O D\
  1 C  1 C  1 C  0 O  0 O O  0 O 0  0 O I  U I  o U  o U  0 O D  o U  \
0 O D  0 O D  0 O D  o U  o U  o U  o U  0 O D  1 C  U I  1 O  U I  C \
C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 0  U I  \
D L  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  o U  1 C \
 0 O D  1 C  1 C  o U  o U  1 C  1 C  0 O D  1 C  0 O D  o U  U I  P 0\
  U I  U 1  U 1  0 O  U I  U I  0 O I  0 0 0  0 0 1  U I  0 0 0  o C  \
1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1 L  U I  \
1 1  U I  0 O D  o U  1 C  U I  0 O D  0 0 O  U I  0 O 0  0 0 O  0 0 o\
  0 O C  0 O 0  0 0 1  C o  0 0 P  0 O 0  U I  1 O  U I  C C  0 0 0  0\
 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 0  U I  D L  0 O  U\
 I  U I  U I  o U  1 C  0 O D  1 C  1 C  o U  o U  1 C  1 C  0 O D  1 \
C  0 O D  o U  U I  1 U  P 0  U I  0 O D  o U  1 C  U I  1 P  U I  0 0\
 O  C o  0 O C  0 O 0  U I  1 U  U I  U 1  P 0  U 1  U I  1 U  U I  0 \
O D  o U  1 C  U I  1 P  U I  0 0 L  C o  0 O L  0 0 o  0 O 0  U I  1 \
U  U I  U 1  D C  U 1  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 \
P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  0 O D  0 O I  U \
I  1 C  D O  U I  1 D  U I  1 C  D O  D L  U I  0 O D  1 C  U I  1 U  \
U I  o C  1 L  0 0 0  o C  U I  1 U  U I  0 0 0  1 L  0 0 0  o C  1 L \
 U I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U\
 I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  \
0 O D  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  o U  1\
 C  0 O D  1 C  1 C  o U  o U  1 C  1 C  0 O D  1 C  0 O D  o U  0 O  \
U I  0 O D  0 O I  U I  D O  D o  U I  1 D  U I  D O  D o  D L  U I  0\
 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  o C  0 0 0  0\
 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U I  o U  0 O D  1 C  o U  \
0 O  U I  0 O D  0 O I  U I  D 1  D P  U I  1 D  U I  D 1  D P  D L  U\
 I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  o U  0 O D  1 C  o U  U I  \
1 o  U I  o U  o U  o U  o U  0 O  0 O O  0 O 0  0 O I  U I  o C  0 0 \
0  0 0 0  1 L  0 0 0  0 0 0  U I  1 O  U I  C C  0 0 0  0 0 0  0 O o  \
0 O D  0 O 0  o 1  C o  0 0 1  U I  1 1  U I  P o  o C  o C  o D  o U \
 P C  o O  o U  o P  P C  U I  1 0  U I  D L  0 O  U I  0 0 P  0 0 1  \
0 I 0  U I  D L  0 O  U I  U I  0 O D  0 O D  1 C  o U  0 O D  1 C  o \
U  0 O D  o U  o U  0 O D  U I  P 0  U I  0 0 0  0 0 D  U I  1 P  U I \
 0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  \
U I  1 O  U I  0 0 0  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 0 0  o C  \
o C  o C  o C  0 0 0  U I  1 1  U I  P o  o C  o C  o D  o U  P C  o O\
  o U  o P  P C  U I  1 0  0 O  U I  U I  C C  0 0 0  0 0 0  0 O o  0 \
O D  0 O 0  o 1  C o  0 0 1  U I  1 P  U I  0 0 D  C o  0 0 L  0 O 0  \
U I  1 O  U I  0 O D  0 O D  1 C  o U  0 O D  1 C  o U  0 O D  o U  o \
U  0 O D  U I  1 1  U I  0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  C D\
  0 O O  0 O D  0 0 D  C C  C o  0 0 1  0 O O  U I  P 0  U I  L 1  0 0\
 1  0 0 o  0 O 0  U I  1 0  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I \
 0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  0 O D  0 O \
I  U I  D o  1 C  U I  1 D  U I  D o  1 C  D L  U I  0 0 0  0 0 0  o C\
  0 0 0  o C  1 L  0 0 0  U I  U o  U I  0 0 0  o C  1 L  0 0 0  U I  \
1 P  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  0 O O  0 O 0  0 \
O I  U I  o U  1 C  0 O D  0 O D  0 O D  U I  1 O  U I  P o  o C  o C \
 o D  o U  P C  o O  o U  o P  P C  U I  1 0  U I  D L  0 O  U I  0 O \
D  0 O I  U I  D D  1 L  U I  1 D  U I  D D  1 L  D L  U I  0 0 0  1 L\
  0 0 0  o C  1 L  U I  U o  U I  o U  0 O D  1 C  o U  U I  U o  U I \
 o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 P  U I\
  o U  1 C  1 C  0 O D  U I  1 o  U I  0 O D  1 C  0 O  U I  o C  o C \
 1 L  0 0 0  0 0 0  o C  0 0 0  o C  o C  1 L  o C  o C  0 0 0  U I  P\
 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  0 O D  0 O I  U I  P o  o\
 C  o C  o D  o U  P C  o O  o U  o P  P C  U I  D L  0 O  U I  U I  0\
 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  0 O D  0 O D  1 C  o\
 U  0 O D  1 C  o U  0 O D  o U  o U  0 O D  U I  P 0  U I  0 0 0  0 0\
 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0\
 0  0 O D  0 0 O  U I  1 O  U I  0 0 0  0 0 0  1 L  0 0 0  0 0 0  o C \
 1 L  0 0 0  o C  o C  o C  o C  0 0 0  U I  1 1  U I  P o  o C  o C  \
o D  o U  P C  o O  o U  o P  P C  U I  1 0  0 O  U I  U I  U I  o C  \
o C  1 L  0 0 0  0 0 0  o C  0 0 0  o C  o C  1 L  o C  o C  0 0 0  U \
I  P 0  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 O L  0 O D  C L\
  U I  1 P  U I  o P  L o  L O  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0\
  o 1  C o  0 0 1  U I  1 O  U I  1 0  0 O  U I  U I  U I  o C  o C  1\
 L  0 0 0  0 0 0  o C  0 0 0  o C  o C  1 L  o C  o C  0 0 0  U I  1 P\
  U I  0 O L  0 0 0  C o  0 O O  U I  1 O  U I  0 O D  0 O D  1 C  o U\
  0 O D  1 C  o U  0 O D  o U  o U  0 O D  U I  1 1  U I  0 O D  0 O U\
  0 0 O  0 0 0  0 0 1  0 O 0  C D  0 O O  0 O D  0 0 D  C C  C o  0 0 \
1  0 O O  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 0  0 O  U I \
 U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I \
 U I  o C  o C  1 L  0 0 0  0 0 0  o C  0 0 0  o C  o C  1 L  o C  o C\
  0 0 0  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  U I  U I  \
0 O D  0 O I  U I  D U  1 C  U I  1 D  U I  D U  1 C  D L  U I  0 0 0 \
 o C  1 L  0 0 0  U I  1 I  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0\
 0  U I  1 o  U I  0 0 0  o C  1 L  0 0 0  U I  1 P  U I  0 0 0  o C  \
1 L  0 0 0  U I  1 P  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  \
o U  U I  1 I  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  0 O D  0 O \
I  U I  0 0 O  0 0 0  0 0 P  U I  o C  o C  1 L  0 0 0  0 0 0  o C  0 \
0 0  o C  o C  1 L  o C  o C  0 0 0  U I  D L  0 O  U I  U I  o C  o C\
  1 L  0 0 0  0 0 0  o C  0 0 0  o C  o C  1 L  o C  o C  0 0 0  U I  \
P 0  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  0 O L  0 O D  C L  U\
 I  1 P  U I  o P  L o  L O  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o\
 1  C o  0 0 1  U I  1 O  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  \
D o  D 0  U I  1 D  U I  D o  D 0  D L  U I  o U  o U  o U  o U  U I  \
1 I  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D \
 1 C  0 O D  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  \
o C  o C  1 L  0 0 0  0 0 0  o C  0 0 0  o C  o C  1 L  o C  o C  0 0 \
0  0 O  U I  0 O D  0 O I  U I  D O  D D  U I  1 D  U I  D O  D D  D L\
  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 I  U I  o C  0 0 \
0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  0 O O  0 O 0  0 O I  U I  0 \
O D  1 C  1 C  o U  U I  1 O  U I  0 O I  0 0 o  0 0 O  C D  C C  C o \
 0 O L  0 O L  U I  1 1  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C \
o  0 0 P  C o  U I  1 1  U I  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0  \
C D  o 1  C o  0 0 1  U I  1 1  U I  0 O C  U I  1 0  U I  D L  0 O  U\
 I  0 0 0  o C  1 L  0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  1 L  o C  1 L \
 1 L  U I  P 0  U I  U C  U C  0 O  U I  0 O D  0 O I  U I  D U  U I  \
1 D  U I  D U  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U \
I  U o  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 U \
 U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  0 O D  0 O \
I  U I  o U  0 O D  o U  o U  o U  0 O D  o U  1 C  o U  1 C  U I  0 0\
 O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  0 0 D  0 I 0  0 0 D  U I  1 \
P  U I  0 0 I  C o  0 0 P  0 O 1  U I  D L  0 O  U I  U I  0 0 D  0 I \
0  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  C o \
 0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  o U  0 O D  o U  o \
U  o U  0 O D  o U  1 C  o U  1 C  U I  1 0  0 O  U I  U I  0 O D  0 O\
 I  U I  1 C  D 0  U I  1 D  U I  1 C  D 0  D L  U I  0 0 0  0 0 0  0 \
0 0  1 L  o C  0 0 0  1 L  0 O  U I  U I  0 O D  0 O I  U I  1 C  D o \
 U I  1 D  U I  1 C  D o  D L  U I  o U  0 O D  1 C  o U  U I  1 D  U \
I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  0 0 P  0 0 1  \
0 I 0  U I  D L  0 O  U I  U I  o C  o C  o C  o C  0 0 0  1 L  1 L  1\
 L  0 0 0  1 L  1 L  o C  o C  U I  P 0  U I  U C  0 O D  0 O C  0 0 I\
  0 0 0  0 0 1  0 0 P  U I  U C  U I  1 U  U I  0 O I  0 0 o  0 0 O  C\
 D  C C  C o  0 O L  0 O L  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D \
 0 0 P  U I  1 O  U I  U C  1 P  U C  U I  1 0  U I  C 0  U I  1 L  U \
I  C U  0 O  U I  U I  0 O D  0 O I  U I  D o  D 1  U I  1 D  U I  D o\
  D 1  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O \
D  U I  1 P  U I  o C  1 L  0 0 0  o C  U I  U o  U I  o C  0 0 0  0 0\
 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0\
  o C  1 L  o C  1 L  1 L  U I  1 D  U I  o C  1 L  0 0 0  o C  U I  1\
 I  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  U I  \
0 O 0  0 I O  0 O 0  C C  U I  1 O  U I  o C  o C  o C  o C  0 0 0  1 \
L  1 L  1 L  0 0 0  1 L  1 L  o C  o C  U I  1 0  0 O  U I  U I  0 O D\
  0 O I  U I  D 0  D 0  U I  1 D  U I  D 0  D 0  D L  U I  o C  0 0 0 \
 0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  U o  U I  o U  1 C  1 C  0 O D\
  U I  1 D  U I  o U  o U  o U  o U  U I  1 P  U I  o U  o U  0 O D  o\
 U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 o  U I  o U  o U  0 O D  \
o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  0 O 0  0 I O  C C  0 \
O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  D o  D \
1  U I  1 D  U I  D o  D 1  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C\
  0 0 0  U I  1 U  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I\
  1 I  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 \
O  U I  U I  0 0 P  0 0 1  C o  C C  0 O 0  C L  C o  C C  0 O o  U I \
 1 P  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  C D  0 O 0  0 I O  C C  \
U I  1 O  U I  0 O I  0 O D  0 O L  0 O 0  U I  P 0  U I  0 0 D  0 I 0\
  0 0 D  U I  1 P  U I  0 0 D  0 0 P  0 O O  0 0 0  0 0 o  0 0 P  U I \
 1 0  0 O  U I  U I  0 O D  0 O I  U I  D P  D 1  U I  1 D  U I  D P  \
D 1  D L  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0\
 O D  1 C  0 O D  0 O  U I  0 O 0  0 I O  0 O 0  C C  U I  1 O  U I  U\
 C  0 0 1  0 O 0  0 0 P  C D  0 0 L  C o  0 O L  P 0  U C  U I  1 U  U\
 I  0 O I  0 0 o  0 0 O  C D  C C  C o  0 O L  0 O L  U I  1 0  0 O  U\
 I  0 O D  0 O I  U I  D O  D o  U I  1 D  U I  D O  D o  D L  U I  0 \
0 0  o C  1 L  0 0 0  U I  1 D  U I  o U  1 C  o U  0 O D  1 C  1 C  1\
 C  U I  1 U  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  U o  U \
I  0 0 0  o C  1 L  0 0 0  U I  U o  U I  o C  1 L  0 0 0  o C  0 O  U\
 I  0 O D  0 O I  U I  D P  D I  U I  1 D  U I  D P  D I  D L  U I  0 \
0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 U  U I  0 0 0  o C  1 \
L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  0 O D  1 C  1 C \
 o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 U  U I\
  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U I  0 0 P  0 0\
 1  0 I 0  U I  D L  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1 \
 0 0 O  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  0 0 0  o C  1 L  0 0 \
0  0 0 0  0 0 0  0 0 0  0 0 0  1 L  o C  1 L  1 L  U I  1 0  0 O  U I \
 0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 1  0 O 0  \
0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 0  o C  1 L  0 0 0  0 0 0  0 0 0 \
 0 0 0  0 0 0  1 L  o C  1 L  1 L  0 O  U I  0 O D  0 O I  U I  D 1  D\
 O  U I  1 D  U I  D 1  D O  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  \
1 L  o C  1 L  1 L  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L \
 0 0 0  U I  1 U  U I  o U  1 C  1 C  0 O D  0 O  0 O O  0 O 0  0 O I \
 U I  0 O D  0 O D  0 O D  1 C  1 C  o U  o U  1 C  o U  U I  1 O  U I\
  0 O I  0 0 o  0 0 O  C D  C C  C o  0 O L  0 O L  U I  1 1  U I  0 0\
 I  C o  0 O U  0 O 0  C D  0 O O  C o  0 0 P  C o  U I  1 1  U I  P o\
  0 0 0  0 0 0  0 O o  0 O D  0 O 0  C D  o 1  C o  0 0 1  U I  1 1  U\
 I  0 O C  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  D 1  D o  \
U I  1 D  U I  D 1  D o  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L \
 0 0 0  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  0 O U \
 0 O L  0 0 0  C L  C o  0 O L  U I  0 0 0  1 L  o C  o C  1 L  1 L  0\
 O  U I  U I  0 0 0  1 L  o C  o C  1 L  1 L  U I  P 0  U I  0 0 0  1 \
L  o C  o C  1 L  1 L  U I  1 U  U I  1 C  0 O  U I  U I  0 0 0  o C  \
1 L  0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  1 L  o C  1 L  1 L  U I  P 0  \
U I  U C  U C  0 O  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  \
U C  0 O O  0 0 0  0 0 0  0 0 0  0 0 0  0 O O  0 0 0  0 0 0  U C  0 O \
 U I  U I  0 O D  0 O I  U I  o U  0 O D  o U  o U  o U  0 O D  o U  1\
 C  o U  1 C  U I  0 0 O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  0 0 D \
 0 I 0  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  D L  0 O \
 U I  U I  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P \
 0 O 1  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 \
O  U I  o U  0 O D  o U  o U  o U  0 O D  o U  1 C  o U  1 C  U I  1 0\
  0 O  U I  U I  U I  0 O D  0 O I  U I  D 1  D 0  U I  1 D  U I  D 1 \
 D 0  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 o  U I  0 \
0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 I  U I  0 0 0  o C  1 \
L  0 0 0  U I  1 P  U I  0 O D  1 C  0 O  U I  U I  o C  0 0 0  0 0 0 \
 0 0 0  0 0 0  U I  P 0  U I  U C  o P  L U  L O  0 0 1  0 0 0  0 O O \
 0 I 0  0 0 O  C o  0 O C  0 O D  C C  P o  0 0 0  0 O O  0 O 0  U o  \
0 0 D  1 P  0 0 I  0 I 0  U C  U I  U o  U I  0 0 D  0 0 P  0 0 1  U I\
  1 O  U I  0 0 0  1 L  o C  o C  1 L  1 L  U I  1 0  0 O  U I  U I  0\
 O D  o U  0 O D  0 O D  0 O D  o U  0 O D  o U  0 O D  U I  P 0  U I \
 0 0 0  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I \
 0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I  o U  0 O D  o U  o U  o U \
 0 O D  o U  1 C  o U  1 C  U I  1 1  U I  o C  0 0 0  0 0 0  0 0 0  0\
 0 0  U I  1 0  0 O  U I  U I  0 0 0  o C  U I  P 0  U I  0 0 0  0 0 I\
  0 O 0  0 0 O  U I  1 O  U I  0 O D  o U  0 O D  0 O D  0 O D  o U  0\
 O D  o U  0 O D  U I  1 1  U I  U 1  0 0 C  C L  U 1  U I  1 0  0 O  \
U I  U I  0 0 0  o C  U I  1 P  U I  0 0 C  0 0 1  0 O D  0 0 P  0 O 0\
  U I  1 O  U I  U 1  U D  U I  1 D  1 I  1 D  U I  C C  0 0 0  0 O O \
 0 O D  0 0 O  0 O U  D L  U I  0 0 o  0 0 P  0 O I  1 D  D P  U I  1 \
D  1 I  1 D  C I  0 0 O  U 1  U I  1 0  0 O  U I  U I  0 0 0  o C  U I\
  1 P  U I  0 0 C  0 0 1  0 O D  0 0 P  0 O 0  U I  1 O  U I  0 O I  0\
 0 o  0 0 O  C D  C C  C o  0 O L  0 O L  U I  1 P  U I  0 O 0  0 0 O \
 C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U 1  0 0 o  0 0 P  0 O I  1 \
D  D P  U 1  U I  1 0  U I  1 0  U I  D C  0 O  U I  U I  0 0 0  o C  \
U I  1 P  U I  C C  0 O L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 \
O  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  C L  0 O 0  \
0 O I  0 0 0  0 0 1  0 O 0  U I  0 O O  0 0 0  U C  0 O  U I  U I  0 O\
 D  1 C  o U  1 C  o U  0 O D  1 C  1 C  0 O D  U I  P 0  U I  o U  1 \
C  0 O D  o U  0 O D  0 O D  0 O D  o U  1 C  U I  1 O  U I  o C  0 0 \
0  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0\
 P  U I  1 O  U I  U C  1 P  U C  U I  1 0  U I  C 0  U I  1 L  U I  C\
 U  U I  1 1  U I  0 O D  o U  0 O D  0 O D  0 O D  o U  0 O D  o U  0\
 O D  U I  1 0  0 O  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I \
 U C  C o  0 O I  0 0 P  0 O 0  0 0 1  U C  0 O  U I  U I  0 O D  0 O \
I  U I  D P  D D  U I  1 D  U I  D P  D D  D L  U I  0 0 0  0 0 0  o C\
  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  o C  0 0 0  0 0 0  0 0 0  1 L\
  1 L  1 L  1 L  U I  1 D  U I  o C  1 L  0 0 0  o C  U I  1 U  U I  o\
 U  0 O D  o U  o U  U I  U o  U I  0 0 0  o C  1 L  0 0 0  U I  1 o  \
U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  U I \
 0 0 0  o C  1 L  0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  1 L  o C  1 L  1 \
L  U I  P 0  U I  0 O D  1 C  o U  1 C  o U  0 O D  1 C  1 C  0 O D  U\
 I  1 P  U I  o 0  0 O 0  0 0 P  o P  L U  L O  0 0 1  0 0 0  P L  C o\
  0 0 P  C o  U I  1 O  U I  0 0 I  C o  0 O U  0 O 0  C D  0 O O  C o\
  0 0 P  C o  U I  1 1  U I  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0  C\
 D  o 1  C o  0 0 1  U I  1 1  U I  0 O C  U I  1 0  0 O  U I  U I  0 \
0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  0 0 1  0 O 0  0 0 P  \
0 0 o  0 0 1  0 0 O  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  0 0 0  o\
 C  1 L  0 0 0  0 0 0  0 0 0  0 0 0  0 0 0  1 L  o C  1 L  1 L  U I  1\
 0  0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U\
 I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 0  o C  1 L  0 \
0 0  0 0 0  0 0 0  0 0 0  0 0 0  1 L  o C  1 L  1 L  0 O  U I  0 O 0  \
0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 P  0 0 1  C o  C C\
  0 O 0  C L  C o  C C  0 O o  U I  1 P  U I  0 0 I  0 0 1  0 O D  0 0\
 O  0 0 P  C D  0 O 0  0 I O  C C  U I  1 O  U I  1 0  0 O  U I  0 0 1\
  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  U 1  U 1  0 O  U I  0 O D  0\
 O I  U I  1 C  D O  U I  1 D  U I  1 C  D O  D L  U I  o C  0 0 0  0 \
0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  0 O O  0 O 0  0 O I  U I  o U  1 \
C  0 O D  o U  0 O D  0 O D  0 O D  o U  1 C  U I  1 O  U I  0 O I  0 \
0 o  0 O L  0 O L  C D  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 O I\
  0 O D  0 O L  0 O 0  0 0 O  C o  0 O C  0 O 0  0 0 C  0 O D  0 0 P  \
0 O 1  0 0 I  C o  0 0 P  0 O 1  U I  1 0  U I  D L  0 O  U I  0 0 P  \
0 0 1  0 I 0  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  D P  D 1  U \
I  1 D  U I  D P  D 1  D L  U I  o U  o U  o U  o U  U I  1 D  U I  o \
U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  U I  U I  0 O D  0 O C  0 0 I \
 0 0 0  0 0 1  0 0 P  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  0\
 O L  0 O D  C L  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 \
0 O  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  0 O L  0 O D  C L \
 U I  1 P  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  C D  0 O C  \
0 0 0  0 O O  0 0 o  0 O L  0 O 0  U I  1 O  U I  0 O I  0 0 o  0 O L \
 0 O L  C D  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 0 I  C o  C C \
 0 O o  C o  0 O U  0 O 0  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U \
I  1 0  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 \
O  U I  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 O D  0 O\
 C  0 0 I  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U \
I  0 O D  0 O C  0 0 I  U I  1 P  U I  0 O L  0 0 0  C o  0 O O  C D  \
0 0 D  0 0 0  0 0 o  0 0 1  C C  0 O 0  U I  1 O  U I  0 O I  0 0 o  0\
 O L  0 O L  C D  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 O I  0 O \
D  0 O L  0 O 0  0 0 O  C o  0 O C  0 O 0  0 0 C  0 O D  0 0 P  0 O 1 \
 0 0 I  C o  0 0 P  0 O 1  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I \
 D 1  D 0  U I  1 D  U I  D 1  D 0  D L  U I  0 O D  o U  o U  1 C  1 \
C  1 C  0 O D  U I  1 o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 \
0  U I  1 U  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 P  U\
 I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 P  U I  o C  0 0 0  0 0 0  0 0\
 0  1 L  1 L  1 L  1 L  0 O  U I  U I  0 O D  0 O I  U I  D I  D P  U \
I  1 D  U I  D I  D P  D L  U I  o U  1 C  1 C  0 O D  U I  1 D  U I  \
0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 D  U I  0 0 0  \
0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 P  U I  0 0 0  1 L \
 0 0 0  o C  1 L  U I  1 D  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0\
 O D  o U  U I  1 I  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  0 O O  0 O\
 0  0 O I  U I  o C  o C  o C  o C  o C  U I  1 O  U I  C C  C o  0 0 \
I  0 0 P  C C  0 O 1  C o  0 O o  0 O 0  0 I 0  U I  1 1  U I  C C  0 \
O P  U I  1 1  U I  0 0 P  0 I 0  0 0 I  0 O 0  U I  P 0  U I  1 C  U \
I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  D 1  D P  U I  1 D  U I\
  D 1  D P  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 U  U I  o U \
 1 C  o U  0 O D  1 C  1 C  1 C  U I  1 D  U I  o U  o U  0 O D  o U  \
0 O D  o U  o U  1 C  1 C  0 O D  U I  1 o  U I  o U  1 C  o U  0 O D \
 1 C  1 C  1 C  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0\
 0  0 O  U I  0 O D  0 O I  U I  D U  1 L  U I  1 D  U I  D U  1 L  D \
L  U I  o C  1 L  0 0 0  o C  U I  1 U  U I  o U  0 O D  1 C  o U  U I\
  1 P  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 o  U I  o U \
 1 C  1 C  0 O D  U I  1 o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D\
  U I  1 I  U I  o U  o U  o U  o U  0 O  U I  0 O D  0 O I  U I  D P \
 D U  U I  1 D  U I  D P  D U  D L  U I  o U  0 O D  1 C  o U  U I  1 \
P  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  U o  U I  o\
 C  1 L  0 0 0  o C  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  \
U I  o C  o C  0 0 0  1 L  1 L  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 \
0 0  U I  P 0  U I  U 1  U 1  0 O  U I  0 O D  1 C  0 O D  1 C  0 O D \
 0 O D  o U  o U  0 O D  0 O D  0 O D  o U  o U  U I  P 0  U I  U 1  U\
 1  0 O  U I  0 O D  0 O I  U I  D U  U I  1 D  U I  D U  D L  U I  o \
C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 o  U I  0 0 0  1 L  1 L \
 o C  1 L  0 0 0  0 0 0  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  U\
 I  U o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 I  U I  0 O \
D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 U  U I  0 0 0  o C \
 1 L  0 0 0  0 O  U I  0 O D  0 O I  U I  1 C  1 C  U I  1 D  U I  1 C\
  1 C  D L  U I  0 O D  1 C  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  \
o C  1 L  o C  1 L  1 L  U I  U o  U I  o U  o U  o U  o U  U I  1 P  \
U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  0 O D  0 O I\
  U I  D o  D O  U I  1 D  U I  D o  D O  D L  U I  o U  0 O D  1 C  o\
 U  0 O  U I  0 O D  0 O I  U I  D I  D U  U I  1 D  U I  D I  D U  D \
L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  U\
 o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 D  U I  0 O D  \
0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 P  U I  o U  1 C  o U \
 0 O D  1 C  1 C  1 C  0 O  U I  0 O D  0 O I  U I  D I  D O  U I  1 D\
  U I  D I  D O  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  \
o U  U I  1 o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 U \
 U I  o U  0 O D  o U  o U  U I  1 P  U I  o U  0 O D  o U  o U  U I  \
U o  U I  o C  1 L  0 0 0  o C  0 O  U I  o U  0 O D  1 C  o U  o U  o\
 U  1 C  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  0 O  U I  0 0 0\
  0 0 0  o U  0 O D  0 O D  1 C  0 O D  0 O D  1 C  o U  o U  1 C  0 O\
 D  o U  1 C  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  0 O D\
  1 C  0 O D  1 C  0 O D  0 O D  o U  o U  0 O D  0 O D  0 O D  o U  o\
 U  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  0 O D  0 O I  U\
 I  0 O L  0 O 0  0 0 O  U I  1 O  U I  C C  C o  0 0 I  0 0 P  C C  0\
 O 1  C o  0 O o  0 O 0  0 I 0  U I  1 0  U I  P I  U I  1 L  U I  D L\
  0 O  U I  U I  o C  o C  1 L  o C  0 0 0  U I  P 0  U I  C C  C o  0\
 0 I  0 0 P  C C  0 O 1  C o  0 O o  0 O 0  0 I 0  0 O  U I  U I  0 O \
D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o C  o C  1 L  o C  0 0 0  U \
I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0\
 P  0 O 1  U I  1 O  U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  U C  U I  1\
 0  U I  D L  0 O  U I  U I  U I  o C  o C  1 L  o C  0 0 0  U I  P 0 \
 U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  D L  1 o  1 o  0 0 C  0 0 C  0 \
0 C  1 P  0 O U  0 0 0  0 0 0  0 O U  0 O L  0 O 0  1 P  C C  0 0 0  0\
 O C  1 o  0 0 1  0 O 0  C C  C o  0 0 I  0 0 P  C C  0 O 1  C o  1 o \
 C o  0 0 I  0 O D  1 o  C C  0 O 1  C o  0 O L  0 O L  0 O 0  0 0 O  \
0 O U  0 O 0  P U  0 O o  P 0  U C  U I  1 U  U I  o C  o C  1 L  o C \
 0 0 0  U I  1 U  U I  U C  U L  C o  0 O P  C o  0 I O  P 0  1 C  U C\
  0 O  U I  U I  U I  0 O D  0 O I  U I  D D  D U  U I  1 D  U I  D D \
 D U  D L  U I  o U  0 O D  1 C  o U  U I  1 P  U I  0 O D  1 C  U I  \
1 D  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  U o  U I  0 0 0  1\
 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 o  U I  o C  1 L  0 0 0  o C  \
U I  U o  U I  o C  1 L  0 0 0  o C  0 O  U I  U I  o U  0 O D  1 C  o\
 U  o U  o U  1 C  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  0 O  U I  \
U I  0 O D  0 O I  U I  D P  D o  U I  1 D  U I  D P  D o  D L  U I  o\
 C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 U  U I  0 0 0  0 0 0  o\
 C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 o  U I  0 0 0  1 L  0 0 0  \
o C  1 L  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  U I  U o  U I  o C  0\
 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  U I  0 O D  o U  1 C\
  0 O D  0 O D  1 C  o U  0 O D  U I  P 0  U I  U C  C C  0 O 1  C o  \
0 O L  0 O L  0 O 0  0 0 O  0 O U  0 O 0  1 P  1 I  P U  C I  U C  1 O\
  1 P  1 I  P U  1 0  C I  U C  U C  0 O  U I  U I  o C  0 0 0  0 0 0 \
 o C  o C  o C  0 0 0  o C  0 0 0  0 0 0  1 L  o C  1 L  U I  P 0  U I\
  U C  C I  U C  1 O  1 P  1 I  P U  1 0  C I  U C  U C  0 O  U I  U I\
  o C  1 L  o C  o C  o C  o C  0 0 0  1 L  U I  P 0  U I  0 0 0  o C \
 o C  o C  o C  U I  1 O  U I  o C  o C  1 L  o C  0 0 0  U I  1 1  U \
I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  P 0  \
U I  C C  0 O P  U I  1 0  0 O  U I  U I  o C  o C  0 0 0  1 L  1 L  0\
 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  P 0  U I  0 0 1  0 O 0 \
 U I  1 P  U I  0 O I  0 O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 \
O  U I  0 O D  o U  1 C  0 O D  0 O D  1 C  o U  0 O D  U I  1 1  U I \
 o C  1 L  o C  o C  o C  o C  0 0 0  1 L  U I  1 0  U I  C 0  U I  1 \
L  U I  C U  0 O  U I  U I  o C  o C  0 0 0  0 0 0  o C  1 L  o C  0 0\
 0  1 L  1 L  U I  P 0  U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  D L  1 o\
  1 o  0 0 C  0 0 C  0 0 C  1 P  0 O U  0 0 0  0 0 0  0 O U  0 O L  0 \
O 0  1 P  C C  0 0 0  0 O C  1 o  0 0 1  0 O 0  C C  C o  0 0 I  0 0 P\
  C C  0 O 1  C o  1 o  C o  0 0 I  0 O D  1 o  0 0 1  0 O 0  0 O L  0\
 0 0  C o  0 O O  P U  C C  P 0  U C  U I  D C  0 O  U I  U I  0 O D  \
o U  o U  o U  o U  o U  o U  o U  0 O D  o U  o U  o U  U I  P 0  U I\
  o C  o C  1 L  o C  0 0 0  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D\
  0 0 P  U I  1 O  U I  U C  0 O o  P 0  U C  U I  1 0  U I  C 0  U I \
 1 C  U I  C U  0 O  U I  U I  o C  o C  0 0 0  0 0 0  o C  1 L  o C  \
0 0 0  1 L  1 L  U I  1 U  P 0  U I  o C  o C  0 0 0  1 L  1 L  0 0 0 \
 0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  U C  U L  0 O o  P\
 0  U C  U I  1 U  U I  0 O D  o U  o U  o U  o U  o U  o U  o U  0 O \
D  o U  o U  o U  U I  1 U  U I  U C  U L  0 0 1  0 O 0  C o  0 0 D  0\
 0 0  0 0 O  P 0  0 O D  U L  0 0 P  0 I 0  0 0 I  0 O 0  P 0  0 O D  \
0 O C  C o  0 O U  0 O 0  U L  0 O L  C o  0 0 O  0 O U  P 0  0 O 0  0\
 0 O  U C  0 O  U I  U I  0 0 0  1 L  0 0 0  0 0 0  1 L  0 0 0  1 L  1\
 L  0 0 0  0 0 0  o C  1 L  1 L  U I  P 0  U I  0 0 0  o C  o C  o C  \
o C  U I  1 O  U I  o C  o C  0 0 0  0 0 0  o C  1 L  o C  0 0 0  1 L \
 1 L  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o \
 0 0 1  U I  P 0  U I  C C  0 O P  U I  1 0  0 O  U I  U I  0 0 0  0 0\
 0  o U  0 O D  0 O D  1 C  0 O D  0 O D  1 C  o U  o U  1 C  0 O D  o\
 U  1 C  U I  P 0  U I  0 0 1  0 O 0  U I  1 P  U I  0 O I  0 O D  0 0\
 O  0 O O  C o  0 O L  0 O L  U I  1 O  U I  o C  0 0 0  0 0 0  o C  o\
 C  o C  0 0 0  o C  0 0 0  0 0 0  1 L  o C  1 L  U I  1 1  U I  0 0 0\
  1 L  0 0 0  0 0 0  1 L  0 0 0  1 L  1 L  0 0 0  0 0 0  o C  1 L  1 L\
  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U I  o U  o U  0 O\
 D  o U  0 O D  0 O D  o U  1 C  0 O D  U I  P 0  U I  U C  0 O 1  0 0\
 P  0 0 P  0 0 I  D L  1 o  1 o  0 0 C  0 0 C  0 0 C  1 P  0 O U  0 0 \
0  0 0 0  0 O U  0 O L  0 O 0  1 P  C C  0 0 0  0 O C  1 o  0 0 1  0 O\
 0  C C  C o  0 0 I  0 0 P  C C  0 O 1  C o  1 o  C o  0 0 I  0 O D  1\
 o  0 O D  0 O C  C o  0 O U  0 O 0  P U  C C  P 0  U C  U I  1 U  U I\
  0 0 0  0 0 0  o U  0 O D  0 O D  1 C  0 O D  0 O D  1 C  o U  o U  1\
 C  0 O D  o U  1 C  0 O  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0\
 0 P  U I  o U  o U  0 O D  o U  0 O D  0 O D  o U  1 C  0 O D  U I  1\
 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  \
0 O 1  U I  1 O  U I  U 1  0 O 1  0 0 P  0 0 P  0 0 I  U 1  U I  1 0  \
U I  D L  0 O  U I  U I  U I  o U  o U  0 O D  o U  0 O D  0 O D  o U \
 1 C  0 O D  U I  P 0  U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  D L  1 o \
 1 o  0 0 C  0 0 C  0 0 C  1 P  0 O U  0 0 0  0 0 0  0 O U  0 O L  0 O\
 0  1 P  C C  0 0 0  0 O C  1 o  0 0 1  0 O 0  C C  C o  0 0 I  0 0 P \
 C C  0 O 1  C o  1 o  C o  0 0 I  0 O D  1 o  U C  U I  1 U  U I  o U\
  o U  0 O D  o U  0 O D  0 O D  o U  1 C  0 O D  0 O  U I  U I  0 O D\
  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 0 1  C o  0 0 O  0 O O  0 \
0 0  0 O C  0 O  U I  U I  0 O D  o U  1 C  0 O D  o U  1 C  o U  1 C \
 0 O D  1 C  o U  U I  P 0  U I  0 0 1  C o  0 0 O  0 O O  0 0 0  0 O \
C  U I  1 P  U I  0 0 1  C o  0 0 O  0 O O  0 0 1  C o  0 0 O  0 O U  \
0 O 0  U I  1 O  U I  1 C  1 L  1 L  U I  1 1  U I  1 C  1 L  1 L  1 L\
  U I  1 1  U I  D U  U I  1 0  0 O  U I  U I  o U  o U  0 O D  o C  1\
 L  o C  0 0 0  U I  P 0  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 I  C o\
  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U\
 I  0 0 0  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 0 0  o C  o C  o C  o\
 C  0 0 0  U I  1 1  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  0 O D  o\
 U  1 C  0 O D  o U  1 C  o U  1 C  0 O D  1 C  o U  U I  1 0  U I  1 \
U  U I  U 1  C C  C o  0 0 I  0 0 P  C C  0 O 1  C o  1 P  0 O D  0 O \
C  0 O U  U 1  U I  1 0  0 O  U I  U I  o U  o U  o U  1 C  1 C  o U  \
1 C  U I  P 0  U I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  o U  o \
U  0 O D  o C  1 L  o C  0 0 0  U I  1 1  U I  U 1  0 0 C  C L  U 1  U\
 I  1 0  0 O  U I  U I  o U  o U  o U  1 C  1 C  o U  1 C  U I  1 P  U\
 I  0 0 C  0 0 1  0 O D  0 0 P  0 O 0  U I  1 O  U I  0 0 0  o C  o C \
 o C  o C  U I  1 O  U I  o U  o U  0 O D  o U  0 O D  0 O D  o U  1 C\
  0 O D  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C\
 o  0 0 1  U I  P 0  U I  C C  0 O P  U I  1 0  U I  1 0  0 O  U I  U \
I  o U  o U  o U  1 C  1 C  o U  1 C  U I  1 P  U I  C C  0 O L  0 0 0\
  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  U I  o C  o C  o C  o C \
 1 L  0 0 0  1 L  o C  U I  P 0  U I  0 O D  o U  1 C  1 C  1 C  o U  \
U I  1 O  U I  C C  C o  0 0 I  0 0 P  C C  0 O 1  C o  U I  P 0  U I \
 o U  o U  0 O D  o C  1 L  o C  0 0 0  U I  1 0  0 O  U I  U I  0 O D\
  1 C  0 O D  1 C  0 O D  0 O D  o U  o U  0 O D  0 O D  0 O D  o U  o\
 U  U I  P 0  U I  o C  o C  o C  o C  1 L  0 0 0  1 L  o C  U I  1 P \
 U I  0 O U  0 O 0  0 0 P  U I  1 O  U I  1 0  0 O  U I  U I  0 0 0  0\
 0 D  U I  1 P  U I  0 0 1  0 O 0  0 O C  0 0 0  0 0 L  0 O 0  U I  1 \
O  U I  o U  o U  0 O D  o C  1 L  o C  0 0 0  U I  1 0  0 O  U I  U I\
  0 O D  0 O I  U I  D P  D D  U I  1 D  U I  D P  D D  D L  U I  0 O \
D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U\
 I  1 D  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I\
  U o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  \
1 P  U I  o U  o U  o U  o U  U I  1 o  U I  0 0 0  o C  1 L  0 0 0  1\
 L  0 0 0  0 0 0  o C  1 L  0 O  U I  0 O D  0 O I  U I  0 0 0  0 0 0 \
 o U  0 O D  0 O D  1 C  0 O D  0 O D  1 C  o U  o U  1 C  0 O D  o U \
 1 C  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  0 0 P  0 I 0  0 0 I \
 0 O 0  U I  P 0  P 0  U I  1 C  U I  D L  0 O  U I  U I  U I  0 0 1  \
0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  U C  0 0 1  0 O 0  C C  C o  0\
 0 I  0 0 P  C C  0 O 1  C o  C D  C C  0 O 1  C o  0 O L  0 O L  0 O \
0  0 0 O  0 O U  0 O 0  C D  0 O I  0 O D  0 O 0  0 O L  0 O O  P 0  U\
 C  U I  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U\
 I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D\
  U I  1 O  U I  0 0 0  0 0 0  o U  0 O D  0 O D  1 C  0 O D  0 O D  1\
 C  o U  o U  1 C  0 O D  o U  1 C  U I  1 0  U I  1 U  U I  U C  U L \
 0 0 1  0 O 0  C C  C o  0 0 I  0 0 P  C C  0 O 1  C o  C D  0 0 1  0 \
O 0  0 0 D  0 0 I  0 0 0  0 0 O  0 0 D  0 O 0  C D  0 O I  0 O D  0 O \
0  0 O L  0 O O  P 0  U C  U I  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  \
0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0\
 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 O D  1 C  0 O D  1 C  0 O D \
 0 O D  o U  o U  0 O D  0 O D  0 O D  o U  o U  U I  1 0  0 O  U I  U\
 I  0 O 0  0 O L  0 O D  0 O I  U I  0 0 P  0 I 0  0 0 I  0 O 0  U I  \
P 0  P 0  U I  D O  U I  D L  0 O  U I  U I  U I  0 0 1  0 O 0  0 0 P \
 0 0 o  0 0 1  0 0 O  U I  U C  0 0 1  0 O 0  C C  C o  0 0 I  0 0 P  \
C C  0 O 1  C o  C D  C C  0 O 1  C o  0 O L  0 O L  0 O 0  0 0 O  0 O\
 U  0 O 0  C D  0 O I  0 O D  0 O 0  0 O L  0 O O  D L  U C  U I  1 U \
 U I  0 0 0  0 0 0  o U  0 O D  0 O D  1 C  0 O D  0 O D  1 C  o U  o \
U  1 C  0 O D  o U  1 C  U I  1 U  U I  U C  1 1  0 0 1  0 O 0  C C  C\
 o  0 0 I  0 0 P  C C  0 O 1  C o  C D  0 0 1  0 O 0  0 0 D  0 0 I  0 \
0 0  0 0 O  0 0 D  0 O 0  C D  0 O I  0 O D  0 O 0  0 O L  0 O O  D L \
 U C  U I  1 U  U I  0 O D  1 C  0 O D  1 C  0 O D  0 O D  o U  o U  0\
 O D  0 O D  0 O D  o U  o U  0 O  U I  U I  0 O 0  0 O L  0 0 D  0 O \
0  U I  D L  0 O  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 \
0 O  U I  U C  0 0 1  0 O 0  C C  C o  0 0 I  0 0 P  C C  0 O 1  C o  \
C D  C C  0 O 1  C o  0 O L  0 O L  0 O 0  0 0 O  0 O U  0 O 0  C D  0\
 O I  0 O D  0 O 0  0 O L  0 O O  P 0  U C  U I  1 U  U I  0 0 o  0 0 \
1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P\
  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 0  0 0 0 \
 o U  0 O D  0 O D  1 C  0 O D  0 O D  1 C  o U  o U  1 C  0 O D  o U \
 1 C  U I  1 0  U I  1 U  U I  U C  U L  0 0 1  0 O 0  C C  C o  0 0 I\
  0 0 P  C C  0 O 1  C o  C D  0 0 1  0 O 0  0 0 D  0 0 I  0 0 0  0 0 \
O  0 0 D  0 O 0  C D  0 O I  0 O D  0 O 0  0 O L  0 O O  P 0  U C  U I\
  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0\
 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  \
1 O  U I  0 O D  1 C  0 O D  1 C  0 O D  0 O D  o U  o U  0 O D  0 O D\
  0 O D  o U  o U  U I  1 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I\
  D L  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  U\
 C  U C  0 O  U I  U I  0 O D  0 O I  U I  D 1  U I  1 D  U I  D 1  D \
L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  0 0 \
0  o C  1 L  0 0 0  U I  1 I  U I  o C  o C  0 0 0  0 0 0  o C  o C  0\
 0 0  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L\
  0 O  U I  U I  0 O D  0 O I  U I  D D  D o  U I  1 D  U I  D D  D o \
 D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  U o  U I  o\
 U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  0 O O  0 O 0  0 O I  U I  0 0\
 0  o C  o C  o C  o C  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 1  \
U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  P 0\
  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  0 0 I  0 0 0  0 0 D  0\
 0 P  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  0 0 P  0\
 O D  0 O C  0 O 0  0 0 0  0 0 o  0 0 P  U I  P 0  U I  D O  1 L  U I \
 1 1  U I  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  0 0 D  U I  P 0  U \
I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  0 0 O  0 0 0  0 0 1  0 O 0\
  0 O O  0 O D  0 0 1  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  U\
 I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  D P  1 C  U I  1 D  U \
I  D P  1 C  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1\
 L  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  \
U I  1 I  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 U  U I  0 0\
 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  0 O D  0 O I  U I  D\
 0  D O  U I  1 D  U I  D 0  D O  D L  U I  o U  o U  0 O D  o U  0 O \
D  o U  o U  1 C  1 C  0 O D  U I  1 P  U I  o C  o C  0 0 0  0 0 0  o\
 C  o C  0 0 0  0 O  U I  o C  1 L  o C  1 L  0 0 0  1 L  0 0 0  1 L  \
0 0 0  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I\
  1 P  U I  o I  L 1  L 1  L O  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0\
  L O  0 0 1  0 0 0  C C  0 O 0  0 0 D  0 0 D  0 0 0  0 0 1  U I  1 O \
 U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 \
0  0 O  U I  0 O D  0 O I  U I  1 C  D U  U I  1 D  U I  1 C  D U  D L\
  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 P  U I  o U  1 C \
 o U  0 O D  1 C  1 C  1 C  0 O  U I  0 O D  0 O I  U I  0 0 O  0 0 0 \
 0 0 1  0 O 0  0 O O  0 O D  0 0 1  U I  D L  0 O  U I  U I  o C  o C \
 0 0 0  0 0 0  o C  o C  1 L  1 L  o C  1 L  o C  o C  1 L  1 L  0 0 0\
  0 0 0  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U\
 I  1 P  U I  C L  0 0 o  0 O D  0 O L  0 O O  C D  0 0 0  0 0 I  0 O \
0  0 0 O  0 O 0  0 0 1  U I  1 O  U I  0 O D  1 C  0 O D  o U  o U  1 \
C  o U  0 O D  0 O D  o U  0 O D  o U  1 C  U I  1 1  U I  o C  1 L  o\
 C  1 L  0 0 0  1 L  0 0 0  1 L  0 0 0  U I  1 1  U I  0 0 o  0 0 1  0\
 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  o I  L 1  L 1  L O  P P  \
C o  0 0 D  0 O D  C C  P D  0 0 o  0 0 P  0 O 1  o I  C o  0 0 O  0 O\
 O  0 O L  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  1 1  U I  0 0 o  0 0\
 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  o I  L 1  L 1  L O  \
o I  C o  0 0 O  0 O O  0 O L  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  \
1 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  o \
C  o C  0 0 0  0 0 0  o C  o C  1 L  1 L  o C  1 L  o C  o C  1 L  1 L\
  0 0 0  0 0 0  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L \
 D O  U I  1 P  U I  C L  0 0 o  0 O D  0 O L  0 O O  C D  0 0 0  0 0 \
I  0 O 0  0 0 O  0 O 0  0 0 1  U I  1 O  U I  o C  1 L  o C  1 L  0 0 \
0  1 L  0 0 0  1 L  0 0 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  \
0 O D  C L  D O  U I  1 P  U I  o I  L 1  L 1  L O  P P  C o  0 0 D  0\
 O D  C C  P D  0 0 o  0 0 P  0 O 1  o I  C o  0 0 O  0 O O  0 O L  0 \
O 0  0 0 1  U I  1 O  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 \
O L  0 O D  C L  D O  U I  1 P  U I  o I  L 1  L 1  L O  o I  C o  0 0\
 O  0 O O  0 O L  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  1 0  0 O  U I\
  U I  0 O D  0 O I  U I  1 C  D D  U I  1 D  U I  1 C  D D  D L  U I \
 0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 o  U I  o U\
  0 O D  o U  o U  U I  1 P  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C \
 U I  1 o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  o U  \
o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  P 0  U I  0 0 o  0 0 1  \
0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  L I  0 O 0  0 0 U  0 0 o\
  0 O 0  0 0 D  0 0 P  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 0  0\
 O  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I  \
C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  U I  1\
 O  U I  U C  L D  0 0 D  0 O 0  0 0 1  1 D  P D  0 O U  0 O 0  0 0 O \
 0 0 P  U C  U I  1 1  U I  U C  o o  0 0 0  0 I I  0 O D  0 O L  0 O \
L  C o  1 o  D U  1 P  1 L  U I  1 O  L o  0 O D  0 0 O  0 O O  0 0 0 \
 0 0 C  0 0 D  U I  o L  L 1  U I  D 1  1 P  1 C  D C  U I  L o  o C  \
L o  D 1  D I  1 0  U I  P D  0 0 I  0 0 I  0 O L  0 O 0  L o  0 O 0  \
C L  o D  0 O D  0 0 P  1 o  D U  D 0  D D  1 P  D 0  D 1  U I  1 O  o\
 D  o I  L 1  o o  o P  1 1  U I  0 O L  0 O D  0 O o  0 O 0  U I  o 0\
  0 O 0  C C  0 O o  0 0 0  1 0  U I  P o  0 O 1  0 0 1  0 0 0  0 O C \
 0 O 0  1 o  D 0  D 0  1 P  1 L  1 P  1 C  D D  D U  1 L  1 P  1 C  D \
U  D I  U I  L U  C o  0 O I  C o  0 0 1  0 O D  1 o  D U  D 0  D D  1\
 P  D 0  D 1  U C  U I  1 0  0 O  U I  0 O D  0 O I  U I  0 O 1  0 O 0\
  C o  0 O O  0 O 0  0 0 1  0 0 D  U I  D L  0 O  U I  U I  0 O I  0 0\
 0  0 0 1  U I  0 0 0  1 L  o C  o C  0 0 0  0 0 0  1 L  o C  o C  1 L\
  o C  o C  o C  U I  1 1  U I  o U  0 O D  1 C  U I  0 O D  0 0 O  U \
I  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  0 0 D  U I  D L  0 O  U I  \
U I  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I \
 C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  U I  \
1 O  U I  0 0 0  1 L  o C  o C  0 0 0  0 0 0  1 L  o C  o C  1 L  o C \
 o C  o C  U I  1 1  U I  o U  0 O D  1 C  U I  1 0  0 O  U I  U I  U \
I  0 O D  0 O I  U I  D U  D o  U I  1 D  U I  D U  D o  D L  U I  o U\
  0 O D  o U  o U  U I  U o  U I  o U  o U  0 O D  o U  0 O D  o U  o \
U  1 C  1 C  0 O D  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L \
 0 0 0  0 O  U I  o U  1 C  o U  o U  1 C  1 C  o U  0 O D  o U  o U  \
U I  P 0  U I  o C  o C  0 0 0  0 0 0  o C  o C  1 L  1 L  o C  1 L  o\
 C  o C  1 L  1 L  0 0 0  0 0 0  U I  1 P  U I  0 0 0  0 0 I  0 O 0  0\
 0 O  U I  1 O  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I\
  1 1  U I  0 0 I  0 0 0  0 0 D  0 0 P  U I  1 1  U I  0 0 P  0 O D  0\
 O C  0 O 0  0 0 0  0 0 o  0 0 P  U I  P 0  U I  0 0 P  0 O D  0 O C  \
0 O 0  0 0 0  0 0 o  0 0 P  U I  1 0  0 O  U I  o C  1 L  0 0 0  U I  \
P 0  U I  o U  1 C  o U  o U  1 C  1 C  o U  0 O D  o U  o U  U I  1 P\
  U I  0 0 1  0 O 0  C o  0 O O  U I  1 O  U I  1 0  0 O  U I  o U  1 \
C  o U  o U  1 C  1 C  o U  0 O D  o U  o U  U I  1 P  U I  C C  0 O L\
  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  0 0 1  0 O 0  0 0\
 P  0 0 o  0 0 1  0 0 O  U I  o C  1 L  0 0 0  U I  D C  0 O  U I  0 O\
 D  0 O I  U I  D I  1 C  U I  1 D  U I  D I  1 C  D L  U I  o U  1 C \
 1 C  0 O D  U I  1 U  U I  o U  0 O D  1 C  o U  U I  1 I  U I  o C  \
0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  0 O O  0 O 0  0 O I  U I\
  0 0 0  1 L  0 0 0  o C  0 0 0  o C  0 0 0  1 L  U I  1 O  U I  0 0 D\
  0 0 P  0 0 1  U I  1 1  U I  0 0 1  0 O 0  0 O U  U I  P 0  U I  o L\
  0 0 0  0 0 O  0 O 0  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I\
  0 0 1  0 O 0  0 O U  U I  D L  0 O  U I  U I  0 0 D  0 0 P  0 0 1  U\
 I  P 0  U I  0 0 1  0 O 0  U I  1 P  U I  0 O I  0 O D  0 0 O  0 O O \
 C o  0 O L  0 O L  U I  1 O  U I  0 0 1  0 O 0  0 O U  U I  1 1  U I \
 0 0 D  0 0 P  0 0 1  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I\
  o U  o U  o U  1 C  o U  0 O D  o U  1 C  0 O D  1 C  0 O D  U I  P \
0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 o  \
0 0 O  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  U I  1 O  U I  0 0 D  0 0 P \
 0 0 1  U I  C 0  U I  1 L  U I  D L  U I  0 O L  0 O 0  0 0 O  U I  1\
 O  U I  0 0 D  0 0 P  0 0 1  U I  1 0  U I  1 D  U I  1 C  U I  C U  \
U I  1 0  U I  D C  0 O  U I  0 0 0  1 L  o C  o C  o C  o C  o C  0 0\
 0  1 L  U I  P 0  U I  U C  U C  U I  D C  0 O  U I  0 O I  0 0 0  0 \
0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  \
0 0 0  U I  0 O D  0 0 O  U I  0 0 1  C o  0 0 O  0 O U  0 O 0  U I  1\
 O  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  o U  o U  o U  1 C  o U  \
0 O D  o U  1 C  0 O D  1 C  0 O D  U I  1 0  U I  1 0  U I  D L  0 O \
 U I  U I  0 0 0  1 L  o C  o C  o C  o C  o C  0 0 0  1 L  U I  1 U  \
P 0  U I  C C  0 O 1  0 0 1  U I  1 O  U I  0 0 0  0 0 1  0 O O  U I  \
1 O  U I  o U  o U  o U  1 C  o U  0 O D  o U  1 C  0 O D  1 C  0 O D \
 U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0\
 0 0  0 0 0  U I  C U  U I  1 0  U I  1 D  U I  o U  o U  o U  1 C  o \
U  0 O D  o U  1 C  0 O D  1 C  0 O D  U I  C 0  U I  0 O L  0 O 0  0 \
0 O  U I  1 O  U I  o U  o U  o U  1 C  o U  0 O D  o U  1 C  0 O D  1\
 C  0 O D  U I  1 0  U I  1 D  U I  1 C  U I  C U  U I  1 0  U I  D C \
 0 O  U I  0 0 0  1 L  o C  o C  o C  o C  o C  0 0 0  1 L  U I  P 0  \
U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 o  0 0\
 O  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  U I  1 O  U I  0 0 0  1 L  o C \
 o C  o C  o C  o C  0 0 0  1 L  U I  1 0  0 O  U I  0 O D  0 O I  U I\
  D U  D D  U I  1 D  U I  D U  D D  D L  U I  0 0 0  o C  1 L  0 0 0 \
 U I  1 U  U I  0 0 0  o C  1 L  0 0 0  0 O  U I  0 0 1  0 O 0  0 0 P \
 0 0 o  0 0 1  0 0 O  U I  0 0 0  1 L  o C  o C  o C  o C  o C  0 0 0 \
 1 L  0 O  U I  0 O D  0 O I  U I  D U  D 1  U I  1 D  U I  D U  D 1  \
D L  U I  o U  o U  o U  o U  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0 \
 1 L  1 L  1 L  1 L  0 O  0 O O  0 O 0  0 O I  U I  0 0 0  o C  0 0 0 \
 0 0 0  o C  1 L  o C  1 L  o C  1 L  0 0 0  0 0 0  o C  o C  o C  U I\
  1 O  U I  0 0 D  0 0 P  0 0 1  U I  1 0  U I  D L  0 O  U I  o U  0 \
O D  1 C  o U  0 O D  1 C  U I  P 0  U I  0 0 1  0 O 0  U I  1 P  U I \
 0 O I  0 O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 O  U I  U C  0 \
0 o  0 0 O  0 O 0  0 0 D  C C  C o  0 0 I  0 O 0  C I  1 O  C I  U C  \
1 O  1 P  1 I  P U  1 0  C I  U C  U C  U I  1 1  U I  0 0 D  0 0 P  0\
 0 1  U I  1 0  0 O  U I  0 O D  0 O I  U I  D 0  D U  U I  1 D  U I  \
D 0  D U  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L \
 U I  1 D  U I  o U  o U  o U  o U  U I  U o  U I  0 0 0  0 0 0  o C  \
0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  0 O D  0 O I  U I  1 O  U I \
 0 0 O  0 0 0  0 0 P  U I  o U  0 O D  1 C  o U  0 O D  1 C  U I  P 0 \
 P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 0  U I  C o  0 0 O  0 O O \
 U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  o U  0 O D  1 C  o U  0 O D \
 1 C  U I  1 0  U I  P I  U I  1 L  U I  D L  0 O  U I  U I  0 O I  0 \
0 0  0 0 1  U I  o U  o U  1 C  1 C  1 C  o U  1 C  o U  0 O D  0 O D \
 U I  0 O D  0 0 O  U I  o U  0 O D  1 C  o U  0 O D  1 C  U I  D L  0\
 O  U I  U I  U I  0 O D  0 O I  U I  D P  D I  U I  1 D  U I  D P  D \
I  D L  U I  o U  0 O D  o U  o U  U I  U o  U I  0 O D  0 O D  o U  1\
 C  0 O D  o U  0 O D  o U  U I  U o  U I  o C  o C  0 0 0  0 0 0  o C\
  o C  0 0 0  U I  1 U  U I  o C  1 L  0 0 0  o C  U I  U o  U I  0 0 \
0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  U I  U I  0 0\
 D  0 0 P  0 0 1  U I  P 0  U I  0 0 D  0 0 P  0 0 1  U I  1 P  U I  0\
 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  o U  o U  1\
 C  1 C  1 C  o U  1 C  o U  0 O D  0 O D  U I  1 1  U I  0 0 o  0 0 1\
  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 o  0 0 O  0 0 U  0 0 o \
 0 0 0  0 0 P  0 O 0  U I  1 O  U I  o U  o U  1 C  1 C  1 C  o U  1 C\
  o U  0 O D  0 O D  U I  1 0  U I  1 0  0 O  U I  0 0 1  0 O 0  0 0 P\
  0 0 o  0 0 1  0 0 O  U I  0 0 D  0 0 P  0 0 1  0 O  U I  0 O D  0 O \
I  U I  D I  D D  U I  1 D  U I  D I  D D  D L  U I  o U  1 C  1 C  0 \
O D  U I  1 U  U I  o U  0 O D  1 C  o U  U I  1 P  U I  o U  0 O D  o\
 U  o U  U I  1 I  U I  o U  o U  o U  o U  U I  1 P  U I  0 0 0  1 L \
 0 0 0  o C  1 L  U I  1 o  U I  o U  1 C  1 C  0 O D  0 O  0 O D  1 C\
  1 C  0 O D  0 O D  U I  P 0  U I  1 L  0 O  0 O O  0 O 0  0 O I  U I\
  o C  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 0 0  0 0 0  1 L  U I  1 O\
  U I  0 O C  U I  1 1  U I  0 O 1  0 0 P  0 O C  0 O L  C D  0 0 I  C\
 o  0 O U  0 O 0  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O \
0  o 1  C o  0 0 1  U I  1 0  U I  D L  0 O  U I  0 O U  0 O L  0 0 0 \
 C L  C o  0 O L  U I  0 O D  1 C  1 C  0 O D  0 O D  0 O  U I  0 O D \
 1 C  1 C  0 O D  0 O D  U I  1 U  P 0  U I  1 C  0 O  U I  0 0 0  o C\
  o C  o C  o C  o C  1 L  o C  0 0 0  0 0 0  0 0 0  0 0 0  U I  P 0  \
U I  0 O C  U I  C 0  U I  U C  0 O 0  0 I O  0 0 I  0 0 1  0 O 0  0 0\
 D  U C  U I  C U  0 O  U I  0 O D  o U  1 C  o U  1 C  0 O D  o U  o \
U  1 C  0 O D  U I  P 0  U I  0 O C  U I  C 0  U I  U C  0 0 I  C o  0\
 O U  0 O 0  U C  U I  C U  0 O  U I  0 0 0  1 L  0 0 0  1 L  1 L  1 L\
  o C  0 0 0  U I  P 0  U I  0 0 1  0 O 0  U I  1 P  U I  C C  0 0 0  \
0 O C  0 0 I  0 O D  0 O L  0 O 0  U I  1 O  U I  U C  C I  U P  o P  \
0 O D  0 0 L  0 O 0  L U  0 0 P  0 0 1  0 O 0  C o  0 O C  P o  C o  0\
 0 I  0 0 P  C C  0 O 1  C o  C I  C 0  1 O  C 0  C 1  C I  C U  C U  \
1 I  1 0  C I  C U  U C  U I  1 0  U I  1 P  U I  0 O I  0 O D  0 0 O \
 0 O O  C o  0 O L  0 O L  U I  1 O  U I  0 0 0  o C  o C  o C  o C  o\
 C  1 L  o C  0 0 0  0 0 0  0 0 0  0 0 0  U I  1 0  U I  C 0  U I  1 L\
  U I  C U  0 O  U I  0 O D  0 O I  U I  D U  D D  U I  1 D  U I  D U \
 D D  D L  U I  o U  o U  o U  o U  U I  1 I  U I  o U  o U  0 O D  o \
U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U I  0 O D  1 C  0 O  U\
 I  o C  o C  1 L  o C  0 0 0  U I  P 0  U I  0 0 1  0 O 0  U I  1 P  \
U I  C C  0 0 0  0 O C  0 0 I  0 O D  0 O L  0 O 0  U I  1 O  U I  0 0\
 0  1 L  0 0 0  1 L  1 L  1 L  o C  0 0 0  U I  1 0  U I  1 P  U I  0 \
O I  0 O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 O  U I  0 O 1  0 0\
 P  0 O C  0 O L  C D  0 0 I  C o  0 O U  0 O 0  U I  1 0  U I  C 0  U\
 I  1 L  U I  C U  0 O  U I  0 O D  0 O I  U I  D I  D I  U I  1 D  U \
I  D I  D I  D L  U I  o C  1 L  0 0 0  o C  U I  1 o  U I  o U  0 O D\
  o U  o U  U I  1 U  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  \
U I  U o  U I  o U  0 O D  1 C  o U  U I  1 o  U I  o U  1 C  o U  0 O\
 D  1 C  1 C  1 C  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  \
o C  1 L  1 L  0 O  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  \
o C  o C  1 L  o C  0 0 0  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 \
0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U 1  0 O 1  0 0\
 P  0 0 P  0 0 I  U 1  U I  1 0  U I  D L  0 O  U I  U I  0 O D  0 O D\
  1 C  1 C  o U  0 O D  0 O D  0 O D  U I  P 0  U I  U C  0 O 1  0 0 P\
  0 0 P  0 0 I  D L  1 o  1 o  U C  U I  1 U  U I  U 1  U 1  U I  1 P \
 U I  0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I  0 O D  o U  1 C  o U \
 1 C  0 O D  o U  o U  1 C  0 O D  U I  1 P  U I  0 0 D  0 0 I  0 O L \
 0 O D  0 0 P  U I  1 O  U I  U C  1 o  U C  U I  1 0  U I  C 0  U I  \
D O  U I  D L  U I  D 0  U I  C U  U I  1 0  0 O  U I  U I  0 O D  0 O\
 I  U I  o C  o C  1 L  o C  0 0 0  U I  1 P  U I  0 0 D  0 0 P  C o  \
0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U 1  1\
 o  U 1  U I  1 0  U I  D L  0 O  U I  U I  U I  o C  o C  1 L  o C  0\
 0 0  U I  P 0  U I  0 O D  0 O D  1 C  1 C  o U  0 O D  0 O D  0 O D \
 U I  1 U  U I  o C  o C  1 L  o C  0 0 0  0 O  U I  U I  0 O 0  0 O L\
  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  o C  o C  1 L  o C  0 0 \
0  U I  P 0  U I  0 O D  0 O D  1 C  1 C  o U  0 O D  0 O D  0 O D  U \
I  1 U  U I  U C  1 o  U C  U I  1 U  U I  o C  o C  1 L  o C  0 0 0  \
0 O  U I  U I  U I  0 O D  0 O I  U I  D 0  D O  U I  1 D  U I  D 0  D\
 O  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 P  U I\
  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  U o  U I  \
0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 D  U I  o U  0 O D  1 C \
 o U  0 O  U I  o U  o U  0 O D  o C  1 L  o C  0 0 0  U I  P 0  U I  \
0 0 0  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  \
0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I  0 0 0  0 0 0  1 L  0 0 0  0\
 0 0  o C  1 L  0 0 0  o C  o C  o C  o C  0 0 0  U I  1 1  U I  0 0 D\
  0 0 P  0 0 1  U I  1 O  U I  0 O D  1 C  1 C  0 O D  0 O D  U I  1 0\
  U I  1 U  U I  U 1  C C  C o  0 0 I  0 0 P  C C  0 O 1  C o  1 P  0 \
O P  0 0 I  0 O U  U 1  U I  1 0  0 O  U I  o U  o U  o U  1 C  1 C  o\
 U  1 C  U I  P 0  U I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  o U\
  o U  0 O D  o C  1 L  o C  0 0 0  U I  1 1  U I  U 1  0 0 C  C L  U \
1  U I  1 0  0 O  U I  0 O D  0 O I  U I  1 C  1 C  U I  1 D  U I  1 C\
  1 C  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O \
D  U I  1 U  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  o U\
  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  P 0  U I  0 0 o  0 0 1\
  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  L I  0 O 0  0 0 U  0 0\
 o  0 O 0  0 0 D  0 0 P  U I  1 O  U I  o C  o C  1 L  o C  0 0 0  U I\
  1 0  0 O  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 \
P  U I  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1\
  U I  1 O  U I  U C  L D  0 0 D  0 O 0  0 0 1  1 D  P D  0 O U  0 O 0\
  0 0 O  0 0 P  U C  U I  1 1  U I  U C  o o  0 0 0  0 I I  0 O D  0 O\
 L  0 O L  C o  1 o  D U  1 P  1 L  U I  1 O  L o  0 O D  0 0 O  0 O O\
  0 0 0  0 0 C  0 0 D  U I  o L  L 1  U I  D 1  1 P  1 C  D C  U I  0 \
0 1  0 0 L  D L  1 C  D I  1 P  1 L  1 0  U I  o 0  0 O 0  C C  0 O o \
 0 0 0  1 o  D O  1 L  1 C  1 L  1 L  1 C  1 L  1 C  U I  o O  0 O D  \
0 0 1  0 O 0  0 O I  0 0 0  0 I O  1 o  1 C  D I  1 P  1 L  1 P  1 C  \
U C  U I  1 0  0 O  U I  0 O D  0 O I  U I  U C  0 0 1  0 O 0  0 O I  \
0 O 0  0 0 1  0 O 0  0 0 1  U C  U I  0 O D  0 0 O  U I  0 O C  U I  D\
 L  0 O  U I  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  \
1 P  U I  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0\
 1  U I  1 O  U I  U C  L I  0 O 0  0 O I  0 O 0  0 0 1  0 O 0  0 0 1 \
 U C  U I  1 1  U I  0 O C  U I  C 0  U I  U C  0 0 1  0 O 0  0 O I  0\
 O 0  0 0 1  0 O 0  0 0 1  U C  U I  C U  U I  1 0  0 O  U I  0 O D  0\
 O I  U I  U C  C o  0 O U  0 O 0  0 0 O  0 0 P  U C  U I  0 O D  0 0 \
O  U I  0 O C  U I  D L  0 O  U I  U I  o U  o U  0 O D  0 O D  1 C  o\
 U  0 O D  1 C  U I  1 P  U I  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C\
 o  0 O O  0 O 0  0 0 1  U I  1 O  U I  U C  L D  0 0 D  0 O 0  0 0 1 \
 1 D  C o  0 O U  0 O 0  0 0 O  0 0 P  U C  U I  1 1  U I  0 O C  U I \
 C 0  U I  U C  C o  0 O U  0 O 0  0 0 O  0 0 P  U C  U I  C U  U I  1\
 0  0 O  U I  0 O D  0 O I  U I  U C  0 0 D  0 O 0  0 0 P  C C  0 0 0 \
 0 0 0  0 O o  0 O D  0 O 0  U C  U I  0 O D  0 0 O  U I  0 O C  U I  \
D L  0 O  U I  U I  0 O D  0 O I  U I  D P  1 L  U I  1 D  U I  D P  1\
 L  D L  U I  o U  o U  o U  o U  U I  U o  U I  o U  o U  o U  o U  U\
 I  U o  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  \
U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I \
 1 P  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 o  U\
 I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  \
U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I  C o \
 0 O O  0 O O  C D  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  U I  1 O  \
U I  U C  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0  U C  U I  1 1  U I  \
0 O C  U I  C 0  U I  U C  0 0 D  0 O 0  0 0 P  C C  0 0 0  0 0 0  0 O\
 o  0 O D  0 O 0  U C  U I  C U  U I  1 0  0 O  U I  U I  0 O D  0 O I\
  U I  1 C  D 0  U I  1 D  U I  1 C  D 0  D L  U I  0 O D  o U  o U  1\
 C  1 C  1 C  0 O D  U I  1 U  U I  o U  o U  0 O D  o U  0 O D  o U  \
o U  1 C  1 C  0 O D  U I  1 D  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 \
0  0 0 0  o C  1 L  U I  U o  U I  o U  0 O D  o U  o U  U I  1 o  U I\
  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 \
O D  U I  1 P  U I  o U  1 C  1 C  0 O D  0 O  U I  U I  0 O D  0 O I \
 U I  D 1  1 L  U I  1 D  U I  D 1  1 L  D L  U I  o U  0 O D  o U  o \
U  U I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  U o \
 U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 D  U I  0 O D  1 C\
  0 O  U I  U I  0 O D  0 O I  U I  D D  D o  U I  1 D  U I  D D  D o \
 D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 o  U I  0 0\
 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 P  U I  o U  \
o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I  0 O \
D  0 O I  U I  D D  D o  U I  1 D  U I  D D  D o  D L  U I  o U  o U  \
o U  o U  U I  1 D  U I  o U  0 O D  1 C  o U  0 O  U I  0 0 o  0 0 1 \
 0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  0 0 o  0 0 1  0 O L  0 \
0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  o U  o U  0 O D  0 O D  1 C  \
o U  0 O D  1 C  U I  1 0  0 O  U I  o U  1 C  o U  o U  1 C  1 C  o U\
  0 O D  o U  o U  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C\
 L  D O  U I  1 P  U I  0 0 o  0 0 1  0 O L  0 0 0  0 0 I  0 O 0  0 0 \
O  U I  1 O  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1\
 0  0 O  U I  0 O D  0 O I  U I  D I  D 0  U I  1 D  U I  D I  D 0  D \
L  U I  o U  1 C  1 C  0 O D  U I  1 U  U I  o U  o U  0 O D  o U  0 O\
 D  o U  o U  1 C  1 C  0 O D  U I  U o  U I  o U  1 C  o U  0 O D  1 \
C  1 C  1 C  U I  1 o  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U\
  1 C  o U  0 O D  1 C  0 O D  U I  1 I  U I  0 O D  o U  o U  1 C  1 \
C  1 C  0 O D  0 O  U I  o U  o U  o U  1 C  1 C  o U  1 C  U I  1 P  \
U I  0 0 C  0 0 1  0 O D  0 0 P  0 O 0  U I  1 O  U I  o U  1 C  o U  \
o U  1 C  1 C  o U  0 O D  o U  o U  U I  1 P  U I  0 0 1  0 O 0  C o \
 0 O O  U I  1 O  U I  1 0  U I  1 0  0 O  U I  o U  1 C  o U  o U  1 \
C  1 C  o U  0 O D  o U  o U  U I  1 P  U I  C C  0 O L  0 0 0  0 0 D \
 0 O 0  U I  1 O  U I  1 0  0 O  U I  o U  o U  o U  1 C  1 C  o U  1 \
C  U I  1 P  U I  C C  0 O L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0 \
 0 O  U I  o C  o C  o C  o C  1 L  0 0 0  1 L  o C  U I  P 0  U I  0 \
O D  o U  1 C  1 C  1 C  o U  U I  1 O  U I  C C  C o  0 0 I  0 0 P  C\
 C  0 O 1  C o  U I  P 0  U I  o U  o U  0 O D  o C  1 L  o C  0 0 0  \
U I  1 0  0 O  U I  0 O D  1 C  0 O D  1 C  0 O D  0 O D  o U  o U  0 \
O D  0 O D  0 O D  o U  o U  U I  P 0  U I  o C  o C  o C  o C  1 L  0\
 0 0  1 L  o C  U I  1 P  U I  0 O U  0 O 0  0 0 P  U I  1 O  U I  1 0\
  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 O D  1 C \
 0 O D  1 C  0 O D  0 O D  o U  o U  0 O D  0 O D  0 O D  o U  o U  0 \
O  U I  0 O D  0 O I  U I  D P  D o  U I  1 D  U I  D P  D o  D L  U I\
  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 P  U I  o U  0 O D  o \
U  o U  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C \
 1 L  U I  1 P  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  \
0 O D  U I  U o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  0 \
O O  0 O 0  0 O I  U I  o C  0 0 0  0 0 0  1 L  1 L  o C  1 L  U I  1 \
O  U I  0 O D  0 O C  C o  0 O U  0 O 0  0 0 1  0 O 0  0 O U  0 O 0  0\
 I O  U I  1 1  U I  0 O 1  0 0 P  0 O C  0 O L  C D  0 0 I  C o  0 O \
U  0 O 0  U I  1 1  U I  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  \
C o  0 0 1  U I  1 1  U I  0 O C  U I  1 0  U I  D L  0 O  U I  0 O U \
 0 O L  0 0 0  C L  C o  0 O L  U I  0 O D  1 C  1 C  0 O D  0 O D  0 \
O  U I  0 O D  1 C  1 C  0 O D  0 O D  U I  1 U  P 0  U I  1 C  0 O  U\
 I  0 O D  0 O I  U I  D D  1 L  U I  1 D  U I  D D  1 L  D L  U I  0 \
O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 D  U I  o C  0 0 0  0 0 0 \
 0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U I  o U  1 C  o U  0 O D  1 C  \
1 C  1 C  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U \
I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  U\
 o  U I  o U  1 C  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  1 C  U I  \
1 D  U I  1 C  D L  U I  o U  o U  o U  o U  U I  1 o  U I  o U  1 C  \
1 C  0 O D  0 O  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  0 O\
 D  0 O C  C o  0 O U  0 O 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U I  \
P 0  P 0  U I  U C  U C  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  0\
 O 1  0 0 P  0 O C  0 O L  C D  0 0 I  C o  0 O U  0 O 0  U I  1 P  U \
I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1 \
 U I  1 O  U I  U 1  0 O 1  0 0 P  0 0 P  0 0 I  U 1  U I  1 0  U I  D\
 L  0 O  U I  U I  U I  0 O D  0 O D  1 C  1 C  o U  0 O D  0 O D  0 O\
 D  U I  P 0  U I  0 0 0  o C  o C  o C  o C  U I  1 O  U I  0 O 1  0 \
0 P  0 O C  0 O L  C D  0 0 I  C o  0 O U  0 O 0  U I  1 1  U I  C C  \
0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  P 0  U I  C C\
  0 0 0  0 0 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 0  0 O  U\
 I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  0 O\
 D  0 O D  1 C  1 C  o U  0 O D  0 O D  0 O D  U I  P 0  U I  0 O 1  0\
 0 P  0 O C  0 O L  C D  0 0 I  C o  0 O U  0 O 0  0 O  U I  U I  o C \
 o C  1 L  o C  0 0 0  U I  P 0  U I  0 0 1  0 O 0  U I  1 P  U I  C C\
  0 0 0  0 O C  0 0 I  0 O D  0 O L  0 O 0  U I  1 O  U I  0 O D  0 O \
C  C o  0 O U  0 O 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U I  1 0  U I\
  1 P  U I  0 O I  0 O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 O  U\
 I  0 O 1  0 0 P  0 O C  0 O L  C D  0 0 I  C o  0 O U  0 O 0  U I  1 \
0  U I  C 0  U I  1 L  U I  C U  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0 \
 U I  D L  0 O  U I  U I  o C  o C  1 L  o C  0 0 0  U I  P 0  U I  0 \
O 1  0 0 P  0 O C  0 O L  C D  0 0 I  C o  0 O U  0 O 0  0 O  U I  U I\
  0 O D  0 O I  U I  U C  0 0 0  0 0 O  0 O 0  0 0 I  0 O L  C o  0 I \
0  1 P  0 0 P  0 0 L  1 o  0 O 0  0 O C  C L  0 O 0  0 O O  U C  U I  \
0 O D  0 0 O  U I  0 O 1  0 0 P  0 O C  0 O L  C D  0 0 I  C o  0 O U \
 0 O 0  U I  D L  0 O  U I  U I  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 \
1  0 0 P  U I  0 0 0  0 0 O  0 O 0  0 0 I  0 O L  C o  0 I 0  0 O  U I\
  U I  U I  0 O D  0 O D  1 C  1 C  o U  0 O D  0 O D  0 O D  U I  P 0\
  U I  0 0 0  o C  o C  o C  o C  U I  1 O  U I  0 O 1  0 0 P  0 O C  \
0 O L  C D  0 0 I  C o  0 O U  0 O 0  U I  1 1  U I  C C  0 0 0  0 0 0\
  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  P 0  U I  C C  0 0 0  0 0\
 0  0 O o  0 O D  0 O 0  o 1  C o  0 0 1  U I  1 0  0 O  U I  U I  U I\
  o C  o C  1 L  o C  0 0 0  U I  P 0  U I  0 0 0  0 0 O  0 O 0  0 0 I\
  0 O L  C o  0 I 0  U I  1 P  U I  0 O U  0 O 0  0 0 P  P o  C o  0 0\
 I  0 0 P  C C  0 O 1  C o  L D  0 0 1  0 O L  U I  1 O  U I  0 O D  0\
 O D  1 C  1 C  o U  0 O D  0 O D  0 O D  U I  1 0  0 O  U I  U I  U I\
  0 O D  0 O I  U I  D D  D I  U I  1 D  U I  D D  D I  D L  U I  0 0 \
0  1 L  0 0 0  o C  1 L  U I  1 o  U I  o C  o C  0 0 0  0 0 0  o C  o\
 C  0 0 0  U I  1 o  U I  o U  0 O D  o U  o U  U I  1 I  U I  0 0 0  \
0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 P  U I  o U  0 O D \
 1 C  o U  U I  1 P  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O\
  U I  o U  o U  0 O D  o C  1 L  o C  0 0 0  U I  P 0  U I  0 0 0  0 \
0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I  0 O P  0 \
0 0  0 O D  0 0 O  U I  1 O  U I  0 0 0  0 0 0  1 L  0 0 0  0 0 0  o C\
  1 L  0 0 0  o C  o C  o C  o C  0 0 0  U I  1 1  U I  0 0 D  0 0 P  \
0 0 1  U I  1 O  U I  0 O D  1 C  1 C  0 O D  0 O D  U I  1 0  U I  1 \
U  U I  U 1  C C  C o  0 0 I  0 0 P  C C  0 O 1  C o  1 P  0 O P  0 0 \
I  0 O U  U 1  U I  1 0  0 O  U I  o U  o U  o U  1 C  1 C  o U  1 C  \
U I  P 0  U I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  o U  o U  0 \
O D  o C  1 L  o C  0 0 0  U I  1 1  U I  U 1  0 0 C  C L  U 1  U I  1\
 0  0 O  U I  0 O D  0 O I  U I  D U  D o  U I  1 D  U I  D U  D o  D \
L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 P  U\
 I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 o  U I  0 0 0  1 L\
  0 0 0  o C  1 L  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  \
0 0 0  o C  1 L  U I  1 U  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 \
0  0 O  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  P 0  U\
 I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  D O  U I  1 P  U I  L I  0\
 O 0  0 0 U  0 0 o  0 O 0  0 0 D  0 0 P  U I  1 O  U I  o C  o C  1 L \
 o C  0 0 0  U I  1 0  0 O  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O\
 D  1 C  U I  1 P  U I  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  0 O\
 O  0 O 0  0 0 1  U I  1 O  U I  U C  L D  0 0 D  0 O 0  0 0 1  1 D  P\
 D  0 O U  0 O 0  0 0 O  0 0 P  U C  U I  1 1  U I  U C  o o  0 0 0  0\
 I I  0 O D  0 O L  0 O L  C o  1 o  D U  1 P  1 L  U I  1 O  L o  0 O\
 D  0 0 O  0 O O  0 0 0  0 0 C  0 0 D  U I  o L  L 1  U I  D 1  1 P  1\
 C  D C  U I  0 0 1  0 0 L  D L  1 C  D I  1 P  1 L  1 0  U I  o 0  0 \
O 0  C C  0 O o  0 0 0  1 o  D O  1 L  1 C  1 L  1 L  1 C  1 L  1 C  U\
 I  o O  0 O D  0 0 1  0 O 0  0 O I  0 0 0  0 I O  1 o  1 C  D I  1 P \
 1 L  1 P  1 C  U C  U I  1 0  0 O  U I  0 O D  0 O I  U I  U C  0 0 1\
  0 O 0  0 O I  0 O 0  0 0 1  0 O 0  0 0 1  U C  U I  0 O D  0 0 O  U \
I  0 O C  U I  D L  0 O  U I  U I  o U  o U  0 O D  0 O D  1 C  o U  0\
 O D  1 C  U I  1 P  U I  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  0\
 O O  0 O 0  0 0 1  U I  1 O  U I  U C  L I  0 O 0  0 O I  0 O 0  0 0 \
1  0 O 0  0 0 1  U C  U I  1 1  U I  0 O C  U I  C 0  U I  U C  0 0 1 \
 0 O 0  0 O I  0 O 0  0 0 1  0 O 0  0 0 1  U C  U I  C U  U I  1 0  0 \
O  U I  0 O D  0 O I  U I  U C  C o  0 O U  0 O 0  0 0 O  0 0 P  U C  \
U I  0 O D  0 0 O  U I  0 O C  U I  D L  0 O  U I  U I  o U  o U  0 O \
D  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I  C o  0 O O  0 O O  C D \
 0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  U I  1 O  U I  U C  L D  0 0 \
D  0 O 0  0 0 1  1 D  C o  0 O U  0 O 0  0 0 O  0 0 P  U C  U I  1 1  \
U I  0 O C  U I  C 0  U I  U C  C o  0 O U  0 O 0  0 0 O  0 0 P  U C  \
U I  C U  U I  1 0  0 O  U I  0 O D  0 O I  U I  U C  C o  C C  C C  0\
 O 0  0 0 I  0 0 P  U C  U I  0 O D  0 0 O  U I  0 O C  U I  D L  0 O \
 U I  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I\
  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  0 O O  0 O 0  0 0 1  U I \
 1 O  U I  U C  P D  C C  C C  0 O 0  0 0 I  0 0 P  U C  U I  1 1  U I\
  0 O C  U I  C 0  U I  U C  C o  C C  C C  0 O 0  0 0 I  0 0 P  U C  \
U I  C U  U I  1 0  0 O  U I  0 O D  0 O I  U I  U C  0 0 D  0 O 0  0 \
0 P  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  U C  U I  0 O D  0 0 O  U\
 I  0 O C  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  D 0  U I  1 D  \
U I  D 0  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L \
 U I  1 I  U I  o U  0 O D  o U  o U  U I  U o  U I  0 0 0  o C  1 L  \
0 0 0  U I  U o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 I \
 U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 o  U I  o\
 C  1 L  0 0 0  o C  0 O  U I  U I  o U  o U  0 O D  0 O D  1 C  o U  \
0 O D  1 C  U I  1 P  U I  C o  0 O O  0 O O  C D  0 O 1  0 O 0  C o  \
0 O O  0 O 0  0 0 1  U I  1 O  U I  U C  P o  0 0 0  0 0 0  0 O o  0 O\
 D  0 O 0  U C  U I  1 1  U I  0 O C  U I  C 0  U I  U C  0 0 D  0 O 0\
  0 0 P  C C  0 0 0  0 0 0  0 O o  0 O D  0 O 0  U C  U I  C U  U I  1\
 0  0 O  U I  U I  0 O D  0 O I  U I  D o  D U  U I  1 D  U I  D o  D \
U  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 I  U I \
 o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U I\
  0 O D  1 C  U I  1 P  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  \
U I  U o  U I  o U  0 O D  o U  o U  U I  1 U  U I  0 0 0  o C  1 L  0\
 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  U I  0 O D  0 O I  U I  D\
 o  D P  U I  1 D  U I  D o  D P  D L  U I  o U  o U  o U  o U  U I  1\
 P  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  U I  0 O D\
  0 O I  U I  D U  D I  U I  1 D  U I  D U  D I  D L  U I  o U  o U  0\
 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 o  U I  0 0 0  0 0\
 0  0 0 0  1 L  o C  0 0 0  1 L  U I  U o  U I  o C  0 0 0  0 0 0  0 0\
 0  1 L  1 L  1 L  1 L  U I  1 I  U I  o U  1 C  1 C  0 O D  U I  1 I \
 U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I\
  U I  0 O D  0 O I  U I  D I  D P  U I  1 D  U I  D I  D P  D L  U I \
 0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 P  U I  o U  o U  o U\
  o U  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  \
1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I  U I  0 \
O D  0 O I  U I  D 0  D 0  U I  1 D  U I  D 0  D 0  D L  U I  0 0 0  1\
 L  0 0 0  o C  1 L  U I  U o  U I  o U  0 O D  1 C  o U  U I  1 U  U \
I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  U I  o U  1 C  o U  o U  \
1 C  1 C  o U  0 O D  o U  o U  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 \
O L  0 O D  C L  D O  U I  1 P  U I  0 0 o  0 0 1  0 O L  0 0 0  0 0 I\
  0 O 0  0 0 O  U I  1 O  U I  o U  o U  0 O D  0 O D  1 C  o U  0 O D\
  1 C  U I  1 0  0 O  U I  0 O D  0 O I  U I  D o  D 0  U I  1 D  U I \
 D o  D 0  D L  U I  o U  1 C  1 C  0 O D  U I  1 P  U I  0 0 0  0 0 0\
  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  0 O D  o U  o U  1 C  1 \
C  1 C  0 O D  U I  1 U  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 \
L  0 O  U I  o U  o U  o U  1 C  1 C  o U  1 C  U I  1 P  U I  0 0 C  \
0 0 1  0 O D  0 0 P  0 O 0  U I  1 O  U I  o U  1 C  o U  o U  1 C  1 \
C  o U  0 O D  o U  o U  U I  1 P  U I  0 0 1  0 O 0  C o  0 O O  U I \
 1 O  U I  1 0  U I  1 0  0 O  U I  o U  1 C  o U  o U  1 C  1 C  o U \
 0 O D  o U  o U  U I  1 P  U I  C C  0 O L  0 0 0  0 0 D  0 O 0  U I \
 1 O  U I  1 0  0 O  U I  o U  o U  o U  1 C  1 C  o U  1 C  U I  1 P \
 U I  C C  0 O L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  o\
 C  o C  o C  o C  1 L  0 0 0  1 L  o C  U I  P 0  U I  0 O D  o U  1 \
C  1 C  1 C  o U  U I  1 O  U I  C C  C o  0 0 I  0 0 P  C C  0 O 1  C\
 o  U I  P 0  U I  o U  o U  0 O D  o C  1 L  o C  0 0 0  U I  1 0  0 \
O  U I  0 O D  1 C  0 O D  1 C  0 O D  0 O D  o U  o U  0 O D  0 O D  \
0 O D  o U  o U  U I  P 0  U I  o C  o C  o C  o C  1 L  0 0 0  1 L  o\
 C  U I  1 P  U I  0 O U  0 O 0  0 0 P  U I  1 O  U I  1 0  0 O  U I  \
0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 O D  1 C  0 O D  1 C \
 0 O D  0 O D  o U  o U  0 O D  0 O D  0 O D  o U  o U  0 O  U I  0 O \
D  0 O I  U I  D U  D P  U I  1 D  U I  D U  D P  D L  U I  0 0 0  o C\
  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  o U  o U  0 \
O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 P  U I  o U  0 O D \
 o U  o U  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U\
 I  1 D  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 D  U I  0 0 \
0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I  0 O D  0 O I  U I  D \
I  1 C  U I  1 D  U I  D I  1 C  D L  U I  o U  0 O D  o U  o U  U I  \
1 o  U I  o U  1 C  1 C  0 O D  U I  1 o  U I  o U  0 O D  o U  o U  U\
 I  1 D  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 P\
  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  0 O D  0 O I\
  U I  D 1  D U  U I  1 D  U I  D 1  D U  D L  U I  o U  o U  0 O D  o\
 U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U I  0 0 0  0 0 0  o C\
  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 P  U I  o C  o C  0 0 0  0 0 \
0  o C  o C  0 0 0  U I  1 o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O\
 D  U I  1 o  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O\
  U I  0 O D  0 O I  U I  D 1  D o  U I  1 D  U I  D 1  D o  D L  U I \
 o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  U o  U I  o C  0 0\
 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  0 O D  0 O I  U I  D D\
  D 1  U I  1 D  U I  D D  D 1  D L  U I  0 0 0  0 0 0  o C  0 0 0  o \
C  1 L  o C  1 L  1 L  U I  1 I  U I  0 O D  0 O D  o U  1 C  0 O D  o\
 U  0 O D  o U  U I  1 o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U \
I  U o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I \
 1 U  U I  o C  1 L  0 0 0  o C  0 O  U I  0 O D  0 O I  U I  D I  D P\
  U I  1 D  U I  D I  D P  D L  U I  0 0 0  o C  1 L  0 0 0  U I  U o \
 U I  o U  1 C  1 C  0 O D  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o\
 C  1 L  0 0 0  U I  U o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0\
  0 O  U I  0 O D  0 O I  U I  D D  D o  U I  1 D  U I  D D  D o  D L \
 U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  U o  U I  0 O D \
 o U  o U  1 C  1 C  1 C  0 O D  U I  U o  U I  0 O D  1 C  1 C  o U  \
0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 o  U I  o U \
 1 C  1 C  0 O D  U I  U o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  \
0 O  U I  0 O D  0 O I  U I  D U  D 1  U I  1 D  U I  D U  D 1  D L  U\
 I  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o\
 C  1 L  o C  1 L  1 L  U I  1 I  U I  0 O D  0 O D  o U  1 C  0 O D  \
o U  0 O D  o U  0 O  U I  0 O D  0 O I  U I  D P  D I  U I  1 D  U I \
 D P  D I  D L  U I  o C  1 L  0 0 0  o C  U I  1 U  U I  0 O D  1 C  \
1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 U \
 U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  0 O D  0 O I \
 U I  D 0  D 0  U I  1 D  U I  D 0  D 0  D L  U I  0 O D  1 C  1 C  o \
U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  0 O  U I  0 O D \
 0 O I  U I  D o  D 0  U I  1 D  U I  D o  D 0  D L  U I  o C  0 0 0  \
0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  0 O D  0 O I  U I  D 0  D \
I  U I  1 D  U I  D 0  D I  D L  U I  o U  o U  o U  o U  U I  1 D  U \
I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  o U  0\
 O D  o U  o U  U I  1 o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0\
  0 O  U I  0 O D  0 O I  U I  1 C  D o  U I  1 D  U I  1 C  D o  D L \
 U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  0 O O \
 0 O 0  0 O I  U I  o U  0 O D  o U  U I  1 O  U I  0 0 O  C o  0 O C \
 0 O 0  U I  1 1  U I  0 O 1  0 O 0  C o  0 O O  0 0 O  C o  0 O C  0 \
O 0  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  D I  U I  1 D  U\
 I  D I  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 U  \
U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 P  U I  o U \
 1 C  1 C  0 O D  U I  1 o  U I  o U  o U  0 O D  o U  0 O D  o U  o U\
  1 C  1 C  0 O D  U I  1 D  U I  o U  o U  0 O D  o U  0 O D  o U  o \
U  1 C  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  D U  D O  U I  1 D  U\
 I  D U  D O  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 I \
 U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  o U  0 O D  1\
 C  1 C  0 O D  0 O D  o U  U I  P 0  U I  0 I O  C L  0 O C  C C  U I\
  1 P  U I  o D  0 O 0  0 I 0  C L  0 0 0  C o  0 0 1  0 O O  U I  1 O\
  U I  U C  0 O O  0 O 0  0 O I  C o  0 0 o  0 O L  0 0 P  U C  U I  1\
 1  U I  U C  0 O 1  0 O 0  C o  0 O O  0 O D  0 0 O  0 O U  U C  U I \
 1 1  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 0  0 O  U I  o U  0 O D  1\
 C  1 C  0 O D  0 O D  o U  U I  1 P  U I  0 0 D  0 O 0  0 0 P  P L  0\
 O 0  0 O I  C o  0 0 o  0 O L  0 0 P  U I  1 O  U I  0 0 O  C o  0 O \
C  0 O 0  U I  1 0  0 O  U I  o U  0 O D  1 C  1 C  0 O D  0 O D  o U \
 U I  1 P  U I  0 0 D  0 O 0  0 0 P  o I  0 O 0  C o  0 O O  0 O D  0 \
0 O  0 O U  U I  1 O  U I  0 O 1  0 O 0  C o  0 O O  0 0 O  C o  0 O C\
  0 O 0  U I  1 0  0 O  U I  o U  0 O D  1 C  1 C  0 O D  0 O D  o U  \
U I  1 P  U I  0 0 D  0 O 0  0 0 P  o I  0 O D  0 O O  0 O O  0 O 0  0\
 0 O  o U  0 0 O  0 0 I  0 0 o  0 0 P  U I  1 O  U I  o O  C o  0 O L \
 0 0 D  0 O 0  U I  1 0  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  \
0 0 O  U I  o U  0 O D  1 C  1 C  0 O D  0 O D  o U  U I  1 P  U I  0 \
O U  0 O 0  0 0 P  L 1  0 O 0  0 I O  0 0 P  U I  1 O  U I  1 0  0 O  \
U I  0 O D  0 O I  U I  D D  1 C  U I  1 D  U I  D D  1 C  D L  U I  0\
 O D  1 C  U I  1 D  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I\
  1 D  U I  o C  1 L  0 0 0  o C  0 O  U I  0 O D  0 O I  U I  D O  D \
P  U I  1 D  U I  D O  D P  D L  U I  0 0 0  o C  1 L  0 0 0  0 O  U I\
  0 O D  0 O I  U I  D D  U I  1 D  U I  D D  D L  U I  0 0 0  1 L  1 \
L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  0 0 0  0 0 0  0 0 0  1 L  o \
C  0 0 0  1 L  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 \
0  0 O  U I  0 O D  0 O I  U I  D U  D P  U I  1 D  U I  D U  D P  D L\
  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  0 0 0\
  1 L  0 0 0  o C  1 L  U I  1 U  U I  o U  0 O D  1 C  o U  U I  U o \
 U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 D  U I  o\
 C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  C C  0 O L  C o  0 0 D  0\
 0 D  U I  0 O D  o U  1 C  1 C  1 C  o U  U I  1 O  U I  0 I O  C L  \
0 O C  C C  0 O U  0 0 o  0 O D  U I  1 P  U I  L o  0 O D  0 0 O  0 O\
 O  0 0 0  0 0 C  P L  0 O D  C o  0 O L  0 0 0  0 O U  U I  1 0  U I \
 D L  0 O  U I  0 O O  0 O 0  0 O I  U I  C D  C D  0 O D  0 0 O  0 O \
D  0 0 P  C D  C D  U I  1 O  U I  0 0 D  0 O 0  0 O L  0 O I  U I  1 \
1  U I  1 I  U I  C o  0 0 1  0 O U  0 0 D  U I  1 1  U I  1 I  1 I  U\
 I  0 O o  0 0 C  C o  0 0 1  0 O U  0 0 D  U I  1 0  U I  D L  0 O  U\
 I  U I  0 0 D  0 O 0  0 O L  0 O I  U I  1 P  U I  C C  0 0 I  0 0 P \
 0 O L  0 0 0  C C  U I  P 0  U I  0 O o  0 0 C  C o  0 0 1  0 O U  0 \
0 D  U I  1 P  U I  0 O U  0 O 0  0 0 P  U I  1 O  U I  U C  C C  C o \
 0 0 I  0 0 P  C C  0 O 1  C o  U C  U I  1 0  0 O  U I  U I  0 0 D  0\
 O 0  0 O L  0 O I  U I  1 P  U I  0 O D  0 O C  0 O U  U I  P 0  U I \
 0 I O  C L  0 O C  C C  0 O U  0 0 o  0 O D  U I  1 P  U I  P o  0 0 \
0  0 0 O  0 0 P  0 0 1  0 0 0  0 O L  o U  0 O C  C o  0 O U  0 O 0  U\
 I  1 O  U I  D 0  D 0  D U  U I  1 1  U I  D 0  1 L  U I  1 1  U I  D\
 1  D O  D I  U I  1 1  U I  D 1  1 L  U I  1 1  U I  0 0 D  0 O 0  0 \
O L  0 O I  U I  1 P  U I  C C  0 0 I  0 0 P  0 O L  0 0 0  C C  U I  \
1 0  0 O  U I  U I  0 0 D  0 O 0  0 O L  0 O I  U I  1 P  U I  C o  0 \
O O  0 O O  P o  0 0 0  0 0 O  0 0 P  0 0 1  0 0 0  0 O L  U I  1 O  U\
 I  0 0 D  0 O 0  0 O L  0 O I  U I  1 P  U I  0 O D  0 O C  0 O U  U \
I  1 0  0 O  U I  U I  0 0 D  0 O 0  0 O L  0 O I  U I  1 P  U I  0 O \
o  C L  0 O O  U I  P 0  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  o\
 D  0 O 0  0 I 0  C L  0 0 0  C o  0 0 1  0 O O  U I  1 O  U I  1 0  0\
 O  U I  U I  0 O D  0 O I  U I  D O  D U  U I  1 D  U I  D O  D U  D \
L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  U o  U I  o C \
 o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 I  U I  o U  0 O D  o U  o\
 U  U I  1 D  U I  o U  1 C  1 C  0 O D  U I  1 I  U I  o U  0 O D  1 \
C  o U  U I  1 I  U I  o U  o U  o U  o U  0 O  U I  0 O O  0 O 0  0 O\
 I  U I  0 O U  0 O 0  0 0 P  U I  1 O  U I  0 0 D  0 O 0  0 O L  0 O \
I  U I  1 0  U I  D L  0 O  U I  U I  0 0 D  0 O 0  0 O L  0 O I  U I \
 1 P  U I  0 0 D  0 O 1  0 0 0  0 0 C  U I  1 O  U I  1 0  0 O  U I  U\
 I  0 0 P  0 O D  0 O C  0 O 0  U I  1 P  U I  0 0 D  0 O L  0 O 0  0 \
O 0  0 0 I  U I  1 O  U I  D O  U I  1 0  0 O  U I  U I  0 0 D  0 O 0 \
 0 O L  0 O I  U I  1 P  U I  0 O o  C L  0 O O  U I  1 P  U I  0 O O \
 0 0 0  o o  0 0 0  0 O O  C o  0 O L  U I  1 O  U I  1 0  0 O  U I  U\
 I  0 O D  0 O I  U I  1 O  U I  0 0 D  0 O 0  0 O L  0 O I  U I  1 P \
 U I  0 O o  C L  0 O O  U I  1 P  U I  0 O D  0 0 D  P o  0 0 0  0 0 \
O  0 O I  0 O D  0 0 1  0 O C  0 O 0  0 O O  U I  1 O  U I  1 0  U I  \
1 0  U I  D L  0 O  U I  U I  U I  o U  1 C  0 O D  o U  1 C  o U  1 C\
  0 O D  0 O D  1 C  U I  P 0  U I  0 0 D  0 O 0  0 O L  0 O I  U I  1\
 P  U I  0 O o  C L  0 O O  U I  1 P  U I  0 O U  0 O 0  0 0 P  L 1  0\
 O 0  0 I O  0 0 P  U I  1 O  U I  1 0  0 O  U I  U I  U I  0 0 D  0 O\
 0  0 O L  0 O I  U I  1 P  U I  C C  0 O L  0 0 0  0 0 D  0 O 0  U I \
 1 O  U I  1 0  0 O  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1 \
 0 0 O  U I  o U  1 C  0 O D  o U  1 C  o U  1 C  0 O D  0 O D  1 C  0\
 O  U I  U I  0 0 D  0 O 0  0 O L  0 O I  U I  1 P  U I  C C  0 O L  0\
 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  U I  0 0 1  0 O 0  0\
 0 P  0 0 o  0 0 1  0 0 O  U I  o O  C o  0 O L  0 0 D  0 O 0  0 O  U \
I  U I  0 O D  0 O I  U I  D 0  D 0  U I  1 D  U I  D 0  D 0  D L  U I\
  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 o  U I  o U  o U  0 \
O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 U  U I  o C  1 L  0\
 0 0  o C  0 O  0 O O  0 O 0  0 O I  U I  o C  0 0 0  o C  0 0 0  0 0 \
0  1 L  0 0 0  o C  U I  1 O  U I  1 0  U I  D L  0 O  U I  0 O D  0 O\
 C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 0 P  0 O D  0 O C  0 O 0  0 O  \
U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 D  0 0 P  0 0 \
1  U I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 P  0 O D  0 \
O C  0 O 0  U I  1 P  U I  0 0 P  0 O D  0 O C  0 O 0  U I  1 O  U I  \
1 0  U I  1 I  U I  1 C  1 L  1 L  1 L  U I  1 0  U I  1 0  0 O  U I  \
0 O D  0 O I  U I  D D  D U  U I  1 D  U I  D D  D U  D L  U I  0 0 0 \
 0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  U o  U I  0 0 0  0 0 0  o C \
 0 0 0  o C  1 L  o C  1 L  1 L  U I  1 U  U I  0 0 0  o C  1 L  0 0 0\
  0 O  0 O O  0 O 0  0 O I  U I  o U  1 C  0 O D  U I  1 O  U I  1 0  \
U I  D L  0 O  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 0\
 P  0 O D  0 O C  0 O 0  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  \
0 0 O  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  0 O D  0 0 O  0 0 P  U\
 I  1 O  U I  0 0 P  0 O D  0 O C  0 O 0  U I  1 P  U I  0 0 P  0 O D \
 0 O C  0 O 0  U I  1 O  U I  1 0  U I  1 0  U I  1 0  0 O  U I  0 O D\
  0 O I  U I  D o  D O  U I  1 D  U I  D o  D O  D L  U I  0 0 0  0 0 \
0  o C  0 0 0  o C  1 L  0 0 0  U I  U o  U I  o U  o U  0 O D  o U  0\
 O D  o U  o U  1 C  1 C  0 O D  0 O  0 O O  0 O 0  0 O I  U I  0 0 0 \
 0 0 0  1 L  1 L  0 0 0  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  1 L  1 \
L  U I  1 O  U I  1 0  U I  D L  0 O  U I  0 O D  0 O D  1 C  0 O D  o\
 C  o C  1 L  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  U I  P 0  \
U I  C 0  U I  C U  0 O  U I  0 O D  o U  1 C  0 O D  0 O D  1 C  1 C \
 1 C  0 O D  0 O D  o U  0 O D  0 O D  U I  P 0  U I  0 0 D  0 I 0  0 \
0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  D O  U I \
 C U  0 O  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I \
 0 O D  o U  1 C  0 O D  0 O D  1 C  1 C  1 C  0 O D  0 O D  o U  0 O \
D  0 O D  U I  1 0  U I  P I  P 0  U I  D O  U I  D L  0 O  U I  U I  \
0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D  o U  U I  P 0  U I  0 0 D  \
0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  \
D O  U I  C U  0 O  U I  U I  0 O D  o U  o U  0 O D  0 O D  0 O D  o \
U  1 C  0 O D  o U  1 C  U I  P 0  U I  0 0 0  o C  1 L  0 0 0  0 O D \
 o U  0 O D  o U  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C \
 0 O 0  U I  1 O  U I  U C  P U  U C  U I  1 1  U I  U C  U C  U I  1 \
0  0 O  U I  U I  0 O D  0 O I  U I  1 O  U I  0 0 0  o C  1 L  0 0 0 \
 0 O D  o U  0 O D  o U  U I  C 0  U I  0 O L  0 O 0  0 0 O  U I  1 O \
 U I  0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D  o U  U I  1 0  U I  1\
 D  U I  1 C  U I  C U  U I  P 0  P 0  U I  U C  1 o  U C  U I  1 0  U\
 I  D L  0 O  U I  U I  U I  0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D\
  o U  U I  P 0  U I  0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D  o U  \
U I  C 0  U I  1 L  U I  D L  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I \
 0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D  o U  U I  1 0  U I  1 D  U\
 I  D O  U I  C U  0 O  U I  U I  0 0 0  o C  1 L  1 L  1 L  1 L  1 L \
 0 0 0  o C  1 L  0 0 0  1 L  o C  U I  P 0  U I  0 O D  o U  o U  0 O\
 D  0 O D  0 O D  o U  1 C  0 O D  o U  1 C  U I  1 P  U I  0 0 D  0 0\
 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  U L  U C  U I  1 0  0 O  \
U I  U I  0 O D  0 O D  1 C  0 O D  o C  o C  1 L  1 L  o C  0 0 0  0 \
0 0  0 0 0  1 L  1 L  1 L  U I  P 0  U I  0 I U  U I  0 I D  0 O  U I \
 U I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 \
L  o C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  0 0 1  C o  0 0 O\
  0 O U  0 O 0  U I  1 O  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 0\
 0  o C  1 L  1 L  1 L  1 L  1 L  0 0 0  o C  1 L  0 0 0  1 L  o C  U \
I  1 0  U I  1 0  U I  D L  0 O  U I  U I  U I  o U  o U  o U  0 O D  \
o U  1 C  0 O D  o U  1 C  U I  P 0  U I  0 I U  U I  0 I D  0 O  U I \
 U I  U I  o U  o U  o U  0 O D  o U  1 C  0 O D  o U  1 C  U I  P 0  \
U I  0 0 0  o C  1 L  1 L  1 L  1 L  1 L  0 0 0  o C  1 L  0 0 0  1 L \
 o C  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0\
 0  0 0 0  0 0 0  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D \
 0 0 P  U I  1 O  U I  U C  P 0  U C  U I  1 0  0 O  U I  U I  U I  0 \
O D  0 O I  U I  1 O  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  o U  o \
U  o U  0 O D  o U  1 C  0 O D  o U  1 C  U I  1 0  U I  1 0  U I  P 0\
  P 0  U I  D O  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O D  1 C \
 0 O D  o C  o C  1 L  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  U\
 I  C 0  U I  o U  o U  o U  0 O D  o U  1 C  0 O D  o U  1 C  U I  C \
0  U I  1 L  U I  C U  U I  C U  U I  P 0  U I  o U  o U  o U  0 O D  \
o U  1 C  0 O D  o U  1 C  U I  C 0  U I  1 C  U I  C U  0 O  U I  0 0\
 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 O D  0 O D  1 C  0 O D  \
o C  o C  1 L  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  0 O  U I \
 0 O D  0 O I  U I  D 0  1 C  U I  1 D  U I  D 0  1 C  D L  U I  o U  \
o U  o U  o U  U I  U o  U I  o U  0 O D  o U  o U  U I  1 P  U I  o C\
  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 o  U I  0 0 0  0 0 0  o C\
  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 o  U I  0 O D  1 C  0 O  U I \
 0 O D  0 O I  U I  D 1  1 L  U I  1 D  U I  D 1  1 L  D L  U I  0 O D\
  o U  o U  1 C  1 C  1 C  0 O D  U I  U o  U I  o U  o U  o U  o U  U\
 I  1 o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  \
o U  o U  o U  o U  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L \
 o C  1 L  1 L  U I  1 o  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O\
 D  o U  0 O  0 O O  0 O 0  0 O I  U I  0 O D  1 C  o U  0 O D  1 C  1\
 C  o U  o U  U I  1 O  U I  1 0  U I  D L  0 O  U I  0 O D  0 O D  1 \
C  1 C  1 C  o U  U I  P 0  U I  0 O P  0 0 D  0 0 0  0 0 O  U I  1 P \
 U I  0 O L  0 0 0  C o  0 O O  0 0 D  U I  1 O  U I  0 0 0  0 0 I  0 \
O 0  0 0 O  U I  1 O  U I  0 O D  0 O D  0 O D  o U  1 C  1 C  U I  1 \
0  U I  1 P  U I  0 0 1  0 O 0  C o  0 O O  U I  1 O  U I  1 0  U I  1\
 0  0 O  U I  o C  o C  o C  0 0 0  o C  o C  U I  P 0  U I  0 O L  0 \
O 0  0 0 O  U I  1 O  U I  0 O D  0 O D  1 C  1 C  1 C  o U  U I  1 0 \
 0 O  U I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 \
0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  0 O D  0 O D\
  1 C  1 C  1 C  o U  U I  D L  0 O  U I  U I  o C  0 0 0  0 0 0  o C \
 1 L  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0\
 0  0 0 0  0 0 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U I  o U  0 \
O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  P 0  U I  o C  0 0 0  0 0 \
0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  1 C \
 U I  C U  0 O  U I  U I  0 O D  1 C  0 O D  0 O D  0 O D  0 O D  o U \
 1 C  1 C  0 O D  0 O D  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0\
 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  D O  U I  C U  0 O\
  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  0 O D  \
1 C  o U  o U  1 C  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0 \
 1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  D 0  U I  C U  0 O  U I\
  U I  U I  0 O D  0 O I  U I  0 O D  1 C  o U  o U  1 C  U I  P 0  P \
0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  U I  U I  0\
 0 1  C o  0 O D  0 0 D  0 O 0  0 O  U I  U I  0 O 0  0 I O  C C  0 O \
0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  0 O D  0 O I  U I  o C \
 1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I\
  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 \
O  0 O U  U I  1 O  U I  U C  0 0 o  0 0 D  0 O 0  C D  0 0 P  0 O 1  \
0 0 o  0 O C  C L  U C  U I  1 0  U I  P 0  P 0  U I  U 1  0 0 P  0 0 \
1  0 0 o  0 O 0  U 1  U I  D L  0 O  U I  U I  U I  U I  0 O D  1 C  o\
 U  o U  1 C  U I  P 0  U I  0 O D  1 C  0 O D  0 O D  0 O D  0 O D  o\
 U  1 C  1 C  0 O D  0 O D  0 O  U I  U I  U I  0 O 0  0 O L  0 0 D  0\
 O 0  U I  D L  0 O  U I  U I  U I  U I  0 O D  1 C  o U  o U  1 C  U \
I  P 0  U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  0 O  U\
 I  U I  0 0 P  0 0 1  0 I 0  U I  D L  U I  0 0 0  0 0 0  1 L  1 L  1\
 L  0 O D  0 O D  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1\
 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  D U  U I  C U  0 O  U I  \
U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 0  0 0\
 0  1 L  1 L  1 L  0 O D  0 O D  U I  P 0  U I  o L  0 0 0  0 0 O  0 O\
 0  0 O  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  U I  o C  0 0 0  o C\
  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  P 0  U I \
 o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U \
I  C 0  U I  D 1  U I  C U  0 O  U I  U I  0 O 0  0 I O  C C  0 O 0  0\
 0 I  0 0 P  U I  D L  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  \
1 L  0 0 0  0 0 0  1 L  o C  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  \
0 O  U I  U I  0 O D  0 O I  U I  D D  D 0  U I  1 D  U I  D D  D 0  D\
 L  U I  o U  1 C  1 C  0 O D  U I  U o  U I  o C  o C  0 0 0  0 0 0  \
o C  o C  0 0 0  0 O  U I  U I  0 O D  0 O I  U I  o C  0 0 0  0 0 0  \
1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  D I  U \
I  C U  U I  P 0  P 0  U I  1 L  U I  D L  0 O  U I  U I  U I  o C  0 \
0 0  0 0 0  0 0 0  o C  U I  1 O  U I  o U  0 O D  o U  0 O D  1 C  1 \
C  0 O D  o U  U I  1 1  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  U\
 I  0 O D  1 C  0 O D  0 O D  0 O D  0 O D  o U  1 C  1 C  0 O D  0 O \
D  U I  1 1  U I  0 O D  1 C  o U  o U  1 C  U I  1 1  U I  U C  U C  \
U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  \
0 O I  C o  0 0 L  U C  U I  1 1  U I  0 0 0  0 0 0  1 L  1 L  1 L  0 \
O D  0 O D  U I  1 1  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1\
 L  0 0 0  0 0 0  1 L  o C  U I  1 1  U I  o C  o C  o C  0 0 0  o C  \
o C  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 \
O  U I  U I  U I  0 O D  o U  1 C  0 O D  o U  o U  0 O D  0 O D  0 O \
D  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  o\
 U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1  U I  o C  0 0 0\
  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I\
  D I  U I  C U  U I  1 1  U I  0 O D  1 C  0 O D  0 O D  0 O D  0 O D\
  o U  1 C  1 C  0 O D  0 O D  U I  1 1  U I  0 O D  0 O D  1 C  0 O D\
  o U  o U  1 C  o U  o U  U I  1 1  U I  U C  U C  U I  1 1  U I  U C\
  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I\
  U C  0 O I  C o  0 0 L  U C  U I  1 0  0 O  U I  U I  U I  0 O D  0 \
O I  U I  D O  D U  U I  1 D  U I  D O  D U  D L  U I  o U  o U  o U  \
o U  U I  1 U  U I  o U  0 O D  1 C  o U  0 O  U I  U I  U I  0 O D  0\
 O I  U I  D D  D o  U I  1 D  U I  D D  D o  D L  U I  o C  0 0 0  0 \
0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  0 O O  0 O 0  0 O I  U I  0 O D  \
o U  1 C  1 C  1 C  1 C  0 O D  U I  1 O  U I  0 0 O  C o  0 O C  0 O \
0  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  0 O D  C C  0 0 \
0  0 0 O  0 O D  0 O C  C o  0 O U  0 O 0  U I  1 1  U I  0 O I  C o  \
0 0 O  C o  0 0 1  0 0 P  U I  1 1  U I  0 O C  0 0 0  0 O O  0 O 0  U\
 I  1 1  U I  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U \
I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  0 0 1  0 O 0  0 \
O U  0 O 0  0 I O  0 0 D  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I\
  1 0  U I  D L  0 O  U I  o U  1 C  o U  0 O D  1 C  0 O D  o U  o U \
 o U  o U  0 O D  U I  P 0  U I  C 0  U I  C U  0 O  U I  0 0 P  0 0 1\
  0 I 0  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  1 C  D I  U I  1 \
D  U I  1 C  D I  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U\
 I  1 P  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 P  U I  \
0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  0 0 O  C o  0 O C  0 O 0  \
U I  P 0  U I  0 0 O  C o  0 O C  0 O 0  U I  1 P  U I  0 O 0  0 0 O  \
C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D\
  D P  U C  U I  1 1  U I  U C  0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 O\
 0  U C  U I  1 0  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U\
 I  D L  0 O  U I  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  0 O D  0 O\
 I  U I  0 0 0  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1\
 P  U I  0 O 0  0 I O  0 O D  0 0 D  0 0 P  0 0 D  U I  1 O  U I  0 O \
D  0 O D  0 O D  o U  1 C  1 C  U I  1 0  U I  P 0  P 0  U I  o O  C o\
  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  o U  o U  o U  1 C  0 \
O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U C  o o  C o  0 O o \
 0 O D  0 0 O  0 O U  U I  o O  C o  0 0 L  0 0 0  0 0 1  0 O D  0 0 P\
  0 O 0  0 0 D  U I  o O  0 O D  0 O L  0 O 0  U C  U I  1 0  0 O  U I\
  U I  o U  1 C  o U  0 O D  1 C  0 O D  o U  o U  o U  o U  0 O D  U \
I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  1 \
O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  \
U I  1 1  U I  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C  C o  0 O U  0 O\
 0  U I  1 1  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U I  1 1  U I\
  0 O C  0 0 0  0 O O  0 O 0  U I  1 1  U I  0 0 I  0 O L  C o  0 I 0 \
 0 O L  0 O D  0 0 D  0 0 P  U I  1 1  U I  0 0 1  0 O 0  0 O U  0 O 0\
  0 I O  0 0 D  U I  1 0  U I  1 0  0 O  U I  U I  o U  1 C  o U  1 C \
 o U  1 C  1 C  o U  0 O D  U I  P 0  U I  0 0 0  0 0 I  0 O 0  0 0 O \
 U I  1 O  U I  0 O D  0 O D  0 O D  o U  1 C  1 C  U I  1 1  U I  U 1\
  0 0 C  U 1  U I  1 0  0 O  U I  U I  o U  1 C  o U  1 C  o U  1 C  1\
 C  o U  0 O D  U I  1 P  U I  0 0 C  0 0 1  0 O D  0 0 P  0 O 0  U I \
 1 O  U I  0 O P  0 0 D  0 0 0  0 0 O  U I  1 P  U I  0 O O  0 0 o  0 \
O C  0 0 I  0 0 D  U I  1 O  U I  o U  1 C  o U  0 O D  1 C  0 O D  o \
U  o U  o U  o U  0 O D  U I  1 0  U I  1 0  0 O  U I  U I  o U  1 C  \
o U  1 C  o U  1 C  1 C  o U  0 O D  U I  1 P  U I  C C  0 O L  0 0 0 \
 0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O \
0  U I  D L  0 O  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O\
 D  o U  o U  U I  1 O  U I  U C  P D  0 0 I  0 0 I  0 O 0  0 0 O  0 O\
 O  0 O D  0 0 O  0 O U  U I  o O  C o  0 0 L  0 0 0  0 0 1  0 O D  0 \
0 P  0 O 0  0 0 D  U C  U I  1 0  0 O  U I  U I  o U  1 C  o U  1 C  o\
 U  1 C  1 C  o U  0 O D  U I  P 0  U I  0 0 0  0 0 I  0 O 0  0 0 O  U\
 I  1 O  U I  0 O D  0 O D  0 O D  o U  1 C  1 C  U I  1 0  U I  1 P  \
U I  0 0 1  0 O 0  C o  0 O O  U I  1 O  U I  1 0  0 O  U I  U I  o C \
 o C  o C  1 L  o C  o C  0 0 0  U I  P 0  U I  0 O P  0 0 D  0 0 0  0\
 0 O  U I  1 P  U I  0 O L  0 0 0  C o  0 O O  0 0 D  U I  1 O  U I  o\
 U  1 C  o U  1 C  o U  1 C  1 C  o U  0 O D  U I  1 0  0 O  U I  U I \
 o C  o C  o C  1 L  o C  o C  0 0 0  U I  1 P  U I  C o  0 0 I  0 0 I\
  0 O 0  0 0 O  0 O O  U I  1 O  U I  1 O  U I  0 0 O  C o  0 O C  0 O\
 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  0 O D  C C  0 0\
 0  0 0 O  0 O D  0 O C  C o  0 O U  0 O 0  U I  1 1  U I  0 O I  C o \
 0 0 O  C o  0 0 1  0 0 P  U I  1 1  U I  0 O C  0 0 0  0 O O  0 O 0  \
U I  1 0  U I  1 0  0 O  U I  U I  o C  0 0 0  o C  U I  P 0  U I  0 0\
 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  0 O D  0 O D  0 O D  o U  1 C \
 1 C  U I  1 1  U I  U 1  0 0 C  U 1  U I  1 0  0 O  U I  U I  o C  0 \
0 0  o C  U I  1 P  U I  0 0 C  0 0 1  0 O D  0 0 P  0 O 0  U I  1 O  \
U I  0 O P  0 0 D  0 0 0  0 0 O  U I  1 P  U I  0 O O  0 0 o  0 O C  0\
 0 I  0 0 D  U I  1 O  U I  o C  o C  o C  1 L  o C  o C  0 0 0  U I  \
1 0  U I  1 0  0 O  U I  U I  o C  0 0 0  o C  U I  1 P  U I  C C  0 O\
 L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0 O  U I  U I  0 O D  0 O\
 I  U I  D U  1 L  U I  1 D  U I  D U  1 L  D L  U I  o C  0 0 0  0 0 \
0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0 \
 o C  1 L  0 0 0  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0\
 0 0  o C  1 L  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C\
  1 L  1 L  U I  1 U  U I  o U  0 O D  o U  o U  U I  1 I  U I  0 0 0 \
 o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  U I  0 O D  0\
 O I  U I  D O  1 L  U I  1 D  U I  D O  1 L  D L  U I  0 O D  1 C  U \
I  1 o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  0\
 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  0 O O  0 O 0  0 O I  U \
I  o C  1 L  1 L  0 0 0  0 0 0  1 L  o C  1 L  1 L  U I  1 O  U I  0 0\
 O  C o  0 O C  0 O 0  U I  1 0  U I  D L  0 O  U I  o C  o C  o C  1 \
L  o C  o C  0 0 0  U I  P 0  U I  0 O P  0 0 D  0 0 0  0 0 O  U I  1 \
P  U I  0 O L  0 0 0  C o  0 O O  0 0 D  U I  1 O  U I  0 0 0  0 0 I  \
0 O 0  0 0 O  U I  1 O  U I  0 O D  0 O D  0 O D  o U  1 C  1 C  U I  \
1 0  U I  1 P  U I  0 0 1  0 O 0  C o  0 O O  U I  1 O  U I  1 0  U I \
 1 0  0 O  U I  0 O I  0 0 0  0 0 1  U I  0 0 0  o C  1 L  1 L  0 0 0 \
 0 0 0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1 L  U I  0 O D  0 0 O  U \
I  0 0 1  C o  0 0 O  0 O U  0 O 0  U I  1 O  U I  0 O L  0 O 0  0 0 O\
  U I  1 O  U I  o C  o C  o C  1 L  o C  o C  0 0 0  U I  1 0  U I  1\
 0  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  o C  o C  o C  1 L  o \
C  o C  0 0 0  U I  C 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 \
0  o C  o C  0 0 0  o C  0 0 0  1 L  U I  C U  U I  C 0  U I  1 L  U I\
  C U  U I  P 0  P 0  U I  0 0 O  C o  0 O C  0 O 0  U I  D L  0 O  U \
I  U I  U I  0 O O  0 O 0  0 O L  U I  o C  o C  o C  1 L  o C  o C  0\
 0 0  U I  C 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o\
 C  0 0 0  o C  0 0 0  1 L  U I  C U  0 O  U I  U I  U I  o C  0 0 0  \
o C  U I  P 0  U I  0 0 0  0 0 I  0 O 0  0 0 O  U I  1 O  U I  0 O D  \
0 O D  0 O D  o U  1 C  1 C  U I  1 1  U I  U 1  0 0 C  U 1  U I  1 0 \
 0 O  U I  U I  U I  o C  0 0 0  o C  U I  1 P  U I  0 0 C  0 0 1  0 O\
 D  0 0 P  0 O 0  U I  1 O  U I  0 O P  0 0 D  0 0 0  0 0 O  U I  1 P \
 U I  0 O O  0 0 o  0 O C  0 0 I  0 0 D  U I  1 O  U I  o C  o C  o C \
 1 L  o C  o C  0 0 0  U I  1 0  U I  1 0  0 O  U I  U I  U I  o C  0 \
0 0  o C  U I  1 P  U I  C C  0 O L  0 0 0  0 0 D  0 O 0  U I  1 O  U \
I  1 0  0 O  U I  U I  U I  C L  0 0 1  0 O 0  C o  0 O o  0 O  U I  0\
 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o \
 0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O\
  U I  U 1  L L  P P  o o  P o  1 P  P o  0 0 0  0 0 O  0 0 P  C o  0 \
O D  0 0 O  0 O 0  0 0 1  1 P  L I  0 O 0  0 O I  0 0 1  0 O 0  0 0 D \
 0 O 1  U 1  U I  1 0  0 O  U I  0 O D  0 O I  U I  D 1  D U  U I  1 D\
  U I  D 1  D U  D L  U I  o C  1 L  0 0 0  o C  U I  1 U  U I  o U  0\
 O D  1 C  o U  0 O  0 O O  0 O 0  0 O I  U I  o C  0 0 0  1 L  o C  1\
 L  o C  o C  1 L  o C  0 0 0  o C  1 L  U I  1 O  U I  0 0 o  0 0 1  \
0 O L  U I  1 0  U I  D L  0 O  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1\
  0 0 P  U I  0 0 o  0 0 1  0 O L  0 0 1  0 O 0  0 0 D  0 0 0  0 O L  \
0 0 L  0 O 0  0 0 1  0 O  U I  0 O D  o U  o U  0 O D  o U  1 C  1 C  \
0 O D  o U  1 C  o U  0 O D  1 C  U I  P 0  U I  0 0 o  0 0 1  0 O L  \
0 0 1  0 O 0  0 0 D  0 0 0  0 O L  0 0 L  0 O 0  0 0 1  U I  1 P  U I \
 o I  0 0 0  0 0 D  0 0 P  0 O 0  0 O O  o o  0 O 0  0 O O  0 O D  C o\
  o O  0 O D  0 O L  0 O 0  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1\
 0  0 O  U I  0 O D  0 O I  U I  0 O D  o U  o U  0 O D  o U  1 C  1 C\
  0 O D  o U  1 C  o U  0 O D  1 C  U I  D L  0 O  U I  U I  o C  1 L \
 1 L  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 0 1  0 O 0  0 0 D  0 0 0  \
0 O L  0 0 L  0 O 0  0 0 1  U I  1 P  U I  0 0 1  0 O 0  0 0 D  0 0 0 \
 0 O L  0 0 L  0 O 0  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 0  0 \
O  U I  U I  0 0 0  1 L  1 L  0 0 0  0 0 0  U I  P 0  U I  o C  1 L  1\
 L  0 O  U I  U I  0 O D  0 O I  U I  0 O D  0 0 D  0 O D  0 0 O  0 0 \
D  0 0 P  C o  0 0 O  C C  0 O 0  U I  1 O  U I  0 0 0  1 L  1 L  0 0 \
0  0 0 0  U I  1 1  U I  0 O L  0 O D  0 0 D  0 0 P  U I  1 0  U I  D \
L  0 O  U I  U I  U I  0 O I  0 0 0  0 0 1  U I  o U  o U  0 O D  0 O \
D  o U  o U  0 O D  1 C  U I  0 O D  0 0 O  U I  0 0 0  1 L  1 L  0 0 \
0  0 0 0  U I  D L  0 O  U I  U I  U I  U I  o C  1 L  0 0 0  o C  1 L\
  0 0 0  0 0 0  1 L  o C  U I  P 0  U I  o C  1 L  o U  1 C  1 C  0 O \
D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0 \
 0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  \
U C  0 0 U  0 0 o  C o  0 O L  0 O D  0 0 P  0 I 0  U C  U I  1 0  0 O\
  U I  U I  U I  U I  0 O D  0 O I  U I  o U  o U  0 O D  0 O D  o U  \
o U  0 O D  1 C  U I  C 0  U I  U C  0 0 U  0 0 o  C o  0 O L  0 O D  \
0 0 P  0 I 0  U C  U I  C U  U I  P 0  P 0  U I  U C  o I  P L  U C  U\
 I  D L  0 O  U I  U I  U I  U I  U I  o C  1 L  1 L  U I  P 0  U I  o\
 U  o U  0 O D  0 O D  o U  o U  0 O D  1 C  U I  C 0  U I  U C  0 0 o\
  0 0 1  0 O L  U C  U I  C U  0 O  U I  U I  U I  U I  U I  C L  0 0 \
1  0 O 0  C o  0 O o  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 \
O I  U I  o U  o U  0 O D  0 O D  o U  o U  0 O D  1 C  U I  C 0  U I \
 U C  0 0 U  0 0 o  C o  0 O L  0 O D  0 0 P  0 I 0  U C  U I  C U  U \
I  P 0  P 0  U I  U C  L U  P L  U C  U I  D L  0 O  U I  U I  U I  U \
I  U I  o C  1 L  1 L  U I  P 0  U I  o U  o U  0 O D  0 O D  o U  o U\
  0 O D  1 C  U I  C 0  U I  U C  0 0 o  0 0 1  0 O L  U C  U I  C U  \
0 O  U I  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  o U  o U  0 \
O D  0 O D  o U  o U  0 O D  1 C  U I  C 0  U I  U C  0 0 U  0 0 o  C \
o  0 O L  0 O D  0 0 P  0 I 0  U C  U I  C U  U I  P 0  P 0  U I  U C \
 1 C  1 L  D P  1 L  0 0 I  U C  U I  C o  0 0 O  0 O O  U I  o C  1 L\
  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 \
P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0\
 O U  U I  1 O  U I  U C  1 C  1 L  D P  1 L  0 0 I  0 0 U  0 0 o  C o\
  0 O L  0 O D  0 0 P  0 I 0  U C  U I  1 0  U I  P 0  P 0  U I  U C  \
0 0 P  0 0 1  0 0 o  0 O 0  U C  U I  D L  0 O  U I  U I  U I  U I  U \
I  o C  1 L  1 L  U I  P 0  U I  o U  o U  0 O D  0 O D  o U  o U  0 O\
 D  1 C  U I  C 0  U I  U C  0 0 o  0 0 1  0 O L  U C  U I  C U  0 O  \
U I  U I  U I  U I  U I  C L  0 0 1  0 O 0  C o  0 O o  0 O  U I  U I \
 0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  o C  1 L  1\
 L  U I  P 0  U I  0 0 0  1 L  1 L  0 0 0  0 0 0  0 O  U I  0 O 0  0 O\
 L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 I O  C L  0 O C  C C  U I\
  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 o \
 0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O  U I  U 1  L L  P P  o o \
 P o  1 P  o L  0 0 0  0 0 P  0 O D  0 O I  0 O D  C C  C o  0 0 P  0 \
O D  0 0 0  0 0 O  1 O  L 1  0 O 0  C o  0 O C  L U  0 0 I  0 0 0  0 0\
 1  0 0 P  0 0 D  1 1  L D  0 0 1  0 O L  0 0 1  0 O 0  0 0 D  0 0 0  \
0 O L  0 0 L  0 O 0  0 0 1  U I  0 O O  0 0 0  0 0 O  0 0 0  0 0 P  U \
I  0 0 D  0 0 o  0 0 I  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 0 P  0 O 1 \
 0 O D  0 0 D  U I  0 O O  0 0 0  0 O C  C o  0 O D  0 0 O  1 P  U I  \
1 D  U I  1 1  D U  1 L  1 L  1 L  1 0  U 1  U I  1 0  0 O  U I  U I  \
o C  1 L  1 L  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O  U I  0 0 1  0 \
O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  o C  1 L  1 L  0 O  0 O O  0 O 0\
  0 O I  U I  0 0 0  0 0 0  0 0 0  o C  o C  o C  1 L  0 0 0  0 0 0  o\
 C  0 0 0  o C  o C  o C  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 1\
  U I  0 O L  0 O D  0 0 D  0 0 P  0 O D  0 0 P  0 O 0  0 O C  U I  1 \
1  U I  0 0 I  0 O O  0 O D  C o  0 O L  0 0 0  0 O U  0 0 o  0 O 0  U\
 I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 0  U I  D L  0 O  U I  \
0 O D  0 O I  U I  D 1  D P  U I  1 D  U I  D 1  D P  D L  U I  o U  o\
 U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  0 O  U I  0 O D  0 O\
 I  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 O L  0 0 0  0 0 C  0 O \
0  0 0 1  U I  1 O  U I  1 0  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1 \
 0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  0 0 I  \
0 O L  0 0 o  0 O U  0 O D  0 0 O  U C  U I  1 0  U I  C o  0 0 O  0 O\
 O  U I  U C  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0  U C  U I \
 0 0 O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I\
  1 P  U I  0 O L  0 0 0  0 0 C  0 O 0  0 0 1  U I  1 O  U I  1 0  U I\
  D L  0 O  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  0 0\
 I  0 O L  C o  0 I 0  0 O D  0 0 O  0 O U  U I  0 0 L  0 O D  C o  U \
I  0 0 1  0 0 o  0 0 O  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U C \
 0 O  U I  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0\
 O 0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O D\
  0 0 O  U I  1 O  U I  U C  L L  P P  o o  P o  1 P  L I  0 0 o  0 0 \
O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U C  U I  1 U  U I  0 \
0 o  0 0 1  0 O L  U I  1 U  U I  U C  1 0  U C  U I  1 0  0 O  U I  U\
 I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L \
 o C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  0 0 1  C o  0 0 O  \
0 O U  0 O 0  U I  1 O  U I  D P  U I  1 0  U I  D L  0 O  U I  U I  U\
 I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 0 D  0 O L  0 O 0  0 O 0 \
 0 0 I  U I  1 O  U I  D U  1 L  1 L  U I  1 0  0 O  U I  U I  U I  0 \
0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O I  U \
I  D D  D 1  U I  1 D  U I  D D  D 1  D L  U I  0 0 0  o C  1 L  0 0 0\
  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  U I  U I  U I  0 O D  0 O I  \
U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O U  0 O 0  0 0 P  P o  \
0 0 0  0 0 O  0 O O  L P  0 O D  0 0 D  0 O D  C L  0 O D  0 O L  0 O \
D  0 0 P  0 I 0  U I  1 O  U I  U 1  L O  0 O L  C o  0 I 0  0 O 0  0 \
0 1  1 P  o I  C o  0 0 D  o o  0 O 0  0 O O  0 O D  C o  U 1  U I  1 \
0  U I  C o  0 0 O  0 O O  U I  0 I O  C L  0 O C  C C  U I  1 P  U I \
 L O  0 O L  C o  0 I 0  0 O 0  0 0 1  U I  1 O  U I  1 0  U I  1 P  U\
 I  0 O D  0 0 D  L O  0 O L  C o  0 I 0  0 O D  0 0 O  0 O U  U I  1 \
O  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 0 1  0 O 0  0 0\
 P  0 0 o  0 0 1  0 0 O  U I  L 1  0 0 1  0 0 o  0 O 0  0 O  U I  U I \
 U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C \
o  0 0 D  0 0 D  0 O  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I\
  U C  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O D  0 0 O  0 O U  \
U I  0 0 O  0 0 0  0 0 C  U C  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0\
 o  0 0 1  0 0 O  U I  o O  C o  0 O L  0 0 D  0 O 0  0 O  U I  0 O D \
 0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  P o  0 0 o  0 0 D  0 0 P  0 0\
 0  0 O C  L O  0 O L  C o  0 I 0  0 O 0  0 0 1  U I  1 1  U I  0 0 P \
 0 O D  0 O C  0 O 0  0 O  U I  0 O D  0 O I  U I  D o  D o  U I  1 D \
 U I  D o  D o  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O\
  U I  o U  o U  o U  0 O D  0 O D  0 O D  o U  U I  P 0  U I  P o  0 \
0 o  0 0 D  0 0 P  0 0 0  0 O C  L O  0 O L  C o  0 I 0  0 O 0  0 0 1 \
 U I  1 P  U I  o o  0 I 0  L L  P P  o o  P o  L O  0 O L  C o  0 I 0\
  0 O 0  0 0 1  U I  1 O  U I  1 0  0 O  U I  o U  o U  o U  0 O D  0 \
O D  0 O D  o U  U I  1 P  U I  0 0 I  0 O O  0 O D  C o  0 O L  0 0 0\
  0 O U  0 0 o  0 O 0  U I  P 0  U I  0 0 I  0 O O  0 O D  C o  0 O L \
 0 0 0  0 O U  0 0 o  0 O 0  0 O  U I  o U  1 C  1 C  o U  o U  o U  o\
 U  1 C  1 C  1 C  1 C  o U  o U  U I  P 0  U I  0 0 P  0 O D  0 O C  \
0 O 0  U I  1 P  U I  0 0 P  0 O D  0 O C  0 O 0  U I  1 O  U I  1 0  \
0 O  U I  0 O D  0 O I  U I  D 1  U I  1 D  U I  D 1  D L  U I  0 0 0 \
 o C  1 L  0 0 0  U I  1 o  U I  o C  1 L  0 0 0  o C  U I  1 U  U I  \
0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0\
 P  U I  U C  0 O U  0 0 0  0 O D  0 0 O  0 O U  U I  0 0 P  0 0 0  U \
I  0 0 I  0 O L  C o  0 I 0  U C  0 O  U I  0 O D  0 O C  0 0 I  0 0 0\
  0 0 1  0 0 P  U I  0 0 P  0 O D  0 O C  0 O 0  0 O  U I  0 O D  1 C \
 1 C  1 C  0 O D  0 O D  o U  o U  o U  o U  U I  P 0  U I  0 0 P  0 O\
 D  0 O C  0 O 0  U I  1 P  U I  0 0 P  0 O D  0 O C  0 O 0  U I  1 O \
 U I  1 0  0 O  U I  o U  o U  o U  0 O D  0 O D  0 O D  o U  U I  1 P\
  U I  0 0 I  0 O L  C o  0 I 0  U I  1 O  U I  0 0 o  0 0 1  0 O L  U\
 I  1 1  U I  0 O L  0 O D  0 0 D  0 0 P  0 O D  0 0 P  0 O 0  0 O C  \
U I  1 0  0 O  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 0 D  0 O \
L  0 O 0  0 O 0  0 0 I  U I  1 O  U I  1 C  1 L  1 L  1 L  U I  1 0  0\
 O  U I  0 O D  0 O I  U I  D P  D o  U I  1 D  U I  D P  D o  D L  U \
I  o U  o U  o U  o U  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U\
 I  U I  0 0 C  0 O 1  0 O D  0 O L  0 O 0  U I  o U  o U  o U  0 O D \
 0 O D  0 O D  o U  U I  1 P  U I  0 O D  0 0 D  C D  C o  C C  0 0 P \
 0 O D  0 0 L  0 O 0  U I  D L  0 O  U I  U I  U I  0 I O  C L  0 O C \
 C C  U I  1 P  U I  0 0 D  0 O L  0 O 0  0 O 0  0 0 I  U I  1 O  U I \
 D I  1 L  1 L  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D P  \
D D  U I  1 D  U I  D P  D D  D L  U I  0 O D  0 O D  o U  1 C  0 O D \
 o U  0 O D  o U  U I  U o  U I  o U  0 O D  o U  o U  0 O  U I  U I  \
U I  0 O D  0 O I  U I  o U  o U  o U  0 O D  0 O D  0 O D  o U  U I  \
1 P  U I  0 0 o  0 0 1  0 O L  0 0 I  0 O L  C o  0 I 0  0 O 0  0 O O \
 U I  D L  0 O  U I  U I  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P \
 U I  U C  0 I 0  0 O 0  0 0 D  U I  0 0 I  0 O L  C o  0 I 0  0 O 0  \
0 O O  U C  0 O  U I  U I  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1\
  0 0 O  U I  L 1  0 0 1  0 0 o  0 O 0  0 O  U I  U I  U I  0 O D  0 O\
 I  U I  0 0 P  0 O D  0 O C  0 O 0  U I  1 P  U I  0 0 P  0 O D  0 O \
C  0 O 0  U I  1 O  U I  1 0  U I  1 D  U I  0 O D  1 C  1 C  1 C  0 O\
 D  0 O D  o U  o U  o U  o U  U I  P I  U I  D I  U I  D L  U I  0 0 \
1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  o O  C o  0 O L  0 0 D  0 O\
 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D 1  D O  U I  1 D  U I  D \
1  D O  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 U  U I  \
o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 o  U I  0 O D  0 \
O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 I  U I  0 0 0  0 0 0  o \
C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  0 O 0  0 I O  C C  0 O 0 \
 0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  0 0 \
I  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  0 0 O  0 0 0  0 0 P  U I  0 0\
 I  0 O L  C o  0 I 0  0 O 0  0 O O  U C  U I  1 1  U I  0 0 o  0 0 1 \
 0 O L  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  o O  \
C o  0 O L  0 0 D  0 O 0  0 O  0 O O  0 O 0  0 O I  U I  0 O D  0 O D \
 o U  o U  o U  o U  0 O D  o U  1 C  1 C  1 C  U I  1 O  U I  0 0 O  \
C o  0 O C  0 O 0  U I  1 1  U I  0 O C  0 0 o  C D  0 0 I  0 O L  C o\
  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U I  1 1  U I  0 0 U  0 0 o  0 O \
0  0 0 o  0 O 0  L P  0 O D  0 O O  0 O 0  0 0 0  U I  P 0  U I  o L  \
0 0 0  0 0 O  0 O 0  U I  1 0  U I  D L  0 O  U I  0 0 0  0 0 0  1 L  \
1 L  1 L  0 O D  0 O D  U I  P 0  U I  0 I O  C L  0 O C  C C  U I  1 \
P  U I  L O  0 O L  C o  0 I 0  o P  0 O D  0 0 D  0 0 P  U I  1 O  U \
I  0 I O  C L  0 O C  C C  U I  1 P  U I  L O  o P  P D  L C  o P  o U\
  L U  L 1  C D  L P  o U  P L  P C  o C  U I  1 0  0 O  U I  0 O D  0\
 O I  U I  D P  D 1  U I  1 D  U I  D P  D 1  D L  U I  o U  0 O D  1 \
C  o U  U I  U o  U I  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  0 0 0  o\
 C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 D  U I  0 0 0  1 L\
  1 L  o C  1 L  0 0 0  0 0 0  U I  1 I  U I  0 O D  1 C  1 C  o U  0 \
O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 P  U I  0 O D \
 o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  U C  U P\
  U P  o P  L U  L O  0 O L  C o  0 I 0  o C  0 0 O  0 O L  0 I 0  o C\
  0 0 O  0 O 0  U P  U P  U C  U I  0 O D  0 0 O  U I  0 O C  0 0 o  C\
 D  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U I  C 0  U \
I  1 L  U I  C U  U I  D L  0 O  U I  U I  0 O C  0 0 o  C D  0 0 I  0\
 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U I  C 0  U I  1 L  U I \
 C U  U I  P 0  U I  0 O C  0 0 o  C D  0 0 I  0 O L  C o  0 I 0  0 O \
L  0 O D  0 0 D  0 0 P  U I  C 0  U I  1 L  U I  C U  U I  1 P  U I  0\
 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  U P  U\
 P  o P  L U  L O  0 O L  C o  0 I 0  o C  0 0 O  0 O L  0 I 0  o C  0\
 0 O  0 O 0  U P  U P  U C  U I  1 1  U I  U C  U C  U I  1 0  0 O  U \
I  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 0 o  0 0 1  0\
 O L  0 0 I  C o  0 0 1  0 0 D  0 O 0  0 O  U I  U I  o C  0 0 0  o C \
 0 0 0  o C  0 0 0  0 0 0  1 L  o C  0 0 0  o C  1 L  U I  P 0  U I  C\
 0  U I  C U  0 O  U I  U I  o U  1 C  0 O D  0 O D  o U  1 C  0 O D  \
0 O D  o U  1 C  0 O D  1 C  U I  P 0  U I  1 L  0 O  U I  U I  0 O D \
 1 C  1 C  0 O D  1 C  o U  0 O D  1 C  U I  P 0  U I  0 I O  C L  0 O\
 C  C C  0 O U  0 0 o  0 O D  U I  1 P  U I  P L  0 O D  C o  0 O L  0\
 0 0  0 O U  L O  0 0 1  0 0 0  0 O U  0 0 1  0 O 0  0 0 D  0 0 D  U I\
  1 O  U I  1 0  0 O  U I  U I  0 O D  1 C  1 C  0 O D  1 C  o U  0 O \
D  1 C  U I  1 P  U I  C C  0 0 1  0 O 0  C o  0 0 P  0 O 0  U I  1 O \
 U I  U C  L O  0 0 1  0 0 0  0 O U  0 0 1  0 O 0  0 0 D  0 0 D  U C  \
U I  1 1  U I  U C  L 1  0 0 1  0 I 0  0 O D  0 0 O  0 O U  U I  o o  \
0 0 o  0 O L  0 0 P  0 O D  0 0 I  0 O L  0 O 0  U I  o P  0 O D  0 0 \
O  0 O o  0 0 D  U C  U I  1 0  0 O  U I  U I  0 O I  0 0 0  0 0 1  U \
I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  \
U I  0 O D  0 0 O  U I  0 O C  0 0 o  C D  0 0 I  0 O L  C o  0 I 0  0\
 O L  0 O D  0 0 D  0 0 P  U I  D L  0 O  U I  U I  U I  0 O D  0 O I \
 U I  D P  D P  U I  1 D  U I  D P  D P  D L  U I  o U  o U  o U  o U \
 U I  U o  U I  o U  0 O D  o U  o U  U I  1 D  U I  0 0 0  1 L  0 0 0\
  o C  1 L  U I  U o  U I  o U  o U  o U  o U  U I  1 U  U I  0 0 0  0\
 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 D  U I  0 O D  0 O D  o U  1\
 C  0 O D  o U  0 O D  o U  0 O  U I  U I  U I  0 O D  0 O I  U I  D O\
  D 0  U I  1 D  U I  D O  D 0  D L  U I  o U  o U  0 O D  o U  0 O D \
 o U  o U  1 C  1 C  0 O D  0 O  U I  U I  U I  0 O D  0 O I  U I  U C\
  U P  U P  0 O L  0 0 D  0 0 O  C o  0 O C  0 O 0  P 0  U C  U I  0 O\
 D  0 0 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0\
 0 0  0 0 0  U I  D L  0 O  U I  U I  U I  U I  o U  1 C  0 O D  o U  \
1 C  1 C  o U  0 O D  0 O D  o U  1 C  1 C  0 O D  U I  P 0  U I  o C \
 0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 \
P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  U P  U \
P  0 O L  0 0 D  0 0 O  C o  0 O C  0 O 0  P 0  U C  U I  1 0  U I  C \
0  U I  1 C  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 \
P  U I  1 O  U I  U C  U L  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  \
U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U I  U I  U I  \
o C  0 0 0  o C  0 0 0  o C  0 0 0  0 0 0  1 L  o C  0 0 0  o C  1 L  \
U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  \
o U  1 C  0 O D  o U  1 C  1 C  o U  0 O D  0 O D  o U  1 C  1 C  0 O \
D  U I  1 0  0 O  U I  U I  U I  U I  0 O C  0 0 o  C D  0 0 I  0 O L \
 C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U I  C 0  U I  o U  1 C  0 O \
D  0 O D  o U  1 C  0 O D  0 O D  o U  1 C  0 O D  1 C  U I  C U  U I \
 P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0 \
 0 0 0  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U \
I  U C  U P  U P  0 O L  0 0 D  0 0 O  C o  0 O C  0 O 0  P 0  U C  U \
I  1 0  U I  C 0  U I  1 L  U I  C U  U I  1 U  U I  1 O  U I  U C  U \
L  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U C  U I  1 U  U I  o C  \
0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P\
  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  U L  0 0\
 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U C  U I  1 0  U I  C 0  U I  1\
 C  U I  C U  U I  0 O D  0 O I  U I  U C  U L  0 0 1  0 O 0  0 O U  0\
 O 0  0 I O  0 0 D  U C  U I  0 O D  0 0 O  U I  o C  0 0 0  0 0 0  1 \
L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0 O 0  0 O L  0 0 D\
  0 O 0  U I  U C  U C  U I  1 0  0 O  U I  U I  U I  0 O 0  0 O L  0 \
0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  o U  1 C  0 O D  o U  1\
 C  1 C  o U  0 O D  0 O D  o U  1 C  1 C  0 O D  U I  P 0  U I  0 0 o\
  0 0 1  0 O L  0 0 I  C o  0 0 1  0 0 D  0 O 0  U I  1 P  U I  0 0 o \
 0 0 1  0 O L  0 0 I  C o  0 0 1  0 0 D  0 O 0  U I  1 O  U I  o C  0 \
0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 0  \
U I  1 P  U I  0 0 O  0 O 0  0 0 P  0 O L  0 0 0  C C  0 O  U I  U I  \
U I  U I  0 O D  0 O I  U I  o U  1 C  0 O D  o U  1 C  1 C  o U  0 O \
D  0 O D  o U  1 C  1 C  0 O D  U I  P 0  P 0  U I  U C  U C  U I  D L\
  0 O  U I  U I  U I  U I  U I  o C  0 0 0  o C  0 0 0  o C  0 0 0  0 \
0 0  1 L  o C  0 0 0  o C  1 L  U I  1 P  U I  C o  0 0 I  0 0 I  0 O \
0  0 0 O  0 O O  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  0 \
O  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I \
 U I  U I  U I  U I  o C  0 0 0  o C  0 0 0  o C  0 0 0  0 0 0  1 L  o\
 C  0 0 0  o C  1 L  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0\
 O O  U I  1 O  U I  o U  1 C  0 O D  o U  1 C  1 C  o U  0 O D  0 O D\
  o U  1 C  1 C  0 O D  U I  1 0  0 O  U I  U I  U I  0 0 0  o C  1 L \
 1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1 L  U I  P 0 \
 U I  o U  1 C  0 O D  0 O D  o U  1 C  0 O D  0 O D  o U  1 C  0 O D \
 1 C  0 O  U I  U I  U I  o U  1 C  0 O D  0 O D  o U  1 C  0 O D  0 O\
 D  o U  1 C  0 O D  1 C  U I  1 U  P 0  U I  1 C  0 O  U I  U I  U I \
 0 O D  0 O I  U I  D 0  D D  U I  1 D  U I  D 0  D D  D L  U I  0 0 0\
  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  o U  1 C  1 C  0 O \
D  U I  1 D  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 U  U\
 I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 O D  1 C  0 O  U I  U I  \
U I  0 0 0  o C  0 0 0  o C  1 L  1 L  o C  U I  P 0  U I  o C  0 0 0 \
 o C  0 0 0  o C  0 0 0  0 0 0  1 L  o C  0 0 0  o C  1 L  U I  C 0  U\
 I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0\
 0 0  1 L  U I  C U  0 O  U I  U I  U I  0 O D  0 O I  U I  0 O D  1 C\
  1 C  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I  0 O D  0 0 D  C C  \
C o  0 0 O  C C  0 O 0  0 O L  0 O 0  0 O O  U I  1 O  U I  1 0  U I  \
D L  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O  U I  U I  U I\
  0 O D  1 C  1 C  0 O D  1 C  o U  0 O D  1 C  U I  1 P  U I  0 0 o  \
0 0 I  0 O O  C o  0 0 P  0 O 0  U I  1 O  U I  o U  1 C  0 O D  0 O D\
  o U  1 C  0 O D  0 O D  o U  1 C  0 O D  1 C  U I  1 o  U I  0 O L  \
0 O 0  0 0 O  U I  1 O  U I  0 O C  0 0 o  C D  0 0 I  0 O L  C o  0 I\
 0  0 O L  0 O D  0 0 D  0 0 P  U I  1 0  U I  1 I  U I  1 C  1 L  1 L\
  U I  1 1  U I  U 1  U 1  U I  1 1  U I  U 1  o P  0 O D  0 0 O  0 O \
o  U D  U o  0 O O  U 1  U I  U o  U I  1 O  U I  o U  1 C  0 O D  0 O\
 D  o U  1 C  0 O D  0 O D  o U  1 C  0 O D  1 C  U I  1 0  U I  1 1  \
U I  0 0 0  o C  0 0 0  o C  1 L  1 L  o C  U I  1 0  0 O  U I  U I  U\
 I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  C o  0 0 o  0 0 P  0 \
0 0  U I  0 0 I  0 O L  C o  0 I 0  0 0 O  C o  0 O C  0 O 0  0 I O  0\
 I O  U C  U I  1 1  U I  0 0 0  o C  0 0 0  o C  1 L  1 L  o C  0 O  \
U I  U I  U I  0 O D  0 O I  U I  U 1  U L  0 O C  0 0 0  0 O O  0 O 0\
  P 0  1 C  D o  U 1  U I  0 O D  0 0 O  U I  0 O C  0 0 o  C D  0 0 I\
  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U I  C 0  U I  0 0 0 \
 o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1 L \
 U I  C U  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D 0  \
1 C  U I  1 D  U I  D 0  1 C  D L  U I  o C  0 0 0  0 0 0  0 0 0  1 L \
 1 L  1 L  1 L  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0\
 0  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  U o\
  U I  o U  0 O D  o U  o U  U I  U o  U I  0 O D  o U  o U  1 C  1 C \
 1 C  0 O D  U I  1 I  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D \
 o U  0 O  U I  U I  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  \
1 C  o U  1 C  1 C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U  0 0 \
o  0 O D  U I  1 P  U I  o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 O 0  \
0 O C  U I  1 O  U I  0 0 0  o C  0 0 0  o C  1 L  1 L  o C  U I  1 1 \
 U I  0 O D  C C  0 0 0  0 0 O  o U  0 O C  C o  0 O U  0 O 0  U I  P \
0  U I  0 O D  1 C  0 O D  0 O D  0 O D  0 O D  o U  1 C  1 C  0 O D  \
0 O D  U I  1 1  U I  0 0 P  0 O 1  0 0 o  0 O C  C L  0 0 O  C o  0 O\
 D  0 O L  o U  0 O C  C o  0 O U  0 O 0  U I  P 0  U I  0 O D  1 C  0\
 O D  0 O D  0 O D  0 O D  o U  1 C  1 C  0 O D  0 O D  U I  1 0  0 O \
 U I  U I  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  \
1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  o U  0 0 O  0 O I  0 0 0\
  U I  1 O  U I  0 0 P  0 I 0  0 0 I  0 O 0  U I  P 0  U I  U C  L P  \
0 O D  0 O O  0 O 0  0 0 0  U C  U I  1 1  U I  0 O D  0 0 O  0 O I  0\
 0 0  o P  C o  C L  0 O 0  0 O L  0 0 D  U I  P 0  U I  0 I U  U I  U\
 C  L 1  0 O D  0 0 P  0 O L  0 O 0  U C  U I  D L  U I  0 0 0  o C  0\
 0 0  o C  1 L  1 L  o C  U I  0 I D  U I  1 0  0 O  U I  U I  U I  U \
I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P\
  U I  0 0 D  0 O 0  0 0 P  L O  0 0 1  0 0 0  0 0 I  0 O 0  0 0 1  0 \
0 P  0 I 0  U I  1 O  U I  U 1  o U  0 0 D  L O  0 O L  C o  0 I 0  C \
o  C L  0 O L  0 O 0  U 1  U I  1 1  U I  U 1  0 0 P  0 0 1  0 0 o  0 \
O 0  U 1  U I  1 0  0 O  U I  U I  U I  U I  0 0 0  1 L  1 L  o C  o C\
  0 0 0  1 L  0 0 0  1 L  o C  U I  P 0  U I  o C  0 0 0  1 L  o C  1 \
L  o C  o C  1 L  o C  0 0 0  o C  1 L  U I  1 O  U I  0 O C  0 0 o  C\
 D  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U I  C 0  U \
I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0 \
0 0  1 L  U I  C U  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C \
C  0 O 0  U I  1 O  U I  U C  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  1 \
C  D o  U C  U I  1 1  U I  U C  U C  U I  1 0  U I  1 P  U I  0 0 1  \
0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  D C  U C  U \
I  1 1  U I  U C  U C  U I  1 0  U I  1 0  0 O  U I  U I  U I  U I  o \
U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  U I\
  0 0 D  0 O 0  0 0 P  L O  C o  0 0 P  0 O 1  U I  1 O  U I  0 0 0  1\
 L  1 L  o C  o C  0 0 0  1 L  0 0 0  1 L  o C  U I  1 0  0 O  U I  U \
I  U I  U I  0 O D  0 O I  U I  1 C  D I  U I  1 D  U I  1 C  D I  D L\
  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 D  U I  \
0 0 0  1 L  0 0 0  o C  1 L  U I  1 I  U I  o C  o C  0 0 0  0 0 0  o \
C  o C  0 0 0  U I  1 U  U I  o C  1 L  0 0 0  o C  U I  1 P  U I  o U\
  0 O D  1 C  o U  0 O  U I  U I  U I  U I  0 O D  1 C  0 O D  1 C  o \
U  1 C  1 C  0 O D  1 C  o U  U I  P 0  U I  0 0 0  0 0 0  0 0 0  o C \
 o C  o C  1 L  0 0 0  0 0 0  o C  0 0 0  o C  o C  o C  U I  1 O  U I\
  0 0 0  1 L  1 L  o C  o C  0 0 0  1 L  0 0 0  1 L  o C  U I  1 1  U \
I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 0\
  0 O  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  U 1  U P  0 O O\
  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U 1  U I  0 O D  0 0 O  U \
I  0 O C  0 0 o  C D  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0\
 0 P  U I  C 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o\
 C  0 0 0  o C  0 0 0  1 L  U I  C U  U I  D L  0 O  U I  U I  U I  U \
I  0 O D  0 O I  U I  D P  D U  U I  1 D  U I  D P  D U  D L  U I  o C\
  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 P  U I  o U  o U  0 \
O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 o  U I  o C  1 L  0\
 0 0  o C  U I  1 I  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L\
  U I  1 D  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 D  U I  0\
 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  U I  U I  \
U I  0 O D  1 C  o U  o U  1 C  1 C  o U  1 C  1 C  o U  U I  P 0  U I\
  0 O C  0 0 o  C D  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 \
0 P  U I  C 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o \
C  0 0 0  o C  0 0 0  1 L  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O \
L  0 O D  0 0 P  U I  1 O  U I  U C  U L  0 0 1  0 O 0  0 O U  0 O 0  \
0 I O  0 0 D  P 0  U C  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O \
I  U I  D O  D P  U I  1 D  U I  D O  D P  D L  U I  0 0 0  o C  1 L  \
0 0 0  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  \
1 P  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  0 0 \
0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  U I  U I  U I\
  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1  U I  o C  o \
C  1 L  1 L  U I  P 0  U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  1 O  U\
 I  0 O D  1 C  o U  o U  1 C  1 C  o U  1 C  1 C  o U  U I  C 0  U I \
 1 C  U I  C U  U I  1 1  U I  0 O D  1 C  o U  o U  1 C  1 C  o U  1 \
C  1 C  o U  U I  C 0  U I  1 L  U I  C U  U I  1 0  0 O  U I  U I  U \
I  U I  o C  1 L  1 L  0 0 0  o C  U I  P 0  U I  o U  0 O D  o U  0 O\
 D  1 C  1 C  0 O D  o U  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C\
 o  C C  0 O 0  U I  1 O  U I  U C  D C  U C  U I  1 1  U I  U C  U C \
 U I  1 0  0 O  U I  U I  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  \
o U  1 C  o U  1 C  1 C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U \
 0 0 o  0 O D  U I  1 P  U I  o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 \
O 0  0 O C  U I  1 O  U I  0 0 0  o C  0 0 0  o C  1 L  1 L  o C  U I \
 1 1  U I  0 O D  C C  0 0 0  0 0 O  o U  0 O C  C o  0 O U  0 O 0  U \
I  P 0  U I  0 O D  1 C  0 O D  0 O D  0 O D  0 O D  o U  1 C  1 C  0 \
O D  0 O D  U I  1 1  U I  0 0 P  0 O 1  0 0 o  0 O C  C L  0 0 O  C o\
  0 O D  0 O L  o U  0 O C  C o  0 O U  0 O 0  U I  P 0  U I  0 O D  1\
 C  0 O D  0 O D  0 O D  0 O D  o U  1 C  1 C  0 O D  0 O D  U I  1 0 \
 0 O  U I  U I  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  \
o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  o U  0 0 O  0 O I  \
0 0 0  U I  1 O  U I  0 0 P  0 I 0  0 0 I  0 O 0  U I  P 0  U I  U C  \
L P  0 O D  0 O O  0 O 0  0 0 0  U C  U I  1 1  U I  0 O D  0 0 O  0 O\
 I  0 0 0  o P  C o  C L  0 O 0  0 O L  0 0 D  U I  P 0  U I  0 I U  U\
 I  U C  L 1  0 O D  0 0 P  0 O L  0 O 0  U C  U I  D L  U I  0 0 0  o\
 C  0 0 0  o C  1 L  1 L  o C  U I  0 I D  U I  1 0  0 O  U I  U I  U \
I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I\
  1 P  U I  0 0 D  0 O 0  0 0 P  L O  0 0 1  0 0 0  0 0 I  0 O 0  0 0 \
1  0 0 P  0 I 0  U I  1 O  U I  U 1  o U  0 0 D  L O  0 O L  C o  0 I \
0  C o  C L  0 O L  0 O 0  U 1  U I  1 1  U I  U 1  0 0 P  0 0 1  0 0 \
o  0 O 0  U 1  U I  1 0  0 O  U I  U I  U I  U I  o U  1 C  0 O D  1 C\
  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 \
0 P  L O  C o  0 0 P  0 O 1  U I  1 O  U I  o C  1 L  1 L  0 0 0  o C \
 U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D 1  D U  U I  \
1 D  U I  D 1  D U  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1\
 C  1 C  0 O D  U I  1 D  U I  0 O D  1 C  U I  1 P  U I  0 O D  1 C  \
1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  0 O  U I \
 U I  U I  U I  0 O D  1 C  0 O D  1 C  o U  1 C  1 C  0 O D  1 C  o U\
  U I  P 0  U I  0 0 0  0 0 0  0 0 0  o C  o C  o C  1 L  0 0 0  0 0 0\
  o C  0 0 0  o C  o C  o C  U I  1 O  U I  o C  1 L  1 L  0 0 0  o C \
 U I  1 1  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  \
1 C  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  D o  U\
 I  1 D  U I  1 C  D o  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  \
0 0 0  o C  1 L  U I  1 P  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 \
O D  o U  U I  1 D  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I \
 1 U  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 D  U I  0 O D  1 C  1 C\
  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  0 O  U I  U \
I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I \
 o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  P 0  U I  0 O C  0\
 0 o  C D  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U I  \
C 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  \
o C  0 0 0  1 L  U I  C U  0 O  U I  U I  U I  U I  o U  0 O D  o U  0\
 O D  1 C  1 C  0 O D  o U  U I  P 0  U I  o U  0 O D  o U  0 O D  1 C\
  1 C  0 O D  o U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U\
 I  1 O  U I  U C  U L  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  P 0 \
 U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U I  U I  U I \
 o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  P 0  \
U I  0 I O  C L  0 O C  C C  0 O U  0 0 o  0 O D  U I  1 P  U I  o P  \
0 O D  0 0 D  0 0 P  o U  0 0 P  0 O 0  0 O C  U I  1 O  U I  0 0 0  o\
 C  0 0 0  o C  1 L  1 L  o C  U I  1 1  U I  0 O D  C C  0 0 0  0 0 O\
  o U  0 O C  C o  0 O U  0 O 0  U I  P 0  U I  0 O D  1 C  0 O D  0 O\
 D  0 O D  0 O D  o U  1 C  1 C  0 O D  0 O D  U I  1 1  U I  0 0 P  0\
 O 1  0 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  o U  0 O C  C o  0 \
O U  0 O 0  U I  P 0  U I  0 O D  1 C  0 O D  0 O D  0 O D  0 O D  o U\
  1 C  1 C  0 O D  0 O D  U I  1 0  0 O  U I  U I  U I  U I  o U  1 C \
 0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D\
  0 O 0  0 0 P  o U  0 0 O  0 O I  0 0 0  U I  1 O  U I  0 0 P  0 I 0 \
 0 0 I  0 O 0  U I  P 0  U I  U C  L P  0 O D  0 O O  0 O 0  0 0 0  U \
C  U I  1 1  U I  0 O D  0 0 O  0 O I  0 0 0  o P  C o  C L  0 O 0  0 \
O L  0 0 D  U I  P 0  U I  0 I U  U I  U C  L 1  0 O D  0 0 P  0 O L  \
0 O 0  U C  U I  D L  U I  0 0 0  o C  0 0 0  o C  1 L  1 L  o C  U I \
 0 I D  U I  1 0  0 O  U I  U I  U I  U I  o U  1 C  0 O D  1 C  0 O D\
  o U  o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L \
O  0 0 1  0 0 0  0 0 I  0 O 0  0 0 1  0 0 P  0 I 0  U I  1 O  U I  U 1\
  o U  0 0 D  L O  0 O L  C o  0 I 0  C o  C L  0 O L  0 O 0  U 1  U I\
  1 1  U I  U 1  0 0 P  0 0 1  0 0 o  0 O 0  U 1  U I  1 0  0 O  U I  \
U I  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1\
 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L O  C o  0 0 P  0 O 1  U I  1\
 O  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 0  0 O  \
U I  U I  U I  U I  0 O D  0 O I  U I  1 C  D 0  U I  1 D  U I  1 C  D\
 0  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 I  U I\
  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 o  U I  \
0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 o  U I  0 \
0 0  o C  1 L  0 0 0  U I  U o  U I  0 0 0  o C  1 L  0 0 0  0 O  U I \
 U I  U I  U I  0 O D  1 C  0 O D  1 C  o U  1 C  1 C  0 O D  1 C  o U\
  U I  P 0  U I  0 0 0  0 0 0  0 0 0  o C  o C  o C  1 L  0 0 0  0 0 0\
  o C  0 0 0  o C  o C  o C  U I  1 O  U I  o U  0 O D  o U  0 O D  1 \
C  1 C  0 O D  o U  U I  1 1  U I  o U  1 C  0 O D  1 C  0 O D  o U  o\
 U  1 C  o U  1 C  1 C  U I  1 0  0 O  U I  U I  U I  U I  0 0 I  0 0 \
1  0 O D  0 0 O  0 0 P  U I  U C  0 0 I  0 O L  C o  0 I 0  0 O 0  0 O\
 O  U C  U I  1 1  U I  0 O D  1 C  0 O D  1 C  o U  1 C  1 C  0 O D  \
1 C  o U  0 O  U I  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  \
U C  0 0 I  0 O L  C o  0 I 0  0 O 0  0 O O  U C  U I  1 1  U I  0 O D\
  1 C  0 O D  1 C  o U  1 C  1 C  0 O D  1 C  o U  0 O  U I  U I  U I \
 0 O D  0 O I  U I  0 O D  1 C  0 O D  1 C  o U  1 C  1 C  0 O D  1 C \
 o U  U I  D L  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O  U \
I  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O  U I  0 O D  0 O\
 I  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  \
1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P\
  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  C o  0 0 D  0 O o  C D  0 0\
 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  C D  0 O D  0 0 P  \
0 O 0  0 O C  0 0 D  U C  U I  1 0  U I  P 0  P 0  U I  U C  0 0 P  0 \
0 1  0 0 o  0 O 0  U C  U I  C o  0 0 O  0 O O  U I  0 0 O  0 0 0  0 0\
 P  U I  0 0 U  0 0 o  0 O 0  0 0 o  0 O 0  L P  0 O D  0 O O  0 O 0  \
0 0 0  U I  D L  0 O  U I  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0\
 P  U I  0 0 o  0 0 1  0 O L  0 0 I  C o  0 0 1  0 0 D  0 O 0  0 O  U \
I  U I  o C  0 0 0  o C  0 0 0  o C  0 0 0  0 0 0  1 L  o C  0 0 0  o \
C  1 L  U I  P 0  U I  C 0  U I  C U  0 O  U I  U I  o U  1 C  0 O D  \
0 O D  o U  1 C  0 O D  0 O D  o U  1 C  0 O D  1 C  U I  P 0  U I  1 \
L  0 O  U I  U I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 \
L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  0 O C\
  0 0 o  C D  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U \
I  D L  0 O  U I  U I  U I  0 O D  0 O I  U I  U C  U P  U P  0 O L  0\
 0 D  0 0 O  C o  0 O C  0 O 0  P 0  U C  U I  0 O D  0 0 O  U I  o C \
 0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  D \
L  0 O  U I  U I  U I  U I  o U  1 C  0 O D  o U  1 C  1 C  o U  0 O D\
  0 O D  o U  1 C  1 C  0 O D  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  \
1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 I\
  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  U P  U P  0 O L  0 0 D  0 0\
 O  C o  0 O C  0 O 0  P 0  U C  U I  1 0  U I  C 0  U I  1 C  U I  C \
U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U \
C  U L  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U C  U I  1 0  U I  \
C 0  U I  1 L  U I  C U  0 O  U I  U I  U I  U I  o C  0 0 0  o C  0 0\
 0  o C  0 0 0  0 0 0  1 L  o C  0 0 0  o C  1 L  U I  1 P  U I  C o  \
0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  o U  1 C  0 O D  o U\
  1 C  1 C  o U  0 O D  0 O D  o U  1 C  1 C  0 O D  U I  1 0  0 O  U \
I  U I  U I  U I  0 O C  0 0 o  C D  0 0 I  0 O L  C o  0 I 0  0 O L  \
0 O D  0 0 D  0 0 P  U I  C 0  U I  o U  1 C  0 O D  0 O D  o U  1 C  \
0 O D  0 O D  o U  1 C  0 O D  1 C  U I  C U  U I  P 0  U I  o C  0 0 \
0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U \
I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  U P  U P  0 \
O L  0 0 D  0 0 O  C o  0 O C  0 O 0  P 0  U C  U I  1 0  U I  C 0  U \
I  1 L  U I  C U  U I  1 U  U I  1 O  U I  U C  U L  0 0 1  0 O 0  0 O\
 U  0 O 0  0 I O  0 0 D  U C  U I  1 U  U I  o C  0 0 0  0 0 0  1 L  1\
 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 I \
 0 O L  0 O D  0 0 P  U I  1 O  U I  U C  U L  0 0 1  0 O 0  0 O U  0 \
O 0  0 I O  0 0 D  U C  U I  1 0  U I  C 0  U I  1 C  U I  C U  U I  0\
 O D  0 O I  U I  U C  U L  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  \
U C  U I  0 O D  0 0 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  \
o C  0 0 0  0 0 0  0 0 0  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  U C  U\
 C  U I  1 0  0 O  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L\
  0 O  U I  U I  U I  U I  o U  1 C  0 O D  o U  1 C  1 C  o U  0 O D \
 0 O D  o U  1 C  1 C  0 O D  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 0 \
I  C o  0 0 1  0 0 D  0 O 0  U I  1 P  U I  0 0 o  0 0 1  0 O L  0 0 I\
  C o  0 0 1  0 0 D  0 O 0  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L\
  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 0  U I  1 P  U I  0 0 O\
  0 O 0  0 0 P  0 O L  0 0 0  C C  0 O  U I  U I  U I  U I  0 O D  0 O\
 I  U I  o U  1 C  0 O D  o U  1 C  1 C  o U  0 O D  0 O D  o U  1 C  \
1 C  0 O D  U I  P 0  P 0  U I  U C  U C  U I  D L  0 O  U I  U I  U I\
  U I  U I  o C  0 0 0  o C  0 0 0  o C  0 0 0  0 0 0  1 L  o C  0 0 0\
  o C  1 L  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I\
  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  0 O  U I  U I  U I  U \
I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I \
 o C  0 0 0  o C  0 0 0  o C  0 0 0  0 0 0  1 L  o C  0 0 0  o C  1 L \
 U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I \
 o U  1 C  0 O D  o U  1 C  1 C  o U  0 O D  0 O D  o U  1 C  1 C  0 O\
 D  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D O  1 \
C  U I  1 D  U I  D O  1 C  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0\
 0  0 0 0  o C  1 L  0 O  U I  U I  U I  o U  1 C  0 O D  0 O D  o U  \
1 C  0 O D  0 O D  o U  1 C  0 O D  1 C  U I  1 U  P 0  U I  1 C  0 O \
 U I  U I  0 0 0  o C  o C  o C  o C  1 L  0 0 0  0 0 0  1 L  o C  1 L\
  o C  o C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U  0 0 o  0 O D\
  U I  1 P  U I  P L  0 O D  C o  0 O L  0 0 0  0 O U  U I  1 O  U I  \
1 0  0 O  U I  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o \
C  0 0 0  o C  0 0 0  1 L  U I  P 0  U I  0 0 0  o C  o C  o C  o C  1\
 L  0 0 0  0 0 0  1 L  o C  1 L  o C  o C  U I  1 P  U I  0 0 D  0 O 0\
  0 O L  0 O 0  C C  0 0 P  U I  1 O  U I  U C  P o  0 O 1  0 0 0  0 0\
 0  0 0 D  0 O 0  U I  C o  U I  0 0 L  0 O D  0 O O  0 O 0  0 0 0  U \
I  0 0 D  0 0 0  0 0 o  0 0 1  C C  0 O 0  U C  U I  1 1  U I  o C  0 \
0 0  o C  0 0 0  o C  0 0 0  0 0 0  1 L  o C  0 0 0  o C  1 L  U I  1 \
0  0 O  U I  U I  0 O D  0 O I  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 \
0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1 L  U I  P I  P 0  U I  1 L  U\
 I  D L  0 O  U I  U I  U I  0 0 0  o C  0 0 0  o C  1 L  1 L  o C  U \
I  P 0  U I  o C  0 0 0  o C  0 0 0  o C  0 0 0  0 0 0  1 L  o C  0 0 \
0  o C  1 L  U I  C 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0 \
 o C  o C  0 0 0  o C  0 0 0  1 L  U I  C U  0 O  U I  U I  U I  0 0 I\
  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  0 0 I  0 O L  C o  0 I 0  0 0 \
O  C o  0 O C  0 O 0  0 I O  0 I O  U C  U I  1 1  U I  0 0 0  o C  0 \
0 0  o C  1 L  1 L  o C  0 O  U I  U I  U I  0 O D  0 O I  U I  U 1  U\
 L  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D o  U 1  U I  0 O D  0 0 O \
 U I  0 O C  0 0 o  C D  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D\
  0 0 P  U I  C 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C\
  o C  0 0 0  o C  0 0 0  1 L  U I  C U  U I  D L  0 O  U I  U I  U I \
 U I  0 O D  0 O I  U I  D U  D P  U I  1 D  U I  D U  D P  D L  U I  \
o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U I  0 0 0  1 \
L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 U  U I  o U  o U  0 O D  o U  0\
 O D  o U  o U  1 C  1 C  0 O D  U I  1 o  U I  o U  1 C  1 C  0 O D  \
U I  U o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  U I \
 U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  \
U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U  0 0 o  0 O D  U I  1 P  \
U I  o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 O 0  0 O C  U I  1 O  U I\
  0 0 0  o C  0 0 0  o C  1 L  1 L  o C  U I  1 1  U I  0 O D  C C  0 \
0 0  0 0 O  o U  0 O C  C o  0 O U  0 O 0  U I  P 0  U I  0 O D  1 C  \
0 O D  0 O D  0 O D  0 O D  o U  1 C  1 C  0 O D  0 O D  U I  1 1  U I\
  0 0 P  0 O 1  0 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  o U  0 O \
C  C o  0 O U  0 O 0  U I  P 0  U I  0 O D  1 C  0 O D  0 O D  0 O D  \
0 O D  o U  1 C  1 C  0 O D  0 O D  U I  1 0  0 O  U I  U I  U I  U I \
 o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  \
U I  0 0 D  0 O 0  0 0 P  o U  0 0 O  0 O I  0 0 0  U I  1 O  U I  0 0\
 P  0 I 0  0 0 I  0 O 0  U I  P 0  U I  U C  L P  0 O D  0 O O  0 O 0 \
 0 0 0  U C  U I  1 1  U I  0 O D  0 0 O  0 O I  0 0 0  o P  C o  C L \
 0 O 0  0 O L  0 0 D  U I  P 0  U I  0 I U  U I  U C  L 1  0 O D  0 0 \
P  0 O L  0 O 0  U C  U I  D L  U I  0 0 0  o C  0 0 0  o C  1 L  1 L \
 o C  U I  0 I D  U I  1 0  0 O  U I  U I  U I  U I  o U  1 C  0 O D  \
1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0 \
 0 0 P  L O  0 0 1  0 0 0  0 0 I  0 O 0  0 0 1  0 0 P  0 I 0  U I  1 O\
  U I  U 1  o U  0 0 D  L O  0 O L  C o  0 I 0  C o  C L  0 O L  0 O 0\
  U 1  U I  1 1  U I  U 1  0 0 P  0 0 1  0 0 o  0 O 0  U 1  U I  1 0  \
0 O  U I  U I  U I  U I  0 0 0  1 L  1 L  o C  o C  0 0 0  1 L  0 0 0 \
 1 L  o C  U I  P 0  U I  o C  0 0 0  1 L  o C  1 L  o C  o C  1 L  o \
C  0 0 0  o C  1 L  U I  1 O  U I  0 O C  0 0 o  C D  0 0 I  0 O L  C \
o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U I  C 0  U I  0 0 0  o C  1 L  \
1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1 L  U I  C U  \
U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  \
U I  U C  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D o  U C  U I  1 \
1  U I  U C  U C  U I  1 0  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L \
 C o  C C  0 O 0  U I  1 O  U I  U C  D C  U C  U I  1 1  U I  U C  U \
C  U I  1 0  U I  1 0  0 O  U I  U I  U I  U I  o U  1 C  0 O D  1 C  \
0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 \
P  L O  C o  0 0 P  0 O 1  U I  1 O  U I  0 0 0  1 L  1 L  o C  o C  0\
 0 0  1 L  0 0 0  1 L  o C  U I  1 0  0 O  U I  U I  U I  U I  0 I O  \
C L  0 O C  C C  U I  1 P  U I  L O  0 O L  C o  0 I 0  0 O 0  0 0 1  \
U I  1 O  U I  1 0  U I  1 P  U I  0 0 I  0 O L  C o  0 I 0  U I  1 O \
 U I  0 0 0  1 L  1 L  o C  o C  0 0 0  1 L  0 0 0  1 L  o C  U I  1 1\
  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I \
 1 0  0 O  U I  U I  U I  0 O 0  0 O L  0 O D  0 O I  U I  U 1  U P  0\
 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U 1  U I  0 O D  0 0 O\
  U I  0 O C  0 0 o  C D  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 \
D  0 0 P  U I  C 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o \
C  o C  0 0 0  o C  0 0 0  1 L  U I  C U  U I  D L  0 O  U I  U I  U I\
  U I  0 O D  0 O I  U I  D 0  1 L  U I  1 D  U I  D 0  1 L  D L  U I \
 o U  o U  o U  o U  U I  1 I  U I  o U  0 O D  o U  o U  U I  1 o  U \
I  o U  o U  o U  o U  U I  1 P  U I  o U  0 O D  1 C  o U  U I  1 P  \
U I  o U  0 O D  o U  o U  0 O  U I  U I  U I  U I  0 O D  1 C  o U  o\
 U  1 C  1 C  o U  1 C  1 C  o U  U I  P 0  U I  0 O C  0 0 o  C D  0 \
0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U I  C 0  U I  0 0\
 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1\
 L  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1\
 O  U I  U C  U L  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  P 0  U C \
 U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D o  1 C  U I  \
1 D  U I  D o  1 C  D L  U I  o U  0 O D  1 C  o U  U I  1 P  U I  o C\
  1 L  0 0 0  o C  U I  1 U  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 \
0 0  0 O  U I  U I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D \
 o U  U I  1 1  U I  o C  o C  1 L  1 L  U I  P 0  U I  0 0 0  o C  o \
C  0 0 0  0 0 0  U I  1 O  U I  0 O D  1 C  o U  o U  1 C  1 C  o U  1\
 C  1 C  o U  U I  C 0  U I  1 C  U I  C U  U I  1 1  U I  0 O D  1 C \
 o U  o U  1 C  1 C  o U  1 C  1 C  o U  U I  C 0  U I  1 L  U I  C U \
 U I  1 0  0 O  U I  U I  U I  U I  o C  1 L  1 L  0 0 0  o C  U I  P \
0  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 P  U I  0\
 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  D C  U\
 C  U I  1 1  U I  U C  U C  U I  1 0  0 O  U I  U I  U I  U I  o U  1\
 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  P 0  U I  0 \
I O  C L  0 O C  C C  0 O U  0 0 o  0 O D  U I  1 P  U I  o P  0 O D  \
0 0 D  0 0 P  o U  0 0 P  0 O 0  0 O C  U I  1 O  U I  0 0 0  o C  0 0\
 0  o C  1 L  1 L  o C  U I  1 1  U I  0 O D  C C  0 0 0  0 0 O  o U  \
0 O C  C o  0 O U  0 O 0  U I  P 0  U I  0 O D  1 C  0 O D  0 O D  0 O\
 D  0 O D  o U  1 C  1 C  0 O D  0 O D  U I  1 1  U I  0 0 P  0 O 1  0\
 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  o U  0 O C  C o  0 O U  0 \
O 0  U I  P 0  U I  0 O D  1 C  0 O D  0 O D  0 O D  0 O D  o U  1 C  \
1 C  0 O D  0 O D  U I  1 0  0 O  U I  U I  U I  U I  o U  1 C  0 O D \
 1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0\
  0 0 P  o U  0 0 O  0 O I  0 0 0  U I  1 O  U I  0 0 P  0 I 0  0 0 I \
 0 O 0  U I  P 0  U I  U C  L P  0 O D  0 O O  0 O 0  0 0 0  U C  U I \
 1 1  U I  0 O D  0 0 O  0 O I  0 0 0  o P  C o  C L  0 O 0  0 O L  0 \
0 D  U I  P 0  U I  0 I U  U I  U C  L 1  0 O D  0 0 P  0 O L  0 O 0  \
U C  U I  D L  U I  0 0 0  o C  0 0 0  o C  1 L  1 L  o C  U I  0 I D \
 U I  1 0  0 O  U I  U I  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  \
o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L O  0 0 \
1  0 0 0  0 0 I  0 O 0  0 0 1  0 0 P  0 I 0  U I  1 O  U I  U 1  o U  \
0 0 D  L O  0 O L  C o  0 I 0  C o  C L  0 O L  0 O 0  U 1  U I  1 1  \
U I  U 1  0 0 P  0 0 1  0 0 o  0 O 0  U 1  U I  1 0  0 O  U I  U I  U \
I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I\
  1 P  U I  0 0 D  0 O 0  0 0 P  L O  C o  0 0 P  0 O 1  U I  1 O  U I\
  o C  1 L  1 L  0 0 0  o C  U I  1 0  0 O  U I  U I  U I  U I  0 I O \
 C L  0 O C  C C  U I  1 P  U I  L O  0 O L  C o  0 I 0  0 O 0  0 0 1 \
 U I  1 O  U I  1 0  U I  1 P  U I  0 0 I  0 O L  C o  0 I 0  U I  1 O\
  U I  o C  1 L  1 L  0 0 0  o C  U I  1 1  U I  o U  1 C  0 O D  1 C \
 0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 0  0 O  U I  U I  U I  U \
I  0 O D  0 O I  U I  D P  U I  1 D  U I  D P  D L  U I  o C  1 L  0 0\
 0  o C  U I  1 I  U I  o U  0 O D  o U  o U  U I  1 o  U I  0 O D  0 \
O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 D  U I  o U  1 C  o U  0\
 O D  1 C  1 C  1 C  U I  1 D  U I  o C  o C  0 0 0  0 0 0  o C  o C  \
0 0 0  0 O  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  \
U I  U I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I \
 P 0  U I  0 O C  0 0 o  C D  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  \
0 0 D  0 0 P  U I  C 0  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0\
  o C  o C  0 0 0  o C  0 0 0  1 L  U I  C U  0 O  U I  U I  U I  U I \
 o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  P 0  U I  o U  0 O\
 D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 P  U I  0 0 D  0 0 I  0 O\
 L  0 O D  0 0 P  U I  1 O  U I  U C  U L  0 0 1  0 O 0  0 O U  0 O 0 \
 0 I O  0 0 D  P 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  \
U I  U I  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1\
 C  1 C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U  0 0 o  0 O D  U\
 I  1 P  U I  o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 O 0  0 O C  U I \
 1 O  U I  0 0 0  o C  0 0 0  o C  1 L  1 L  o C  U I  1 1  U I  0 O D\
  C C  0 0 0  0 0 O  o U  0 O C  C o  0 O U  0 O 0  U I  P 0  U I  0 O\
 D  1 C  0 O D  0 O D  0 O D  0 O D  o U  1 C  1 C  0 O D  0 O D  U I \
 1 1  U I  0 0 P  0 O 1  0 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  \
o U  0 O C  C o  0 O U  0 O 0  U I  P 0  U I  0 O D  1 C  0 O D  0 O D\
  0 O D  0 O D  o U  1 C  1 C  0 O D  0 O D  U I  1 0  0 O  U I  U I  \
U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U\
 I  1 P  U I  0 0 D  0 O 0  0 0 P  o U  0 0 O  0 O I  0 0 0  U I  1 O \
 U I  0 0 P  0 I 0  0 0 I  0 O 0  U I  P 0  U I  U C  L P  0 O D  0 O \
O  0 O 0  0 0 0  U C  U I  1 1  U I  0 O D  0 0 O  0 O I  0 0 0  o P  \
C o  C L  0 O 0  0 O L  0 0 D  U I  P 0  U I  0 I U  U I  U C  L 1  0 \
O D  0 0 P  0 O L  0 O 0  U C  U I  D L  U I  0 0 0  o C  0 0 0  o C  \
1 L  1 L  o C  U I  0 I D  U I  1 0  0 O  U I  U I  U I  U I  o U  1 C\
  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 \
D  0 O 0  0 0 P  L O  0 0 1  0 0 0  0 0 I  0 O 0  0 0 1  0 0 P  0 I 0 \
 U I  1 O  U I  U 1  o U  0 0 D  L O  0 O L  C o  0 I 0  C o  C L  0 O\
 L  0 O 0  U 1  U I  1 1  U I  U 1  0 0 P  0 0 1  0 0 o  0 O 0  U 1  U\
 I  1 0  0 O  U I  U I  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o \
U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L O  C o  0\
 0 P  0 O 1  U I  1 O  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o\
 U  U I  1 0  0 O  U I  U I  U I  U I  0 I O  C L  0 O C  C C  U I  1 \
P  U I  L O  0 O L  C o  0 I 0  0 O 0  0 0 1  U I  1 O  U I  1 0  U I \
 1 P  U I  0 0 I  0 O L  C o  0 I 0  U I  1 O  U I  o U  0 O D  o U  0\
 O D  1 C  1 C  0 O D  o U  U I  1 1  U I  o U  1 C  0 O D  1 C  0 O D\
  o U  o U  1 C  o U  1 C  1 C  U I  1 0  0 O  U I  0 O 0  0 O L  0 O \
D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  0 0 U  0 0 o  0 O 0  0 0 o  0\
 O 0  L P  0 O D  0 O O  0 O 0  0 0 0  U I  D L  0 O  U I  U I  0 O D \
 0 O I  U I  1 C  1 L  1 L  U I  1 D  U I  1 C  1 L  1 L  D L  U I  o \
U  o U  o U  o U  U I  1 P  U I  0 0 0  o C  1 L  0 0 0  U I  1 P  U I\
  0 0 0  o C  1 L  0 0 0  0 O  U I  U I  0 0 0  0 0 0  1 L  1 L  1 L  \
0 O D  0 O D  U I  1 P  U I  C C  0 O L  0 O 0  C o  0 0 1  U I  1 O  \
U I  1 0  0 O  U I  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L \
 o C  U I  P 0  U I  1 L  0 O  U I  U I  0 O I  0 0 0  0 0 1  U I  o C\
  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0\
 O D  0 0 O  U I  0 O C  0 0 o  C D  0 0 I  0 O L  C o  0 I 0  0 O L  \
0 O D  0 0 D  0 0 P  U I  D L  0 O  U I  U I  U I  0 O D  o U  o U  o \
U  0 0 0  1 L  0 0 0  1 L  o C  U I  1 U  P 0  U I  1 C  0 O  U I  U I\
  U I  0 0 0  o C  o C  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  P 0  \
U I  0 I O  C L  0 O C  C C  0 O U  0 0 o  0 O D  U I  1 P  U I  o P  \
0 O D  0 0 D  0 0 P  o U  0 0 P  0 O 0  0 O C  U I  1 O  U I  U C  U o\
  0 0 D  1 0  U I  U o  0 0 D  U C  U I  U o  U I  1 O  U I  0 0 D  0 \
0 P  0 0 1  U I  1 O  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 \
L  o C  U I  1 0  U I  1 1  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  U\
 I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D 0  D P  U I  1 D  U \
I  D 0  D P  D L  U I  0 O D  1 C  0 O  U I  U I  U I  0 0 P  0 0 1  0\
 I 0  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  U 1  U P  \
0 O O  0 0 0  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U 1  U I  0 O D  0 0 \
O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 \
0 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 O D  1 C  o U  o U  1 C\
  1 C  o U  1 C  1 C  o U  U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L \
 0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 0 D  0 0 I  0 \
O L  0 O D  0 0 P  U I  1 O  U I  U C  U L  0 0 1  0 O 0  0 O U  0 O 0\
  0 I O  0 0 D  P 0  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O \
D  0 O I  U I  1 C  D P  U I  1 D  U I  1 C  D P  D L  U I  0 O D  0 O\
 D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 o  U I  0 0 0  1 L  1 L  \
o C  1 L  0 0 0  0 0 0  U I  1 U  U I  0 0 0  0 0 0  0 0 0  1 L  o C  \
0 0 0  1 L  U I  U o  U I  o U  o U  o U  o U  U I  1 D  U I  0 0 0  0\
 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  U I  U I  U I  U I  o U  \
0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1  U I  o C  o C  1 L \
 1 L  U I  P 0  U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  1 O  U I  0 O\
 D  1 C  o U  o U  1 C  1 C  o U  1 C  1 C  o U  U I  C 0  U I  1 C  U\
 I  C U  U I  1 1  U I  0 O D  1 C  o U  o U  1 C  1 C  o U  1 C  1 C \
 o U  U I  C 0  U I  1 L  U I  C U  U I  1 0  0 O  U I  U I  U I  U I \
 0 O 0  0 O L  0 O D  0 O I  U I  U 1  U L  0 O C  0 0 0  0 O O  0 O 0\
  P 0  1 C  D o  U 1  U I  0 O D  0 0 O  U I  o C  0 0 0  0 0 0  1 L  \
1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  D L  0 O  U I  U I  U \
I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  P 0  U\
 I  o C  0 0 0  1 L  o C  1 L  o C  o C  1 L  o C  0 0 0  o C  1 L  U \
I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 \
0  0 0 0  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  \
U I  1 O  U I  U C  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D o  U \
C  U I  1 1  U I  U C  U C  U I  1 0  U I  1 P  U I  0 0 1  0 O 0  0 0\
 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  D C  U C  U I  1 1  U \
I  U C  U C  U I  1 0  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I\
  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  D L  0 O  U \
I  U I  U I  U I  U I  0 0 0  0 0 0  1 L  1 L  1 L  0 O D  0 O D  U I \
 1 P  U I  C o  0 O O  0 O O  U I  1 O  U I  o U  0 O D  o U  0 O D  1\
 C  1 C  0 O D  o U  U I  1 1  U I  0 0 0  o C  o C  0 0 0  1 L  0 0 0\
  0 0 0  o C  1 L  U I  1 0  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 \
0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  0 0 1  C o  0 O D \
 0 0 D  0 O 0  0 O  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 \
0 P  U I  P C  0 I O  C C  0 O 0  0 0 I  0 0 P  0 O D  0 0 0  0 0 O  U\
 I  D L  0 O  U I  U I  U I  U I  0 0 0  0 0 0  1 L  1 L  1 L  0 O D  \
0 O D  U I  1 P  U I  C o  0 O O  0 O O  U I  1 O  U I  o C  0 0 0  0 \
0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 1  U I  0 \
0 0  o C  o C  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 0  0 O  U I \
 U I  U I  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  U I  U I  U I  0 O\
 D  0 O I  U I  1 C  D P  U I  1 D  U I  1 C  D P  D L  U I  0 O D  o \
U  o U  1 C  1 C  1 C  0 O D  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0 \
 1 L  1 L  1 L  1 L  U I  U o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0\
  0 0 0  o C  1 L  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  \
0 0 0  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 \
L  U I  1 P  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  U\
 I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0\
 0 o  0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I\
  1 O  U I  U C  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P \
 1 P  0 0 I  0 O L  C o  0 I 0  0 0 0  0 O I  0 O I  0 0 D  0 O 0  0 0\
 P  1 O  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 1  1 L  1 0  U C  U I  1\
 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 O\
 D  0 O I  U I  1 C  D 1  U I  1 D  U I  1 C  D 1  D L  U I  o U  0 O \
D  o U  o U  0 O  U I  U I  o C  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  1\
 L  1 L  U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U  0 0 o  0 O D  U\
 I  1 P  U I  o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 O 0  0 O C  U I \
 1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  0 O  U I  U I  0 0 0  0\
 0 0  1 L  1 L  1 L  0 O D  0 O D  U I  1 P  U I  C o  0 O O  0 O O  U\
 I  1 O  U I  0 O C  0 0 o  C D  0 0 I  0 O L  C o  0 I 0  0 O L  0 O \
D  0 0 D  0 0 P  U I  1 1  U I  o C  0 0 0  o C  1 L  1 L  0 0 0  0 0 \
0  1 L  1 L  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  D D  D I  U I\
  1 D  U I  D D  D I  D L  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I \
 U I  0 O D  0 O I  U I  D o  D P  U I  1 D  U I  D o  D P  D L  U I  \
o U  o U  o U  o U  U I  1 o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0\
 0 0  U I  U o  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  \
o U  0 O D  1 C  0 O D  U I  1 I  U I  o U  0 O D  1 C  o U  U I  1 D \
 U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  0 O O  0 O 0  0 O I  U\
 I  o C  0 0 0  1 L  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  0 0 0  U\
 I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 0 o  0 0 1  0\
 O L  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  D 1  U I  1 D  \
U I  D 1  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 \
D  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  0\
 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 U  U I  0 0 0  0 0 0  o\
 C  0 0 0  o C  1 L  0 0 0  U I  U o  U I  0 0 0  1 L  1 L  o C  1 L  \
0 0 0  0 0 0  0 O  U I  0 O D  0 O I  U I  o C  1 L  o U  1 C  1 C  0 \
O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O \
0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I\
  U C  0 0 D  C o  0 0 L  0 O 0  C D  0 O L  0 0 0  C C  C o  0 0 P  0\
 O D  0 0 0  0 0 O  U C  U I  1 0  U I  P 0  P 0  U I  U 1  U 1  U I  \
D L  0 O  U I  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I \
O  0 O 0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0\
 O D  0 0 O  U I  1 O  U I  U 1  L L  P P  o o  P o  1 P  o L  0 0 0  \
0 0 P  0 O D  0 O I  0 O D  C C  C o  0 0 P  0 O D  0 0 0  0 0 O  1 O \
 U C  L 1  0 O 0  C o  0 O C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  \
U C  1 1  U C  P o  0 O 1  0 0 0  0 0 0  0 0 D  0 O 0  U I  C o  U I  \
0 O L  0 0 0  C C  C o  0 0 P  0 O D  0 0 0  0 0 O  U I  0 0 P  0 0 0 \
 U I  0 0 D  C o  0 0 L  0 O 0  U I  0 O I  0 O D  0 O L  0 O 0  0 0 D\
  1 P  U C  1 1  1 C  D U  1 L  1 L  1 L  1 1  U 1  U I  1 U  U I  0 0\
 0  o C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U I  1 U  U I\
  U 1  1 0  U 1  U I  1 0  0 O  U I  U I  o C  1 L  o U  1 C  1 C  0 O\
 D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 0 0  0 0 I\
  0 O 0  0 0 O  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  0 0 D  \
U I  1 O  U I  1 0  0 O  U I  0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O \
D  o U  U I  P 0  U I  0 I U  U I  U C  0 0 o  0 0 1  0 O L  U C  U I \
 D L  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  U C  0 O O  0 0 0  0 0 \
C  0 0 O  0 O L  0 0 0  C o  0 O O  C D  0 0 I  C o  0 0 P  0 O 1  U C\
  U I  D L  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C \
 0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 \
P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 0 D  C o  0 0 L  \
0 O 0  C D  0 O L  0 0 0  C C  C o  0 0 P  0 O D  0 0 0  0 0 O  U C  U\
 I  1 0  U I  0 I D  0 O  U I  0 O O  0 0 0  0 0 C  0 0 O  0 O L  0 0 \
0  C o  0 O O  0 O 0  0 0 1  U I  1 P  U I  0 O O  0 0 0  0 0 C  0 0 O\
  0 O L  0 0 0  C o  0 O O  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U\
 I  1 1  U I  0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D  o U  U I  1 0\
  0 O  U I  0 0 0  o C  o C  o C  o C  1 L  0 0 0  0 0 0  1 L  o C  1 \
L  o C  o C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U  0 0 o  0 O \
D  U I  1 P  U I  P L  0 O D  C o  0 O L  0 0 0  0 O U  U I  1 O  U I \
 1 0  0 O  U I  o U  0 O D  o U  o U  0 O D  1 C  o U  1 C  o U  1 C  \
1 C  o U  0 O D  U I  P 0  U I  0 0 0  o C  o C  o C  o C  1 L  0 0 0 \
 0 0 0  1 L  o C  1 L  o C  o C  U I  1 P  U I  0 I 0  0 O 0  0 0 D  0\
 0 O  0 0 0  U I  1 O  U I  U C  L 1  0 O 0  C o  0 O C  L U  0 0 I  0\
 0 0  0 0 1  0 0 P  0 0 D  U C  U I  1 1  U I  U C  P L  0 0 0  U I  0\
 I 0  0 0 0  0 0 o  U I  0 0 C  C o  0 0 O  0 0 P  U I  0 0 P  0 0 0  \
U I  C o  0 O O  0 O O  U I  0 0 P  0 O 1  0 O D  0 0 D  U I  0 O I  0\
 O D  0 O L  0 O 0  U I  C o  0 0 D  U I  C o  U I  0 0 D  0 0 0  0 0 \
o  0 0 1  C C  0 O 0  P U  U C  U I  1 0  0 O  U I  0 O D  0 O I  U I \
 o U  0 O D  o U  o U  0 O D  1 C  o U  1 C  o U  1 C  1 C  o U  0 O D\
  U I  D L  0 O  U I  U I  o C  1 L  o C  o C  1 L  o C  U I  1 O  U I\
  0 0 0  0 0 D  U I  1 P  U I  0 0 I  C o  0 0 P  0 O 1  U I  1 P  U I\
  0 O P  0 0 0  0 O D  0 0 O  U I  1 O  U I  o C  1 L  o U  1 C  1 C  \
0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 \
O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U\
 I  U C  0 0 D  C o  0 0 L  0 O 0  C D  0 O L  0 0 0  C C  C o  0 0 P \
 0 O D  0 0 0  0 0 O  U C  U I  1 0  U I  1 1  U I  0 0 O  C o  0 O C \
 0 O 0  U I  1 0  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  1 C  1 L\
  1 L  U I  1 D  U I  1 C  1 L  1 L  D L  U I  o U  1 C  o U  0 O D  1\
 C  1 C  1 C  U I  U o  U I  0 O D  1 C  U I  1 D  U I  0 0 0  1 L  0 \
0 0  o C  1 L  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  U o  U\
 I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I  o C  0 0 0  0 0 0  0 0\
 0  1 L  1 L  1 L  1 L  0 O  0 O O  0 O 0  0 O I  U I  o C  o C  o C  \
1 L  1 L  1 L  o C  0 0 0  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 \
1  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  U I  D L  0 O  U I  0 O D \
 0 O I  U I  D P  U I  1 D  U I  D P  D L  U I  o C  0 0 0  0 0 0  0 0\
 0  1 L  1 L  1 L  1 L  U I  1 D  U I  o U  0 O D  o U  o U  U I  1 U \
 U I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  o U  1 C  1 C  0 O D  U I\
  1 I  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O \
D  1 C  0 O D  U I  1 D  U I  0 0 0  o C  1 L  0 0 0  0 O  U I  0 O D \
 1 C  o U  0 O D  U I  P 0  U I  C 0  U I  U C  0 0 I  0 O L  0 0 o  0\
 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  \
0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 O U  0 O 0  0 0 \
O  0 O 0  0 0 D  0 O D  0 0 D  1 o  P U  C o  C C  0 0 P  0 O D  0 0 0\
  0 0 O  P 0  0 0 D  0 O 1  0 0 0  0 0 C  0 0 D  C D  0 0 D  0 O 0  C \
o  0 0 1  C C  0 O 1  U C  U I  1 1  U I  U C  0 0 I  0 O L  0 0 o  0 \
O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0\
 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 O U  0 O 0  0 0 O\
  0 O 0  0 0 D  0 O D  0 0 D  1 o  P U  C o  C C  0 0 P  0 O D  0 0 0 \
 0 0 O  P 0  0 O C  0 0 0  0 0 L  0 O D  0 O 0  0 0 D  C D  0 0 D  0 O\
 0  C o  0 0 1  C C  0 O 1  U C  U I  1 1  U I  U C  0 0 I  0 O L  0 0\
 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 \
O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 0 D  C o  0\
 O L  0 0 P  0 0 D  1 o  P U  0 O C  0 0 0  0 O O  0 O 0  P 0  0 0 D  \
0 O 0  C o  0 0 1  C C  0 O 1  U L  C o  0 O C  0 0 I  D C  0 0 D  0 O\
 0  C C  0 0 P  0 O D  0 0 0  0 0 O  P 0  o o  0 0 0  0 0 L  0 O D  0 \
O 0  0 0 D  U C  U I  1 1  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D\
  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P \
 0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 0 D  C o  0 O L  0 0 P  0 0\
 D  1 o  P U  0 O C  0 0 0  0 O O  0 O 0  P 0  0 0 D  0 O 0  C o  0 0 \
1  C C  0 O 1  U L  C o  0 O C  0 0 I  D C  0 0 D  0 O 0  C C  0 0 P  \
0 O D  0 0 0  0 0 O  P 0  L 1  L P  U C  U I  1 1  U I  U C  0 0 I  0 \
O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0\
 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 O C\
  0 0 o  C C  0 O 1  0 O C  0 0 0  0 0 L  0 O D  0 O 0  0 0 D  1 P  0 \
O 1  0 O O  1 o  P U  C o  C C  0 0 P  0 O D  0 0 0  0 0 O  P 0  0 O C\
  0 0 0  0 0 L  0 O D  0 O 0  0 0 D  C D  0 0 D  0 O 0  C o  0 0 1  C \
C  0 O 1  U C  U I  1 1  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  \
0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0\
 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 0 L  0 O D  0 0 0  0 0 0  0 I\
 I  1 P  C C  0 0 0  1 o  P U  C o  C C  0 0 P  0 O D  0 0 0  0 0 O  P\
 0  0 0 1  0 0 0  0 0 0  0 0 P  C D  0 0 D  0 O 0  C o  0 0 1  C C  0 \
O 1  U C  U I  1 1  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O\
  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L \
 0 O D  0 O O  0 O 0  0 0 0  1 P  0 0 0  0 0 1  0 0 0  0 0 1  0 0 0  0\
 0 P  0 0 L  1 o  P U  C o  C C  0 0 P  0 O D  0 0 0  0 0 O  P 0  0 0 \
D  0 O 1  0 0 0  0 0 C  0 0 D  C D  0 0 D  0 O 0  C o  0 0 1  C C  0 O\
 1  U C  U I  1 1  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O \
 D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  \
0 O D  0 O O  0 O 0  0 0 0  1 P  0 I 0  0 O D  0 O I  0 I 0  0 O C  0 \
0 0  0 0 L  0 O D  0 O 0  0 0 D  1 P  0 O 1  0 O O  1 o  P U  C o  C C\
  0 0 P  0 O D  0 0 0  0 0 O  P 0  0 O C  0 0 0  0 0 L  0 O D  0 O 0  \
0 0 D  C D  0 0 D  0 O 0  C o  0 0 1  C C  0 O 1  U C  U I  1 1  U I  \
U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0\
 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0\
 0  1 P  C C  C o  0 0 1  0 0 P  0 0 0  0 0 0  0 0 O  0 O 1  0 O O  0 \
0 P  0 0 C  0 0 0  1 o  P U  0 O O  0 O 0  0 0 D  C C  0 0 1  0 O D  0\
 0 I  0 0 P  0 O D  0 0 0  0 0 O  U L  C o  0 O C  0 0 I  D C  0 O I  \
C o  0 0 O  C o  0 0 1  0 0 P  U L  C o  0 O C  0 0 I  D C  0 O D  C C\
  0 0 0  0 0 O  0 O D  0 O C  C o  0 O U  0 O 0  U L  C o  0 O C  0 0 \
I  D C  0 O C  0 0 0  0 O O  0 O 0  P 0  D 0  U L  C o  0 O C  0 0 I  \
D C  0 0 O  C o  0 O C  0 O 0  P 0  L U  0 O 0  C o  0 0 1  C C  0 O 1\
  U L  C o  0 O C  0 0 I  D C  0 0 o  0 0 1  0 O L  P 0  0 0 o  0 0 1 \
 0 O L  U C  U I  1 1  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 \
0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0\
 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o\
  C L  0 O 0  1 o  0 O o  0 0 0  0 O O  0 O D  0 0 0  0 0 O  1 o  0 0 \
D  0 O 0  C o  0 0 1  C C  0 O 1  1 o  0 O L  0 O D  0 0 D  0 0 P  1 o\
  U C  U I  1 1  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D\
 L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 \
O D  0 O O  0 O 0  0 0 0  1 P  0 O O  C o  0 O D  0 O L  0 I 0  0 O C \
 0 0 0  0 0 P  0 O D  0 0 0  0 0 O  C D  C C  0 0 0  0 O C  1 o  P U  \
0 O C  0 0 0  0 O O  0 O 0  P 0  0 0 D  0 O 0  C o  0 0 1  C C  0 O 1 \
 U L  C o  0 O C  0 0 I  D C  0 0 o  0 0 1  0 O L  U C  U I  1 1  U I \
 U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  \
0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 \
0 0  1 P  0 0 L  0 O D  0 O C  0 O 0  0 0 0  1 o  0 O o  0 0 0  0 O O \
 0 O D  0 0 0  0 0 O  1 o  0 0 D  0 O 0  C o  0 0 1  C C  0 O 1  1 o  \
0 O L  0 O D  0 0 D  0 0 P  1 o  U C  U I  C U  0 O  U I  0 O D  0 O I\
  U I  D 0  1 C  U I  1 D  U I  D 0  1 C  D L  U I  0 O D  0 O D  o U \
 1 C  0 O D  o U  0 O D  o U  U I  1 D  U I  0 0 0  0 0 0  o C  0 0 0 \
 o C  1 L  0 0 0  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0\
 0 0  U I  1 D  U I  o U  o U  o U  o U  U I  1 U  U I  o U  0 O D  o \
U  o U  U I  1 o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1\
 L  0 O  U I  0 O D  0 O I  U I  D o  1 L  U I  1 D  U I  D o  1 L  D \
L  U I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 \
0  o C  1 L  0 0 0  0 O  U I  0 O D  0 O I  U I  D o  U I  1 D  U I  D\
 o  D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 P  U I  o C  o C  0 0 0  \
0 0 0  o C  o C  0 0 0  U I  1 U  U I  o U  1 C  1 C  0 O D  U I  1 D \
 U I  o U  0 O D  o U  o U  0 O  U I  0 O D  0 O I  U I  D 0  1 L  U I\
  1 D  U I  D 0  1 L  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 \
O D  o U  U I  1 o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 P\
  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U I  0 O D\
  0 O I  U I  1 C  D D  U I  1 D  U I  1 C  D D  D L  U I  o U  0 O D \
 o U  o U  U I  1 U  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I\
  1 I  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  0 O D  \
0 O I  U I  D U  U I  1 D  U I  D U  D L  U I  0 O D  1 C  U I  U o  U\
 I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 P  U I  0 0 0  0 0\
 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I  0 O D  0 O I  U I  D 1  D D\
  U I  1 D  U I  D 1  D D  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 \
0  0 0 0  o C  1 L  U I  1 U  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1\
 C  o U  1 C  o U  0 O D  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  D D\
  D O  U I  1 D  U I  D D  D O  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o \
C  0 0 0  1 L  U I  U o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0 \
 0 O  U I  0 O D  0 O I  U I  D o  D 0  U I  1 D  U I  D o  D 0  D L  \
U I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  \
o C  1 L  o C  1 L  1 L  U I  1 P  U I  0 0 0  1 L  1 L  o C  1 L  0 0\
 0  0 0 0  U I  1 P  U I  o U  1 C  1 C  0 O D  U I  U o  U I  0 O D  \
o U  o U  1 C  1 C  1 C  0 O D  U I  U o  U I  o C  0 0 0  0 0 0  0 0 \
0  1 L  1 L  1 L  1 L  0 O  U I  0 O D  0 O I  U I  D D  D I  U I  1 D\
  U I  D D  D I  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  \
U I  1 o  U I  o U  1 C  1 C  0 O D  U I  U o  U I  o C  o C  0 0 0  0\
 0 0  o C  o C  0 0 0  0 O  U I  0 O D  0 O I  U I  D U  D O  U I  1 D\
  U I  D U  D O  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  \
U I  U o  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I \
 0 O D  0 O I  U I  D O  D U  U I  1 D  U I  D O  D U  D L  U I  0 0 0\
  1 L  0 0 0  o C  1 L  U I  1 o  U I  0 0 0  1 L  0 0 0  o C  1 L  U \
I  U o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 D  U I  0\
 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 I  U I  o U\
  o U  o U  o U  0 O  U I  o C  0 0 0  o C  0 0 0  o C  0 0 0  0 0 0  \
1 L  o C  0 0 0  o C  1 L  U I  P 0  U I  C 0  U I  U C  o 0  0 O 0  0\
 0 O  0 0 D  0 O D  0 0 D  U I  L 1  L P  U C  U I  1 1  U I  U C  o 0\
  0 O 0  0 0 O  0 O 0  0 0 D  0 O D  0 0 D  U I  o o  0 0 0  0 0 L  0 \
O D  0 O 0  U C  U I  1 1  U I  U C  L U  C o  0 O L  0 0 P  U I  0 O \
C  0 0 0  0 0 L  0 O D  0 O 0  U C  U I  1 1  U I  U C  0 0 D  C o  0 \
O L  0 0 P  U I  L 1  L P  U C  U I  1 1  U I  U C  o o  0 0 o  C C  0\
 O 1  0 O C  0 0 0  0 0 L  0 O D  0 O 0  0 0 D  U C  U I  1 1  U I  U \
C  0 0 L  0 O D  0 0 0  0 0 0  0 I I  U C  U I  1 1  U I  U C  o C  L \
I  0 0 0  0 0 1  0 0 0  L 1  L P  U C  U I  1 1  U I  U C  L C  0 O D \
 0 O I  0 I 0  0 O C  0 0 0  0 0 L  0 O D  0 O 0  0 0 D  U C  U I  1 1\
  U I  U C  C C  C o  0 0 1  0 0 P  0 0 0  0 0 0  0 0 O  o I  P L  U C\
  U I  1 1  U I  U C  L C  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0  U C\
  U I  1 1  U I  U C  P L  C o  0 O D  0 O L  0 I 0  o o  0 0 0  0 0 P\
  0 O D  0 0 0  0 0 O  U C  U I  1 1  U I  U C  L P  0 O D  0 O C  0 O\
 0  0 0 0  U C  U I  C U  0 O  U I  0 O D  0 O I  U I  D O  D 0  U I  \
1 D  U I  D O  D 0  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C \
 1 L  1 L  0 O  U I  0 0 0  o C  o C  o C  o C  1 L  0 0 0  0 0 0  1 L\
  o C  1 L  o C  o C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U  0 \
0 o  0 O D  U I  1 P  U I  P L  0 O D  C o  0 O L  0 0 0  0 O U  U I  \
1 O  U I  1 0  0 O  U I  0 0 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o \
C  o C  0 0 0  o C  0 0 0  1 L  U I  P 0  U I  0 0 0  o C  o C  o C  o\
 C  1 L  0 0 0  0 0 0  1 L  o C  1 L  o C  o C  U I  1 P  U I  0 0 D  \
0 O 0  0 O L  0 O 0  C C  0 0 P  U I  1 O  U I  U C  P o  0 O 1  0 0 0\
  0 0 0  0 0 D  0 O 0  U I  C o  U I  0 0 L  0 O D  0 O O  0 O 0  0 0 \
0  U I  0 0 D  0 0 0  0 0 o  0 0 1  C C  0 O 0  U C  U I  1 1  U I  o \
C  0 0 0  o C  0 0 0  o C  0 0 0  0 0 0  1 L  o C  0 0 0  o C  1 L  U \
I  1 0  0 O  U I  0 O D  0 O I  U I  1 C  1 L  1 L  U I  1 D  U I  1 C\
  1 L  1 L  D L  U I  o U  o U  o U  o U  U I  1 U  U I  o U  o U  0 O\
 D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 P  U I  0 O D  o U  \
o U  1 C  1 C  1 C  0 O D  U I  1 U  U I  o U  1 C  1 C  0 O D  U I  1\
 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 0\
 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  0 O D  0 O I  U I  0 0\
 0  o C  1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1\
 L  U I  P I  P 0  U I  1 L  U I  D L  0 O  U I  U I  0 0 o  0 0 1  0 \
O L  U I  P 0  U I  0 O D  1 C  o U  0 O D  U I  C 0  U I  0 0 0  o C \
 1 L  1 L  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  o C  0 0 0  1 L  U I \
 C U  0 O  U I  U I  0 O D  0 O I  U I  D 1  D U  U I  1 D  U I  D 1  \
D U  D L  U I  o U  0 O D  1 C  o U  U I  1 o  U I  o U  0 O D  o U  o\
 U  0 O  U I  U I  0 O D  0 O D  o U  o U  1 C  0 O D  U I  1 O  U I  \
0 0 o  0 0 1  0 O L  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  1 C  \
D o  U I  1 D  U I  1 C  D o  D L  U I  0 O D  o U  o U  1 C  1 C  1 C\
  0 O D  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  \
1 L  U I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 \
D  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I  0 O D  1 C  1 C  o\
 U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 U  U I  \
0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  0 O O  0 O 0  0 O I  U I\
  0 O D  o U  1 C  0 O D  o U  o U  0 O D  0 O D  0 O D  0 O D  U I  1\
 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 0 o  0 0 1  0 O L \
 U I  1 1  U I  0 O C  0 0 0  0 O O  0 O 0  U I  1 1  U I  0 O D  C C \
 0 0 0  0 0 O  0 O D  0 O C  C o  0 O U  0 O 0  U I  1 1  U I  0 O I  \
C o  0 0 O  C o  0 0 1  0 0 P  U I  1 1  U I  0 O O  0 O 0  0 0 D  C C\
  0 0 1  0 O D  0 0 I  0 0 P  0 O D  0 0 0  0 0 O  U I  1 1  U I  0 O \
U  0 O 0  0 0 O  0 0 1  0 O 0  U I  1 1  U I  0 O O  C o  0 0 P  0 O 0\
  U I  1 1  U I  C C  0 0 1  0 O 0  0 O O  0 O D  0 0 P  0 0 D  U I  1\
 1  U I  0 0 D  0 O 1  0 0 0  0 0 C  C C  0 0 0  0 0 O  0 0 P  0 O 0  \
0 I O  0 0 P  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  U I  1 1  \
U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  P 0  U I  o L  0 0\
 0  0 0 O  0 O 0  U I  1 1  U I  0 0 1  0 O 0  0 O U  C D  0 0 o  0 0 \
1  0 O L  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  C o \
 0 O L  0 O L  0 O D  0 0 O  0 O I  0 0 0  U I  P 0  U I  0 I U  U I  \
0 I D  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  D 0  D P  U I \
 1 D  U I  D 0  D P  D L  U I  o U  0 O D  o U  o U  U I  1 o  U I  0 \
0 0  o C  1 L  0 0 0  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  U I  U o \
 U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  0\
 O D  0 O I  U I  D o  D O  U I  1 D  U I  D o  D O  D L  U I  0 0 0  \
1 L  0 0 0  o C  1 L  U I  1 o  U I  o U  o U  0 O D  o U  0 O D  o U \
 o U  1 C  1 C  0 O D  U I  1 I  U I  0 O D  o U  o U  1 C  1 C  1 C  \
0 O D  U I  1 D  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  0 O D  0 \
O I  U I  D o  D o  U I  1 D  U I  D o  D o  D L  U I  0 0 0  0 0 0  o\
 C  0 0 0  o C  1 L  o C  1 L  1 L  U I  U o  U I  o C  o C  0 0 0  0 \
0 0  o C  o C  0 0 0  0 O  U I  0 O D  0 O I  U I  0 0 1  0 O 0  0 O U\
  0 O 0  0 I O  0 0 D  U I  C o  0 0 O  0 O O  U I  0 O L  0 O 0  0 0 \
O  U I  1 O  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  1 0  \
U I  P I  U I  1 L  U I  D L  0 O  U I  U I  0 0 0  1 L  1 L  1 L  1 L\
  o C  1 L  1 L  0 0 0  o C  1 L  o C  U I  P 0  U I  0 0 D  0 I 0  0 \
0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I \
 C U  U I  1 U  U I  U 1  P U  0 0 o  0 0 1  0 O L  P 0  U 1  U I  1 U\
  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0\
 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  \
U I  0 0 o  0 0 1  0 O L  U I  1 0  U I  1 U  U I  U 1  U L  0 O C  0 \
0 0  0 O O  0 O 0  P 0  U 1  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  \
1 O  U I  0 O C  0 0 0  0 O O  0 O 0  U I  1 0  U I  1 U  U I  U 1  U \
L  0 0 O  C o  0 O C  0 O 0  P 0  U 1  U I  1 U  U I  0 0 o  0 0 1  0 \
O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O\
 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 O C \
 0 O 0  U I  1 0  U I  1 U  U I  U 1  U L  0 O I  C o  0 0 O  C o  0 0\
 1  0 0 P  P 0  U 1  U I  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D \
 C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 \
O L  0 0 o  0 0 D  U I  1 O  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P\
  U I  1 0  U I  1 U  U I  U 1  U L  0 0 1  0 O 0  0 O U  0 O 0  0 I O\
  0 0 D  P 0  U 1  U I  1 U  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0\
 0 D  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0\
 0 0  1 L  1 L  1 L  1 L  o C  1 L  1 L  0 0 0  o C  1 L  o C  U I  P \
0  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  \
U I  C 0  U I  1 L  U I  C U  U I  1 U  U I  U 1  P U  0 0 o  0 0 1  0\
 O L  P 0  U 1  U I  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L \
 U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  \
0 0 o  0 0 D  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 0  U I  1 U  \
U I  U 1  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  U 1  U I  1 U  U I  0 \
0 D  0 0 P  0 0 1  U I  1 O  U I  0 O C  0 0 0  0 O O  0 O 0  U I  1 0\
  U I  1 U  U I  U 1  U L  0 0 O  C o  0 O C  0 O 0  P 0  U 1  U I  1 \
U  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  \
0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O \
 U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  U I  1 U  U I  U 1  U L  0 O\
 I  C o  0 0 O  C o  0 0 1  0 0 P  P 0  U 1  U I  1 U  U I  0 0 o  0 0\
 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 \
P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 O I  C o  \
0 0 O  C o  0 0 1  0 0 P  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  \
D 0  U I  1 D  U I  D 0  D L  U I  0 0 0  o C  1 L  0 0 0  U I  U o  U\
 I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 P  U I\
  o C  1 L  0 0 0  o C  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  0 \
O  U I  o U  1 C  0 O D  1 C  o U  1 C  o U  0 O D  0 O D  0 O D  0 O \
D  1 C  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  0 O  U I  0 O D  0 O \
I  U I  0 O O  C o  0 0 P  0 O 0  U I  P 0  P 0  U I  U C  U C  U I  D\
 L  0 O  U I  U I  0 O O  C o  0 0 P  0 O 0  U I  P 0  U I  o L  0 0 0\
  0 0 O  0 O 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U\
 I  U I  0 O O  0 O 0  0 0 D  C C  0 0 1  0 O D  0 0 I  0 0 P  0 O D  \
0 0 0  0 0 O  U I  1 U  P 0  U I  U C  C I  0 0 O  C I  0 0 O  P L  C \
o  0 0 P  0 O 0  D L  U I  U o  0 0 D  U C  U I  U o  U I  0 O O  C o \
 0 0 P  0 O 0  0 O  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o\
 U  1 C  1 C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U  0 0 o  0 O\
 D  U I  1 P  U I  o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 O 0  0 O C \
 U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 O D  C C  0\
 0 0  0 0 O  o U  0 O C  C o  0 O U  0 O 0  U I  P 0  U I  U 1  P L  0\
 O 0  0 O I  C o  0 0 o  0 O L  0 0 P  o O  0 0 0  0 O L  0 O O  0 O 0\
  0 0 1  1 P  0 0 I  0 0 O  0 O U  U 1  U I  1 1  U I  0 0 P  0 O 1  0\
 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  o U  0 O C  C o  0 O U  0 \
O 0  U I  P 0  U I  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C  C o  0 O U\
  0 O 0  U I  1 0  0 O  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U\
 I  1 O  U I  C o  0 O L  0 O L  0 O D  0 0 O  0 O I  0 0 0  U I  1 0 \
 U I  P O  U I  1 C  U I  D L  0 O  U I  U I  o U  1 C  0 O D  1 C  0 \
O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P \
 o U  0 0 O  0 O I  0 0 0  U I  1 O  U I  0 0 P  0 I 0  0 0 I  0 O 0  \
U I  P 0  U I  U 1  L P  0 O D  0 O O  0 O 0  0 0 0  U 1  U I  1 1  U \
I  0 O D  0 0 O  0 O I  0 0 0  o P  C o  C L  0 O 0  0 O L  0 0 D  U I\
  P 0  U I  0 I U  U I  U 1  L 1  0 O D  0 0 P  0 O L  0 O 0  U 1  U I\
  D L  U I  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  U 1  L O  0 O L  \
0 0 0  0 0 P  U 1  U I  D L  U I  0 O O  0 O 0  0 0 D  C C  0 0 1  0 O\
 D  0 0 I  0 0 P  0 O D  0 0 0  0 0 O  U I  1 1  U I  U 1  o 0  0 O 0 \
 0 0 O  0 0 1  0 O 0  U 1  U I  D L  U I  0 O U  0 O 0  0 0 O  0 0 1  \
0 O 0  U I  1 1  U I  U 1  0 O O  C o  0 0 P  0 O 0  C o  0 O O  0 O O\
  0 O 0  0 O O  U 1  U I  D L  U I  0 O O  C o  0 0 P  0 O 0  U I  1 1\
  U I  U 1  C C  0 0 1  0 O 0  0 O O  0 O D  0 0 P  0 0 D  U 1  U I  D\
 L  U I  C C  0 0 1  0 O 0  0 O O  0 O D  0 0 P  0 0 D  U I  0 I D  U \
I  1 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I \
 o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  \
U I  0 0 D  0 O 0  0 0 P  o U  0 0 O  0 O I  0 0 0  U I  1 O  U I  0 0\
 P  0 I 0  0 0 I  0 O 0  U I  P 0  U I  U 1  L P  0 O D  0 O O  0 O 0 \
 0 0 0  U 1  U I  1 1  U I  0 O D  0 0 O  0 O I  0 0 0  o P  C o  C L \
 0 O 0  0 O L  0 0 D  U I  P 0  U I  C o  0 O L  0 O L  0 O D  0 0 O  \
0 O I  0 0 0  U I  1 0  0 O  U I  o U  1 C  0 O D  1 C  0 O D  o U  o \
U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L O  0 0 1 \
 0 0 0  0 0 I  0 O 0  0 0 1  0 0 P  0 I 0  U I  1 O  U I  U 1  o O  C \
o  0 0 O  C o  0 0 1  0 0 P  C D  o U  0 O C  C o  0 O U  0 O 0  U 1  \
U I  1 1  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U I  1 0  0 O  U \
I  0 O D  0 O I  U I  0 0 D  0 O 1  0 0 0  0 0 C  C C  0 0 0  0 0 O  0\
 0 P  0 O 0  0 I O  0 0 P  U I  D L  0 O  U I  U I  o C  1 L  o C  0 0\
 0  0 0 0  1 L  o C  U I  P 0  U I  C 0  U I  C U  0 O  U I  U I  0 O \
D  o U  o U  o U  0 O D  0 O D  o U  1 C  0 O D  1 C  0 O D  U I  P 0 \
 U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C\
  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0\
 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 0 I  C o  0 0 1  0 O 0  0 0 \
O  0 0 P  C o  0 O L  C L  0 O L  0 0 0  C C  0 O o  0 O 0  0 O O  U C\
  U I  1 0  0 O  U I  U I  0 O D  o U  o U  o U  0 O D  0 O D  o U  1 \
C  0 O D  1 C  0 O D  U I  P 0  U I  0 O D  o U  o U  o U  0 O D  0 O \
D  o U  1 C  0 O D  1 C  0 O D  U I  P 0  P 0  U I  U 1  0 0 P  0 0 1 \
 0 0 o  0 O 0  U 1  0 O  U I  U I  0 O D  0 O D  0 O D  1 C  U I  P 0 \
 U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C\
  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0\
 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 0 I  C o  0 0 1  0 O 0  0 0 \
O  0 0 P  C o  0 O L  C L  0 O L  0 0 0  C C  0 O o  0 O 0  0 O O  0 0\
 I  0 O D  0 0 O  U C  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  D o\
  D 0  U I  1 D  U I  D o  D 0  D L  U I  o U  o U  o U  o U  U I  U o\
  U I  o U  1 C  1 C  0 O D  0 O  U I  U I  0 O D  0 O I  U I  0 O L  \
0 O 0  0 0 O  U I  1 O  U I  0 O D  0 O D  0 O D  1 C  U I  1 0  U I  \
P I  U I  1 L  U I  D L  0 O  U I  U I  U I  0 O D  0 O I  U I  0 O D \
 o U  o U  o U  0 O D  0 O D  o U  1 C  0 O D  1 C  0 O D  U I  D L  0\
 O  U I  U I  U I  U I  o C  1 L  o C  0 0 0  0 0 0  1 L  o C  U I  1 \
P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  1 O  U \
I  U C  P L  0 O D  0 0 D  C o  C L  0 O L  0 O 0  U I  L O  C o  0 0 \
1  0 O 0  0 0 O  0 0 P  C o  0 O L  U I  P P  0 O L  0 0 0  C C  0 O o\
  U C  U I  1 1  U I  U C  L L  P P  o o  P o  1 P  L I  0 0 o  0 0 O \
 L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o  0 0 D  P U  0 O C  \
0 0 0  0 O O  0 O 0  P 0  D U  D U  U L  0 0 O  C o  0 O C  0 O 0  P 0\
  U o  0 0 D  1 0  U C  U I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  \
U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U \
 U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I \
 0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U\
 I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  U I  1 0  U I  1 0  \
U I  1 0  0 O  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 \
O  U I  U I  U I  U I  o C  1 L  o C  0 0 0  0 0 0  1 L  o C  U I  1 P\
  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  1 O  U I\
  U C  P C  0 0 O  C o  C L  0 O L  0 O 0  U I  L O  C o  0 0 1  0 O 0\
  0 0 O  0 0 P  C o  0 O L  U I  P P  0 O L  0 0 0  C C  0 O o  U C  U\
 I  1 1  U I  U C  L L  P P  o o  P o  1 P  L I  0 0 o  0 0 O  L O  0 \
O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o  0 0 D  P U  0 O C  0 0 0  0\
 O O  0 O 0  P 0  D U  D 1  U L  0 0 O  C o  0 O C  0 O 0  P 0  U o  0\
 0 D  1 0  U C  U I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P\
  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 \
1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  \
0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O \
 U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  U I  1 0  U I  1 0  U I  1 0\
  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D P  D 0  U I  1 D  U I \
 D P  D 0  D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 P  \
U I  o U  0 O D  o U  o U  U I  1 D  U I  0 0 0  1 L  0 0 0  o C  1 L \
 U I  1 P  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  U I\
  0 O D  0 O I  U I  0 0 D  0 O 1  0 0 0  0 0 C  C C  0 0 0  0 0 O  0 \
0 P  0 O 0  0 I O  0 0 P  U I  P 0  P 0  U I  U C  0 0 D  0 0 0  0 0 o\
  0 0 1  C C  0 O 0  U C  U I  D L  0 O  U I  U I  U I  0 O D  0 O I  \
U I  D D  D 0  U I  1 D  U I  D D  D 0  D L  U I  0 O D  o U  o U  1 C\
  1 C  1 C  0 O D  U I  1 D  U I  0 O D  0 O D  o U  1 C  0 O D  o U  \
0 O D  o U  U I  1 P  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  \
o U  0 O  U I  U I  U I  0 O D  0 O I  U I  0 0 O  C o  0 O C  0 O 0  \
U I  0 O D  0 0 O  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  o U  1 C  \
1 C  o U  1 C  1 C  0 O D  1 C  o U  U I  1 0  U I  D L  0 O  U I  U I\
  U I  U I  o C  1 L  o C  0 0 0  0 0 0  1 L  o C  U I  1 P  U I  C o \
 0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  1 O  U I  U C  L I \
 0 O 0  0 O C  0 0 0  0 0 L  0 O 0  U I  0 O I  0 0 1  0 0 0  0 O C  U\
 I  L U  0 0 0  0 0 o  0 0 1  C C  0 O 0  0 0 D  U C  U I  1 1  U I  U\
 C  L L  P P  o o  P o  1 P  L I  0 0 o  0 0 O  L O  0 O L  0 0 o  0 O\
 U  0 O D  0 0 O  1 O  U o  0 0 D  P U  0 O C  0 0 0  0 O O  0 O 0  P \
0  D P  U L  0 0 O  C o  0 O C  0 O 0  P 0  U o  0 0 D  1 0  U C  U I \
 U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0\
 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  0 0 o  0 0 1\
  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P \
 0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 \
O C  0 O 0  U I  1 0  U I  1 0  U I  1 0  U I  1 0  0 O  U I  U I  U I\
  U I  0 O D  0 O I  U I  D O  D O  U I  1 D  U I  D O  D O  D L  U I \
 o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 o  U I  o C  0 0\
 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U I  0 O D  1 C  1 C  \
o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  U o  U I \
 0 0 0  1 L  0 0 0  o C  1 L  U I  1 P  U I  o C  1 L  0 0 0  o C  U I\
  1 U  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U I  U I  \
U I  U I  0 O D  0 O I  U I  D 1  D I  U I  1 D  U I  D 1  D I  D L  U\
 I  o U  1 C  1 C  0 O D  U I  U o  U I  0 0 0  o C  1 L  0 0 0  1 L  \
0 0 0  0 0 0  o C  1 L  U I  1 o  U I  0 O D  1 C  1 C  o U  0 O D  1 \
C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  U o  U I  o C  o C  0 0\
 0  0 0 0  o C  o C  0 0 0  0 O  U I  U I  0 O 0  0 O L  0 O D  0 O I \
 U I  0 0 D  0 O 1  0 0 0  0 0 C  C C  0 0 0  0 0 O  0 0 P  0 O 0  0 I\
 O  0 0 P  U I  P 0  P 0  U I  U C  0 O O  0 0 0  0 0 C  0 0 O  0 O L \
 0 0 0  C o  0 O O  U C  U I  D L  0 O  U I  U I  U I  o C  1 L  o C  \
0 0 0  0 0 0  1 L  o C  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O\
  0 O O  U I  1 O  U I  1 O  U I  U C  P L  0 0 0  0 0 C  0 0 O  0 O L\
  0 0 0  C o  0 O O  U C  U I  1 1  U I  U C  L L  P P  o o  P o  1 P \
 L I  0 0 o  0 0 O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o  \
0 0 D  P U  0 0 o  0 0 1  0 O L  P 0  U o  0 0 D  U L  0 O C  0 0 0  0\
 O O  0 O 0  P 0  D o  U L  0 0 O  C o  0 O C  0 O 0  P 0  U o  0 0 D \
 1 0  U C  0 O  U I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P\
  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 \
1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  \
0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O \
 U I  0 0 o  0 0 1  0 O L  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O \
L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0\
  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 O C  0\
 O 0  U I  1 0  U I  1 0  U I  1 0  U I  1 0  0 O  U I  U I  0 O 0  0 \
O L  0 O D  0 O I  U I  0 0 D  0 O 1  0 0 0  0 0 C  C C  0 0 0  0 0 O \
 0 0 P  0 O 0  0 I O  0 0 P  U I  P 0  P 0  U I  U C  0 O I  C o  0 0 \
L  U C  U I  D L  0 O  U I  U I  U I  o C  1 L  o C  0 0 0  0 0 0  1 L\
  o C  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O\
  U I  1 O  U I  U C  L I  0 O 0  0 O C  0 0 0  0 0 L  0 O 0  U I  0 O\
 I  0 0 1  0 0 0  0 O C  U I  L 1  0 O 0  C o  0 O C  L U  0 0 I  0 0 \
0  0 0 1  0 0 P  0 0 D  U I  o O  C o  0 0 L  0 0 0  0 0 1  0 O D  0 0\
 P  0 O 0  0 0 D  U C  U I  1 1  U I  U C  L L  P P  o o  P o  1 P  L \
I  0 0 o  0 0 O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o  0 0\
 D  P U  0 O C  0 0 0  0 O O  0 O 0  P 0  D 1  U L  0 0 O  C o  0 O C \
 0 O 0  P 0  U o  0 0 D  1 0  U C  0 O  U I  U o  U I  1 O  U I  0 0 D\
  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I\
  1 L  U I  C U  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L\
  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L \
 0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  U I \
 1 0  U I  1 0  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  0 0 D  0 O\
 1  0 0 0  0 0 C  C C  0 0 0  0 0 O  0 0 P  0 O 0  0 I O  0 0 P  U I  \
P 0  P 0  U I  U C  U U  U U  0 0 o  0 0 I  0 O O  C o  0 0 P  0 O 0  \
U C  U I  D L  0 O  U I  U I  U I  o U  1 C  0 O D  0 O D  0 O D  1 C \
 U I  P 0  U I  1 O  0 O  U I  U C  U o  0 0 D  P U  0 0 o  0 0 1  0 O\
 L  P 0  U o  0 0 D  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D D  U\
 L  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  P 0  U o  0 0 D  U C  0 \
O  U I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0\
 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  0 0 o\
  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0 \
 0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 1  \
0 O 0  0 O U  C D  0 0 o  0 0 1  0 O L  U I  1 0  U I  1 1  U I  0 0 1\
  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  1 0  0 O  U I  1 0  0 O  U I\
  U I  U I  o C  1 L  o C  0 0 0  0 0 0  1 L  o C  U I  1 P  U I  C o \
 0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  1 O  U I  U C  C 0 \
 P o  o C  o P  o C  L I  U I  0 I 0  0 O 0  0 O L  0 O L  0 0 0  0 0 \
C  C U  U U  U U  0 0 o  0 0 I  0 O O  C o  0 0 P  0 O 0  C 0  1 o  P \
o  o C  o P  o C  L I  C U  U C  U I  1 1  U I  U C  L L  P P  o o  P \
o  1 P  L I  0 0 o  0 0 O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O\
  U o  0 0 D  1 0  U C  U I  U o  U I  o U  1 C  0 O D  0 O D  0 O D  \
1 C  U I  1 0  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 \
0  0 0 P  U I  0 0 O  C o  0 O C  0 O 0  U I  0 O D  0 0 O  U I  o C  \
1 L  0 0 0  1 L  o C  0 0 0  U I  D L  0 O  U I  U I  U I  o C  1 L  o\
 C  0 0 0  0 0 0  1 L  o C  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0\
 0 O  0 O O  U I  1 O  U I  1 O  U I  U C  P D  0 O O  0 O O  U I  0 0\
 P  0 0 0  U I  L 1  0 O 0  C o  0 O C  L U  0 0 I  0 0 0  0 0 1  0 0 \
P  0 0 D  U I  o O  C o  0 0 L  0 0 0  0 0 1  0 O D  0 0 P  0 O 0  0 0\
 D  U C  U I  1 1  U I  U C  L L  P P  o o  P o  1 P  L I  0 0 o  0 0 \
O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o  0 0 D  P U  0 O C\
  0 0 0  0 O O  0 O 0  P 0  D U  U L  0 0 O  C o  0 O C  0 O 0  P 0  U\
 o  0 0 D  U L  0 0 o  0 0 1  0 O L  P 0  U o  0 0 D  U L  0 O D  C C \
 0 0 0  0 0 O  0 O D  0 O C  C o  0 O U  0 O 0  P 0  U o  0 0 D  U L  \
0 O I  C o  0 0 O  C o  0 0 1  0 0 P  P 0  U o  0 0 D  U L  0 O I  C o\
  0 0 L  C D  0 O C  0 0 0  0 O O  0 O 0  P 0  U o  0 0 D  1 0  U C  0\
 O  U I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  \
0 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  0 0 \
o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0\
  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 O \
 C o  0 O C  0 O 0  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O \
L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  \
0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1\
 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U\
 I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D\
  U I  1 O  U I  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C  C o  0 O U  0\
 O 0  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L \
 U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  \
0 0 o  0 0 D  U I  1 O  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U I\
  1 0  U I  1 1  U I  0 O C  0 0 0  0 O O  0 O 0  U I  1 0  U I  1 0  \
U I  1 0  0 O  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o\
 U  1 C  1 C  U I  1 P  U I  C o  0 O O  0 O O  P o  0 0 0  0 0 O  0 0\
 P  0 O 0  0 I O  0 0 P  o o  0 O 0  0 0 O  0 0 o  o U  0 0 P  0 O 0  \
0 O C  0 0 D  U I  1 O  U I  o C  1 L  o C  0 0 0  0 0 0  1 L  o C  U \
I  1 0  0 O  U I  o U  1 C  0 O D  1 C  o U  1 C  o U  0 O D  0 O D  0\
 O D  0 O D  1 C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L \
 0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  C o  0 O O  0 O O  P L  0 \
O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  o U  0 0 P  0 O 0 \
 0 O C  U I  1 O  U I  0 O 1  C o  0 0 O  0 O O  0 O L  0 O 0  U I  P \
0  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  \
1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U I  C U  U I \
 1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  0 0 0  1 L  1\
 L  1 L  1 L  o C  1 L  1 L  0 0 0  o C  1 L  o C  U I  1 1  U I  0 O \
L  0 O D  0 0 D  0 0 P  0 O D  0 0 P  0 O 0  0 O C  U I  P 0  U I  o U\
  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 1  U I \
 0 O D  0 0 D  o O  0 0 0  0 O L  0 O O  0 O 0  0 0 1  U I  P 0  U I  \
L 1  0 0 1  0 0 o  0 O 0  U I  1 0  0 O  U I  0 0 1  0 O 0  0 0 P  0 0\
 o  0 0 1  0 0 O  U I  o U  1 C  0 O D  1 C  o U  1 C  o U  0 O D  0 O\
 D  0 O D  0 O D  1 C  0 O  0 O O  0 O 0  0 O I  U I  0 O D  o U  0 O \
D  0 O D  0 O D  o U  o U  0 O D  0 O D  0 O D  U I  1 O  U I  0 0 o  \
0 0 1  0 O L  U I  1 1  U I  0 0 P  0 O D  0 0 P  0 O L  0 O 0  U I  1\
 1  U I  0 O C  0 O 0  0 O O  0 O D  C o  C D  0 0 P  0 I 0  0 0 I  0 \
O 0  U I  P 0  U I  U C  0 0 L  0 O D  0 O O  0 O 0  0 0 0  U C  U I  \
1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  D o  1 C  U I  1 D  U I  D\
 o  1 C  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 P  \
U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  U o  U I  o \
U  0 O D  o U  o U  U I  1 D  U I  0 O D  0 O D  o U  1 C  0 O D  o U \
 0 O D  o U  U I  1 P  U I  o U  o U  o U  o U  U I  U o  U I  0 0 0  \
0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  0 O D  0 O I  U \
I  D O  D U  U I  1 D  U I  D O  D U  D L  U I  0 0 0  o C  1 L  0 0 0\
  0 O  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 I 0  0 0 \
0  0 0 o  0 0 P  0 0 o  C L  0 O 0  0 O O  0 O L  0 O  U I  0 O D  0 O\
 I  U I  D 1  D 0  U I  1 D  U I  D 1  D 0  D L  U I  o C  0 0 0  0 0 \
0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  0 O D  0 O I  U I  0 0 O  0 0 \
0  0 0 P  U I  0 0 o  0 0 1  0 O L  U I  P 0  P 0  U I  U C  U C  U I \
 D L  0 O  U I  U I  0 O D  0 O I  U I  0 O C  0 O 0  0 O O  0 O D  C \
o  C D  0 0 P  0 I 0  0 0 I  0 O 0  U I  P 0  P 0  U I  U C  C o  0 0 \
o  0 O O  0 O D  0 0 0  U C  U I  D L  0 O  U I  U I  U I  0 I 0  0 0 \
0  0 0 o  0 0 P  0 0 o  C L  0 O 0  0 O O  0 O L  U I  1 P  U I  0 0 D\
  0 O D  0 0 O  0 O U  0 O L  0 O 0  C D  L C  P L  U I  1 O  U I  0 0\
 o  0 0 1  0 O L  U I  1 1  U I  0 O O  0 0 0  0 0 C  0 0 O  0 O L  0 \
0 0  C o  0 O O  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 1  U \
I  C o  0 0 o  0 O O  0 O D  0 0 0  U I  P 0  U I  L 1  0 0 1  0 0 o  \
0 O 0  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  \
0 O  U I  U I  U I  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0  0 O\
 O  0 O L  U I  1 P  U I  0 0 D  0 O D  0 0 O  0 O U  0 O L  0 O 0  C \
D  L C  P L  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  0 O O \
 0 0 0  0 0 C  0 0 O  0 O L  0 0 0  C o  0 O O  U I  P 0  U I  L 1  0 \
0 1  0 0 o  0 O 0  U I  1 0  0 O  U I  0 O 0  0 O L  0 O D  0 O I  U I\
  0 I O  C L  0 O C  C C  U I  1 P  U I  L O  0 O L  C o  0 I 0  0 O 0\
  0 0 1  U I  1 O  U I  1 0  U I  1 P  U I  0 O D  0 0 D  L O  0 O L  \
C o  0 I 0  0 O D  0 0 O  0 O U  U I  1 O  U I  1 0  U I  P 0  P 0  U \
I  L 1  0 0 1  0 0 o  0 O 0  U I  D L  0 O  U I  U I  0 O D  0 O C  0 \
0 I  0 0 0  0 0 1  0 0 P  U I  L C  P L  L U  0 0 P  0 0 1  0 O 0  C o\
  0 O C  P C  0 I O  0 0 P  0 0 1  C o  C C  0 0 P  0 0 0  0 0 1  0 O \
 U I  U I  0 O D  0 O I  U I  L C  P L  L U  0 0 P  0 0 1  0 O 0  C o \
 0 O C  P C  0 I O  0 0 P  0 0 1  C o  C C  0 0 P  0 0 0  0 0 1  U I  \
1 P  U I  0 O D  0 0 D  P L  0 0 0  0 0 C  0 0 O  0 O L  0 0 0  C o  0\
 O O  0 O D  0 0 O  0 O U  U I  1 O  U I  1 0  U I  P 0  P 0  U I  L 1\
  0 0 1  0 0 o  0 O 0  U I  D L  0 O  U I  U I  U I  0 O D  0 O I  U I\
  D o  D 1  U I  1 D  U I  D o  D 1  D L  U I  0 0 0  1 L  0 0 0  o C \
 1 L  0 O  U I  U I  U I  L C  P L  L U  0 0 P  0 0 1  0 O 0  C o  0 O\
 C  P C  0 I O  0 0 P  0 0 1  C o  C C  0 0 P  0 0 0  0 0 1  U I  1 P \
 U I  0 O C  C o  0 0 O  C o  0 O U  0 O 0  P L  0 0 0  0 0 C  0 0 O  \
0 O L  0 0 0  C o  0 O O  0 0 D  U I  1 O  U I  1 0  0 O  U I  U I  0 \
O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  o U  o U  o U \
 o U  0 O D  0 O D  1 C  U I  P 0  U I  0 I O  C L  0 O C  C C  U I  1\
 P  U I  L O  0 O L  C o  0 I 0  0 O 0  0 0 1  U I  1 O  U I  1 0  U I\
  1 P  U I  0 O U  0 O 0  0 0 P  L O  0 O L  C o  0 I 0  0 O D  0 0 O \
 0 O U  o O  0 O D  0 O L  0 O 0  U I  1 O  U I  1 0  0 O  U I  U I  U\
 I  0 O D  0 O I  U I  D 1  D 0  U I  1 D  U I  D 1  D 0  D L  U I  0 \
O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U I  U I  U I  o U \
 o U  o U  o U  0 O D  0 O D  1 C  U I  P 0  U I  o U  o U  o U  o U  \
0 O D  0 O D  1 C  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U\
 I  1 O  U I  U C  0 I 1  L D  0 0 D  0 O 0  0 0 1  1 D  P D  0 O U  0\
 O 0  0 0 O  0 0 P  P 0  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  \
0 O  U I  U I  U I  0 0 0  o C  o C  0 0 0  1 L  0 0 0  0 0 0  o C  1 \
L  U I  P 0  U I  0 I U  U I  U C  0 0 o  0 0 1  0 O L  U C  U I  D L \
 U I  o U  o U  o U  o U  0 O D  0 O D  1 C  U I  1 1  U I  U C  0 0 P\
  0 O D  0 0 P  0 O L  0 O 0  U C  U I  D L  U I  0 0 P  0 O D  0 0 P \
 0 O L  0 O 0  U I  1 1  U I  U C  0 O C  0 O 0  0 O O  0 O D  C o  C \
D  0 0 P  0 I 0  0 0 I  0 O 0  U C  U I  D L  U I  0 O C  0 O 0  0 O O\
  0 O D  C o  C D  0 0 P  0 I 0  0 0 I  0 O 0  U I  0 I D  0 O  U I  U\
 I  U I  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0  0 O O  0 O L  \
U I  1 P  U I  0 0 D  0 O D  0 0 O  0 O U  0 O L  0 O 0  C D  L C  P L\
  U I  1 O  U I  U C  U C  U I  1 1  U I  0 O O  0 0 0  0 0 C  0 0 O  \
0 O L  0 0 0  C o  0 O O  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I\
  1 1  U I  0 O O  0 O L  C D  0 O D  0 0 O  0 O I  0 0 0  U I  P 0  U\
 I  0 0 0  o C  o C  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 0  0 O\
  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 I O  C L\
  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  0\
 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O  U I  U \
1  L L  P P  o o  P o  1 P  o L  0 0 0  0 0 P  0 O D  0 O I  0 O D  C \
C  C o  0 0 P  0 O D  0 0 0  0 0 O  1 O  P L  o C  L o  o L  o P  o C \
 P D  P L  1 1  o O  0 O D  0 0 1  0 0 D  0 0 P  U I  L O  0 O L  C o \
 0 I 0  U I  C 0  P o  o C  o P  o C  L I  U I  0 I 0  0 O 0  0 O L  0\
 O L  0 0 0  0 0 C  C U  L o  o I  o U  o P  P C  U I  0 0 I  0 O L  C\
 o  0 I 0  0 O D  0 0 O  0 O U  U I  0 O O  0 0 0  0 0 C  0 0 O  0 O L\
  0 0 0  C o  0 O O  C 0  1 o  P o  o C  o P  o C  L I  C U  U I  1 1 \
 1 C  1 L  1 L  1 L  1 L  1 0  U 1  U I  1 0  0 O  U I  U I  0 O D  0 \
O I  U I  1 C  1 C  U I  1 D  U I  1 C  1 C  D L  U I  0 O D  0 O D  o\
 U  1 C  0 O D  o U  0 O D  o U  U I  1 D  U I  0 0 0  o C  1 L  0 0 0\
  0 O  U I  U I  0 O D  0 O I  U I  D o  D O  U I  1 D  U I  D o  D O \
 D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  0 O O  0 O 0  0 O\
 I  U I  o U  1 C  o U  1 C  U I  1 O  U I  0 0 D  0 0 P  0 0 1  0 O D\
  0 0 O  0 O U  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  0 O D\
  0 0 D  0 O D  0 0 O  0 0 D  0 0 P  C o  0 0 O  C C  0 O 0  U I  1 O \
 U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 1  U I  C L  C \
o  0 0 D  0 O 0  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U I  1 0  U\
 I  D L  0 O  U I  U I  0 O D  0 O I  U I  0 O D  0 0 D  0 O D  0 0 O \
 0 0 D  0 0 P  C o  0 0 O  C C  0 O 0  U I  1 O  U I  0 0 D  0 0 P  0 \
0 1  0 O D  0 0 O  0 O U  U I  1 1  U I  0 0 o  0 0 O  0 O D  C C  0 0\
 0  0 O O  0 O 0  U I  1 0  U I  D L  0 O  U I  U I  U I  0 0 D  0 0 P\
  0 0 1  0 O D  0 0 O  0 O U  U I  P 0  U I  0 0 D  0 0 P  0 0 1  0 O \
D  0 0 O  0 O U  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0\
  U I  1 O  U I  U C  C o  0 0 D  C C  0 O D  0 O D  U C  U I  1 1  U \
I  U C  0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  U C  U I  1 0  0 O  \
U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 D  0 0 P  0 0 \
1  0 O D  0 0 O  0 O U  0 O  0 O O  0 O 0  0 O I  U I  0 0 0  0 0 0  0\
 0 0  1 L  U I  1 O  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U  U \
I  1 1  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O D  0 0 O  0 O U  U I\
  P 0  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  U I  D \
L  0 O  U I  0 O D  0 O I  U I  0 O D  0 0 D  0 O D  0 0 O  0 0 D  0 0\
 P  C o  0 0 O  C C  0 O 0  U I  1 O  U I  0 0 D  0 0 P  0 0 1  0 O D \
 0 0 O  0 O U  U I  1 1  U I  C L  C o  0 0 D  0 O 0  0 0 D  0 0 P  0 \
0 1  0 O D  0 0 O  0 O U  U I  1 0  U I  D L  0 O  U I  U I  0 O D  0 \
O I  U I  0 0 O  0 0 0  0 0 P  U I  0 O D  0 0 D  0 O D  0 0 O  0 0 D \
 0 0 P  C o  0 0 O  C C  0 O 0  U I  1 O  U I  0 0 D  0 0 P  0 0 1  0 \
O D  0 0 O  0 O U  U I  1 1  U I  0 0 o  0 0 O  0 O D  C C  0 0 0  0 O\
 O  0 O 0  U I  1 0  U I  D L  0 O  U I  U I  U I  0 0 D  0 0 P  0 0 1\
  0 O D  0 0 O  0 O U  U I  P 0  U I  0 0 o  0 0 O  0 O D  C C  0 0 0 \
 0 O O  0 O 0  U I  1 O  U I  0 0 D  0 0 P  0 0 1  0 O D  0 0 O  0 O U\
  U I  1 1  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O D  0 0 O  0 O U \
 U I  1 1  U I  U C  0 O D  0 O U  0 0 O  0 0 0  0 0 1  0 O 0  U C  U \
I  1 0  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 D\
  0 0 P  0 0 1  0 O D  0 0 O  0 O U  0 O  0 O O  0 O 0  0 O I  U I  o \
U  1 C  1 C  U I  1 O  U I  0 0 D  U I  1 0  U I  D L  U I  0 0 1  0 O\
 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  U 1  U 1  U I  1 P  U I  0 O P  0\
 0 0  0 O D  0 0 O  U I  1 O  U I  0 O I  0 O D  0 O L  0 0 P  0 O 0  \
0 0 1  U I  1 O  U I  0 O L  C o  0 O C  C L  0 O O  C o  U I  o C  o \
C  o C  1 L  U I  D L  U I  0 0 0  0 0 1  0 O O  U I  1 O  U I  o C  o\
 C  o C  1 L  U I  1 0  U I  P O  U I  1 C  D O  D P  U I  1 1  U I  0\
 0 D  U I  1 0  U I  1 0  0 O  0 O D  0 O I  U I  1 C  D 1  U I  1 D  \
U I  1 C  D 1  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o \
U  U I  1 o  U I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  o C  1 L  0 0\
 0  o C  U I  1 I  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U\
  U I  1 I  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  0 O O  0 O 0  0 O I\
  U I  0 O D  0 O D  o U  0 O D  o U  1 C  1 C  o U  0 O D  o U  1 C  \
0 O D  0 O D  U I  1 O  U I  C C  0 0 0  0 O C  0 O C  C o  0 0 O  0 O\
 O  U I  1 0  U I  D L  0 O  U I  o C  o C  o C  1 L  o C  o C  0 0 0 \
 U I  P 0  U I  U C  U C  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O\
  U I  U I  o C  o C  o C  1 L  o C  o C  0 0 0  U I  P 0  U I  0 I O \
 C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 \
P  0 O 0  o 1  L U  o C  o L  L I  L O  P o  U I  1 O  U I  0 0 0  0 0\
 0  0 0 0  1 L  U I  1 O  U I  C C  0 0 0  0 O C  0 O C  C o  0 0 O  0\
 O O  U I  1 0  U I  1 0  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0\
 0 P  U I  L D  0 0 O  0 O D  C C  0 0 0  0 O O  0 O 0  P C  0 0 O  C \
C  0 0 0  0 O O  0 O 0  P C  0 0 1  0 0 1  0 0 0  0 0 1  U I  D L  0 O\
  U I  U I  o C  o C  o C  1 L  o C  o C  0 0 0  U I  P 0  U I  0 I O \
 C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 \
P  0 O 0  o 1  L U  o C  o L  L I  L O  P o  U I  1 O  U I  o U  1 C  \
o U  1 C  U I  1 O  U I  C C  0 0 0  0 O C  0 O C  C o  0 0 O  0 O O  \
U I  1 0  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  1 C  1 L  1 L  U\
 I  1 D  U I  1 C  1 L  1 L  D L  U I  0 O D  o U  o U  1 C  1 C  1 C \
 0 O D  U I  1 U  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  U I  \
0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 0 0  0 0 0  0 0 0  1 \
L  U I  1 O  U I  o C  o C  o C  1 L  o C  o C  0 0 0  U I  1 0  0 O  \
U I  0 O D  0 O I  U I  D D  1 L  U I  1 D  U I  D D  1 L  D L  U I  0\
 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  U o  U I  o C  1 L  0 0 0  \
o C  U I  U o  U I  o U  1 C  1 C  0 O D  0 O  0 O O  0 O 0  0 O I  U \
I  0 O D  0 O D  o U  o U  1 C  0 O D  U I  1 O  U I  0 0 o  0 0 1  0 \
O L  U I  1 1  U I  0 O U  0 O D  0 0 L  0 O 0  C D  0 O C  0 O 0  C D\
  0 0 1  0 O 0  0 0 D  0 0 o  0 O L  0 0 P  U I  P 0  U I  o L  0 0 0 \
 0 0 O  0 O 0  U I  1 1  U I  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  \
0 0 D  0 0 P  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  U I  1 0  \
U I  D L  0 O  U I  0 O D  0 O I  U I  U C  C o  0 0 o  0 O O  0 O D  \
0 0 0  U C  U I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  D L  0 O\
  U I  U I  0 O D  o U  1 C  o U  o U  o U  o U  1 C  U I  P 0  U I  0\
 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U C  0 I U  U 1  0 O P  0 0 D \
 0 0 0  0 0 O  0 0 1  0 0 I  C C  U 1  D L  U 1  D O  1 P  1 L  U 1  1\
 1  U 1  0 O C  0 O 0  0 0 P  0 O 1  0 0 0  0 O O  U 1  D L  U 1  o O \
 0 O D  0 O L  0 O 0  0 0 D  1 P  o 0  0 O 0  0 0 P  P L  0 O D  0 0 1\
  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  U 1  1 1  U 1  0 0 I  C o  0\
 0 1  C o  0 O C  0 0 D  U 1  D L  U I  0 I U  U 1  0 O O  0 O D  0 0 \
1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  U 1  D L  U 1  U o  0 0 D  \
U 1  1 1  U 1  0 O C  0 O 0  0 O O  0 O D  C o  U 1  D L  U 1  0 0 L  \
0 O D  0 O O  0 O 0  0 0 0  U 1  1 1  U I  U 1  0 0 I  0 0 1  0 0 0  0\
 0 I  0 O 0  0 0 1  0 0 P  0 O D  0 O 0  0 0 D  U 1  D L  U I  C 0  U \
1  0 0 P  0 O D  0 0 P  0 O L  0 O 0  U 1  1 1  U I  U 1  C o  0 O L  \
C L  0 0 o  0 O C  U 1  1 1  U I  U 1  C o  0 0 1  0 0 P  0 O D  0 0 D\
  0 0 P  U 1  1 1  U I  U 1  0 O O  0 0 o  0 0 1  C o  0 0 P  0 O D  0\
 0 0  0 0 O  U 1  1 1  U 1  0 0 P  0 O 1  0 0 o  0 O C  C L  0 0 O  C \
o  0 O D  0 O L  U 1  1 1  U I  U 1  0 I 0  0 O 0  C o  0 0 1  U 1  C \
U  0 I D  1 1  U I  U 1  0 O D  0 O O  U 1  D L  U I  1 C  0 I D  U C \
 U I  1 0  U I  U o  U I  0 0 o  0 0 1  0 O L  0 O  U I  0 O 0  0 O L \
 0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 O D  o U  1 C  o U  o U  o U\
  o U  1 C  U I  P 0  U I  0 0 0  0 0 0  0 0 0  1 L  U I  1 O  U I  U \
C  0 I U  U 1  0 O P  0 0 D  0 0 0  0 0 O  0 0 1  0 0 I  C C  U 1  D L\
  U 1  D O  1 P  1 L  U 1  1 1  U 1  0 O C  0 O 0  0 0 P  0 O 1  0 0 0\
  0 O O  U 1  D L  U 1  o O  0 O D  0 O L  0 O 0  0 0 D  1 P  o 0  0 O\
 0  0 0 P  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  \
U 1  1 1  U 1  0 0 I  C o  0 0 1  C o  0 O C  0 0 D  U 1  D L  0 I U  \
U 1  0 O O  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  U 1 \
 D L  U 1  U o  0 0 D  U 1  1 1  U 1  0 O C  0 O 0  0 O O  0 O D  C o \
 U 1  D L  U 1  0 0 L  0 O D  0 O O  0 O 0  0 0 0  U 1  1 1  U 1  0 0 \
I  0 0 1  0 0 0  0 0 I  0 O 0  0 0 1  0 0 P  0 O D  0 O 0  0 0 D  U 1 \
 D L  C 0  U I  U 1  0 0 I  0 O L  0 0 0  0 0 P  U 1  1 1  U 1  0 0 I \
 0 O L  C o  0 I 0  C C  0 0 0  0 0 o  0 0 O  0 0 P  U 1  1 1  U 1  0 \
O O  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  U 1  1 1  U I  U 1\
  0 O U  0 O 0  0 0 O  0 0 1  0 O 0  U 1  1 1  U 1  0 0 L  0 0 0  0 0 \
P  0 O 0  0 0 D  U 1  1 1  U 1  0 O O  0 0 o  0 0 1  C o  0 0 P  0 O D\
  0 0 0  0 0 O  U 1  1 1  U 1  0 0 P  0 0 1  C o  0 O D  0 O L  0 O 0 \
 0 0 1  U 1  1 1  U 1  0 0 I  0 0 1  0 O 0  0 O C  0 O D  0 O 0  0 0 1\
  0 O 0  0 O O  U 1  1 1  U 1  0 0 P  0 O 1  0 0 o  0 O C  C L  0 0 O \
 C o  0 O D  0 O L  U 1  1 1  U 1  0 0 P  0 O D  0 0 P  0 O L  0 O 0  \
U 1  1 1  U 1  0 I 0  0 O 0  C o  0 0 1  U 1  1 1  U 1  0 O O  C o  0 \
0 P  0 O 0  C o  0 O O  0 O O  0 O 0  0 O O  U 1  1 1  U 1  0 O I  C o\
  0 0 O  C o  0 0 1  0 0 P  U 1  1 1  U 1  0 0 1  C o  0 0 P  0 O D  0\
 0 O  0 O U  U 1  1 1  U 1  0 0 D  0 O 0  C o  0 0 D  0 0 0  0 0 O  U \
1  1 1  U 1  0 O 0  0 0 I  0 O D  0 0 D  0 0 0  0 O O  0 O 0  U 1  1 1\
  U 1  0 0 D  0 0 P  0 0 o  0 O O  0 O D  0 0 0  U 1  1 1  U 1  0 O C \
 0 0 I  C o  C o  U 1  C U  0 I D  1 1  U 1  0 O D  0 O O  U 1  D L  1\
 C  0 I D  U C  U I  1 0  U I  U o  U I  0 0 o  0 0 1  0 O L  0 O  U I\
  o C  0 0 0  1 L  0 0 0  U I  P 0  U I  0 O P  0 0 D  0 0 0  0 0 O  U\
 I  1 P  U I  0 O L  0 0 0  C o  0 O O  0 0 D  U I  1 O  U I  0 O D  0\
 O D  o U  0 O D  o U  1 C  1 C  o U  0 O D  o U  1 C  0 O D  0 O D  U\
 I  1 O  U I  0 O D  o U  1 C  o U  o U  o U  o U  1 C  U I  1 0  U I \
 1 0  0 O  U I  0 O D  0 O I  U I  D U  D 1  U I  1 D  U I  D U  D 1  \
D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I \
 1 I  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 U  U\
 I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 I  U I  0 0\
 0  o C  1 L  0 0 0  U I  1 o  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L\
  1 L  1 L  U I  1 I  U I  0 O D  1 C  0 O  U I  0 O D  0 O I  U I  0 \
O U  0 O D  0 0 L  0 O 0  C D  0 O C  0 O 0  C D  0 0 1  0 O 0  0 0 D \
 0 0 o  0 O L  0 0 P  U I  D L  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 \
0 o  0 0 1  0 0 O  U I  o C  0 0 0  1 L  0 0 0  0 O  U I  0 O D  0 O I\
  U I  o C  0 0 0  1 L  0 0 0  U I  1 P  U I  0 O 1  C o  0 0 D  C D  \
0 O o  0 O 0  0 I 0  U I  1 O  U I  U C  0 O 0  0 0 1  0 0 1  0 0 0  0\
 0 1  U C  U I  1 0  U I  D L  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0\
 o  0 0 1  0 0 O  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O \
 U I  U I  0 O D  0 O I  U I  D O  D U  U I  1 D  U I  D O  D U  D L  \
U I  0 0 0  o C  1 L  0 0 0  U I  1 P  U I  0 0 0  1 L  0 0 0  o C  1 \
L  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U\
 I  1 U  U I  o U  0 O D  o U  o U  U I  1 I  U I  0 0 0  1 L  0 0 0  \
o C  1 L  0 O  U I  U I  0 O I  0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  \
1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  0 O D  0 0 O  U I\
  o C  0 0 0  1 L  0 0 0  U I  C 0  U I  U C  0 0 1  0 O 0  0 0 D  0 0\
 o  0 O L  0 0 P  U C  U I  C U  U I  C 0  U I  U C  0 O I  0 O D  0 O\
 L  0 O 0  0 0 D  U C  U I  C U  U I  D L  0 O  U I  U I  U I  0 0 0  \
1 L  0 0 0  o C  0 0 0  0 0 0  o C  1 L  0 0 0  0 0 0  1 L  1 L  U I  \
P 0  U I  0 I U  U I  0 I D  0 O  U I  U I  U I  0 0 o  0 0 1  0 O L  \
U I  P 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 \
0 0  0 0 0  U I  C 0  U I  U C  0 O I  0 O D  0 O L  0 O 0  U C  U I  \
C U  0 O  U I  U I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  o\
 U  1 C  1 C  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  \
o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  U C  0 O L  C o  C L  0 O 0  \
0 O L  U C  U I  C U  U I  1 0  0 O  U I  U I  U I  o U  o U  1 C  o U\
  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  P 0  U I  o U  1 C \
 1 C  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0\
 0  0 0 0  0 0 0  U I  C 0  U I  U C  0 0 P  0 O 1  0 0 o  0 O C  C L \
 0 0 O  C o  0 O D  0 O L  U C  U I  C U  U I  1 0  0 O  U I  U I  U I\
  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  U I  P 0  U I  o \
U  1 C  1 C  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o\
 C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  U C  0 O I  C o  0 0 O  C o  0\
 0 1  0 0 P  U C  U I  C U  U I  1 0  0 O  U I  U I  U I  0 0 0  1 L  \
0 0 0  o C  0 0 0  0 0 0  o C  1 L  0 0 0  0 0 0  1 L  1 L  U I  P 0  \
U I  0 O O  0 O D  C C  0 0 P  U I  1 O  U I  1 O  U I  0 O o  U I  1 \
1  U I  0 0 L  U I  1 0  U I  0 O I  0 0 0  0 0 1  U I  0 O o  U I  1 \
1  U I  0 0 L  U I  0 O D  0 0 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 \
0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 P  U I  0 O D  0 0 P  0 O 0\
  0 0 1  0 O D  0 0 P  0 O 0  0 O C  0 0 D  U I  1 O  U I  1 0  U I  0\
 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  0 0 L  U I  P 0  P 0  U I \
 U C  1 L  U C  U I  0 0 0  0 0 1  U I  0 0 O  0 0 0  0 0 P  U I  0 0 \
L  U I  P 0  P 0  U I  1 D  U I  1 C  U I  0 0 0  0 0 1  U I  0 0 L  U\
 I  P 0  P 0  U I  U C  U C  U I  1 0  0 O  U I  U I  U I  0 0 0  1 L \
 0 0 0  o C  0 0 0  0 0 0  o C  1 L  0 0 0  0 0 0  1 L  1 L  U I  1 P \
 U I  0 0 I  0 0 0  0 0 I  U I  1 O  U I  U 1  0 O I  0 O D  0 O L  0 \
O 0  U 1  U I  1 1  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 0  0 O  U I \
 U I  U I  0 O D  0 O I  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L \
 o C  0 0 0  0 0 0  0 0 0  U I  C 0  U I  U C  0 O I  0 O D  0 O L  0 \
O 0  0 0 P  0 I 0  0 0 I  0 O 0  U C  U I  C U  U I  P 0  P 0  U I  U \
C  0 O I  0 O D  0 O L  0 O 0  U C  U I  D L  0 O  U I  U I  U I  U I \
 0 O D  0 O I  U I  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0\
 P  U I  D L  0 O  U I  U I  U I  U I  U I  0 O D  0 O D  o U  o U  o \
U  o U  0 O D  o U  1 C  1 C  1 C  U I  1 O  U I  o C  0 0 0  0 0 0  o\
 C  1 L  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  0 0 U  0 0\
 o  0 O 0  0 0 o  0 O 0  L P  0 O D  0 O O  0 O 0  0 0 0  U I  P 0  U \
I  U C  1 C  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  C C  0 0 0  \
0 0 O  0 0 P  0 O D  0 0 O  0 0 o  0 O 0  0 O  U I  U I  U I  U I  0 O\
 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  o C  \
0 0 0  0 0 0  0 0 0  o C  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 1\
  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  o U  o U  1 C  o U \
 o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  1 1  U I  0 O D  0 O\
 D  1 C  0 O D  o U  o U  1 C  o U  o U  U I  1 1  U I  U C  U C  U I \
 1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C \
 U I  1 1  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  U C  U C  U I\
  1 1  U I  0 0 P  0 0 0  0 0 P  C o  0 O L  U I  P 0  U I  0 O L  0 O\
 0  0 0 O  U I  1 O  U I  o C  0 0 0  1 L  0 0 0  U I  C 0  U I  U C  \
0 0 1  0 O 0  0 0 D  0 0 o  0 O L  0 0 P  U C  U I  C U  U I  C 0  U I\
  U C  0 O I  0 O D  0 O L  0 O 0  0 0 D  U C  U I  C U  U I  1 0  U I\
  1 1  U I  C o  0 O L  0 O L  0 O D  0 0 O  0 O I  0 0 0  U I  P 0  U\
 I  0 0 0  1 L  0 0 0  o C  0 0 0  0 0 0  o C  1 L  0 0 0  0 0 0  1 L \
 1 L  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D D  \
1 L  U I  1 D  U I  D D  1 L  D L  U I  0 O D  o U  o U  1 C  1 C  1 C\
  0 O D  U I  1 U  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 \
C  o U  0 O D  1 C  0 O D  0 O  U I  U I  U I  U I  U I  0 O D  0 O I \
 U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 \
0  U I  C 0  U I  U C  0 0 P  0 I 0  0 0 I  0 O 0  U C  U I  C U  U I \
 C o  0 0 O  0 O O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C \
 0 0 0  0 0 0  0 0 0  U I  C 0  U I  U C  0 0 P  0 I 0  0 0 I  0 O 0  \
U C  U I  C U  U I  P 0  P 0  U I  U C  0 0 P  0 0 L  0 0 D  0 O 1  0 \
0 0  0 0 C  U C  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 I O  C\
 L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U \
I  0 0 D  0 O 0  0 0 P  P o  0 0 0  0 0 O  0 0 P  0 O 0  0 0 O  0 0 P \
 U I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 \
D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U I  C\
 U  U I  1 0  U I  1 1  U I  U C  0 0 P  0 0 L  0 0 D  0 O 1  0 0 0  0\
 0 C  0 0 D  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  0 O 0  0 O L\
  0 O D  0 O I  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0\
 0  0 0 0  0 0 0  U I  C 0  U I  U C  0 O 0  0 0 I  0 O D  0 0 D  0 0 \
0  0 O O  0 O 0  U C  U I  C U  U I  P I  U I  1 L  U I  D L  0 O  U I\
  U I  U I  U I  U I  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o\
  0 O U  0 O D  0 0 O  U I  1 P  U I  0 0 D  0 O 0  0 0 P  P o  0 0 0 \
 0 0 O  0 0 P  0 O 0  0 0 O  0 0 P  U I  1 O  U I  0 O D  0 0 O  0 0 P\
  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U\
  0 0 L  U I  C 0  U I  1 C  U I  C U  U I  1 0  U I  1 1  U I  U C  0\
 O 0  0 0 I  0 O D  0 0 D  0 0 0  0 O O  0 O 0  0 0 D  U C  U I  1 0  \
0 O  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D D  1 L  U I  1\
 D  U I  D D  1 L  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L\
  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 \
O  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I \
 U I  U I  0 O D  o U  1 C  0 O D  o U  o U  0 O D  0 O D  0 O D  0 O \
D  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  0 0 o  0\
 0 1  0 O L  U I  1 1  U I  D U  D 0  U I  1 1  U I  o U  o U  1 C  o \
U  o U  o U  o U  0 O D  o U  o U  1 C  0 O D  U I  1 1  U I  0 O D  0\
 O D  1 C  0 O D  o U  o U  1 C  o U  o U  U I  1 1  U I  U C  U C  U \
I  1 1  U I  U C  U C  U I  1 1  U I  U C  U C  U I  1 1  U I  U C  U \
C  U I  1 1  U I  C o  0 O L  0 O L  0 O D  0 0 O  0 O I  0 0 0  U I  \
P 0  U I  0 0 0  1 L  0 0 0  o C  0 0 0  0 0 0  o C  1 L  0 0 0  0 0 0\
  1 L  1 L  U I  1 0  0 O  U I  U I  0 I O  C L  0 O C  C C  0 0 I  0 \
O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  0 O 0  0 0 O  0 O O  o\
 C  0 O I  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  \
U I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D\
  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U I  C \
U  U I  1 0  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  D D  D 1  U I\
  1 D  U I  D D  D 1  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 \
O D  o U  U I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U \
I  U o  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 D \
 U I  0 O D  1 C  0 O  0 O O  0 O 0  0 O I  U I  o C  0 0 0  0 0 0  0 \
0 0  o C  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  0 0 O  C \
o  0 O C  0 O 0  U I  1 1  U I  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C\
  C o  0 O U  0 O 0  U I  1 1  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0\
 P  U I  1 1  U I  0 O O  0 O 0  0 0 D  C C  0 0 1  0 O D  0 0 I  0 0 \
P  0 O D  0 0 0  0 0 O  U I  1 1  U I  0 O U  0 O 0  0 0 O  0 0 1  0 O\
 0  U I  1 1  U I  0 O O  C o  0 0 P  0 O 0  U I  1 1  U I  0 0 D  0 O\
 1  0 0 0  0 0 C  C C  0 0 0  0 0 O  0 0 P  0 O 0  0 I O  0 0 P  U I  \
1 1  U I  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U I  1\
 1  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  1 1  U I  0 0 \
P  0 0 0  0 0 P  C o  0 O L  U I  1 1  U I  0 0 D  0 O 0  0 0 P  P o  \
0 0 0  0 0 0  0 O o  0 O D  0 O 0  U I  P 0  U I  U 1  U 1  U I  1 1  \
U I  C o  0 O L  0 O L  0 O D  0 0 O  0 O I  0 0 0  U I  P 0  U I  0 I\
 U  U I  0 I D  U I  1 0  U I  D L  0 O  U I  0 O D  0 O I  U I  D U  \
1 C  U I  1 D  U I  D U  1 C  D L  U I  o C  o C  0 0 0  0 0 0  o C  o\
 C  0 0 0  U I  1 U  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I\
  1 I  U I  0 0 0  o C  1 L  0 0 0  U I  1 I  U I  o U  o U  o U  o U \
 U I  1 o  U I  o U  1 C  1 C  0 O D  0 O  U I  o C  1 L  o C  0 0 0  \
0 0 0  1 L  o C  U I  P 0  U I  C 0  U I  C U  0 O  U I  0 O D  o U  o\
 U  o U  0 O D  0 O D  o U  1 C  0 O D  1 C  0 O D  U I  P 0  U I  o C\
  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U \
I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0\
 O  0 O U  U I  1 O  U I  U C  0 0 I  C o  0 0 1  0 O 0  0 0 O  0 0 P \
 C o  0 O L  C L  0 O L  0 0 0  C C  0 O o  0 O 0  0 O O  U C  U I  1 \
0  0 O  U I  0 O D  o U  o U  o U  0 O D  0 O D  o U  1 C  0 O D  1 C \
 0 O D  U I  P 0  U I  0 O D  o U  o U  o U  0 O D  0 O D  o U  1 C  0\
 O D  1 C  0 O D  U I  P 0  P 0  U I  U 1  0 0 P  0 0 1  0 0 o  0 O 0 \
 U 1  0 O  U I  0 O D  0 O D  0 O D  1 C  U I  P 0  U I  o C  1 L  o U\
  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U \
I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U \
 U I  1 O  U I  U C  0 0 I  C o  0 0 1  0 O 0  0 0 O  0 0 P  C o  0 O \
L  C L  0 O L  0 0 0  C C  0 O o  0 O 0  0 O O  0 0 I  0 O D  0 0 O  U\
 C  U I  1 0  0 O  U I  0 O D  0 O I  U I  1 C  D o  U I  1 D  U I  1 \
C  D o  D L  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I \
 1 D  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  U o  U I  o\
 U  o U  o U  o U  U I  1 o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 \
0 0  U I  U o  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 \
O  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 O D  \
0 O D  0 O D  1 C  U I  1 0  U I  P I  U I  1 L  U I  D L  0 O  U I  U\
 I  0 O D  0 O I  U I  0 O D  o U  o U  o U  0 O D  0 O D  o U  1 C  0\
 O D  1 C  0 O D  U I  D L  0 O  U I  U I  U I  o C  1 L  o C  0 0 0  \
0 0 0  1 L  o C  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O\
  U I  1 O  U I  1 O  U I  U C  P L  0 O D  0 0 D  C o  C L  0 O L  0 \
O 0  U I  L O  C o  0 0 1  0 O 0  0 0 O  0 0 P  C o  0 O L  U I  P P  \
0 O L  0 0 0  C C  0 O o  U C  U I  1 1  U I  U C  L L  P P  o o  P o \
 1 P  L I  0 0 o  0 0 O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  \
U o  0 0 D  P U  0 O C  0 0 0  0 O O  0 O 0  P 0  D U  D U  U L  0 0 O\
  C o  0 O C  0 O 0  P 0  U o  0 0 D  1 0  U C  U I  U o  U I  1 O  U \
I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  \
C 0  U I  1 L  U I  C U  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 \
O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I\
  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1\
 0  U I  1 0  U I  1 0  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 0 D  \
0 O 0  U I  D L  0 O  U I  U I  U I  o C  1 L  o C  0 0 0  0 0 0  1 L \
 o C  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O \
 U I  1 O  U I  U C  P C  0 0 O  C o  C L  0 O L  0 O 0  U I  L O  C o\
  0 0 1  0 O 0  0 0 O  0 0 P  C o  0 O L  U I  P P  0 O L  0 0 0  C C \
 0 O o  U C  U I  1 1  U I  U C  L L  P P  o o  P o  1 P  L I  0 0 o  \
0 0 O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o  0 0 D  P U  0\
 O C  0 0 0  0 O O  0 O 0  P 0  D U  D 1  U L  0 0 O  C o  0 O C  0 O \
0  P 0  U o  0 0 D  1 0  U C  U I  U o  U I  1 O  U I  0 0 D  0 I 0  0\
 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I\
  C U  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P\
  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 \
0 D  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  U I  1 0  U I \
 1 0  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D 1  D U  U I  \
1 D  U I  D 1  D U  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1\
 C  1 C  0 O D  U I  1 P  U I  o U  o U  o U  o U  0 O  U I  0 0 P  0 \
0 1  0 I 0  U I  D L  0 O  U I  U I  0 0 O  C o  0 O C  0 O 0  U I  P \
0  U I  0 0 O  C o  0 O C  0 O 0  U I  1 P  U I  0 O 0  0 0 O  C C  0 \
0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  \
U C  U I  1 0  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  \
D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  o U  1 C  0 O D  1 C  o \
U  1 C  o U  0 O D  0 O D  0 O D  0 O D  1 C  U I  P 0  U I  L 1  0 0 \
1  0 0 o  0 O 0  0 O  U I  0 0 0  o C  0 0 0  o C  1 L  o U  0 O D  0 \
O D  1 C  o U  o U  1 C  0 O D  0 O D  U I  P 0  U I  o O  C o  0 O L \
 0 0 D  0 O 0  0 O  U I  0 O D  0 O I  U I  0 0 1  0 O 0  0 O U  0 O 0\
  0 I O  0 0 D  U I  D L  0 O  U I  U I  0 0 0  0 0 0  o C  0 0 0  1 L\
  1 L  U I  P 0  U I  U C  1 C  D D  U C  0 O  U I  U I  0 O D  0 O I \
 U I  U C  0 O L  0 O D  0 0 D  0 0 P  0 0 1  0 O 0  0 0 I  0 O 0  C o\
  0 0 P  U C  U I  0 O D  0 0 O  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I \
O  0 0 D  U I  D L  0 O  U I  U I  U I  0 0 0  o C  0 0 0  o C  1 L  o\
 U  0 O D  0 O D  1 C  o U  o U  1 C  0 O D  0 O D  U I  P 0  U I  L 1\
  0 0 1  0 0 o  0 O 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D o  D P\
  U I  1 D  U I  D o  D P  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1\
 C  U I  1 P  U I  0 0 0  o C  1 L  0 0 0  U I  U o  U I  o C  o C  0 \
0 0  0 0 0  o C  o C  0 0 0  U I  U o  U I  o U  0 O D  o U  o U  U I \
 1 D  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U\
 I  U I  o C  1 L  o C  0 0 0  0 0 0  1 L  o C  U I  1 P  U I  C o  0 \
0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  1 O  U I  U C  C 0  P \
o  o C  o P  o C  L I  U I  0 0 C  0 O 1  0 O D  0 0 P  0 O 0  C U  U \
U  U U  P L  0 0 0  0 0 C  0 0 O  0 O L  0 0 0  C o  0 O O  U I  P o  \
0 0 o  0 0 1  0 0 1  0 O 0  0 0 O  0 0 P  0 O L  0 I 0  U I  L O  0 O \
L  C o  0 I 0  0 O D  0 0 O  0 O U  U U  U U  C 0  1 o  P o  o C  o P \
 o C  L I  C U  U C  U I  1 1  U I  U C  L L  P P  o o  P o  1 P  L I \
 0 0 o  0 0 O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o  0 0 D\
  P U  0 0 o  0 0 1  0 O L  P 0  U o  0 0 D  U L  0 O C  0 0 0  0 O O \
 0 O 0  P 0  D O  1 C  U L  0 0 O  C o  0 O C  0 O 0  P 0  U o  0 0 D \
 1 0  U C  0 O  U I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P\
  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 \
1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  \
0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O \
 U I  0 0 o  0 0 1  0 O L  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O \
L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0\
  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 O C  0\
 O 0  U I  1 0  U I  1 0  U I  1 0  U I  1 0  0 O  U I  0 O 0  0 O L  \
0 O D  0 O I  U I  1 O  U I  C o  0 0 O  0 I 0  U I  1 O  U I  0 I O  \
U I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  0 O I  0 0 0  0 0 1 \
 U I  0 I O  U I  0 O D  0 0 O  U I  0 0 0  0 0 0  0 0 0  0 0 0  U I  \
1 0  U I  C o  0 0 O  0 O O  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  \
0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U \
I  1 O  U I  U C  0 O 1  0 0 P  0 0 P  0 0 I  U C  U I  1 0  U I  1 0 \
 U I  0 0 0  0 0 1  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 O 0  0 \
0 O  0 O O  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  U L\
  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D o  U C  U I  1 0  U I  D L  \
0 O  U I  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O L\
  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O\
  U I  U C  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D o  U C  U I  \
1 1  U I  U C  U C  U I  1 0  0 O  U I  U I  0 0 0  0 0 0  o C  0 0 0 \
 1 L  1 L  U I  P 0  U I  U C  1 C  D o  U C  0 O  U I  U I  o C  1 L \
 o C  0 0 0  0 0 0  1 L  o C  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0 \
 0 0 O  0 O O  U I  1 O  U I  1 O  U I  U C  C 0  P o  o C  o P  o C  \
L I  U I  0 0 C  0 O 1  0 O D  0 0 P  0 O 0  C U  U U  U U  P L  0 0 0\
  0 0 C  0 0 O  0 O L  0 0 0  C o  0 O O  U I  P o  0 0 o  0 0 1  0 0 \
1  0 O 0  0 0 O  0 0 P  0 O L  0 I 0  U I  L O  0 O L  C o  0 I 0  0 O\
 D  0 0 O  0 O U  U U  U U  C 0  1 o  P o  o C  o P  o C  L I  C U  U \
C  U I  1 1  U I  U C  L L  P P  o o  P o  1 P  L I  0 0 o  0 0 O  L O\
  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o  0 0 D  P U  0 0 o  0 0 \
1  0 O L  P 0  U o  0 0 D  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  D O  \
1 C  U L  0 0 O  C o  0 O C  0 O 0  P 0  U o  0 0 D  1 0  U C  0 O  U \
I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1 \
 0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  0 0 o  0 0\
 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 \
P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 o  0 0 1\
  0 O L  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C\
 L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O \
L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  U \
I  1 0  U I  1 0  U I  1 0  0 O  U I  0 O 0  0 O L  0 O D  0 O I  U I \
 0 0 o  0 0 1  0 O L  U I  1 P  U I  0 O 0  0 0 O  0 O O  0 0 D  0 0 C\
  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  U L  0 O C  0 0 0  0 O O  0\
 O 0  P 0  1 C  D P  U C  U I  1 0  U I  D L  0 O  U I  U I  0 0 o  0 \
0 1  0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 1  \
0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  U L  0 O C  \
0 0 0  0 O O  0 O 0  P 0  1 C  D P  U C  U I  1 1  U I  U C  U C  U I \
 1 0  0 O  U I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  U I\
  U C  1 C  D P  U C  0 O  U I  U I  o C  1 L  o C  0 0 0  0 0 0  1 L \
 o C  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O \
 U I  1 O  U I  U C  C 0  P o  o C  o P  o C  L I  U I  0 0 C  0 O 1  \
0 O D  0 0 P  0 O 0  C U  U U  U U  P L  0 0 0  0 0 C  0 0 O  0 O L  0\
 0 0  C o  0 O O  U U  U U  C 0  1 o  P o  o C  o P  o C  L I  C U  U \
C  U I  1 1  U I  U C  L L  P P  o o  P o  1 P  L I  0 0 o  0 0 O  L O\
  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o  0 0 D  P U  0 0 o  0 0 \
1  0 O L  P 0  U o  0 0 D  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  D O  \
D 0  U L  0 0 O  C o  0 O C  0 O 0  P 0  U o  0 0 D  1 0  U C  0 O  U \
I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1 \
 0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  0 0 o  0 0\
 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 \
P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 o  0 0 1\
  0 O L  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C\
 L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O \
L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  U \
I  1 0  U I  1 0  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  o C  1 L\
  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 \
P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0\
 O U  U I  1 O  U I  U C  0 O O  0 O L  C o  0 0 o  0 O O  0 O D  0 0 \
0  0 0 0  0 0 O  0 O L  0 I 0  U C  U I  1 0  U I  P 0  P 0  U I  U C \
 0 0 P  0 0 1  0 0 o  0 O 0  U C  U I  D L  0 O  U I  U I  U I  o C  1\
 L  o C  0 0 0  0 0 0  1 L  o C  U I  1 P  U I  C o  0 0 I  0 0 I  0 O\
 0  0 0 O  0 O O  U I  1 O  U I  1 O  U I  U C  U U  U U  P L  0 0 0  \
0 0 C  0 0 O  0 O L  0 0 0  C o  0 O O  U I  C 0  P o  o C  o P  o C  \
L I  U I  0 0 D  0 O 0  C o  C L  0 O L  0 0 o  0 O 0  C U  P D  0 0 o\
  0 O O  0 O D  0 0 0  U U  U U  C 0  1 o  P o  o C  o P  o C  L I  C \
U  U C  U I  1 1  U I  U C  L L  P P  o o  P o  1 P  L I  0 0 o  0 0 O\
  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o  0 0 D  P U  0 0 o \
 0 0 1  0 O L  P 0  U o  0 0 D  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  \
D O  D I  U L  0 0 O  C o  0 O C  0 O 0  P 0  U o  0 0 D  1 0  U C  0 \
O  U I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0\
 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  0 0 o\
  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0 \
 0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 o  \
0 0 1  0 O L  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O\
 D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I \
 0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 \
0  U I  1 0  U I  1 0  U I  1 0  0 O  U I  0 O 0  0 O L  0 O D  0 O I \
 U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 \
0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  0 O C  C o\
  0 O U  0 0 O  0 O 0  0 0 P  D L  P U  0 I O  0 0 P  P 0  U C  U I  1\
 0  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  U C  U L  U C  U I  0 \
O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  C o  0 0 O  0 O O  U I  0 0\
 O  0 0 0  0 0 P  U I  U C  U L  C o  0 O C  0 0 I  D C  U C  U I  0 O\
 D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  U I  0 0\
 o  0 0 1  0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  0\
 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  U L  U\
 C  U I  1 1  U I  U C  U L  C o  0 O C  0 0 I  D C  U C  U I  1 0  0 \
O  U I  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  U C  0 0 I  0 O L  0 \
0 o  0 O U  0 O D  0 0 O  D L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0\
 O D  0 0 O  1 P  0 0 L  0 O D  0 O O  0 O 0  0 0 0  1 P  0 0 I  0 0 o\
  0 O L  0 0 D  C o  0 0 1  1 o  0 0 I  0 O L  C o  0 I 0  P U  0 0 o \
 0 0 1  0 O D  P 0  U C  U I  1 U  U I  0 0 o  0 0 1  0 O L  0 O  U I \
 U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  U I  U C  1 C  D O\
  U C  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  \
0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  U I  U C  1 C  D O  U C \
 0 O  U I  U I  o C  1 L  o C  0 0 0  0 0 0  1 L  o C  U I  1 P  U I  \
C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  1 O  U I  U C  \
C 0  P o  o C  o P  o C  L I  U I  0 0 C  0 O 1  0 O D  0 0 P  0 O 0  \
C U  U U  U U  P L  0 0 0  0 0 C  0 0 O  0 O L  0 0 0  C o  0 O O  U I\
  P o  0 0 o  0 0 1  0 0 1  0 O 0  0 0 O  0 0 P  0 O L  0 I 0  U I  L \
O  0 O L  C o  0 I 0  0 O D  0 0 O  0 O U  U U  U U  C 0  1 o  P o  o \
C  o P  o C  L I  C U  U C  U I  1 1  U I  U C  L L  P P  o o  P o  1 \
P  L I  0 0 o  0 0 O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o\
  0 0 D  P U  0 0 o  0 0 1  0 O L  P 0  U o  0 0 D  U L  0 O C  0 0 0 \
 0 O O  0 O 0  P 0  D O  1 C  U L  0 0 O  C o  0 O C  0 O 0  P 0  U o \
 0 0 D  1 0  U C  0 O  U I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U\
 I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  \
U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  \
0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U \
I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 0  U I  1 1  U I  0 0 o  0 0 \
1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P\
  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0\
 O C  0 O 0  U I  1 0  U I  1 0  U I  1 0  U I  1 0  0 O  U I  0 O D  \
0 O I  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 o  1\
 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O D  0 O O\
  0 O 0  0 0 0  1 P  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0  1 \
o  0 0 I  0 O L  C o  0 I 0  1 o  P U  0 0 L  0 O D  0 O O  0 O 0  0 0\
 0  C D  0 O D  0 O O  P 0  U C  U I  0 O D  0 0 O  U I  0 0 o  0 0 1 \
 0 O L  U I  D L  0 O  U I  U I  0 0 0  o C  1 L  U I  P 0  U I  0 0 o\
  0 0 1  0 O L  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0\
 O 0  U I  1 O  U I  U C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D \
L  1 o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 P  0 0 L  0 O\
 D  0 O O  0 O 0  0 0 0  1 P  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  \
0 O 0  1 o  0 0 I  0 O L  C o  0 I 0  1 o  P U  0 0 L  0 O D  0 O O  0\
 O 0  0 0 0  C D  0 O D  0 O O  P 0  U C  U I  1 1  U I  U C  0 O 1  0\
 0 P  0 0 P  0 0 I  0 0 D  D L  1 o  1 o  0 0 C  0 0 C  0 0 C  1 P  0 \
I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0  1 P  C C  0 0 0  0 O C  1\
 o  0 0 C  C o  0 0 P  C C  0 O 1  P U  0 0 L  P 0  U C  U I  1 0  0 O\
  U I  U I  o C  1 L  o C  0 0 0  0 0 0  1 L  o C  U I  1 P  U I  C o \
 0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  U I  1 O  U I  U C  U U \
 U U  P L  0 0 0  0 0 C  0 0 O  0 O L  0 0 0  C o  0 O O  U I  C 0  P \
o  o C  o P  o C  L I  U I  C L  0 O L  0 0 o  0 O 0  C U  P D  0 0 o \
 0 O O  0 O D  0 0 0  U U  U U  C 0  1 o  P o  o C  o P  o C  L I  C U\
  U C  U I  1 1  U I  U C  L L  P P  o o  P o  1 P  L I  0 0 o  0 0 O \
 L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  1 O  U o  0 0 D  P U  0 0 o  \
0 0 1  0 O L  P 0  U o  0 0 D  U L  0 O C  0 0 0  0 O O  0 O 0  P 0  D\
 O  D I  U L  0 0 O  C o  0 O C  0 O 0  P 0  U o  0 0 D  1 0  U C  0 O\
  U I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 \
0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  0 0 o \
 0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  \
0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 0  o\
 C  1 L  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C\
 L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O \
L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 0  U \
I  1 0  U I  1 0  U I  1 0  0 O  U I  0 0 0  1 L  1 L  1 L  1 L  o C  \
1 L  1 L  0 0 0  o C  1 L  o C  U I  P 0  U I  0 0 D  0 I 0  0 0 D  U \
I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U\
 I  1 U  U I  U 1  P U  U 1  0 O  U I  o U  1 C  o U  1 C  0 O D  1 C \
 o U  1 C  o U  1 C  o U  1 C  U I  P 0  U I  o O  C o  0 O L  0 0 D  \
0 O 0  0 O  U I  0 O D  0 O I  U I  0 0 I  0 O L  C o  0 I 0  0 O L  0\
 O D  0 0 D  0 0 P  U I  D L  0 O  U I  U I  0 O D  0 O I  U I  o C  1\
 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  \
1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O \
 0 O U  U I  1 O  U I  U C  C o  0 O O  0 O O  C D  0 0 I  0 O L  C o \
 0 I 0  0 O L  0 O D  0 0 D  0 0 P  U C  U I  1 0  U I  P 0  P 0  U I \
 U 1  0 O I  C o  0 O L  0 0 D  0 O 0  U 1  U I  C o  0 0 O  0 O O  U \
I  U C  U P  U P  o P  L U  L O  0 O L  C o  0 I 0  o C  0 0 O  0 O L \
 0 I 0  o C  0 0 O  0 O 0  U P  U P  U C  U I  0 0 O  0 0 0  0 0 P  U \
I  0 O D  0 0 O  U I  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0\
 0 P  U I  C 0  U I  1 L  U I  C U  U I  D L  0 O  U I  U I  U I  0 0 \
0  1 L  1 L  1 L  1 L  o C  1 L  1 L  0 0 0  o C  1 L  o C  U I  1 U  \
P 0  U I  U 1  0 0 o  0 0 1  0 O L  P 0  U 1  U I  1 U  U I  0 0 o  0 \
0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0\
 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 o  0 0 \
1  0 O L  U I  1 0  U I  1 U  U I  U 1  U L  0 O C  0 0 0  0 O O  0 O \
0  P 0  U 1  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  0 O  U\
 I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  0 0\
 0  1 L  1 L  1 L  1 L  o C  1 L  1 L  0 0 0  o C  1 L  o C  U I  1 U \
 P 0  U I  U 1  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D 0  U L  0 0 O \
 C o  0 O C  0 O 0  P 0  U o  0 0 D  U L  0 0 I  0 O L  C o  0 I 0  0 \
O L  0 O D  0 0 D  0 0 P  P 0  U o  0 0 D  U 1  U I  U o  U I  1 O  U \
I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o\
  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I \
 0 0 O  C o  0 O C  0 O 0  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O \
L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0\
  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 D  0 0 P  0 0 1 \
 U I  1 O  U I  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  \
U I  1 0  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  \
U I  1 O  U I  U C  1 1  U C  U I  1 1  U I  U C  0 I 1  0 I 1  U C  U\
 I  1 0  U I  1 0  U I  1 0  0 O  U I  U I  U I  0 0 O  C o  0 O C  0 \
O 0  U I  P 0  U I  0 0 O  C o  0 O C  0 O 0  U I  1 U  U I  U C  C 0 \
 P o  o C  o P  o C  L I  U I  0 O C  C o  0 O U  0 O 0  0 0 O  0 0 P \
 C o  C U  U I  1 O  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O\
  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 0 I  0 O L  C o  0 I 0  0\
 O L  0 O D  0 0 D  0 0 P  U I  1 0  U I  1 0  U I  1 U  U I  U C  U I\
  0 O D  0 0 P  0 O 0  0 O C  0 0 D  U I  1 0  C 0  1 o  P o  o C  o P\
  o C  L I  C U  U C  0 O  U I  U I  U I  o U  1 C  o U  1 C  0 O D  1\
 C  o U  1 C  o U  1 C  o U  1 C  U I  P 0  U I  L 1  0 0 1  0 0 o  0 \
O 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 \
0 0  1 L  1 L  1 L  1 L  o C  1 L  1 L  0 0 0  o C  1 L  o C  U I  1 U\
  P 0  U I  U 1  0 0 o  0 0 1  0 O L  P 0  U 1  U I  1 U  U I  0 0 o  \
0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0\
 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 o  0 \
0 1  0 O L  U I  1 0  U I  1 U  U I  U 1  U L  0 O C  0 0 0  0 O O  0 \
O 0  P 0  U 1  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  0 O \
 U I  0 O D  0 O I  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I\
  D L  0 O  U I  U I  0 0 0  1 L  1 L  1 L  1 L  o C  1 L  1 L  0 0 0 \
 o C  1 L  o C  U I  1 U  P 0  U I  U 1  U L  0 0 1  0 O 0  0 O U  0 O\
 0  0 I O  0 0 D  P 0  U 1  U I  1 U  U I  0 0 1  0 O 0  0 O U  0 O 0 \
 0 I O  0 0 D  0 O  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  \
0 0 D  0 O 0  0 0 P  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0  U I  P 0 \
 P 0  U I  U C  U C  U I  D L  0 O  U I  U I  0 0 0  1 L  1 L  1 L  1 \
L  o C  1 L  1 L  0 0 0  o C  1 L  o C  U I  1 U  P 0  U I  U 1  U L  \
0 0 D  0 O 0  0 0 P  P o  0 0 0  0 0 0  0 O o  0 O D  0 O 0  P 0  U 1 \
 U I  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I \
 0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U\
 I  1 O  U I  0 0 D  0 O 0  0 0 P  P o  0 0 0  0 0 0  0 O o  0 O D  0 \
O 0  U I  1 0  0 O  U I  0 O D  0 O I  U I  0 O D  C C  0 0 0  0 0 O  \
0 O D  0 O C  C o  0 O U  0 O 0  U I  C o  0 0 O  0 O O  U I  0 0 O  0\
 0 0  0 0 P  U I  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C  C o  0 O U  \
0 O 0  U I  P 0  P 0  U I  U C  U C  U I  D L  0 O  U I  U I  0 0 0  1\
 L  1 L  1 L  1 L  o C  1 L  1 L  0 0 0  o C  1 L  o C  U I  1 U  P 0 \
 U I  U 1  U L  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C  C o  0 O U  0 \
O 0  P 0  U 1  U I  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  \
U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0\
 0 o  0 0 D  U I  1 O  U I  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C  C \
o  0 O U  0 O 0  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  D 0  D I \
 U I  1 D  U I  D 0  D I  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 \
C  U I  1 I  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U\
  0 O D  1 C  0 O D  U I  1 I  U I  o U  0 O D  o U  o U  0 O  U I  0 \
O D  0 O I  U I  0 O O  C o  0 0 P  0 O 0  U I  P 0  P 0  U I  U C  U \
C  U I  D L  0 O  U I  U I  0 O O  C o  0 0 P  0 O 0  U I  P 0  U I  o\
 L  0 0 0  0 0 O  0 O 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D \
L  0 O  U I  U I  0 O O  0 O 0  0 0 D  C C  0 0 1  0 O D  0 0 I  0 0 P\
  0 O D  0 0 0  0 0 O  U I  1 U  P 0  U I  U C  C I  0 0 O  C I  0 0 O\
  P L  C o  0 0 P  0 O 0  D L  U I  U o  0 0 D  U C  U I  U o  U I  0 \
O O  C o  0 0 P  0 O 0  0 O  U I  o U  1 C  0 O D  1 C  0 O D  o U  o \
U  1 C  o U  1 C  1 C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U  0\
 0 o  0 O D  U I  1 P  U I  o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 O \
0  0 O C  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 O \
D  C C  0 0 0  0 0 O  o U  0 O C  C o  0 O U  0 O 0  U I  P 0  U I  U \
1  P L  0 O 0  0 O I  C o  0 0 o  0 O L  0 0 P  L P  0 O D  0 O O  0 O\
 0  0 0 0  1 P  0 0 I  0 0 O  0 O U  U 1  U I  1 1  U I  0 0 P  0 O 1 \
 0 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  o U  0 O C  C o  0 O U  \
0 O 0  U I  P 0  U I  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C  C o  0 O\
 U  0 O 0  U I  1 0  0 O  U I  0 O D  0 O I  U I  D O  1 C  U I  1 D  \
U I  D O  1 C  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I \
 1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  0\
 0 0  o C  1 L  0 0 0  U I  U o  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0\
 0 0  1 L  0 O  U I  0 O D  0 O I  U I  C o  0 O L  0 O L  0 O D  0 0 \
O  0 O I  0 0 0  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  0 \
0 0  0 0 1  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  C o  0 O L  0 O L\
  0 O D  0 0 O  0 O I  0 0 0  U I  1 0  U I  P O  U I  1 C  U I  D L  \
0 O  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1\
 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  o U  0 0 O  0 O I  0 0 0  U I \
 1 O  U I  0 0 P  0 I 0  0 0 I  0 O 0  U I  P 0  U I  U 1  L P  0 O D \
 0 O O  0 O 0  0 0 0  U 1  U I  1 1  U I  0 O D  0 0 O  0 O I  0 0 0  \
o P  C o  C L  0 O 0  0 O L  0 0 D  U I  P 0  U I  0 I U  U I  U 1  L \
1  0 O D  0 0 P  0 O L  0 O 0  U 1  U I  D L  U I  0 0 O  C o  0 O C  \
0 O 0  U I  1 1  U I  U 1  L O  0 O L  0 0 0  0 0 P  U 1  U I  D L  U \
I  0 O O  0 O 0  0 0 D  C C  0 0 1  0 O D  0 0 I  0 0 P  0 O D  0 0 0 \
 0 0 O  U I  1 1  U I  U 1  o 0  0 O 0  0 0 O  0 0 1  0 O 0  U 1  U I \
 D L  U I  0 O U  0 O 0  0 0 O  0 0 1  0 O 0  U I  1 1  U I  U 1  0 O \
O  C o  0 0 P  0 O 0  C o  0 O O  0 O O  0 O 0  0 O O  U 1  U I  D L  \
U I  0 O O  C o  0 0 P  0 O 0  U I  0 I D  U I  1 0  0 O  U I  0 O 0  \
0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  o U  1 C  0 O D  1 C  0 \
O D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P \
 o U  0 0 O  0 O I  0 0 0  U I  1 O  U I  0 0 P  0 I 0  0 0 I  0 O 0  \
U I  P 0  U I  U 1  L P  0 O D  0 O O  0 O 0  0 0 0  U 1  U I  1 1  U \
I  0 O D  0 0 O  0 O I  0 0 0  o P  C o  C L  0 O 0  0 O L  0 0 D  U I\
  P 0  U I  C o  0 O L  0 O L  0 O D  0 0 O  0 O I  0 0 0  U I  1 0  0\
 O  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U \
I  1 P  U I  0 0 D  0 O 0  0 0 P  L O  0 0 1  0 0 0  0 0 I  0 O 0  0 0\
 1  0 0 P  0 I 0  U I  1 O  U I  U 1  o O  C o  0 0 O  C o  0 0 1  0 0\
 P  C D  o U  0 O C  C o  0 O U  0 O 0  U 1  U I  1 1  U I  0 O I  C o\
  0 0 O  C o  0 0 1  0 0 P  U I  1 0  0 O  U I  0 O D  0 O I  U I  D U\
  D U  U I  1 D  U I  D U  D U  D L  U I  o U  o U  0 O D  o U  0 O D \
 o U  o U  1 C  1 C  0 O D  U I  U o  U I  0 O D  o U  o U  1 C  1 C  \
1 C  0 O D  U I  1 P  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U \
I  1 I  U I  o U  0 O D  o U  o U  U I  1 o  U I  o C  o C  0 0 0  0 0\
 0  o C  o C  0 0 0  U I  1 P  U I  0 O D  1 C  1 C  o U  0 O D  1 C  \
1 C  o U  1 C  o U  0 O D  1 C  0 O D  0 O  U I  0 O D  0 O I  U I  1 \
O  U I  0 0 O  0 0 0  0 0 P  U I  o U  1 C  o U  1 C  0 O D  1 C  o U \
 1 C  o U  1 C  o U  1 C  U I  1 0  U I  C o  0 0 O  0 O O  U I  0 0 O\
  0 0 0  0 0 P  U I  C o  0 0 O  0 I 0  U I  1 O  U I  0 I O  U I  0 O\
 D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  0 O I  0 0 0  0 0 1  U I  0 \
I O  U I  0 O D  0 0 O  U I  0 O D  o U  o U  0 O D  0 O D  1 C  o U  \
o U  0 O D  U I  1 0  U I  C o  0 0 O  0 O O  U I  0 0 O  0 0 0  0 0 P\
  U I  U C  U P  L O  o P  P D  L C  P C  L I  L O  L I  o C  L L  L C\
  U P  P 0  U C  U I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  D L\
  0 O  U I  U I  0 O D  0 O I  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O \
 0 0 D  U I  D L  0 O  U I  U I  U I  0 O D  0 O I  U I  D O  D 1  U I\
  1 D  U I  D O  D 1  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  \
1 L  U I  1 o  U I  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  0 0 0  o C \
 1 L  0 0 0  0 O  U I  U I  U I  0 O D  0 O I  U I  U C  U P  0 0 I  0\
 I 0  o O  0 0 o  0 0 O  C C  0 0 P  0 O D  0 0 0  0 0 O  D L  0 0 I  \
0 O L  C o  0 I 0  0 O C  0 O 0  0 O O  0 O D  C o  1 O  U C  U I  0 0\
 O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  0 O L  \
0 O D  C L  U I  1 P  U I  0 0 o  0 0 O  0 0 U  0 0 o  0 0 0  0 0 P  0\
 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 1  0 O 0  0 \
O U  0 O 0  0 I O  0 0 D  U I  1 0  U I  C o  0 0 O  0 O O  U I  U C  \
0 0 O  0 0 0  0 0 P  0 0 I  0 O L  C o  0 I 0  C o  C L  0 O L  0 O 0 \
 U C  U I  0 0 O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  0 0 o  0 0 1  \
0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 o  0 0 O  0 0 U  0 0 o  0\
 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 \
0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  1 0  U I  C o  0 0 O  0 O\
 O  U I  U C  0 O L  0 O D  0 0 D  0 0 P  0 0 1  0 O 0  0 0 I  0 O 0  \
C o  0 0 P  U C  U I  0 0 O  0 0 0  0 0 P  U I  0 O D  0 0 O  U I  0 0\
 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 o  0 0 O  0 0 \
U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1\
 O  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  1 0  U I  D L \
 0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D U  D D  U I  1 D  U I  \
D U  D D  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  U \
I  U I  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C\
  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L O  0 0 1  0 0 0  0 0 I  0\
 O 0  0 0 1  0 0 P  0 I 0  U I  1 O  U I  U C  o U  0 0 D  L O  0 O L \
 C o  0 I 0  C o  C L  0 O L  0 O 0  U C  U I  1 1  U I  U C  0 0 P  0\
 0 1  0 0 o  0 O 0  U C  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 0 D \
 0 O 0  U I  D L  0 O  U I  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U\
  o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L O  0 \
0 1  0 0 0  0 0 I  0 O 0  0 0 1  0 0 P  0 I 0  U I  1 O  U I  U C  o U\
  0 0 D  L O  0 O L  C o  0 I 0  C o  C L  0 O L  0 O 0  U C  U I  1 1\
  U I  U C  0 0 P  0 0 1  0 0 o  0 O 0  U C  U I  1 0  0 O  U I  0 O 0\
  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  o U  o U  o U  1 C  0 \
O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U C  o L  o C  L 1  U\
 I  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  0 O D  0 0 D\
  0 0 I  0 O L  C o  0 I 0  C o  C L  0 O L  0 O 0  U C  U I  1 U  U I\
  0 0 o  0 0 1  0 O L  U I  1 0  0 O  U I  0 O D  0 O I  U I  0 0 D  0\
 O 1  0 0 0  0 0 C  C C  0 0 0  0 0 O  0 0 P  0 O 0  0 I O  0 0 P  U I\
  D L  0 O  U I  U I  0 O D  0 O I  U I  D I  1 C  U I  1 D  U I  D I \
 1 C  D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 I  U I  0 O D  0 O D  o\
 U  1 C  0 O D  o U  0 O D  o U  U I  1 U  U I  o U  0 O D  o U  o U  \
U I  1 I  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I \
 0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  o C  1 L  0\
 0 0  o C  0 O  U I  U I  0 O D  0 O I  U I  0 0 D  0 O 1  0 0 0  0 0 \
C  C C  0 0 0  0 0 O  0 0 P  0 O 0  0 I O  0 0 P  U I  P 0  P 0  U I  \
U C  0 O I  C o  0 0 L  U C  U I  D L  0 O  U I  U I  U I  o C  1 L  o\
 C  0 0 0  0 0 0  1 L  o C  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0\
 0 O  0 O O  U I  1 O  0 O  U I  1 O  U I  U C  L I  0 O 0  0 O C  0 0\
 0  0 0 L  0 O 0  U I  0 O I  0 0 1  0 0 0  0 O C  U I  L 1  0 O 0  C \
o  0 O C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  U I  o O  C o  0 0 L\
  0 0 0  0 0 1  0 O D  0 0 P  0 O 0  0 0 D  U C  U I  1 1  U I  U C  L\
 L  P P  o o  P o  1 P  L I  0 0 o  0 0 O  L O  0 O L  0 0 o  0 O U  0\
 O D  0 0 O  1 O  U o  0 0 D  P U  0 O C  0 0 0  0 O O  0 O 0  P 0  D \
1  U L  0 0 O  C o  0 O C  0 O 0  P 0  U o  0 0 D  1 0  U C  0 O  U I \
 U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0\
 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  0 0 o  0 0 1\
  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P \
 0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 \
O C  0 O 0  U I  1 0  U I  1 0  U I  1 0  0 O  U I  1 0  0 O  U I  U I\
  0 O 0  0 O L  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  0 0 O  C \
o  0 O C  0 O 0  U I  0 O D  0 0 O  U I  o C  1 L  0 0 0  1 L  o C  0 \
0 0  U I  D L  0 O  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O \
 U I  U I  U I  U I  o C  0 0 0  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  0\
 0 0  o C  U I  P 0  U I  1 O  0 O  U I  U C  U o  0 0 D  P U  0 O C  \
0 0 0  0 O O  0 O 0  P 0  D U  U L  0 0 O  C o  0 O C  0 O 0  P 0  U o\
  0 0 D  U L  0 0 o  0 0 1  0 O L  P 0  U o  0 0 D  U L  0 O D  C C  0\
 0 0  0 0 O  0 O D  0 O C  C o  0 O U  0 O 0  P 0  U o  0 0 D  U L  0 \
O I  C o  0 0 O  C o  0 0 1  0 0 P  P 0  U o  0 0 D  U L  0 O I  C o  \
0 0 L  C D  0 O C  0 0 0  0 O O  0 O 0  P 0  1 L  U C  0 O  U I  U o  \
U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  \
0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  0 0 o  0 0 1  0 O \
L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0\
  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 O  C o  0 O C  0\
 O 0  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L \
 U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  \
0 0 o  0 0 D  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 0  U I  1 1  \
U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0\
 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U \
I  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C  C o  0 O U  0 O 0  U I  1 0\
  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I\
  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  \
U I  1 O  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U I  1 0  U I  1 \
0  0 O  U I  1 0  0 O  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I \
 0 0 P  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0  1 L  0 0 0  1 L\
  0 0 0  0 0 0  o C  0 0 0  o C  U I  P 0  U I  1 O  0 O  U I  U C  U \
o  0 0 D  P U  0 O C  0 0 0  0 O O  0 O 0  P 0  D U  U L  0 0 O  C o  \
0 O C  0 O 0  P 0  U o  0 0 D  U L  0 0 o  0 0 1  0 O L  P 0  U o  0 0\
 D  U L  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C  C o  0 O U  0 O 0  P \
0  U o  0 0 D  U L  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  P 0  U o  0 \
0 D  U L  0 O I  C o  0 0 L  C D  0 O C  0 0 0  0 O O  0 O 0  P 0  1 L\
  U C  0 O  U I  U o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U \
I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U\
 I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 \
o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I\
  0 0 O  C o  0 O C  0 O 0  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O\
 L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O \
0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 o  0 0 1  0 O L\
  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I\
  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 \
o  0 0 D  U I  1 O  U I  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C  C o  \
0 O U  0 O 0  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U\
 I  1 O  U I  U 1  0 0 o  0 0 P  0 O I  1 D  D P  U 1  U I  1 0  U I  \
1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  \
U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 \
D  U I  1 O  U I  0 O I  C o  0 0 O  C o  0 0 1  0 0 P  U I  1 P  U I \
 0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U 1  0 0 o  0 \
0 P  0 O I  1 D  D P  U 1  U I  1 0  U I  1 0  U I  1 0  0 O  U I  1 0\
  0 O  U I  U I  U I  0 O D  0 O I  U I  0 0 I  0 O L  C o  0 I 0  0 O\
 L  0 O D  0 0 D  0 0 P  U I  D L  0 O  U I  U I  U I  U I  o C  0 0 0\
  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  0 0 0  o C  U I  1 U  P 0  U I  \
U C  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  P 0  U C  U\
 I  1 U  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0\
 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I\
  1 O  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  0 0 I  0 O L  C o  0 I\
 0  0 O L  0 O D  0 0 D  0 0 P  U I  1 0  U I  1 P  U I  0 0 1  0 O 0 \
 0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  1 1  U C  U I  1 1\
  U I  U C  0 I 1  0 I 1  U C  U I  1 0  U I  1 0  0 O  U I  U I  U I \
 0 O D  0 O I  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  0 0 D  U I  D L\
  0 O  U I  U I  U I  U I  o C  0 0 0  1 L  0 0 0  1 L  0 0 0  0 0 0  \
o C  0 0 0  o C  U I  1 U  P 0  U I  U 1  U L  0 0 1  0 O 0  0 O U  0 \
O 0  0 I O  0 0 D  P 0  U 1  U I  1 U  U I  0 0 1  0 O 0  0 O U  0 O 0\
  0 I O  0 0 D  0 O  U I  U I  U I  o C  1 L  o C  0 0 0  0 0 0  1 L  \
o C  U I  1 P  U I  C o  0 0 I  0 0 I  0 O 0  0 0 O  0 O O  U I  1 O  \
U I  1 O  U I  U C  P D  0 O O  0 O O  U I  0 0 P  0 0 0  U I  L 1  0 \
O 0  C o  0 O C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  U I  o O  C o\
  0 0 L  0 0 0  0 0 1  0 O D  0 0 P  0 O 0  0 0 D  U C  U I  1 1  U I \
 U C  L L  P P  o o  P o  1 P  L I  0 0 o  0 0 O  L O  0 O L  0 0 o  0\
 O U  0 O D  0 0 O  1 O  U o  0 0 D  1 0  U C  U I  U o  U I  o C  0 0\
 0  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  0 0 0  o C  U I  1 0  U I  1 0\
  0 O  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C \
 1 C  U I  1 P  U I  C o  0 O O  0 O O  P o  0 0 0  0 0 O  0 0 P  0 O \
0  0 I O  0 0 P  o o  0 O 0  0 0 O  0 0 o  o U  0 0 P  0 O 0  0 O C  0\
 0 D  U I  1 O  U I  o C  1 L  o C  0 0 0  0 0 0  1 L  o C  U I  1 0  \
0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  0 O D  0 O I  \
U I  0 0 O  0 0 0  0 0 P  U I  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D \
 0 0 D  0 0 P  U I  0 O D  0 0 D  U I  o L  0 0 0  0 0 O  0 O 0  U I  \
D L  0 O  U I  U I  U I  0 O D  0 O I  U I  o C  1 L  o U  1 C  1 C  0\
 O D  1 C  0 O D  1 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O\
 0  0 0 P  L U  0 O 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U \
I  U C  C o  0 O O  0 O O  C D  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D\
  0 0 D  0 0 P  U C  U I  1 0  U I  P 0  P 0  U I  U 1  0 O I  C o  0 \
O L  0 0 D  0 O 0  U 1  U I  D L  0 O  U I  U I  U I  U I  0 O D  o U \
 1 C  o U  0 O D  1 C  1 C  U I  P 0  U I  0 0 O  C o  0 O C  0 O 0  U\
 I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  1\
 0  U I  U C  U I  1 0  U I  C 0  U I  1 C  U I  C U  0 O  U I  U I  U\
 I  U I  o C  0 0 0  0 0 0  1 L  U I  P 0  U I  C 0  0 O  U I  1 O  U \
I  U C  L O  0 O L  C o  0 I 0  U I  U C  U I  1 U  U I  0 O D  o U  1\
 C  o U  0 O D  1 C  1 C  U I  1 U  U I  U C  U I  L O  0 O L  C o  0 \
I 0  o P  0 O D  0 0 D  0 0 P  U C  U I  1 1  U I  U C  L L  P P  o o \
 P o  1 P  L I  0 0 o  0 0 O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O  \
1 O  U o  0 0 D  P U  0 O C  0 0 0  0 O O  0 O 0  P 0  1 C  D 0  U L  \
0 0 O  C o  0 O C  0 O 0  P 0  U o  0 0 D  U L  0 0 I  0 O L  C o  0 I\
 0  0 O L  0 O D  0 0 D  0 0 P  P 0  U o  0 0 D  1 0  U C  0 O  U I  U\
 o  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O\
 U  0 0 L  U I  C 0  U I  1 L  U I  C U  U I  1 1  U I  0 0 o  0 0 1  \
0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0\
 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 O D  o U  1 C \
 o U  0 O D  1 C  1 C  U I  1 0  U I  1 1  U I  0 0 o  0 0 1  0 O L  0\
 O L  0 O D  C L  U I  1 P  U I  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C \
D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 D  0 0 P  0 0 1  U I\
  1 O  U I  0 0 I  0 O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U I \
 1 0  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I \
 1 O  U I  U C  1 1  U C  U I  1 1  U I  U C  0 I 1  0 I 1  U C  U I  \
1 0  U I  1 0  U I  1 0  U I  1 0  0 O  U I  C U  0 O  U I  U I  U I  \
U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1\
 P  U I  C o  0 O O  0 O O  P o  0 0 0  0 0 O  0 0 P  0 O 0  0 I O  0 \
0 P  o o  0 O 0  0 0 O  0 0 o  o U  0 0 P  0 O 0  0 O C  0 0 D  U I  1\
 O  U I  o C  0 0 0  0 0 0  1 L  U I  1 0  0 O  U I  0 O 0  0 I O  C C\
  0 O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U\
 I  0 O D  0 O I  U I  D I  D o  U I  1 D  U I  D I  D o  D L  U I  o \
U  0 O D  1 C  o U  U I  1 U  U I  o C  o C  0 0 0  0 0 0  o C  o C  0\
 0 0  U I  1 P  U I  o U  o U  o U  o U  U I  1 U  U I  0 0 0  0 0 0  \
o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 o  U I  o U  o U  o U  o U\
  0 O  U I  o U  1 C  0 O D  1 C  o U  1 C  o U  0 O D  0 O D  0 O D  \
0 O D  1 C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o\
  0 O U  0 O D  0 0 O  U I  1 P  U I  C o  0 O O  0 O O  P L  0 O D  0\
 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  o U  0 0 P  0 O 0  0 O C\
  U I  1 O  U I  0 O 1  C o  0 0 O  0 O O  0 O L  0 O 0  U I  P 0  U I\
  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U\
 I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U I  C U  U I  1 0  \
U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  P 0  U I  0 0 0  1 L  1 L  1 \
L  1 L  o C  1 L  1 L  0 0 0  o C  1 L  o C  U I  1 1  U I  0 O L  0 O\
 D  0 0 D  0 0 P  0 O D  0 0 P  0 O 0  0 O C  U I  P 0  U I  o U  1 C \
 0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 1  U I  0 0 P\
  0 0 0  0 0 P  C o  0 O L  o U  0 0 P  0 O 0  0 O C  0 0 D  U I  P 0 \
 U I  0 0 P  0 0 0  0 0 P  C o  0 O L  U I  1 1  U I  0 O D  0 0 D  o \
O  0 0 0  0 O L  0 O O  0 O 0  0 0 1  U I  P 0  U I  0 0 0  o C  0 0 0\
  o C  1 L  o U  0 O D  0 O D  1 C  o U  o U  1 C  0 O D  0 O D  U I  \
1 0  0 O  U I  0 O D  0 O I  U I  D 0  D o  U I  1 D  U I  D 0  D o  D\
 L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 U  U I  o U  o U \
 0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 U  U I  o C  0 0\
 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 I  U I  o U  0 O D  1 C  \
o U  U I  U o  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0\
 O D  U I  1 D  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  \
0 O D  0 O  U I  0 O D  0 O I  U I  D I  1 C  U I  1 D  U I  D I  1 C \
 D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  U o  U I  0\
 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  0 0 1  0 O 0  0 0 P \
 0 0 o  0 0 1  0 0 O  U I  o U  1 C  0 O D  1 C  o U  1 C  o U  0 O D \
 0 O D  0 O D  0 O D  1 C  0 O  U I  0 O D  0 O I  U I  D 1  D D  U I \
 1 D  U I  D 1  D D  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  \
1 C  1 C  0 O D  U I  U o  U I  0 O D  1 C  0 O  U I  0 O D  0 O I  U \
I  D 0  D U  U I  1 D  U I  D 0  D U  D L  U I  0 O D  o U  o U  1 C  \
1 C  1 C  0 O D  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 \
0 0  U I  1 U  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  U o \
 U I  o U  0 O D  o U  o U  U I  U o  U I  o C  1 L  0 0 0  o C  0 O  \
0 O O  0 O 0  0 O I  U I  0 O D  o U  0 O D  1 C  o U  0 O D  1 C  1 C\
  1 C  1 C  0 O D  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  \
0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 O D  C C  0 0 0  0 0 O  0 O\
 D  0 O C  C o  0 O U  0 O 0  U I  1 1  U I  0 0 D  0 O 0  0 0 P  0 0 \
1  0 O 0  0 0 D  0 0 0  0 O L  0 0 L  0 O 0  0 O O  U I  P 0  U I  L 1\
  0 0 1  0 0 o  0 O 0  U I  1 1  U I  0 0 1  0 O 0  0 O U  U I  P 0  U\
 I  o L  0 0 0  0 0 O  0 O 0  U I  1 0  U I  D L  0 O  U I  0 0 I  0 0\
 1  0 O D  0 0 O  0 0 P  U I  U C  0 0 I  0 O L  C o  0 I 0  0 0 D  0 \
O 0  0 0 P  0 0 1  0 O 0  0 0 D  0 0 0  0 O L  0 0 L  0 O 0  0 O O  U \
C  U I  1 1  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  0 0 D  0 O 0  0 \
0 P  0 0 1  0 O 0  0 0 D  0 0 0  0 O L  0 0 L  0 O 0  0 O O  0 O  U I \
 0 O D  0 O I  U I  0 0 o  0 0 1  0 O L  U I  P 0  P 0  U I  o L  0 0 \
0  0 0 O  0 O 0  U I  D L  0 O  U I  U I  0 I O  C L  0 O C  C C  0 0 \
I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  0 O 0  0 0 O  0 O\
 O  o C  0 O I  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 \
I 0  U I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  \
0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U \
I  C U  U I  1 0  U I  1 0  0 O  U I  U I  0 0 1  0 O 0  0 0 P  0 0 o \
 0 0 1  0 0 O  0 O  U I  0 O D  0 O I  U I  0 0 D  0 O 0  0 0 P  0 0 1\
  0 O 0  0 0 D  0 0 0  0 O L  0 0 L  0 O 0  0 O O  U I  D L  0 O  U I \
 U I  o U  1 C  1 C  1 C  0 O D  o U  0 O D  1 C  U I  P 0  U I  L 1  \
0 0 1  0 0 o  0 O 0  0 O  U I  U I  0 O D  0 O I  U I  U C  U P  U P  \
o P  L U  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  U P  U P  U C  U I  0 \
O D  0 0 O  U I  0 0 o  0 0 1  0 O L  U I  D L  0 O  U I  U I  U I  0 \
0 o  0 0 1  0 O L  U I  P 0  U I  0 0 o  0 0 1  0 O L  U I  1 P  U I  \
0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  U P  \
U P  o P  L U  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  U P  U P  U C  U \
I  1 1  U I  U C  U C  U I  1 0  0 O  U I  U I  U I  o U  1 C  1 C  1 \
C  0 O D  o U  0 O D  1 C  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O \
0  0 O  U I  U I  0 O D  0 O I  U I  0 0 1  0 O 0  0 O U  U I  C o  0 \
0 O  0 O O  U I  U C  0 0 O  0 0 0  0 0 P  0 0 I  0 O L  C o  0 I 0  C\
 o  C L  0 O L  0 O 0  U C  U I  0 O D  0 0 O  U I  0 0 1  0 O 0  0 O \
U  U I  D L  0 O  U I  U I  U I  o U  1 C  1 C  1 C  0 O D  o U  0 O D\
  1 C  U I  P 0  U I  o O  C o  0 O L  0 0 D  0 O 0  0 O  U I  U I  U \
I  0 O D  0 O I  U I  1 C  D 1  U I  1 D  U I  1 C  D 1  D L  U I  0 0\
 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  o C  0 0 0  0 0\
 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 P  U I  o U  1 C  o U  0 O D  1 \
C  1 C  1 C  0 O  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C\
  o U  1 C  1 C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U  0 0 o  \
0 O D  U I  1 P  U I  o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 O 0  0 O\
 C  U I  1 O  U I  0 0 O  C o  0 O C  0 O 0  U I  1 1  U I  0 O D  C C\
  0 0 0  0 0 O  o U  0 O C  C o  0 O U  0 O 0  U I  P 0  U I  0 O D  C\
 C  0 0 0  0 0 O  0 O D  0 O C  C o  0 O U  0 O 0  U I  1 1  U I  0 0 \
P  0 O 1  0 0 o  0 O C  C L  0 0 O  C o  0 O D  0 O L  o U  0 O C  C o\
  0 O U  0 O 0  U I  P 0  U I  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C \
 C o  0 O U  0 O 0  U I  1 0  0 O  U I  U I  o U  1 C  0 O D  1 C  0 O\
 D  o U  o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  \
o U  0 0 O  0 O I  0 0 0  U I  1 O  U I  0 0 P  0 I 0  0 0 I  0 O 0  U\
 I  P 0  U I  U C  L P  0 O D  0 O O  0 O 0  0 0 0  U C  U I  1 1  U I\
  0 O D  0 0 O  0 O I  0 0 0  o P  C o  C L  0 O 0  0 O L  0 0 D  U I \
 P 0  U I  0 I U  U I  U C  L 1  0 O D  0 0 P  0 O L  0 O 0  U C  U I \
 D L  U I  0 0 O  C o  0 O C  0 O 0  U I  0 I D  U I  1 0  0 O  U I  U\
 I  o U  1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 \
P  U I  0 0 D  0 O 0  0 0 P  L O  0 0 1  0 0 0  0 0 I  0 O 0  0 0 1  0\
 0 P  0 I 0  U I  1 O  U I  U 1  o U  0 0 D  L O  0 O L  C o  0 I 0  C\
 o  C L  0 O L  0 O 0  U 1  U I  1 1  U I  U 1  0 0 P  0 0 1  0 0 o  0\
 O 0  U 1  U I  1 0  0 O  U I  U I  o U  1 C  0 O D  1 C  0 O D  o U  \
o U  1 C  o U  1 C  1 C  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L O  C o \
 0 0 P  0 O 1  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 0  0 O  U I \
 U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o U  1 C  1 C  1 C \
 0 O D  o U  0 O D  1 C  U I  D L  0 O  U I  U I  U I  0 I O  C L  0 O\
 C  C C  U I  1 P  U I  L O  0 O L  C o  0 I 0  0 O 0  0 0 1  U I  1 O\
  U I  1 0  U I  1 P  U I  0 0 I  0 O L  C o  0 I 0  U I  1 O  U I  0 \
0 o  0 0 1  0 O L  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 0 D  0 O 0\
  U I  D L  0 O  U I  U I  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  \
0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L I  0\
 O 0  0 0 D  0 0 0  0 O L  0 0 L  0 O 0  0 O O  L D  0 0 1  0 O L  U I\
  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U\
 I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U I  C U  \
U I  1 0  U I  1 1  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 1  U I  o U \
 1 C  0 O D  1 C  0 O D  o U  o U  1 C  o U  1 C  1 C  U I  1 0  0 O  \
U I  U I  U I  0 O D  0 O I  U I  D U  D 0  U I  1 D  U I  D U  D 0  D\
 L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  0 O  U I  0 O 0  0\
 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 I O  C L  0 O C  C C  U\
 I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 \
o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O  U I  U C  L L  P P  o \
o  P o  1 P  L I  0 0 o  0 0 O  L O  0 O L  0 0 o  0 O U  0 O D  0 0 O\
  1 O  U C  U I  1 U  U I  0 0 o  0 0 1  0 O L  U I  1 U  U I  U C  1 \
0  U C  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  D P  D I  U I  1 D\
  U I  D P  D I  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  U\
 I  U I  0 O D  0 O I  U I  D o  D D  U I  1 D  U I  D o  D D  D L  U \
I  o U  1 C  1 C  0 O D  0 O  U I  U I  0 O D  0 O I  U I  D o  D P  U\
 I  1 D  U I  D o  D P  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 \
0 0  U I  1 D  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 U  U\
 I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  U I  U I  0 O D\
  0 O I  U I  D o  D P  U I  1 D  U I  D o  D P  D L  U I  0 O D  0 O \
D  o U  1 C  0 O D  o U  0 O D  o U  U I  1 P  U I  0 0 0  0 0 0  0 0 \
0  1 L  o C  0 0 0  1 L  U I  1 P  U I  0 0 0  0 0 0  0 0 0  1 L  o C \
 0 0 0  1 L  U I  1 D  U I  o C  1 L  0 0 0  o C  0 O  0 O O  0 O 0  0\
 O I  U I  o U  1 C  1 C  0 O D  1 C  o U  o U  U I  1 O  U I  0 O L  \
0 O D  0 0 O  0 O o  U I  1 0  U I  D L  0 O  U I  o U  0 O D  o U  0 \
O D  1 C  1 C  0 O D  o U  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  \
0 O D  C L  U I  1 P  U I  0 0 o  0 0 1  0 O L  0 0 0  0 0 I  0 O 0  0\
 0 O  U I  1 O  U I  0 O L  0 O D  0 0 O  0 O o  U I  1 0  0 O  U I  0\
 0 0  o C  o C  o C  1 L  0 0 0  U I  P 0  U I  o U  0 O D  o U  0 O D\
  1 C  1 C  0 O D  o U  U I  1 P  U I  0 0 1  0 O 0  C o  0 O O  U I  \
1 O  U I  1 0  0 O  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U \
 U I  1 P  U I  C C  0 O L  0 0 0  0 0 D  0 O 0  U I  1 O  U I  1 0  0\
 O  U I  0 O D  o U  o U  o U  o C  0 0 0  o C  1 L  1 L  1 L  1 L  U \
I  P 0  U I  0 0 0  o C  o C  o C  1 L  0 0 0  U I  1 P  U I  0 0 D  0\
 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U 1  o 1  0 O 0  0 0 P  0 I \
I  0 0 P  U 1  U I  1 0  0 O  U I  o U  o U  o U  1 C  1 C  0 O D  o U\
  o U  0 O D  U I  P 0  U I  0 O D  o U  o U  o U  o C  0 0 0  o C  1 \
L  1 L  1 L  1 L  U I  C 0  U I  1 C  U I  C U  U I  1 P  U I  0 0 D  \
0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  0 0 I  0 0 1  0 0 0  0\
 O U  0 0 1  C o  0 O C  0 O C  1 o  0 O O  0 O 0  0 0 P  C o  0 O D  \
0 O L  1 P  0 0 I  0 O 1  0 0 I  P U  C C  0 0 0  0 0 O  0 0 D  0 0 P \
 C D  0 O D  0 O O  P 0  U C  U I  1 0  0 O  U I  0 O D  o U  o U  0 O\
 D  U I  P 0  U I  o U  o U  o U  1 C  1 C  0 O D  o U  o U  0 O D  U \
I  C 0  U I  1 C  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D \
 0 0 P  U I  1 O  U I  U C  P O  C L  0 0 1  U I  1 o  P I  P O  C o  \
U I  0 O 1  0 0 1  0 O 0  0 O I  P 0  U 1  1 o  U C  U I  1 0  0 O  U \
I  0 O D  1 C  o U  1 C  1 C  1 C  0 O D  o U  0 O D  0 O D  1 C  0 O \
D  1 C  U I  P 0  U I  0 O D  o U  o U  0 O D  U I  C 0  U I  1 L  U I\
  C U  U I  C 0  U I  D I  1 L  U I  D L  U I  0 O L  0 O 0  0 0 O  U \
I  1 O  U I  0 O D  o U  o U  0 O D  U I  C 0  U I  1 L  U I  C U  U I\
  1 0  U I  C U  0 O  U I  0 0 0  1 L  o C  0 0 0  U I  P 0  U I  o U \
 o U  o U  1 C  1 C  0 O D  o U  o U  0 O D  U I  C 0  U I  D O  U I  \
C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  \
U 1  P O  1 o  C o  P I  P O  1 o  0 0 I  P I  P O  1 o  0 O O  0 O D \
 0 0 L  P I  U 1  U I  1 0  0 O  U I  0 O D  1 C  o U  o U  1 C  1 C  \
0 O D  1 C  0 O D  o U  1 C  U I  P 0  U I  0 0 0  1 L  o C  0 0 0  U \
I  C 0  U I  1 L  U I  C U  U I  C 0  U I  1 C  D D  U I  D L  U I  0 \
O L  0 O 0  0 0 O  U I  1 O  U I  0 0 0  1 L  o C  0 0 0  U I  C 0  U \
I  1 L  U I  C U  U I  1 0  U I  C U  0 O  U I  0 O D  1 C  o U  o U  \
1 C  1 C  0 O D  1 C  0 O D  o U  1 C  U I  P 0  U I  0 O D  1 C  o U \
 o U  1 C  1 C  0 O D  1 C  0 O D  o U  1 C  U I  1 P  U I  0 O 0  0 0\
 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I \
 1 D  D P  U C  U I  1 0  0 O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1 \
 0 0 O  U I  U 1  U I  U I  1 D  U I  U 1  U I  1 U  U I  0 O D  1 C  \
o U  o U  1 C  1 C  0 O D  1 C  0 O D  o U  1 C  U I  1 U  U I  U 1  U\
 I  1 D  U I  U 1  U I  1 U  U I  0 O D  1 C  o U  1 C  1 C  1 C  0 O \
D  o U  0 O D  0 O D  1 C  0 O D  1 C  0 O  U I  0 O D  0 O I  U I  D \
P  1 C  U I  1 D  U I  D P  1 C  D L  U I  o U  o U  o U  o U  U I  1 \
P  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 I  U I  0 0 0 \
 1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 I  U I  o U  1 C  o U  0 O D\
  1 C  1 C  1 C  0 O  U I  0 O D  0 O I  U I  1 C  1 L  U I  1 D  U I \
 1 C  1 L  D L  U I  o U  o U  o U  o U  U I  1 D  U I  0 O D  0 O D  \
o U  1 C  0 O D  o U  0 O D  o U  U I  U o  U I  o U  0 O D  1 C  o U \
 U I  1 D  U I  0 O D  1 C  U I  1 D  U I  o U  1 C  1 C  0 O D  0 O  \
0 O O  0 O 0  0 O I  U I  0 0 0  0 0 0  1 L  o C  1 L  0 0 0  1 L  1 L\
  0 0 0  1 L  o C  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 1  U I  \
0 0 1  0 O 0  0 O U  0 O 0  0 I O  U I  1 0  U I  D L  0 O  U I  o C  \
o C  o C  1 L  o C  o C  0 0 0  U I  P 0  U I  0 O D  0 O D  1 C  o U \
 1 C  0 O D  1 C  o U  U I  1 O  U I  0 0 o  0 0 1  0 O L  U I  1 0  0\
 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  0 O D  o U  o U\
  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  P 0  U I  0 0 1  0 O 0  U I  \
1 P  U I  0 O I  0 O D  0 0 O  0 O O  C o  0 O L  0 O L  U I  1 O  U I\
  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U I  1 1  U I  o C  o C  o C  1 L\
  o C  o C  0 0 0  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U\
 I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  0 O D  o U  o U  o \
U  0 0 0  1 L  0 0 0  1 L  o C  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 \
0 I  0 0 P  U I  D L  0 O  U I  U I  o U  o U  o U  1 C  0 O D  0 O D \
 1 C  0 O D  o U  o U  U I  1 O  U I  U C  0 0 1  0 O 0  0 O U  0 O 0 \
 0 I O  U I  0 O I  C o  0 O D  0 O L  0 O 0  0 O O  U C  U I  1 0  0 \
O  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U\
 I  1 O  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U I  1 0  0 O  U I  U\
 I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  0 O  U I  U I  0 O D  0 \
O I  U I  1 C  1 L  U I  1 D  U I  1 C  1 L  D L  U I  0 0 0  o C  1 L\
  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 D  U I  0 0 0  1 L  0 0 0\
  o C  1 L  U I  1 P  U I  0 O D  1 C  0 O  U I  U I  0 O D  0 O I  U \
I  D P  U I  1 D  U I  D P  D L  U I  0 0 0  o C  1 L  0 0 0  U I  U o\
  U I  o U  o U  o U  o U  U I  1 U  U I  o U  0 O D  o U  o U  0 O  U\
 I  U I  0 O D  0 O I  U I  D O  D I  U I  1 D  U I  D O  D I  D L  U \
I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 o  U I  0 O D  1 C \
 1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 o\
  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 \
C  0 O D  U I  U o  U I  o U  0 O D  1 C  o U  U I  1 D  U I  o U  o U\
  o U  o U  U I  1 I  U I  o U  o U  o U  o U  0 O  0 O O  0 O 0  0 O \
I  U I  0 0 0  o C  0 0 0  0 0 0  1 L  0 0 0  o C  U I  1 O  U I  0 O \
O  U I  1 1  U I  0 0 1  0 0 0  0 0 0  0 0 P  U I  P 0  U I  U 1  0 0 \
1  0 0 0  0 0 0  0 0 P  U 1  U I  1 1  U I  0 0 O  0 O 0  0 0 D  0 0 P\
  0 O 0  0 O O  U I  P 0  U I  1 L  U I  1 0  U I  D L  0 O  U I  0 O \
D  0 O I  U I  D 0  D D  U I  1 D  U I  D 0  D D  D L  U I  0 0 0  0 0\
 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  o U  o U  0 O D  o U  \
0 O D  o U  o U  1 C  1 C  0 O D  U I  1 P  U I  o U  o U  0 O D  o U \
 0 O D  o U  o U  1 C  1 C  0 O D  U I  1 I  U I  o U  0 O D  o U  o U\
  U I  U o  U I  0 O D  1 C  U I  1 o  U I  0 O D  0 O D  o U  1 C  0 \
O D  o U  0 O D  o U  0 O  U I  0 O D  o U  o U  0 O D  o C  o C  o C \
 0 0 0  1 L  1 L  0 0 0  U I  P 0  U I  0 O L  C o  0 O C  C L  0 O O \
 C o  U I  0 O D  0 O D  1 C  0 O D  0 O D  0 O D  0 O D  1 C  U I  D \
L  U I  U C  P O  U C  U I  1 U  U I  0 O D  0 O D  1 C  0 O D  0 O D \
 0 O D  0 O D  1 C  U I  1 U  U I  U C  P I  U C  0 O  U I  0 0 0  1 L\
  o C  o C  0 0 0  1 L  o C  U I  P 0  U I  0 O L  C o  0 O C  C L  0 \
O O  C o  U I  0 O D  0 O D  1 C  0 O D  0 O D  0 O D  0 O D  1 C  U I\
  D L  U I  U C  P O  1 o  U C  U I  1 U  U I  0 O D  0 O D  1 C  0 O \
D  0 O D  0 O D  0 O D  1 C  U I  1 U  U I  U C  P I  C I  0 0 O  U C \
 0 O  U I  0 O D  0 O I  U I  D U  D O  U I  1 D  U I  D U  D O  D L  \
U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 o  U I  0 0 0  0 \
0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  U o  U I  o U  0 O D  1 C  o U \
 0 O  U I  o U  0 O D  1 C  1 C  o U  1 C  o U  1 C  1 C  o U  o U  U \
I  P 0  U I  0 O L  C o  0 O C  C L  0 O O  C o  U I  0 O D  o U  0 O \
D  1 C  1 C  o U  0 O D  1 C  U I  1 1  U I  o U  o U  0 O D  0 O D  0\
 O D  o U  U I  D L  U I  o U  o U  0 O D  0 O D  0 O D  o U  U I  1 U\
  U I  0 O D  o U  o U  0 O D  o C  o C  o C  0 0 0  1 L  1 L  0 0 0  \
U I  1 O  U I  0 0 0  o C  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 \
0 0  o C  U I  1 0  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I \
 0 O D  o U  0 O D  1 C  1 C  o U  0 O D  1 C  U I  1 0  U I  1 U  U I\
  0 0 0  1 L  o C  o C  0 0 0  1 L  o C  U I  1 O  U I  0 0 0  o C  1 \
L  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  o C  U I  1 0  0 O  U I \
 o U  o U  0 O D  0 O D  0 O D  o U  U I  P 0  U I  0 O D  o U  o U  0\
 O D  o C  o C  o C  0 0 0  1 L  1 L  0 0 0  U I  1 O  U I  0 0 1  0 0\
 0  0 0 0  0 0 P  U I  1 0  U I  1 U  U I  U C  C I  0 0 O  U C  U I  \
0 O D  0 O I  U I  0 0 1  0 0 0  0 0 0  0 0 P  U I  0 O 0  0 O L  0 0 \
D  0 O 0  U I  U 1  U 1  0 O  U I  0 O D  0 O I  U I  D 0  D P  U I  1\
 D  U I  D 0  D P  D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U \
I  1 P  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 P  U I  0 O\
 D  1 C  1 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  \
U I  1 U  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U \
I  1 I  U I  o U  0 O D  o U  o U  0 O  U I  0 O I  0 0 0  0 0 1  U I \
 0 0 0  o C  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  o C  U I \
 1 1  U I  o C  0 0 0  o C  o C  1 L  U I  0 O D  0 0 O  U I  0 O O  U\
 I  1 P  U I  0 O D  0 0 P  0 O 0  0 0 1  0 O D  0 0 P  0 O 0  0 O C  \
0 0 D  U I  1 O  U I  1 0  U I  D L  0 O  U I  U I  o U  0 O D  0 O D \
 1 C  o U  U I  P 0  U I  0 0 P  0 I 0  0 0 I  0 O 0  U I  1 O  U I  o\
 C  0 0 0  o C  o C  1 L  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  \
0 0 O  0 O 0  0 0 D  0 0 P  0 O 0  0 O O  U I  P 0  P 0  U I  1 L  U I\
  D L  U I  0 0 0  o C  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0\
  o C  U I  P 0  U I  U C  0 0 1  0 O 0  0 O U  0 O 0  0 I O  U C  0 O\
  U I  U I  0 O D  0 O I  U I  o U  0 O D  0 O D  1 C  o U  U I  0 O D\
  0 0 D  U I  0 O L  0 O D  0 0 D  0 0 P  U I  D L  0 O  U I  U I  U I\
  0 O I  0 0 0  0 0 1  U I  0 O D  o U  0 O D  1 C  1 C  o U  0 O D  1\
 C  U I  0 O D  0 0 O  U I  o C  0 0 0  o C  o C  1 L  U I  D L  0 O  \
U I  U I  U I  U I  0 O D  o U  0 O D  1 C  1 C  o U  0 O D  1 C  U I \
 P 0  U I  0 O 0  0 0 D  C C  C o  0 0 I  0 O 0  U I  1 O  U I  0 O D \
 o U  0 O D  1 C  1 C  o U  0 O D  1 C  U I  1 0  0 O  U I  U I  U I  \
U I  o U  o U  0 O D  0 O D  0 O D  o U  U I  P 0  U I  o U  0 O D  1 \
C  1 C  o U  1 C  o U  1 C  1 C  o U  o U  U I  1 O  U I  0 O D  o U  \
0 O D  1 C  1 C  o U  0 O D  1 C  U I  1 1  U I  o U  o U  0 O D  0 O \
D  0 O D  o U  U I  1 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  1\
 C  1 L  1 L  U I  1 D  U I  1 C  1 L  1 L  D L  U I  o C  o C  0 0 0 \
 0 0 0  o C  o C  0 0 0  U I  1 P  U I  o U  0 O D  o U  o U  U I  1 o\
  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  \
U I  0 O D  0 O I  U I  o U  0 O D  0 O D  1 C  o U  U I  0 O D  0 0 D\
  U I  0 O O  0 O D  C C  0 0 P  U I  D L  0 O  U I  U I  U I  o U  o \
U  0 O D  0 O D  0 O D  o U  U I  P 0  U I  o U  0 O D  1 C  1 C  o U \
 1 C  o U  1 C  1 C  o U  o U  U I  1 O  U I  U C  C I  0 0 O  U C  U \
I  1 U  U I  0 0 0  o C  0 0 0  0 0 0  1 L  0 0 0  o C  U I  1 O  U I \
 o C  0 0 0  o C  o C  1 L  U I  1 1  U I  o L  0 0 0  0 0 O  0 O 0  U\
 I  1 1  U I  0 0 O  0 O 0  0 0 D  0 0 P  0 O 0  0 O O  U I  1 U  U I \
 1 C  U I  1 0  U I  1 1  U I  o U  o U  0 O D  0 O D  0 O D  o U  U I\
  1 0  0 O  U I  U I  0 O D  0 O I  U I  o U  0 O D  0 O D  1 C  o U  \
U I  0 O D  0 0 D  U I  0 0 O  0 0 0  0 0 P  U I  0 O L  0 O D  0 0 D \
 0 0 P  U I  C o  0 0 O  0 O O  U I  o U  0 O D  0 O D  1 C  o U  U I \
 0 O D  0 0 D  U I  0 0 O  0 0 0  0 0 P  U I  0 O O  0 O D  C C  0 0 P\
  U I  D L  0 O  U I  U I  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P\
  U I  o C  0 0 0  o C  o C  1 L  U I  0 O D  0 0 D  U I  o L  0 0 0  \
0 0 O  0 O 0  U I  D L  U I  o C  0 0 0  o C  o C  1 L  U I  P 0  U I \
 0 O 0  0 0 D  C C  C o  0 0 I  0 O 0  U I  1 O  U I  o C  0 0 0  o C \
 o C  1 L  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D O  D o  \
U I  1 D  U I  D O  D o  D L  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L \
 1 L  1 L  U I  1 I  U I  o U  0 O D  1 C  o U  U I  1 I  U I  o U  1 \
C  o U  0 O D  1 C  1 C  1 C  U I  1 I  U I  0 0 0  0 0 0  0 0 0  1 L \
 o C  0 0 0  1 L  0 O  U I  U I  U I  0 O D  0 O I  U I  o C  0 0 0  o\
 C  o C  1 L  U I  0 O D  0 0 D  U I  o L  0 0 0  0 0 O  0 O 0  U I  D\
 L  0 O  U I  U I  U I  U I  o U  o U  0 O D  0 O D  0 O D  o U  U I  \
P 0  U I  o U  0 O D  1 C  1 C  o U  1 C  o U  1 C  1 C  o U  o U  U I\
  1 O  U I  o C  0 0 0  o C  o C  1 L  U I  1 1  U I  o U  o U  0 O D \
 0 O D  0 O D  o U  U I  1 0  0 O  U I  U I  U I  0 O 0  0 O L  0 0 D \
 0 O 0  U I  D L  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D o  D O\
  U I  1 D  U I  D o  D O  D L  U I  o U  o U  o U  o U  0 O  U I  U I\
  U I  U I  o U  o U  0 O D  0 O D  0 O D  o U  U I  P 0  U I  o U  0 \
O D  1 C  1 C  o U  1 C  o U  1 C  1 C  o U  o U  U I  1 O  U I  o C  \
0 0 0  o C  o C  1 L  U I  1 P  U I  0 O 0  0 0 O  C C  0 0 0  0 O O  \
0 O 0  U I  1 O  U I  U 1  0 0 o  0 0 P  0 O I  1 D  D P  U 1  U I  1 \
0  U I  1 1  U I  o U  o U  0 O D  0 O D  0 O D  o U  U I  1 0  0 O  U\
 I  U I  U I  U I  0 O D  0 O I  U I  D D  U I  1 D  U I  D D  D L  U \
I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0 O  U I  o U  o U \
 0 O D  0 O D  0 O D  o U  U I  1 U  P 0  U I  0 0 0  1 L  o C  o C  0\
 0 0  1 L  o C  U I  1 O  U I  0 0 1  0 0 0  0 0 0  0 0 P  U I  1 0  U\
 I  0 O D  0 O I  U I  0 0 1  0 0 0  0 0 0  0 0 P  U I  0 O 0  0 O L  \
0 0 D  0 O 0  U I  U 1  U 1  0 O  U I  0 O D  0 O I  U I  D D  D 0  U \
I  1 D  U I  D D  D 0  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  \
U I  U o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 \
O  U I  0 0 1  0 O 0  0 0 P  0 0 o  0 0 1  0 0 O  U I  o U  o U  0 O D\
  0 O D  0 O D  o U  0 O  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o \
 0 O U  0 O D  0 0 O  U I  1 P  U I  0 0 D  0 O 0  0 0 P  P o  0 0 0  \
0 0 O  0 0 P  0 O 0  0 0 O  0 0 P  U I  1 O  U I  0 O D  0 0 O  0 0 P \
 U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U \
 0 0 L  U I  C 0  U I  1 C  U I  C U  U I  1 0  U I  1 1  U I  U C  0 \
O C  0 0 0  0 0 L  0 O D  0 O 0  0 0 D  U C  U I  1 0  0 O  0 O D  0 O\
 I  U I  D 0  D O  U I  1 D  U I  D 0  D O  D L  U I  o C  1 L  0 0 0 \
 o C  U I  1 U  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U\
 I  1 U  U I  0 0 0  o C  1 L  0 0 0  U I  1 I  U I  o U  0 O D  o U  \
o U  0 O  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  0 I O  C L  0 O C  \
C C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  C o  0 O\
 O  0 O O  L U  0 0 0  0 0 1  0 0 P  o o  0 O 0  0 0 P  0 O 1  0 0 0  \
0 O O  U I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0\
  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  \
U I  C U  U I  1 0  U I  1 1  U I  0 I O  C L  0 O C  C C  0 0 I  0 O \
L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  L U  o C  L I  L 1  C D \
 o o  P C  L 1  o I  o C  P L  C D  L D  o L  L U  o C  L I  L 1  P C \
 P L  U I  1 0  0 O  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L \
 0 O  U I  0 0 I  C o  0 0 D  0 0 D  0 O  0 0 P  0 0 1  0 I 0  U I  D \
L  0 O  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U  0 O D\
  0 0 O  U I  1 P  U I  C o  0 O O  0 O O  L U  0 0 0  0 0 1  0 0 P  o\
 o  0 O 0  0 0 P  0 O 1  0 0 0  0 O O  U I  1 O  U I  0 O D  0 0 O  0 \
0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 \
O U  0 0 L  U I  C 0  U I  1 C  U I  C U  U I  1 0  U I  1 1  U I  0 I\
 O  C L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 \
P  U I  L U  o C  L I  L 1  C D  o o  P C  L 1  o I  o C  P L  C D  o \
P  P D  P P  P C  o P  U I  1 0  0 O  0 O 0  0 I O  C C  0 O 0  0 0 I \
 0 0 P  U I  D L  0 O  U I  0 0 I  C o  0 0 D  0 0 D  0 O  0 0 P  0 0 \
1  0 I 0  U I  D L  0 O  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 \
0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  C o  0 O O  0 O O  L U  0 0 0\
  0 0 1  0 0 P  o o  0 O 0  0 0 P  0 O 1  0 0 0  0 O O  U I  1 O  U I \
 0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U \
I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U I  C U  U I  1 0  U\
 I  1 1  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U  0 O \
D  0 0 O  U I  1 P  U I  L U  o C  L I  L 1  C D  o o  P C  L 1  o I  \
o C  P L  C D  P L  P D  L 1  P C  U I  1 0  0 O  0 O 0  0 I O  C C  0\
 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  0 0 I  C o  0 0 D  0 0 D  0 O \
 0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  0 I O  C L  0 O C  C C  0 0 \
I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  C o  0 O O  0 O O\
  L U  0 0 0  0 0 1  0 0 P  o o  0 O 0  0 0 P  0 O 1  0 0 0  0 O O  U \
I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D  \
U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U I  C U \
 U I  1 0  U I  1 1  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o \
 0 O U  0 O D  0 0 O  U I  1 P  U I  L U  o C  L I  L 1  C D  o o  P C\
  L 1  o I  o C  P L  C D  o 0  P C  o L  L I  P C  U I  1 0  0 O  0 O\
 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  0 0 I  C o  0\
 0 D  0 0 D  0 O  U I  0 O D  0 O I  U I  D 1  D O  U I  1 D  U I  D 1\
  D O  D L  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 \
O  0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D  o U  U I  P 0  U I  0 0 \
0  0 0 0  1 L  1 L  0 0 0  0 0 0  0 0 0  0 0 0  o C  o C  0 0 0  1 L  \
1 L  U I  1 O  U I  1 0  0 O  0 O D  0 O I  U I  D O  U I  1 D  U I  D\
 O  D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  o U  0 O D  \
o U  0 O D  1 C  1 C  0 O D  o U  U I  P 0  U I  o L  0 0 0  0 0 O  0 \
O 0  0 O  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  o L  0 0 0  0 0 \
O  0 O 0  0 O  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  U I  o L \
 0 0 0  0 0 O  0 O 0  0 O  0 0 0  0 0 0  1 L  1 L  1 L  0 O D  0 O D  \
U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  0 O D  1 C  0 O D  0 O D\
  0 O D  0 O D  o U  1 C  1 C  0 O D  0 O D  U I  P 0  U I  o L  0 0 0\
  0 0 O  0 O 0  0 O  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U\
  U I  P 0  U I  o C  0 0 0  0 0 0  o C  1 L  o C  o C  0 O  0 0 0  0 \
0 0  1 L  1 L  1 L  0 O D  0 O D  U I  P 0  U I  o L  0 0 0  0 0 O  0 \
O 0  0 O  0 0 0  0 0 0  1 L  o C  o C  1 L  0 0 0  1 L  0 0 0  1 L  0 \
0 0  0 0 0  o C  1 L  0 0 0  0 0 0  0 0 0  U I  P 0  U I  o L  0 0 0  \
0 0 O  0 O 0  0 O  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 \
0  0 0 0  1 L  o C  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  0 O \
D  0 O I  U I  D I  D D  U I  1 D  U I  D I  D D  D L  U I  0 0 0  0 0\
 0  0 0 0  1 L  o C  0 0 0  1 L  0 O  0 0 P  0 0 1  0 I 0  U I  D L  0\
 O  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  P 0  U I  \
0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 o  0 0 O  0\
 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I\
  1 O  U I  0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D  o U  U I  C 0  \
U I  U 1  0 0 o  0 0 1  0 O L  U 1  U I  C U  U I  1 0  U I  1 P  U I \
 0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 \
0 P  0 O I  1 D  D P  U C  U I  1 0  0 O  0 O 0  0 I O  C C  0 O 0  0 \
0 I  0 0 P  U I  D L  0 O  U I  0 0 I  C o  0 0 D  0 0 D  0 O  0 0 P  \
0 0 1  0 I 0  U I  D L  0 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  P \
0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 o  \
0 0 O  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 \
0 D  U I  1 O  U I  0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D  o U  U \
I  C 0  U I  U 1  0 0 O  C o  0 O C  0 O 0  U 1  U I  C U  U I  1 0  0\
 O  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  0 0 I \
 C o  0 0 D  0 0 D  0 O  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  0 O \
D  1 C  0 O D  0 O D  0 O D  0 O D  o U  1 C  1 C  0 O D  0 O D  U I  \
P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 o\
  0 0 O  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  \
0 0 D  U I  1 O  U I  0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D  o U  \
U I  C 0  U I  U 1  0 O D  C C  0 0 0  0 0 O  0 O D  0 O C  C o  0 O U\
  0 O 0  U 1  U I  C U  U I  1 0  0 O  0 O 0  0 I O  C C  0 O 0  0 0 I\
  0 0 P  U I  D L  0 O  U I  0 0 I  C o  0 0 D  0 0 D  0 O  0 0 P  0 0\
 1  0 I 0  U I  D L  0 O  U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C\
  o U  o U  U I  P 0  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I\
  1 P  U I  0 0 o  0 0 O  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 \
I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 0  o C  1 L  0 0 0  0 O D  \
o U  0 O D  o U  U I  C 0  U I  U 1  0 O I  C o  0 0 O  C o  0 0 1  0 \
0 P  U 1  U I  C U  U I  1 0  0 O  0 O 0  0 I O  C C  0 O 0  0 0 I  0 \
0 P  U I  D L  0 O  U I  0 0 I  C o  0 0 D  0 0 D  0 O  0 0 P  0 0 1  \
0 I 0  U I  D L  0 O  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P \
0  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 0  o C  1 L  0 0 0  0 \
O D  o U  0 O D  o U  U I  C 0  U I  U 1  0 O C  0 0 0  0 O O  0 O 0  \
U 1  U I  C U  U I  1 0  0 O  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  \
U I  D L  0 O  U I  0 0 I  C o  0 0 D  0 0 D  0 O  0 0 P  0 0 1  0 I 0\
  U I  D L  0 O  U I  0 0 0  0 0 0  1 L  1 L  1 L  0 O D  0 O D  U I  \
P 0  U I  0 O 0  0 0 L  C o  0 O L  U I  1 O  U I  0 0 o  0 0 1  0 O L\
  0 O L  0 O D  C L  U I  1 P  U I  0 0 o  0 0 O  0 0 U  0 0 o  0 0 0 \
 0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D  U I  1 O  U I  0 0 0  \
o C  1 L  0 0 0  0 O D  o U  0 O D  o U  U I  C 0  U I  U 1  0 0 I  0 \
O L  C o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U 1  U I  C U  U I  1 0  \
U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  \
U I  U C  0 I 1  0 I 1  U C  U I  1 1  U I  U C  1 1  U C  U I  1 0  U\
 I  1 0  0 O  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U\
 I  0 0 I  C o  0 0 D  0 0 D  0 O  0 0 P  0 0 1  0 I 0  U I  D L  0 O \
 U I  0 0 0  0 0 0  1 L  o C  o C  1 L  0 0 0  1 L  0 0 0  1 L  0 0 0 \
 0 0 0  o C  1 L  0 0 0  0 0 0  0 0 0  U I  P 0  U I  0 O D  0 0 O  0 \
0 P  U I  1 O  U I  0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D  o U  U \
I  C 0  U I  U 1  0 O I  C o  0 0 L  C D  0 O C  0 0 0  0 O O  0 O 0  \
U 1  U I  C U  U I  1 0  0 O  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  \
U I  D L  0 O  U I  0 0 I  C o  0 0 D  0 0 D  0 O  0 0 P  0 0 1  0 I 0\
  U I  D L  0 O  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0\
 0 0  0 0 0  1 L  o C  U I  P 0  U I  0 0 0  o C  1 L  0 0 0  0 O D  o\
 U  0 O D  o U  U I  C 0  U I  U 1  0 0 1  0 O 0  0 O U  0 O 0  0 I O \
 0 0 D  U 1  U I  C U  0 O  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U \
I  D L  0 O  U I  0 0 I  C o  0 0 D  0 0 D  0 O  o C  o C  o C  0 0 0 \
 o C  o C  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  0 0 0  U I  P 0  U I  U\
 C  U C  0 O  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  o C  o C  o C  \
0 0 0  o C  o C  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  0 0 0  U I  P 0  \
U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P  U I  0 0 o  0 0\
 O  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O L  0 0 o  0 0 D\
  U I  1 O  U I  0 0 0  o C  1 L  0 0 0  0 O D  o U  0 O D  o U  U I  \
C 0  U I  U 1  0 0 I  0 O L  C o  0 I 0  0 O D  0 0 P  0 O 0  0 O C  U\
 1  U I  C U  U I  1 0  0 O  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U\
 I  D L  0 O  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  0 O D  0 O I  U\
 I  D o  U I  1 D  U I  D o  D L  U I  o C  1 L  0 0 0  o C  U I  1 I \
 U I  o U  1 C  1 C  0 O D  U I  U o  U I  o C  0 0 0  0 0 0  0 0 0  1\
 L  1 L  1 L  1 L  U I  1 P  U I  o U  o U  0 O D  o U  0 O D  o U  o \
U  1 C  1 C  0 O D  0 O  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D \
 o U  o U  U I  1 O  U I  U 1  o o  0 0 0  0 O O  0 O 0  D L  U I  U 1\
  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  0 0 0  0 0 0  o C\
  0 0 0  1 L  1 L  U I  1 0  U I  1 0  0 O  0 O D  0 O I  U I  D O  U \
I  1 D  U I  D O  D L  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U\
 I  U o  U I  0 0 0  o C  1 L  0 0 0  0 O  0 O D  0 O I  U I  D O  1 C\
  U I  1 D  U I  D O  1 C  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 \
0 0  1 L  U I  1 D  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  U\
 o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0  U I  1 U  U I  0 0 0\
  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  0 O D  0 O I  U I  0 0 O  0 0\
 0  0 0 P  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  0 O\
 D  0 0 D  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  o U  o U\
  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L \
D  L I  o P  D L  U I  U 1  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1\
 O  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 P  U I  \
0 O 0  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0\
 P  0 O I  1 D  D P  U C  U I  1 0  U I  1 0  U I  1 0  0 O  o U  o U \
 o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  o L\
  C o  0 O C  0 O 0  D L  U I  U 1  U I  1 U  U I  0 0 D  0 0 P  0 0 1\
  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 0  U I  1 0  0 O \
 0 O D  0 O I  U I  D o  D O  U I  1 D  U I  D o  D O  D L  U I  o C  \
0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 U  U I  0 0 0  0 0 0  \
0 0 0  1 L  o C  0 0 0  1 L  0 O  0 O D  0 O I  U I  0 0 O  0 0 0  0 0\
 P  U I  o C  o C  o C  0 0 0  o C  o C  o C  1 L  0 0 0  1 L  0 0 0  \
0 0 0  0 0 0  U I  P 0  P 0  U I  U C  U C  U I  D L  0 O  U I  o U  0\
 O D  1 C  1 C  0 O D  0 O D  0 O D  1 C  o U  o U  1 C  0 O D  U I  P\
 0  U I  o C  o C  1 L  o C  o C  o C  o C  0 0 0  0 0 0  1 L  o C  o \
C  o C  U I  1 O  U I  U C  U C  U I  1 1  U I  0 O O  C o  0 0 P  C o\
  U I  P 0  U I  o C  o C  o C  0 0 0  o C  o C  o C  1 L  0 0 0  1 L \
 0 0 0  0 0 0  0 0 0  U I  1 0  0 O  U I  o C  0 0 0  0 0 0  o C  1 L \
 U I  1 1  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1\
  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 \
L  o C  U I  P 0  U I  0 O D  1 C  o U  1 C  0 O D  1 C  U I  1 O  U I\
  o U  0 O D  1 C  1 C  0 O D  0 O D  0 O D  1 C  o U  o U  1 C  0 O D\
  U I  1 1  U I  o L  0 0 0  0 0 O  0 O 0  U I  1 1  U I  0 O O  0 0 0\
  0 0 O  0 0 P  o P  0 O D  0 0 O  0 O o  U I  P 0  U I  L 1  0 0 1  0\
 0 o  0 O 0  U I  1 0  0 O  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U\
 I  P 0  U I  1 C  1 C  D D  0 O  0 O D  0 O I  U I  0 0 0  0 0 0  o C\
  0 0 0  1 L  1 L  U I  P 0  P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  \
D L  0 O  U I  0 O D  0 O I  U I  D U  D O  U I  1 D  U I  D U  D O  D\
 L  U I  o U  0 O D  1 C  o U  U I  1 o  U I  0 O D  o U  o U  1 C  1 \
C  1 C  0 O D  U I  1 P  U I  o U  o U  o U  o U  U I  1 I  U I  0 0 0\
  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  0 0 0  1 L  0 0 0\
  o C  1 L  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o \
U  o U  U I  1 O  U I  U 1  0 O U  0 O 0  0 0 P  L U  0 0 0  0 0 o  0 \
0 1  C C  0 O 0  0 0 D  U 1  U I  1 0  0 O  U I  0 O D  1 C  0 O D  o \
U  o U  o U  0 O D  1 C  0 O D  U I  1 O  U I  1 0  0 O  U I  0 I O  C\
 L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U \
I  0 O 0  0 0 O  0 O O  o C  0 O I  P L  0 O D  0 0 1  0 O 0  C C  0 0\
 P  0 0 0  0 0 1  0 I 0  U I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O \
 U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U \
I  C 0  U I  1 C  U I  C U  U I  1 0  U I  1 0  0 O  U I  0 O D  0 O I\
  U I  D O  D U  U I  1 D  U I  D O  D U  D L  U I  0 0 0  0 0 0  o C \
 0 0 0  o C  1 L  o C  1 L  1 L  U I  1 o  U I  0 0 0  0 0 0  o C  0 0\
 0  o C  1 L  0 0 0  U I  1 D  U I  0 O D  1 C  U I  1 o  U I  o U  1 \
C  o U  0 O D  1 C  1 C  1 C  U I  1 P  U I  0 0 0  1 L  1 L  o C  1 L\
  0 0 0  0 0 0  U I  1 P  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0\
  0 O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L \
 1 L  U I  P 0  P 0  U I  1 C  U I  D L  0 O  U I  o U  o U  o U  1 C \
 0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  0 O U  0 O 0 \
 0 0 P  P L  C o  0 0 P  C o  U 1  U I  1 0  0 O  U I  o C  o C  o C  \
1 L  o C  o C  0 0 0  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U \
I  0 O D  0 O I  U I  D 1  U I  1 D  U I  D 1  D L  U I  o U  o U  o U\
  o U  U I  1 P  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  0 O D  0 \
O I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0 \
 1 L  o C  U I  C o  0 0 O  0 O O  U I  0 O L  0 O 0  0 0 O  U I  1 O \
 U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L\
  o C  U I  1 0  U I  P I  U I  1 L  U I  D L  0 O  U I  U I  o C  o C\
  o C  1 L  o C  o C  0 0 0  U I  1 1  U I  o C  o C  1 L  1 L  U I  P\
 0  U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  1 O  U I  o C  0 0 0  o C\
  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 1  U I \
 o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 0  0 O  U I  U I\
  0 O D  0 O I  U I  D I  D 0  U I  1 D  U I  D I  D 0  D L  U I  0 0 \
0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  0 0 0 \
 1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  U I  0 O D  0 O I  U I  D\
 U  1 L  U I  1 D  U I  D U  1 L  D L  U I  o U  o U  o U  o U  U I  U\
 o  U I  o U  1 C  1 C  0 O D  U I  1 I  U I  o U  o U  0 O D  o U  0 \
O D  o U  o U  1 C  1 C  0 O D  0 O  U I  U I  0 O D  0 O I  U I  o C \
 o C  o C  1 L  o C  o C  0 0 0  U I  1 P  U I  0 0 D  0 0 P  C o  0 0\
 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  0 O \
1  0 0 P  0 0 P  0 0 I  U C  U I  1 0  U I  0 0 0  0 0 1  U I  o C  o \
C  o C  1 L  o C  o C  0 0 0  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1 \
 0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  0 0 D  \
0 O C  C L  U C  U I  1 0  U I  0 0 0  0 0 1  U I  o C  o C  o C  1 L \
 o C  o C  0 0 0  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 \
D  0 0 C  0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  0 0 O  0 O I  0 0 D\
  U C  U I  1 0  U I  0 0 0  0 0 1  U I  o C  o C  o C  1 L  o C  o C \
 0 0 0  U I  1 P  U I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  \
0 O D  0 0 P  0 O 1  U I  1 O  U I  U C  1 o  U C  U I  1 0  U I  D L \
 0 O  U I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I\
  P 0  U I  o C  o C  o C  1 L  o C  o C  0 0 0  0 O  U I  U I  U I  o\
 C  o C  o C  1 L  o C  o C  0 0 0  U I  P 0  U I  o L  0 0 0  0 0 O  \
0 O 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D I  U I  1 D  U I  D I \
 D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 P  U I  o U  1 C  1 C  0 O D\
  0 O  U I  U I  U I  0 O D  0 O I  U I  D 1  D 0  U I  1 D  U I  D 1 \
 D 0  D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 0 0  0 0 0  0\
 0 0  1 L  o C  0 0 0  1 L  U I  U o  U I  o U  1 C  1 C  0 O D  U I  \
1 o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  U o  U I  o U  0\
 O D  1 C  o U  0 O  U I  o C  1 L  0 0 0  o C  1 L  U I  1 O  U I  o \
U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1  U I  0 O D  0 O \
D  1 C  0 O D  o U  o U  1 C  o U  o U  U I  1 1  U I  o C  o C  o C  \
1 L  o C  o C  0 0 0  U I  1 0  0 O  U I  0 I O  C L  0 O C  C C  0 0 \
I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  0 O 0  0 0 O  0 O\
 O  o C  0 O I  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 \
I 0  U I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  \
0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U \
I  C U  U I  1 0  U I  1 0  0 O  U I  0 O D  0 O I  U I  D 1  1 L  U I\
  1 D  U I  D 1  1 L  D L  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 \
0  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  U o \
 U I  0 O D  1 C  U I  1 o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D\
  U I  1 o  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O \
D  0 O  U I  0 O D  0 O I  U I  1 C  D o  U I  1 D  U I  1 C  D o  D L\
  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 P  U \
I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 U  U I  o U  0 O D  1\
 C  o U  U I  1 o  U I  o C  1 L  0 0 0  o C  U I  1 P  U I  0 0 0  o \
C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 I  U I  o C  0 0 0 \
 0 0 0  0 0 0  1 L  1 L  1 L  1 L  0 O  0 O 0  0 O L  0 O D  0 O I  U \
I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0  U I  D O  U I  D\
 L  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  \
U I  1 O  U I  U 1  0 O U  0 O 0  0 0 P  P o  0 O 1  C o  0 0 O  0 0 O\
  0 O 0  0 O L  o U  0 0 P  0 O 0  0 O C  0 0 D  U 1  U I  1 0  0 O  U\
 I  0 O D  o U  o U  o U  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  \
U I  1 1  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1 \
 U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  U I  1 0  0 O\
  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 \
O  U I  1 P  U I  0 O 0  0 0 O  0 O O  o C  0 O I  P L  0 O D  0 0 1  \
0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  U I  1 O  U I  0 O D  0 0 O  0\
 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0\
 O U  0 0 L  U I  C 0  U I  1 C  U I  C U  U I  1 0  U I  1 0  0 O  U \
I  0 O D  0 O I  U I  D U  D o  U I  1 D  U I  D U  D o  D L  U I  0 0\
 0  o C  1 L  0 0 0  U I  1 o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0\
  0 0 0  o C  1 L  U I  U o  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  \
1 L  1 L  0 O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0\
 0  1 L  1 L  U I  P 0  P 0  U I  D 0  U I  D L  0 O  U I  o U  o U  o\
 U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  0 O U\
  0 O 0  0 0 P  L U  0 0 o  C L  P o  0 O 1  C o  0 0 O  0 0 O  0 O 0 \
 0 O L  o U  0 0 P  0 O 0  0 O C  0 0 D  U 1  U I  1 0  0 O  U I  o C \
 1 L  o C  1 L  o C  0 0 0  1 L  1 L  U I  1 O  U I  o C  0 0 0  0 0 0\
  o C  1 L  U I  1 1  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o \
U  U I  1 1  U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  U\
 I  1 0  0 O  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U \
 0 O D  0 0 O  U I  1 P  U I  0 O 0  0 0 O  0 O O  o C  0 O I  P L  0 \
O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  U I  1 O  U I  0 O\
 D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C\
 o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U I  C U  U I  1 0  U I  \
1 0  0 O  U I  0 O D  0 O I  U I  D P  D I  U I  1 D  U I  D P  D I  D\
 L  U I  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  0 O D  o U  o U  1 C  \
1 C  1 C  0 O D  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 \
0 0  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  0 O 0  0 O L  0 \
O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0  U \
I  D I  U I  D L  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O\
 D  o U  o U  U I  1 O  U I  U 1  0 O U  0 O 0  0 0 P  o O  C o  0 0 L\
  0 0 0  0 0 1  0 O D  0 0 P  0 O 0  0 0 D  U 1  U I  1 0  0 O  U I  0\
 O D  1 C  o U  0 O D  1 C  1 C  o U  o U  U I  1 O  U I  1 0  0 O  U \
I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U\
 I  1 P  U I  0 O 0  0 0 O  0 O O  o C  0 O I  P L  0 O D  0 0 1  0 O \
0  C C  0 0 P  0 0 0  0 0 1  0 I 0  U I  1 O  U I  0 O D  0 0 O  0 0 P\
  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U\
  0 0 L  U I  C 0  U I  1 C  U I  C U  U I  1 0  U I  1 0  0 O  U I  0\
 O D  0 O I  U I  D o  D o  U I  1 D  U I  D o  D o  D L  U I  o U  0 \
O D  o U  o U  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C \
 1 L  1 L  0 O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 \
0 0  1 L  1 L  U I  P 0  P 0  U I  D U  U I  D L  0 O  U I  o U  o U  \
o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  C o \
 0 O O  0 O O  o O  C o  0 0 L  0 0 0  0 0 1  0 O D  0 0 P  0 O 0  U 1\
  U I  1 0  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  o \
C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  o C  0 0 0  0 0 0  o C  1 L \
 U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C \
 C I  C I  U I  U C  U I  1 0  U I  C 0  U I  1 C  U I  C U  0 O  U I \
 0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  0 0 \
I  C o  0 0 D  0 0 D  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U \
I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  o C  0 0 0  0 0 0 \
 o C  1 L  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O \
 U I  U C  U I  U I  1 D  U I  U C  U I  1 0  U I  C 0  U I  1 L  U I \
 C U  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O \
 U I  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  0 O D  o U  1 C  1 C  1\
 C  1 C  0 O D  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  \
U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1  U I  0 O \
D  1 C  0 O D  0 O D  0 O D  0 O D  o U  1 C  1 C  0 O D  0 O D  U I  \
1 1  U I  0 O D  0 O D  1 C  0 O D  o U  o U  1 C  o U  o U  U I  1 1 \
 U I  0 0 0  0 0 0  1 L  o C  o C  1 L  0 0 0  1 L  0 0 0  1 L  0 0 0 \
 0 0 0  o C  1 L  0 0 0  0 0 0  0 0 0  U I  1 0  0 O  U I  0 O D  0 O \
I  U I  D 0  D 1  U I  1 D  U I  D 0  D 1  D L  U I  0 O D  1 C  1 C  \
o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 I  U I \
 0 O D  1 C  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  0 0\
 0  1 L  0 0 0  o C  1 L  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C\
  1 L  o C  1 L  1 L  0 O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0\
 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0  U I  D 1  U I  D L  0 O  U I \
 o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I\
  U 1  0 0 1  0 O C  o O  C o  0 0 L  0 0 0  0 0 1  0 O D  0 0 P  0 O \
0  U 1  U I  1 0  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U\
 I  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  o C  0 0 0  0 0 0  o C\
  1 L  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I\
  U C  C I  C I  U I  U C  U I  1 0  U I  C 0  U I  1 C  U I  C U  0 O\
  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I\
  0 0 I  C o  0 0 D  0 0 D  0 O  U I  0 0 P  0 0 1  0 I 0  U I  D L  0\
 O  U I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  o C  0 0 0  \
0 0 0  o C  1 L  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I\
  1 O  U I  U C  U I  U I  1 D  U I  U C  U I  1 0  U I  C 0  U I  1 L\
  U I  C U  0 O  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L\
  0 O  U I  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  o C  1 L  1 L  0 \
0 0  0 0 0  1 L  o C  1 L  1 L  U I  1 O  U I  o C  0 0 0  0 0 0  o C \
 1 L  U I  1 0  0 O  U I  0 O D  0 O I  U I  D o  D P  U I  1 D  U I  \
D o  D P  D L  U I  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  o U  1 C  1\
 C  0 O D  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L\
  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 U  U I  o C  0 0 \
0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 o  U I  o U  o U  o U  o U\
  0 O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L \
 1 L  U I  P 0  P 0  U I  D D  U I  D L  0 O  U I  L U  0 0 I  0 0 0  \
0 0 1  0 0 P  0 0 D  P L  0 O 0  0 0 L  0 O D  0 O L  U I  1 O  U I  1\
 0  0 O  U I  P L  0 0 o  0 0 P  C C  0 O 1  U I  1 O  U I  1 0  0 O  \
U I  0 O D  0 O I  U I  D o  D D  U I  1 D  U I  D o  D D  D L  U I  0\
 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  U o  U I  o C  0 0 0  0\
 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 U  U I  o U  0 O D  1 C  o U  \
U I  1 D  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  U o  U \
I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 U  U I  o C  0 0 0  0 0\
 0  0 0 0  1 L  1 L  1 L  1 L  0 O  0 O 0  0 O L  0 O D  0 O I  U I  0\
 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0  U I  D P  U I  D L  \
0 O  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I \
 1 O  U I  U 1  0 0 1  0 O C  L U  0 0 0  0 0 o  0 0 1  C C  0 O 0  U \
1  U I  1 0  0 O  U I  o C  o C  1 L  0 0 0  0 0 0  o C  o C  o C  1 L\
  o C  o C  o C  U I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 0 \
 0 O  U I  0 O D  0 O I  U I  D 0  1 C  U I  1 D  U I  D 0  1 C  D L  \
U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  0 O 0  0 O L  0 O D\
  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0  U I  \
D o  U I  D L  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D \
 o U  o U  U I  1 O  U I  U 1  0 O O  0 0 0  0 0 C  0 0 O  0 O L  0 0 \
0  C o  0 O O  C D  0 O I  0 O D  0 O L  0 O 0  U 1  U I  1 0  0 O  U \
I  o C  0 0 0  1 L  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  0 0 0  U \
I  1 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  o U  0 O D  o\
 U  0 O D  1 C  1 C  0 O D  o U  U I  1 0  0 O  U I  0 O D  0 O I  U I\
  D 0  D U  U I  1 D  U I  D 0  D U  D L  U I  0 0 0  0 0 0  o C  0 0 \
0  o C  1 L  0 0 0  U I  1 U  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1\
 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 I  U I  o C  0 0 0  0 0 0\
  0 0 0  1 L  1 L  1 L  1 L  U I  1 o  U I  0 0 0  0 0 0  o C  0 0 0  \
o C  1 L  0 0 0  0 O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o\
 C  0 0 0  1 L  1 L  U I  P 0  P 0  U I  1 C  1 L  U I  D L  0 O  U I \
 o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I\
  U 1  0 O U  0 O 0  0 0 P  P o  0 0 0  0 O C  0 O C  0 0 o  0 0 O  0 \
O D  0 0 P  0 I 0  L U  0 0 0  0 0 o  0 0 1  C C  0 O 0  0 0 D  U 1  U\
 I  1 0  0 O  U I  0 0 0  o C  1 L  1 L  0 0 0  o C  o C  0 0 0  0 0 0\
  0 0 0  o C  U I  1 O  U I  1 0  0 O  U I  0 O D  0 O I  U I  D 1  D \
o  U I  1 D  U I  D 1  D o  D L  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1\
 L  1 L  1 L  U I  1 P  U I  o C  1 L  0 0 0  o C  U I  1 D  U I  0 O \
D  o U  o U  1 C  1 C  1 C  0 O D  0 O  0 O 0  0 O L  0 O D  0 O I  U \
I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0  U I  1 C  1 C  U\
 I  D L  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  \
o U  U I  1 O  U I  U 1  C o  0 O O  0 O O  L U  0 0 0  0 0 o  0 0 1  \
C C  0 O 0  U 1  U I  1 0  0 O  U I  o C  1 L  o C  o C  1 L  o C  U I\
  1 O  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 0  0 \
O  U I  0 O D  0 O I  U I  D O  D o  U I  1 D  U I  D O  D o  D L  U I\
  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 P  U I  0 \
0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 o  U I  0 O \
D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 P  U I  o C  1 L  0 0 0  o C\
  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 \
O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L\
  U I  P 0  P 0  U I  1 C  D O  U I  D L  0 O  U I  o U  o U  o U  1 C\
  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  0 0 D  0 O 0\
  0 0 P  L I  0 O 0  0 0 D  0 0 0  0 O L  0 0 L  0 O 0  0 O O  L D  0 \
0 1  0 O L  U 1  U I  1 0  0 O  U I  0 O D  0 O I  U I  0 0 O  0 0 0  \
0 0 P  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 P  U \
I  0 0 D  0 0 P  C o  0 0 1  0 0 P  0 0 D  0 0 C  0 O D  0 0 P  0 O 1 \
 U I  1 O  U I  U 1  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  D L  1 \
o  1 o  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U 1  U I  1 0  U I  \
0 0 0  0 0 1  U I  0 0 O  0 0 0  0 0 P  U I  C o  0 0 O  0 I 0  U I  1\
 O  U I  0 I O  U I  0 O D  0 0 O  U I  o U  0 O D  o U  0 O D  1 C  1\
 C  0 O D  o U  U I  0 O I  0 0 0  0 0 1  U I  0 I O  U I  0 O D  0 0 \
O  U I  0 O D  o U  o U  0 O D  0 O D  1 C  o U  o U  0 O D  U I  1 0 \
 U I  D L  0 O  U I  U I  o U  1 C  1 C  1 C  0 O D  o U  0 O D  1 C  \
U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  0 O  U I  U I  0 O D  0 O I  \
U I  U C  U P  U P  o P  L U  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  U \
P  U P  U C  U I  0 O D  0 0 O  U I  o U  0 O D  o U  0 O D  1 C  1 C \
 0 O D  o U  U I  D L  0 O  U I  U I  U I  o U  0 O D  o U  0 O D  1 C\
  1 C  0 O D  o U  U I  P 0  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 \
O D  o U  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  \
U I  1 O  U I  U C  U P  U P  o P  L U  P L  0 O D  0 0 1  0 O 0  C C \
 0 0 P  U P  U P  U C  U I  1 1  U I  U C  U C  U I  1 0  0 O  U I  U \
I  U I  o U  1 C  1 C  1 C  0 O D  o U  0 O D  1 C  U I  P 0  U I  o O\
  C o  0 O L  0 0 D  0 O 0  0 O  U I  U I  0 O D  o U  o U  o U  0 0 0\
  1 L  0 0 0  1 L  o C  U I  P 0  U I  0 I O  C L  0 O C  C C  0 O U  \
0 0 o  0 O D  U I  1 P  U I  o P  0 O D  0 0 D  0 0 P  o U  0 0 P  0 O\
 0  0 O C  U I  1 O  U I  0 0 I  C o  0 0 P  0 O 1  U I  P 0  U I  o U\
  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 0  0 O  U I  U I  0 \
O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  o U  1 C  1 C  1 C  0 O D  \
o U  0 O D  1 C  U I  D L  0 O  U I  U I  U I  0 I O  C L  0 O C  C C \
 U I  1 P  U I  L O  0 O L  C o  0 I 0  0 O 0  0 0 1  U I  1 O  U I  1\
 0  U I  1 P  U I  0 0 I  0 O L  C o  0 I 0  U I  1 O  U I  o U  0 O D\
  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 0  0 O  U I  U I  0 O 0  0 \
O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  0 I O  C L  0 O C  C \
C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  0 0 D  0 O\
 0  0 0 P  L I  0 O 0  0 0 D  0 0 0  0 O L  0 0 L  0 O 0  0 O O  L D  \
0 0 1  0 O L  U I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D\
  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I\
  1 C  U I  C U  U I  1 0  U I  1 1  U I  L 1  0 0 1  0 0 o  0 O 0  U \
I  1 1  U I  0 O D  o U  o U  o U  0 0 0  1 L  0 0 0  1 L  o C  U I  1\
 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  0 O\
 D  0 O I  U I  D O  D 1  U I  1 D  U I  D O  D 1  D L  U I  0 0 0  0 \
0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 o  U I  0 O D  1 C  1 C  o U \
 0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 D  U I  o C\
  o C  0 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  U I  0 I O  C L  0 O C\
  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  0 O 0  C\
 L  0 0 o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O  U I  U C  L L \
 P P  o o  P o  1 P  L I  0 0 o  0 0 O  L O  0 O L  0 0 o  0 O U  0 O \
D  0 0 O  1 O  U C  U I  1 U  U I  o U  0 O D  o U  0 O D  1 C  1 C  0\
 O D  o U  U I  1 U  U I  U C  1 0  U C  U I  1 0  0 O  U I  U I  0 O \
D  0 O I  U I  D o  U I  1 D  U I  D o  D L  U I  o C  o C  0 0 0  0 0\
 0  o C  o C  0 0 0  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0\
  0 0 0  o C  1 L  0 O  U I  U I  0 O D  0 O I  U I  D o  U I  1 D  U \
I  D o  D L  U I  o U  0 O D  o U  o U  U I  1 U  U I  0 O D  0 O D  o\
 U  1 C  0 O D  o U  0 O D  o U  0 O  0 O 0  0 O L  0 O D  0 O I  U I \
 0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0  U I  1 C  D 0  U I\
  D L  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o \
U  U I  1 O  U I  U 1  0 0 I  0 O L  C o  0 I 0  C D  0 0 I  0 O L  C \
o  0 I 0  0 O L  0 O D  0 0 D  0 0 P  U 1  U I  1 0  0 O  U I  0 O D  \
0 O D  o U  o U  o U  o U  0 O D  o U  1 C  1 C  1 C  U I  1 O  U I  o\
 C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  0 0 0  0 0 0  1 L  1 L  1 L\
  0 O D  0 O D  U I  1 0  0 O  U I  0 O D  0 O I  U I  D 1  D I  U I  \
1 D  U I  D 1  D I  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1\
 C  1 C  0 O D  U I  1 I  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  \
U I  1 o  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  0 O 0  0 O \
L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  P \
0  U I  1 C  D I  U I  D L  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D\
  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  0 O U  0 O 0  0 0 P  C D  \
0 I O  0 O C  0 O L  C D  0 O O  C o  0 0 P  C o  C L  C o  0 0 D  0 O\
 0  U 1  U I  1 0  0 O  U I  0 0 0  0 0 0  0 0 0  o C  0 0 0  1 L  o C\
  o C  o C  0 0 0  0 0 0  1 L  U I  1 O  U I  o U  0 O D  o U  0 O D  \
1 C  1 C  0 O D  o U  U I  1 0  0 O  U I  0 I O  C L  0 O C  C C  0 0 \
I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  0 O 0  0 0 O  0 O\
 O  o C  0 O I  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 \
I 0  U I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  \
0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U \
I  C U  U I  1 0  U I  1 0  0 O  U I  0 O D  0 O I  U I  D U  D D  U I\
  1 D  U I  D U  D D  D L  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 \
0 0  o C  1 L  U I  1 o  U I  o C  o C  0 0 0  0 0 0  o C  o C  0 0 0 \
 U I  U o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U\
 I  1 P  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  \
U I  1 o  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  0 \
O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L\
  U I  P 0  P 0  U I  1 C  D U  U I  D L  0 O  U I  o U  o U  o U  1 C\
  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  C L  0 0 1  \
0 0 0  0 0 C  0 0 D  0 O 0  C D  0 I O  0 O C  0 O L  C D  0 O O  C o \
 0 0 P  C o  C L  C o  0 0 D  0 O 0  U 1  U I  1 0  0 O  U I  0 0 0  0\
 0 0  0 0 0  o C  0 0 0  1 L  o C  o C  o C  0 0 0  0 0 0  1 L  U I  1\
 O  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1  U I  \
L 1  0 0 1  0 0 o  0 O 0  U I  1 0  0 O  U I  0 I O  C L  0 O C  C C  \
0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  0 O 0  0 0 O \
 0 O O  o C  0 O I  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1\
  0 I 0  U I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I\
 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C\
  U I  C U  U I  1 0  U I  1 0  0 O  U I  0 O D  0 O I  U I  D 1  D 0 \
 U I  1 D  U I  D 1  D 0  D L  U I  0 0 0  0 0 0  0 0 0  1 L  o C  0 0\
 0  1 L  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 O D  \
o U  o U  1 C  1 C  1 C  0 O D  U I  1 U  U I  0 O D  1 C  0 O  0 O 0 \
 0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P \
0  P 0  U I  1 C  D 1  U I  D L  0 O  U I  o U  o U  o U  1 C  0 O D  \
0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  C L  0 0 1  0 0 0  0 \
0 C  0 0 D  0 O 0  C D  C C  0 0 0  0 O C  0 O C  0 0 o  0 0 O  0 O D \
 0 0 P  0 I 0  U 1  U I  1 0  0 O  U I  0 0 0  o C  1 L  1 L  0 0 0  o\
 C  o C  0 0 0  0 0 0  0 0 0  o C  U I  1 O  U I  o U  0 O D  o U  0 O\
 D  1 C  1 C  0 O D  o U  U I  1 1  U I  C L  0 0 1  0 0 0  0 0 C  0 0\
 D  0 O 0  U I  P 0  U I  L 1  0 0 1  0 0 o  0 O 0  U I  1 0  0 O  U I\
  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U \
I  1 P  U I  0 O 0  0 0 O  0 O O  o C  0 O I  P L  0 O D  0 0 1  0 O 0\
  C C  0 0 P  0 0 0  0 0 1  0 I 0  U I  1 O  U I  0 O D  0 0 O  0 0 P \
 U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U \
 0 0 L  U I  C 0  U I  1 C  U I  C U  U I  1 0  U I  1 0  0 O  U I  0 \
O D  0 O I  U I  D D  D O  U I  1 D  U I  D D  D O  D L  U I  o U  1 C\
  o U  0 O D  1 C  1 C  1 C  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  \
o C  1 L  o C  1 L  1 L  U I  1 U  U I  0 0 0  o C  1 L  0 0 0  1 L  0\
 0 0  0 0 0  o C  1 L  0 O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 \
0 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0  U I  1 C  D D  U I  0 0 0  0\
 0 1  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0  U I  1 C\
  1 C  D D  U I  D L  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C \
 0 O D  o U  o U  U I  1 O  U I  U 1  0 O U  0 O 0  0 0 P  L I  0 O 0 \
 0 O U  0 O 0  0 I O  L O  C o  0 0 1  0 0 D  0 O 0  0 O O  U 1  U I  \
1 0  0 O  U I  0 O D  0 O I  U I  D o  D 1  U I  1 D  U I  D o  D 1  D\
 L  U I  o U  o U  o U  o U  U I  U o  U I  o U  1 C  1 C  0 O D  U I \
 1 o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  0 O  U I  o C  o C\
  o C  1 L  o C  o C  0 0 0  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  \
0 O  U I  0 O D  0 O I  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C \
 1 L  0 0 0  0 0 0  1 L  o C  U I  C o  0 0 O  0 O O  U I  U C  0 O L \
 0 O D  0 0 D  0 0 P  0 0 1  0 O 0  0 0 I  0 O 0  C o  0 0 P  U C  U I\
  0 O D  0 0 O  U I  0 0 o  0 0 1  0 O L  0 O L  0 O D  C L  U I  1 P \
 U I  0 0 o  0 0 O  0 0 U  0 0 o  0 0 0  0 0 P  0 O 0  C D  0 0 I  0 O\
 L  0 0 o  0 0 D  U I  1 O  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  \
o C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 0  U I  D L  0 O  U I  U I  0\
 O D  o U  1 C  1 C  1 C  o U  1 C  1 C  0 O D  U I  1 1  U I  o U  0 \
O D  o U  o U  0 O D  1 C  o U  1 C  o U  1 C  1 C  o U  0 O D  U I  1\
 1  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 O D  U I  1 1  U I  \
o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C \
 U I  1 1  U I  o C  o C  1 L  0 0 0  0 0 0  o C  0 0 0  o C  o C  1 L\
  o C  o C  0 0 0  U I  P 0  U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  \
1 O  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0 \
 1 L  o C  U I  1 1  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U\
  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  1 C  D 0  U I  1 D  U I \
 1 C  D 0  D L  U I  o U  0 O D  1 C  o U  U I  1 D  U I  o U  0 O D  \
o U  o U  U I  U o  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L \
 1 L  U I  1 U  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  0\
 O  U I  U I  0 0 0  1 L  o C  o C  o C  o C  o C  1 L  o C  U I  P 0 \
 U I  U C  U C  0 O  U I  U I  0 O D  0 O I  U I  D P  D P  U I  1 D  \
U I  D P  D P  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1\
 C  0 O D  U I  1 P  U I  o U  o U  o U  o U  U I  U o  U I  0 O D  o \
U  o U  1 C  1 C  1 C  0 O D  0 O  U I  U I  0 O D  0 O I  U I  1 C  1\
 L  U I  1 D  U I  1 C  1 L  D L  U I  0 O D  o U  o U  1 C  1 C  1 C \
 0 O D  U I  1 U  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C\
  0 O D  0 O  U I  U I  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L\
  1 L  0 0 0  U I  P 0  U I  0 O D  1 C  1 C  o U  1 C  0 O D  o U  0 \
O D  U I  C 0  U I  U C  0 0 O  C o  0 O C  0 O 0  U C  U I  C U  0 O \
 U I  U I  o U  o U  0 0 0  o C  U I  P 0  U I  o C  0 0 0  o C  1 L  \
o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 P  U I  0 0 I \
 0 0 0  0 0 I  U I  1 O  U I  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 \
0  1 L  1 L  0 0 0  U I  1 0  0 O  U I  U I  0 O D  0 O I  U I  1 C  D\
 0  U I  1 D  U I  1 C  D 0  D L  U I  o U  1 C  1 C  0 O D  0 O  U I \
 U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  P 0  U I  U C\
  U C  0 O  U I  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  C\
 C  0 0 0  0 0 I  0 I 0  0 O  U I  U I  o U  0 O D  0 O D  o U  1 C  1\
 C  1 C  U I  P 0  U I  U C  U C  0 O  U I  U I  o C  1 L  o C  o C  o\
 C  0 0 0  1 L  o C  0 0 0  1 L  U I  P 0  U I  1 L  0 O  U I  U I  0 \
O I  0 0 0  0 0 1  U I  0 0 0  1 L  1 L  o C  1 L  U I  0 O D  0 0 O  \
U I  o U  0 O D  o U  o U  0 O D  1 C  o U  1 C  o U  1 C  1 C  o U  0\
 O D  U I  D L  0 O  U I  U I  U I  0 O D  0 O I  U I  D I  1 L  U I  \
1 D  U I  D I  1 L  D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I\
  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 \
U  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U \
 U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 P  U I  o U  o U  \
o U  o U  0 O  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I \
 U I  U I  U I  o C  1 L  o C  o C  o C  0 0 0  1 L  o C  0 0 0  1 L  \
U I  1 U  P 0  U I  1 C  0 O  U I  U I  U I  U I  o C  1 L  0 0 0  0 0\
 0  1 L  o C  1 L  o C  o C  1 L  o C  0 0 0  U I  P 0  U I  C C  0 0 \
0  0 0 I  0 I 0  U I  1 P  U I  0 O O  0 O 0  0 O 0  0 0 I  C C  0 0 0\
  0 0 I  0 I 0  U I  1 O  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o \
C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 0  0 O  U I  U I  U I  U I  0 O\
 D  0 O I  U I  D 1  D 1  U I  1 D  U I  D 1  D 1  D L  U I  0 O D  o \
U  o U  1 C  1 C  1 C  0 O D  U I  U o  U I  0 O D  1 C  1 C  o U  0 O\
 D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  U o  U I  o U  0 \
O D  1 C  o U  0 O  U I  U I  U I  U I  0 0 0  1 L  o C  o C  o C  o C\
  U I  P 0  U I  0 O D  o U  1 C  1 C  1 C  o U  1 C  1 C  0 O D  0 O \
 U I  U I  U I  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0\
 0  0 0 0  0 0 0  U I  P 0  U I  1 L  0 O  U I  U I  U I  U I  0 O I  \
0 0 0  0 0 1  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0\
  0 0 0  0 0 0  U I  0 O D  0 0 O  U I  0 0 1  C o  0 0 O  0 O U  0 O \
0  U I  1 O  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 0 0  1 L  1 L \
 o C  1 L  U I  1 0  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I \
 0 O D  0 O I  U I  D U  D P  U I  1 D  U I  D U  D P  D L  U I  0 0 0\
  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  0 O D  o U  o U  1 \
C  1 C  1 C  0 O D  U I  1 P  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O\
 D  U I  1 I  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 D  U I \
 0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  U I  1 P  U I  o C  o C  0\
 0 0  0 0 0  o C  o C  0 0 0  0 O  U I  U I  U I  U I  U I  0 O D  0 O\
 I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  o C  1 L  0 0 0  0 0 0  1\
 L  o C  1 L  o C  o C  1 L  o C  0 0 0  U I  1 0  U I  P I  U I  1 L \
 U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 O I  0 0 0  0 0 1  U I\
  0 O D  o U  1 C  1 C  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  o U  0 \
O D  U I  1 1  U I  0 0 0  0 0 0  1 L  o C  1 L  1 L  0 0 0  1 L  o C \
 1 L  o C  0 0 0  U I  0 O D  0 0 O  U I  o C  1 L  0 0 0  0 0 0  1 L \
 o C  1 L  o C  o C  1 L  o C  0 0 0  U I  1 P  U I  0 O D  0 0 P  0 O\
 0  0 0 1  0 O D  0 0 P  0 O 0  0 O C  0 0 D  U I  1 O  U I  1 0  U I \
 D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 0\
  0 0 0  1 L  o C  1 L  1 L  0 0 0  1 L  o C  1 L  o C  0 0 0  U I  0 \
O D  0 0 D  U I  0 0 O  0 0 0  0 0 P  U I  o L  0 0 0  0 0 O  0 O 0  U\
 I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  0 O I  0 0 0  0 \
0 1  U I  0 O D  0 O D  0 O D  1 C  1 C  U I  1 1  U I  o U  1 C  0 O \
D  1 C  1 C  o U  o U  o U  0 O D  U I  0 O D  0 0 O  U I  0 0 0  0 0 \
0  1 L  o C  1 L  1 L  0 0 0  1 L  o C  1 L  o C  0 0 0  U I  1 P  U I\
  0 O D  0 0 P  0 O 0  0 0 1  0 O D  0 0 P  0 O 0  0 O C  0 0 D  U I  \
1 O  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  \
U I  0 O D  0 O I  U I  o U  1 C  0 O D  1 C  1 C  o U  o U  o U  0 O \
D  U I  0 O D  0 0 D  U I  0 0 O  0 0 0  0 0 P  U I  o L  0 0 0  0 0 O\
  0 O 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U\
 I  0 O D  0 O I  U I  1 C  D o  U I  1 D  U I  1 C  D o  D L  U I  o \
U  o U  o U  o U  U I  1 I  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0\
 O D  o U  U I  1 U  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  0 0 0  U\
 I  1 D  U I  o U  o U  o U  o U  U I  1 U  U I  0 0 0  o C  1 L  0 0 \
0  1 L  0 0 0  0 0 0  o C  1 L  0 O  U I  U I  U I  U I  U I  U I  U I\
  U I  U I  U I  0 O D  0 O I  U I  1 C  D I  U I  1 D  U I  1 C  D I \
 D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  U I  U I  U I  U \
I  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D 0  D P  U I  1 D\
  U I  D 0  D P  D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C \
 1 C  0 O D  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 \
O D  0 O I  U I  D D  D o  U I  1 D  U I  D D  D o  D L  U I  o U  1 C\
  1 C  0 O D  U I  1 P  U I  o U  o U  o U  o U  0 O  U I  U I  U I  U\
 I  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 0 P  0 I 0  0 0\
 I  0 O 0  U I  1 O  U I  o U  1 C  0 O D  1 C  1 C  o U  o U  o U  0 \
O D  U I  1 0  U I  0 O D  0 0 D  U I  0 O O  0 O D  C C  0 0 P  U I  \
D L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 O I\
  0 0 0  0 0 1  U I  0 O D  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  o\
 U  1 C  1 C  o U  o U  U I  1 1  U I  o U  o U  1 C  U I  0 O D  0 0 \
O  U I  o U  1 C  0 O D  1 C  1 C  o U  o U  o U  0 O D  U I  1 P  U I\
  0 O D  0 0 P  0 O 0  0 0 1  0 O D  0 0 P  0 O 0  0 O C  0 0 D  U I  \
1 O  U I  1 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  \
U I  U I  U I  U I  0 O D  0 O I  U I  o U  o U  1 C  U I  0 O D  0 0 \
D  U I  0 0 O  0 0 0  0 0 P  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  \
0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  \
0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  o L  0 0 0  0 0 O\
  0 O 0  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U\
 I  U I  0 O D  0 O I  U I  0 O D  0 0 D  0 O D  0 0 O  0 0 D  0 0 P  \
C o  0 0 O  C C  0 O 0  U I  1 O  U I  0 0 0  1 L  1 L  o C  1 L  U I \
 1 1  U I  0 0 P  0 0 o  0 0 I  0 O L  0 O 0  U I  1 0  U I  D L  0 O \
 U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I \
 0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I\
  U I  U I  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  \
1 L  1 L  U I  P 0  U I  0 0 0  1 L  1 L  o C  1 L  U I  C 0  U I  o C\
  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C\
 U  U I  1 P  U I  0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U\
 I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  0 O  U I  U I  \
U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 O 0  0 I\
 O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I  U I  U I  \
U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0 \
 0 0 0  1 L  1 L  U I  P 0  U I  0 0 0  1 L  1 L  o C  1 L  U I  C 0  \
U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0\
  U I  C U  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I\
  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  \
U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 0 P  0 0 1  0\
 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I \
 U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P\
 0  U I  0 0 0  1 L  1 L  o C  1 L  U I  1 P  U I  0 O O  0 O 0  C C  \
0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P\
  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I\
  U I  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L\
  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I\
  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  0 0 0\
  1 L  1 L  o C  1 L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I\
  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D O  D D  U I  1 D \
 U I  D O  D D  D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  \
U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 O D\
  0 O I  U I  U C  C 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  \
1 L  o C  0 0 0  1 L  1 L  0 0 0  U I  1 U  U I  U C  1 P  0 0 I  C o \
 0 0 1  C o  0 O C  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O \
 U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 \
0  U I  1 U  U I  1 C  U I  1 0  U I  1 U  U I  U C  C U  C 0  P L  P \
C  C U  U C  U I  0 O D  0 0 O  U I  o U  o U  1 C  U I  D L  0 O  U I\
  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  o U\
  o U  1 C  U I  P 0  U I  o U  o U  1 C  U I  1 P  U I  0 0 1  0 O 0 \
 0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  C 0  U C  U I  1 U\
  U I  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  1 L  0 0 0  U I\
  1 U  U I  U C  1 P  0 0 I  C o  0 0 1  C o  0 O C  U C  U I  1 U  U \
I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 \
0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 U  U I  1 C  U I  1 0  U I \
 1 U  U I  U C  C U  C 0  P L  P C  C U  U C  U I  1 1  U I  0 0 o  0 \
0 O  0 O 0  0 0 D  C C  C o  0 0 I  0 O 0  U I  1 O  U I  0 0 0  0 0 0\
  0 0 0  0 0 0  1 L  1 L  U I  1 0  U I  1 0  0 O  U I  U I  U I  U I \
 U I  U I  U I  U I  U I  U I  U I  U I  U I  o U  1 C  0 O D  1 C  1 \
C  o U  o U  o U  0 O D  U I  C 0  U I  0 O D  1 C  0 O D  1 C  0 O D \
 1 C  1 C  0 O D  o U  1 C  1 C  o U  o U  U I  C U  U I  P 0  U I  o \
U  o U  1 C  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O \
0  U I  1 O  U I  U C  C 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  0 0\
 0  1 L  o C  0 0 0  1 L  1 L  0 0 0  U I  1 U  U I  U C  1 P  0 0 I  \
C o  0 0 1  C o  0 O C  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  \
1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  \
0 0 0  U I  1 U  U I  1 C  U I  1 0  U I  1 U  U I  U C  C U  U C  U I\
  1 1  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  1 0  0 O  U I  \
U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O\
 I  U I  D O  D D  U I  1 D  U I  D O  D D  D L  U I  0 0 0  o C  1 L \
 0 0 0  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 D  U I  0 O\
 D  1 C  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U\
 I  U I  0 O D  0 O I  U I  D 1  D D  U I  1 D  U I  D 1  D D  D L  U \
I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I  1 o  U\
 I  0 O D  1 C  U I  1 I  U I  0 O D  1 C  1 C  o U  0 O D  1 C  1 C  \
o U  1 C  o U  0 O D  1 C  0 O D  U I  U o  U I  o C  0 0 0  0 0 0  0 \
0 0  1 L  1 L  1 L  1 L  U I  1 P  U I  0 0 0  o C  1 L  0 0 0  1 L  0\
 0 0  0 0 0  o C  1 L  U I  1 I  U I  o U  o U  o U  o U  0 O  U I  U \
I  U I  U I  U I  U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0 \
 U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I \
 0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  o L  0 0 0  0 0 \
O  0 O 0  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  \
0 O D  0 O I  U I  0 O D  0 0 D  0 O D  0 0 O  0 0 D  0 0 P  C o  0 0 \
O  C C  0 O 0  U I  1 O  U I  0 0 0  1 L  1 L  o C  1 L  U I  1 1  U I\
  0 0 P  0 0 o  0 0 I  0 O L  0 O 0  U I  1 0  U I  D L  0 O  U I  U I\
  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 0 P  0 0 1  0 I \
0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U \
I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  0 0 \
0  1 L  1 L  o C  1 L  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0\
 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  C U  U I  1 P  U I  0 O O  0 O\
 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I \
 1 D  D P  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  U I  U I \
 U I  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L \
 0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I \
 0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  0 0 0  1 L  1 L \
 o C  1 L  U I  C 0  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C\
  0 0 0  0 0 0  0 0 0  U I  C U  0 O  U I  U I  U I  U I  U I  U I  U \
I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I \
 U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 0 P  0 0 1  \
0 I 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I\
  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  \
0 0 0  1 L  1 L  o C  1 L  U I  1 P  U I  0 O O  0 O 0  C C  0 0 0  0 \
O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U \
I  1 0  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U \
I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U \
I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0\
 0  0 0 0  1 L  1 L  U I  P 0  U I  0 0 0  1 L  1 L  o C  1 L  0 O  U \
I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I\
  U C  C 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 \
0 0  1 L  1 L  0 0 0  U I  1 U  U I  U C  1 P  0 0 I  C o  0 0 1  C o \
 0 O C  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  o C  0\
 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 U \
 U I  1 C  U I  1 0  U I  1 U  U I  U C  C U  C 0  P L  P C  C U  U C \
 U I  0 O D  0 0 O  U I  o U  1 C  0 O D  1 C  1 C  o U  o U  o U  0 O\
 D  U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U\
 I  U I  0 O D  0 O I  U I  D o  U I  1 D  U I  D o  D L  U I  o U  0 \
O D  1 C  o U  U I  1 I  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C \
 1 L  1 L  U I  1 P  U I  o C  1 L  0 0 0  o C  U I  1 D  U I  o U  1 \
C  o U  0 O D  1 C  1 C  1 C  0 O  U I  U I  U I  U I  U I  U I  U I  \
U I  U I  U I  U I  U I  o U  1 C  0 O D  1 C  1 C  o U  o U  o U  0 O\
 D  U I  P 0  U I  o U  1 C  0 O D  1 C  1 C  o U  o U  o U  0 O D  U \
I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U \
I  U C  C 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0\
 0 0  1 L  1 L  0 0 0  U I  1 U  U I  U C  1 P  0 0 I  C o  0 0 1  C o\
  0 O C  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  o C  \
0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 U\
  U I  1 C  U I  1 0  U I  1 U  U I  U C  C U  C 0  P L  P C  C U  U C\
  U I  1 1  U I  0 0 o  0 0 O  0 O 0  0 0 D  C C  C o  0 0 I  0 O 0  U\
 I  1 O  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  1 0  U I  1 0\
  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 O\
 D  0 O I  U I  D 0  1 C  U I  1 D  U I  D 0  1 C  D L  U I  0 0 0  0 \
0 0  o C  0 0 0  o C  1 L  o C  1 L  1 L  U I  1 I  U I  0 O D  1 C  1\
 C  o U  0 O D  1 C  1 C  o U  1 C  o U  0 O D  1 C  0 O D  U I  1 P  \
U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  o C  1 L \
 0 0 0  o C  U I  1 I  U I  0 0 0  o C  1 L  0 0 0  1 L  0 0 0  0 0 0 \
 o C  1 L  U I  U o  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  \
1 C  0 O D  0 O  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I  U I\
  0 0 0  0 0 0  1 L  o C  1 L  1 L  0 0 0  1 L  o C  1 L  o C  0 0 0  \
U I  C 0  U I  0 O D  0 O D  0 O D  1 C  1 C  U I  C U  U I  P 0  U I \
 o U  1 C  0 O D  1 C  1 C  o U  o U  o U  0 O D  U I  1 P  U I  0 0 1\
  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  C 0  U C  \
U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  1 L  0 \
0 0  U I  1 U  U I  U C  1 P  0 0 I  C o  0 0 1  C o  0 O C  U C  U I \
 1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  o C  0 0 0  0 0 0  1 L \
 1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 U  U I  1 C  U I  1\
 0  U I  1 U  U I  U C  C U  U C  U I  1 1  U I  0 0 0  0 0 0  0 0 0  \
0 0 0  1 L  1 L  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  U I  U I\
  U I  U I  U I  0 O D  0 O I  U I  D D  D D  U I  1 D  U I  D D  D D \
 D L  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  1 U  U I  o U  1 \
C  o U  0 O D  1 C  1 C  1 C  U I  1 P  U I  o C  0 0 0  0 0 0  0 0 0 \
 1 L  1 L  1 L  1 L  U I  1 I  U I  o C  o C  0 0 0  0 0 0  o C  o C  \
0 0 0  U I  1 U  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  0 O  U I  U\
 I  U I  U I  U I  U I  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D \
1  U I  1 D  U I  D 1  D L  U I  o U  1 C  1 C  0 O D  U I  1 D  U I  \
0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  U I  U I  U I  0 0 0  0 0 \
0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 \
O  U I  U I  U I  U I  U I  0 O D  0 O I  U I  0 O D  0 0 D  0 O D  0 \
0 O  0 0 D  0 0 P  C o  0 0 O  C C  0 O 0  U I  1 O  U I  0 0 0  1 L  \
1 L  o C  1 L  U I  1 1  U I  0 0 P  0 0 o  0 0 I  0 O L  0 O 0  U I  \
1 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 P  0 0 1  0 I 0 \
 U I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0\
  0 0 0  1 L  1 L  U I  P 0  U I  0 0 0  1 L  1 L  o C  1 L  U I  C 0 \
 U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 \
0  U I  C U  U I  1 P  U I  0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U \
I  1 O  U I  U C  0 0 o  0 0 P  0 O I  1 D  D P  U C  U I  1 0  0 O  U\
 I  U I  U I  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U\
 I  D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  \
0 0 0  1 L  1 L  U I  P 0  U I  0 0 0  1 L  1 L  o C  1 L  U I  C 0  U\
 I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0 \
 U I  C U  0 O  U I  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U\
 I  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  \
D L  0 O  U I  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 \
0  1 L  1 L  U I  P 0  U I  0 0 0  1 L  1 L  o C  1 L  U I  1 P  U I  \
0 O O  0 O 0  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U C  0 0 o  0 0\
 P  0 O I  1 D  D P  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  U I \
 0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  0 O  U I  U I  U I \
 U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  P 0  U\
 I  0 0 0  1 L  1 L  o C  1 L  0 O  U I  U I  U I  U I  U I  0 O D  0 \
O I  U I  U C  C 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L \
 o C  0 0 0  1 L  1 L  0 0 0  U I  1 U  U I  U C  1 P  0 0 I  C o  0 0\
 1  C o  0 O C  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I\
  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U\
 I  1 U  U I  1 C  U I  1 0  U I  1 U  U I  U C  C U  C 0  P L  P C  C\
 U  U C  U I  0 O D  0 0 O  U I  0 0 0  1 L  o C  o C  o C  o C  U I  \
D L  0 O  U I  U I  U I  U I  U I  U I  0 0 0  1 L  o C  o C  o C  o C\
  U I  P 0  U I  0 0 0  1 L  o C  o C  o C  o C  U I  1 P  U I  0 0 1 \
 0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  C 0  U C  U\
 I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  1 L  0 0\
 0  U I  1 U  U I  U C  1 P  0 0 I  C o  0 0 1  C o  0 O C  U C  U I  \
1 U  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  o C  0 0 0  0 0 0  1 L  \
1 L  0 0 0  1 L  o C  0 0 0  0 0 0  0 0 0  U I  1 U  U I  1 C  U I  1 \
0  U I  1 U  U I  U C  C U  C 0  P L  P C  C U  U C  U I  1 1  U I  0 \
0 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  1 0  0 O  U I  U I  U I  U I \
 U I  0 0 0  1 L  o C  o C  o C  o C  U I  P 0  U I  0 0 0  1 L  o C  \
o C  o C  o C  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 \
O 0  U I  1 O  U I  U C  C 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  0\
 0 0  1 L  o C  0 0 0  1 L  1 L  0 0 0  U I  1 U  U I  U C  1 P  0 0 I\
  C o  0 0 1  C o  0 O C  U C  U I  1 U  U I  0 0 D  0 0 P  0 0 1  U I\
  1 O  U I  o C  0 0 0  0 0 0  1 L  1 L  0 0 0  1 L  o C  0 0 0  0 0 0\
  0 0 0  U I  1 U  U I  1 C  U I  1 0  U I  1 U  U I  U C  C U  U C  U\
 I  1 1  U I  0 O 0  0 0 D  C C  C o  0 0 I  0 O 0  U I  1 O  U I  0 0\
 0  0 0 0  0 0 0  0 0 0  1 L  1 L  U I  1 0  U I  1 0  0 O  U I  U I  \
U I  U I  U I  0 O D  0 O I  U I  D P  D o  U I  1 D  U I  D P  D o  D\
 L  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L  U I  1 D  U I  \
0 0 0  1 L  0 0 0  o C  1 L  U I  1 P  U I  o U  o U  0 O D  o U  0 O \
D  o U  o U  1 C  1 C  0 O D  U I  U o  U I  o C  o C  0 0 0  0 0 0  o\
 C  o C  0 0 0  U I  1 P  U I  0 0 0  0 0 0  o C  0 0 0  o C  1 L  o C\
  1 L  1 L  0 O  U I  U I  U I  U I  0 0 0  1 L  o C  o C  o C  o C  U\
 I  P 0  U I  0 0 0  1 L  o C  o C  o C  o C  U I  1 P  U I  0 0 1  0 \
O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  C 0  U C  U I \
 1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  1 L  1 L  0 0 0 \
 U I  1 U  U I  U C  1 P  0 0 I  C o  0 0 1  C o  0 O C  U C  U I  1 U\
  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  1 L  U I  1 0  U I  1 U  U \
I  U C  C U  U C  U I  1 1  U I  0 0 D  0 0 P  0 0 1  U I  1 O  U I  o\
 C  1 L  o C  o C  o C  0 0 0  1 L  o C  0 0 0  1 L  U I  1 0  U I  1 \
0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D 0  D U  U I  1 D  U I\
  D 0  D U  D L  U I  o U  0 O D  1 C  o U  U I  1 o  U I  0 0 0  0 0 \
0  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  o U  o U  0 O D  o U  0\
 O D  o U  o U  1 C  1 C  0 O D  U I  1 P  U I  o U  0 O D  1 C  o U  \
0 O  U I  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D L  0 O  U I  U I \
 U I  U I  U I  0 O D  0 O I  U I  o C  o C  1 L  0 0 0  0 0 0  o C  0\
 0 0  o C  o C  1 L  o C  o C  0 0 0  U I  C o  0 0 O  0 O O  U I  U C\
  C 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  o C  0 0 0  \
1 L  1 L  0 0 0  U I  1 U  U I  U C  1 P  C C  0 0 0  0 0 0  0 O o  0 \
O D  0 O 0  0 0 D  C U  U C  U I  0 O D  0 0 O  U I  0 0 0  1 L  o C  \
o C  o C  o C  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 0  1 L\
  o C  o C  o C  o C  U I  P 0  U I  0 0 0  1 L  o C  o C  o C  o C  U\
 I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U\
 I  U C  C 0  U C  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  o C  \
0 0 0  1 L  1 L  0 0 0  U I  1 U  U I  U C  1 P  C C  0 0 0  0 0 0  0 \
O o  0 O D  0 O 0  0 0 D  C U  U C  U I  1 1  U I  o U  o U  0 O D  o \
U  0 O D  0 O D  0 O D  o U  o U  o U  o U  0 O D  1 C  U I  1 O  U I \
 o C  o C  1 L  0 0 0  0 0 0  o C  0 0 0  o C  o C  1 L  o C  o C  0 0\
 0  U I  1 0  U I  1 0  0 O  U I  U I  U I  U I  0 O 0  0 I O  C C  0 \
O 0  0 0 I  0 0 P  U I  D L  U I  0 0 I  C o  0 0 D  0 0 D  0 O  U I  \
U I  U I  U I  0 O D  0 O I  U I  D U  D U  U I  1 D  U I  D U  D U  D\
 L  U I  o U  0 O D  o U  o U  U I  U o  U I  o U  1 C  1 C  0 O D  U \
I  1 I  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  U I  U I  0 O\
 D  0 O I  U I  D o  D U  U I  1 D  U I  D o  D U  D L  U I  o C  1 L \
 0 0 0  o C  U I  1 o  U I  o U  0 O D  1 C  o U  U I  1 D  U I  0 0 0\
  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  0 O D  1 C  U I  1 \
P  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  U I  U I  0 O D  0\
 O I  U I  D 1  D 0  U I  1 D  U I  D 1  D 0  D L  U I  0 0 0  o C  1 \
L  0 0 0  U I  1 o  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L  1 L \
 0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D O  D I  U I  1 D  U I  \
D O  D I  D L  U I  o U  0 O D  o U  o U  U I  1 o  U I  0 0 0  o C  1\
 L  0 0 0  U I  U o  U I  o C  1 L  0 0 0  o C  U I  1 I  U I  0 0 0  \
0 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 D  U I  0 0 0  o C  1 L  0 \
0 0  0 O  U I  U I  U I  U I  0 O D  o U  1 C  0 O D  0 O D  U I  P 0 \
 U I  U C  U C  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  D 1  1 C  \
U I  1 D  U I  D 1  1 C  D L  U I  o U  0 O D  o U  o U  U I  1 I  U I\
  o U  1 C  1 C  0 O D  U I  1 P  U I  o C  o C  0 0 0  0 0 0  o C  o \
C  0 0 0  0 O  U I  U I  U I  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 \
0 O  U I  1 O  U I  o C  1 L  0 0 0  0 0 0  1 L  o C  1 L  o C  o C  1\
 L  o C  0 0 0  U I  1 0  U I  P I  U I  1 L  U I  D L  0 O  U I  U I \
 U I  U I  U I  0 O D  o U  1 C  0 O D  0 O D  U I  P 0  U I  0 0 0  o\
 C  0 0 0  0 0 0  1 L  0 0 0  o C  U I  1 O  U I  o C  1 L  0 0 0  0 0\
 0  1 L  o C  1 L  o C  o C  1 L  o C  0 0 0  U I  1 1  U I  U C  0 O \
L  0 0 D  0 0 I  0 0 1  0 0 0  0 0 1  0 0 0  0 0 0  0 0 P  U C  U I  1\
 0  0 O  U I  U I  U I  U I  U I  0 O D  o U  1 C  0 O D  0 O D  U I  \
P 0  U I  0 O D  o U  1 C  0 O D  0 O D  U I  1 P  U I  0 0 D  0 0 I  \
0 O L  0 O D  0 0 P  U I  1 O  U I  U C  P O  0 O L  0 0 D  0 0 I  0 0\
 1  0 0 0  0 0 1  0 0 0  0 0 0  0 0 P  P I  U C  U I  1 0  U I  C 0  U\
 I  1 C  U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U\
 I  1 O  U I  U C  P O  1 o  0 O L  0 0 D  0 0 I  0 0 1  0 0 0  0 0 1 \
 0 0 0  0 0 0  0 0 P  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O\
  U I  U I  U I  U I  U I  0 O D  0 O I  U I  D I  D I  U I  1 D  U I \
 D I  D I  D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  0 O  U I  \
U I  U I  U I  U I  0 O D  0 O I  U I  D U  D U  U I  1 D  U I  D U  D\
 U  D L  U I  o U  o U  o U  o U  U I  1 P  U I  0 O D  1 C  U I  1 I \
 U I  0 O D  1 C  0 O  U I  U I  U I  U I  0 0 P  0 0 1  0 I 0  U I  D\
 L  0 O  U I  U I  U I  U I  U I  o U  0 O D  0 O D  o U  1 C  1 C  1 \
C  U I  1 U  P 0  U I  U C  C I  0 0 O  P O  0 O D  0 0 P  0 O 0  0 O \
C  P I  U o  0 0 D  C I  0 0 O  U o  0 0 D  P O  1 o  0 O D  0 0 P  0 \
O 0  0 O C  P I  U C  U I  U o  U I  1 O  U I  0 0 0  1 L  o C  o C  o\
 C  o C  U I  1 1  U I  0 O D  o U  1 C  0 O D  0 O D  U I  1 0  0 O  \
U I  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  D L  \
U I  o U  0 O D  0 O D  o U  1 C  1 C  1 C  U I  1 U  P 0  U I  U C  C\
 I  0 0 O  P O  0 O D  0 0 P  0 O 0  0 O C  P I  U o  0 0 D  C I  0 0 \
O  U o  0 0 D  P O  1 o  0 O D  0 0 P  0 O 0  0 O C  P I  U C  U I  U \
o  U I  1 O  U I  0 0 0  1 L  o C  o C  o C  o C  U I  1 P  U I  0 O 0\
  0 0 O  C C  0 0 0  0 O O  0 O 0  U I  1 O  U I  U 1  0 0 o  0 0 P  0\
 O I  1 D  D P  U 1  U I  1 0  U I  1 1  U I  0 O D  o U  1 C  0 O D  \
0 O D  U I  1 0  0 O  U I  U I  U I  0 O 0  0 I O  C C  0 O 0  0 0 I  \
0 0 P  U I  D L  U I  0 0 P  0 0 1  C o  C C  0 O 0  C L  C o  C C  0 \
O o  U I  1 P  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  C D  0 O 0  0 I\
 O  C C  U I  1 O  U I  0 O I  0 O D  0 O L  0 O 0  U I  P 0  U I  0 0\
 D  0 I 0  0 0 D  U I  1 P  U I  0 0 D  0 0 P  0 O O  0 0 0  0 0 o  0 \
0 P  U I  1 0  0 O  U I  U I  U I  0 O D  0 O I  U I  D P  D O  U I  1\
 D  U I  D P  D O  D L  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U \
I  U o  U I  o U  1 C  o U  0 O D  1 C  1 C  1 C  U I  U o  U I  0 0 0\
  1 L  0 0 0  o C  1 L  U I  1 U  U I  0 0 0  1 L  0 0 0  o C  1 L  0 \
O  U I  U I  U I  0 O D  0 O I  U I  D 1  U I  1 D  U I  D 1  D L  U I\
  o U  0 O D  o U  o U  0 O  U I  U I  U I  0 O D  0 O I  U I  D D  D \
0  U I  1 D  U I  D D  D 0  D L  U I  0 O D  1 C  U I  1 I  U I  0 0 0\
  o C  1 L  0 0 0  1 L  0 0 0  0 0 0  o C  1 L  U I  1 U  U I  0 0 0  \
1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  1 D  U I  o U  0 O D  o U  o U \
 U I  1 P  U I  0 0 0  1 L  0 0 0  o C  1 L  0 O  U I  U I  U I  0 O D\
  0 O I  U I  D o  D 0  U I  1 D  U I  D o  D 0  D L  U I  0 0 0  0 0 \
0  o C  0 0 0  o C  1 L  o C  1 L  1 L  0 O  U I  U I  U I  0 O D  0 O\
 I  U I  D P  1 L  U I  1 D  U I  D P  1 L  D L  U I  o U  1 C  1 C  0\
 O D  U I  1 P  U I  0 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 D  \
U I  o U  o U  o U  o U  U I  1 U  U I  o C  1 L  0 0 0  o C  U I  1 U\
  U I  0 O D  0 O D  o U  1 C  0 O D  o U  0 O D  o U  U I  U o  U I  \
o U  o U  o U  o U  0 O  U I  U I  o U  o U  o U  1 C  0 O D  0 O D  1\
 C  0 O D  o U  o U  U I  1 O  U I  0 0 1  0 O 0  0 0 I  0 0 1  U I  1\
 O  U I  o U  0 O D  0 O D  o U  1 C  1 C  1 C  U I  1 0  U I  1 0  0 \
O  U I  U I  o C  1 L  0 0 0  o C  1 L  U I  1 O  U I  U C  U C  U I  \
1 1  U I  U C  U C  U I  1 1  U I  o U  0 O D  0 O D  o U  1 C  1 C  1\
 C  U I  1 0  0 O  U I  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0\
 o  0 O U  0 O D  0 0 O  U I  1 P  U I  0 O 0  0 0 O  0 O O  o C  0 O \
I  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  U I  1 O\
  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1\
 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U I  C U  U I  \
1 0  U I  1 0  0 O  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U \
I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1  U I  o\
 C  o C  1 L  1 L  U I  P 0  U I  0 0 0  o C  o C  0 0 0  0 0 0  U I  \
1 O  U I  o C  0 0 0  o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0 \
 1 L  o C  U I  1 1  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U\
  U I  1 0  0 O  U I  U I  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  0 0\
 1  0 O 0  0 0 I  0 0 1  U I  1 O  U I  o U  0 O D  o U  0 O D  1 C  1\
 C  0 O D  o U  U I  1 0  U I  1 1  U I  o C  o C  1 L  1 L  U I  1 1 \
 U I  U C  0 O D  0 O C  0 O 1  0 O 0  0 0 1  0 O 0  U C  0 O  U I  U \
I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  1 O  U I  o C  0 0 0  \
o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C o  0\
 0 O  0 O O  U I  U C  0 0 O  0 0 0  0 0 P  0 0 I  0 O L  C o  0 I 0  \
C o  C L  0 O L  0 O 0  U C  U I  0 O D  0 0 O  U I  o C  0 0 0  o C  \
1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  C o  0 0 O \
 0 O O  U I  0 0 O  0 0 0  0 0 P  U I  o U  0 O D  o U  0 O D  1 C  1 \
C  0 O D  o U  U I  1 0  U I  D L  0 O  U I  U I  U I  0 O D  0 O I  U\
 I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  D L  0 O  U I  \
U I  U I  U I  0 O D  0 O I  U I  U C  U P  L O  o P  P D  L C  P C  L\
 I  L O  L I  o C  L L  L C  U P  P 0  U C  U I  0 O D  0 0 O  U I  o \
U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  D L  0 O  U I  U I  U\
 I  U I  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1  \
U I  0 0 0  0 0 0  1 L  1 L  0 0 0  U I  P 0  U I  o U  0 O D  o U  0 \
O D  1 C  1 C  0 O D  o U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  \
0 0 P  U I  1 O  U I  U C  U P  L O  o P  P D  L C  P C  L I  L O  L I\
  o C  L L  L C  U P  P 0  U C  U I  1 0  0 O  U I  U I  U I  U I  U I\
  0 0 I  0 0 1  0 O D  0 0 O  0 0 P  U I  U C  0 0 I  0 0 1  0 0 0  0 \
I O  0 I 0  U C  U I  1 1  U I  0 0 0  0 0 0  1 L  1 L  0 0 0  0 O  U \
I  U I  U I  U I  U I  0 O D  0 O I  U I  1 C  D 0  U I  1 D  U I  1 C\
  D 0  D L  U I  o U  0 O D  1 C  o U  U I  1 o  U I  0 0 0  0 0 0  o \
C  0 0 0  o C  1 L  0 0 0  U I  1 o  U I  0 0 0  0 0 0  o C  0 0 0  o \
C  1 L  0 0 0  U I  1 U  U I  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  1 L \
 1 L  0 O  U I  U I  U I  U I  U I  o U  0 O D  1 C  0 O D  U I  P 0  \
U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  U I  U I  U I  U I  0 0 0  0 \
0 0  0 0 0  0 0 0  o C  0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  o C\
  0 0 0  U I  P 0  U I  o L  0 0 0  0 0 O  0 O 0  0 O  U I  U I  U I  \
U I  U I  0 O D  0 O I  U I  0 O L  0 O 0  0 0 O  U I  1 O  U I  0 0 0\
  0 0 0  1 L  1 L  0 0 0  U I  1 0  U I  P I  U I  1 L  U I  C o  0 0 \
O  0 O O  U I  U C  P 1  U C  U I  0 O D  0 0 O  U I  0 0 0  0 0 0  1 \
L  1 L  0 0 0  U I  D L  0 O  U I  U I  U I  U I  U I  U I  0 0 0  0 0\
 0  1 L  1 L  0 0 0  U I  P 0  U I  0 0 0  0 0 0  1 L  1 L  0 0 0  U I\
  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C  D L\
  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  o U  0 O D  1 C  0\
 O D  U I  P 0  U I  0 0 0  0 0 0  1 L  1 L  0 0 0  U I  C 0  U I  1 L\
  U I  C U  0 O  U I  U I  U I  U I  U I  U I  0 0 0  0 0 0  0 0 0  0 \
0 0  o C  0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  o C  0 0 0  U I  \
P 0  U I  0 0 0  0 0 0  1 L  1 L  0 0 0  U I  C 0  U I  1 C  U I  C U \
 U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  U I  U C \
 P 1  U C  U I  1 0  U I  C 0  U I  1 L  U I  C U  0 O  U I  U I  U I \
 U I  U I  U I  0 0 0  0 0 0  0 0 0  1 L  1 L  o C  1 L  o C  o C  0 0\
 0  U I  P 0  U I  0 0 0  0 0 0  1 L  1 L  0 0 0  U I  C 0  U I  1 C  \
U I  C U  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 O  \
U I  U C  P 1  U C  U I  1 0  U I  C 0  U I  1 C  U I  C U  0 O  U I  \
U I  U I  U I  U I  U I  o U  0 O D  o U  1 C  o U  0 O D  0 O D  1 C \
 o U  o U  o U  o U  1 C  o U  0 O D  0 O D  U I  P 0  U I  0 0 0  0 0\
 0  1 L  1 L  0 0 0  U I  C 0  U I  D O  U I  C U  0 O  U I  U I  U I \
 U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U I  U I  U\
 I  U I  U I  0 0 0  0 0 0  0 0 0  1 L  1 L  o C  1 L  o C  o C  0 0 0\
  U I  1 1  U I  o U  0 O D  o U  1 C  o U  0 O D  0 O D  1 C  o U  o \
U  o U  o U  1 C  o U  0 O D  0 O D  U I  P 0  U I  0 0 0  0 0 0  1 L \
 1 L  0 0 0  U I  1 P  U I  0 0 D  0 0 I  0 O L  0 O D  0 0 P  U I  1 \
O  U I  U C  D L  U C  U I  1 0  0 O  U I  U I  U I  U I  U I  U I  0 \
O D  0 O I  U I  D o  D I  U I  1 D  U I  D o  D I  D L  U I  o U  o U\
  o U  o U  U I  1 P  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U \
I  U o  U I  0 0 0  1 L  1 L  o C  1 L  0 0 0  0 0 0  U I  U o  U I  0\
 O D  o U  o U  1 C  1 C  1 C  0 O D  U I  1 D  U I  0 O D  0 O D  o U\
  1 C  0 O D  o U  0 O D  o U  U I  1 o  U I  0 0 0  0 0 0  o C  0 0 0\
  o C  1 L  o C  1 L  1 L  0 O  U I  U I  U I  U I  U I  o C  1 L  1 L\
  0 0 0  o C  0 0 0  0 0 0  1 L  o C  0 0 0  o C  1 L  U I  1 O  U I  \
o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1  U I  o C  0 0 \
0  0 0 0  o C  1 L  U I  1 1  U I  0 O D  1 C  0 O D  0 O D  0 O D  0 \
O D  o U  1 C  1 C  0 O D  0 O D  U I  1 1  U I  0 0 0  0 0 0  0 0 0  \
1 L  1 L  o C  1 L  o C  o C  0 0 0  U I  1 1  U I  o U  0 O D  o U  1\
 C  o U  0 O D  0 O D  1 C  o U  o U  o U  o U  1 C  o U  0 O D  0 O D\
  U I  1 1  U I  o U  0 O D  1 C  0 O D  U I  1 1  U I  0 0 0  0 0 0  \
0 0 0  0 0 0  o C  0 0 0  o C  0 0 0  0 0 0  0 0 0  1 L  1 L  o C  0 0\
 0  U I  1 0  0 O  U I  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I\
  D L  0 O  U I  U I  U I  U I  U I  0 O D  o U  0 O D  1 C  o U  0 O \
D  1 C  1 C  1 C  1 C  0 O D  U I  1 O  U I  o U  0 O D  o U  0 O D  1\
 C  1 C  0 O D  o U  U I  1 1  U I  o C  0 0 0  0 0 0  o C  1 L  U I  \
1 1  U I  0 O D  1 C  0 O D  0 O D  0 O D  0 O D  o U  1 C  1 C  0 O D\
  0 O D  U I  1 1  U I  o C  o C  1 L  1 L  U I  1 1  U I  o C  0 0 0 \
 o C  1 L  o C  1 L  1 L  o C  1 L  0 0 0  0 0 0  1 L  o C  U I  1 0  \
0 O  U I  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O  U I  U \
I  U I  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O \
0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O D  0\
 0 O  U I  1 O  U I  U 1  L L  P P  o o  P o  1 P  o L  0 0 0  0 0 P  \
0 O D  0 O I  0 O D  C C  C o  0 0 P  0 O D  0 0 0  0 0 O  1 O  L 1  0\
 O 0  C o  0 O C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  1 1  o O  C \
o  0 O D  0 O L  0 O 0  0 O O  U I  0 0 P  0 0 0  U I  0 O 0  0 I O  0\
 0 P  0 0 1  C o  C C  0 0 P  U I  0 0 1  0 O 0  0 O U  0 O 0  0 I O  \
1 P  U I  1 D  U I  U 1  U I  1 U  U I  U 1  0 0 P  0 O 1  0 O D  0 0 \
D  U 1  U I  1 U  U I  U 1  1 1  D I  1 L  1 L  1 L  1 1  U 1  U I  1 \
U  U I  0 0 0  o C  0 0 0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U \
I  1 U  U I  U 1  1 0  U 1  U I  1 0  0 O  0 O 0  0 O L  0 O D  0 O I \
 U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0  U I  1 C  D P\
  U I  D L  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o \
U  o U  U I  1 O  U I  U 1  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 \
O 0  0 O O  0 O L  U 1  U I  1 0  0 O  U I  0 0 P  0 0 1  0 I 0  U I  \
D L  0 O  U I  U I  0 O D  0 O C  0 0 I  0 0 0  0 0 1  0 0 P  U I  0 I\
 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0  0 O O  0 O L  0 O  U I  0 \
O 0  0 I O  C C  0 O 0  0 0 I  0 0 P  U I  P C  0 I O  C C  0 O 0  0 0\
 I  0 0 P  0 O D  0 0 0  0 0 O  U I  D L  0 O  U I  U I  0 I O  C L  0\
 O C  C C  U I  1 P  U I  0 O 0  0 I O  0 O 0  C C  0 0 o  0 0 P  0 O \
0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O D  0 0 O  U I  1 O  U I  U 1  \
L L  P P  o o  P o  1 P  o L  0 0 0  0 0 P  0 O D  0 O I  0 O D  C C  \
C o  0 0 P  0 O D  0 0 0  0 0 O  1 O  L 1  0 O 0  C o  0 O C  L U  0 0\
 I  0 0 0  0 0 1  0 0 P  0 0 D  1 1  L O  0 O L  0 O 0  C o  0 0 D  0 \
O 0  U I  C 0  P o  o C  o P  o C  L I  U I  0 I 0  0 O 0  0 O L  0 O \
L  0 0 0  0 0 C  C U  0 O D  0 0 O  0 0 D  0 0 P  C o  0 O L  0 O L  U\
 I  L C  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0  1 D  0 O O  0 O L  C \
0  1 o  P o  o C  o P  o C  L I  C U  U I  0 O C  0 0 0  0 O O  0 0 o \
 0 O L  0 O 0  U I  1 1  1 C  1 L  1 L  1 L  1 L  1 1  U 1  U I  U 1  \
1 0  U 1  U I  1 0  0 O  U I  0 0 0  1 L  U I  P 0  U I  0 I 0  0 0 0 \
 0 0 o  0 0 P  0 0 o  C L  0 O 0  0 O O  0 O L  U I  1 P  U I  0 0 D  \
0 O D  0 0 O  0 O U  0 O L  0 O 0  C D  L C  P L  U I  1 O  U I  o U  \
0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 0  0 O  U I  0 O D  o \
U  0 O D  1 C  o U  0 O D  1 C  1 C  1 C  1 C  0 O D  U I  1 O  U I  0\
 0 0  1 L  U I  1 1  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  \
0 O D  1 C  0 O D  0 O D  0 O D  0 O D  o U  1 C  1 C  0 O D  0 O D  U\
 I  1 0  0 O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 \
0  1 L  1 L  U I  P 0  P 0  U I  1 C  D o  U I  D L  0 O  U I  o U  o \
U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  o\
 0  0 O 0  0 0 O  0 O 0  0 0 D  0 O D  0 0 D  C C  0 0 0  0 O C  0 O C\
  0 0 0  0 0 O  0 0 1  0 O 0  0 0 D  0 0 0  0 O L  0 0 L  0 O 0  0 0 1\
  0 0 D  U 1  U I  1 0  0 O  U I  0 O D  o U  0 O D  1 C  o U  0 O D  \
1 C  1 C  1 C  1 C  0 O D  U I  1 O  U I  o C  0 0 0  1 L  o C  1 L  o\
 C  o C  1 L  o C  0 0 0  o C  1 L  U I  1 O  U I  o U  0 O D  o U  0 \
O D  1 C  1 C  0 O D  o U  U I  1 0  U I  1 1  U I  o C  0 0 0  0 0 0 \
 o C  1 L  U I  1 1  U I  0 O D  1 C  0 O D  0 O D  0 O D  0 O D  o U \
 1 C  1 C  0 O D  0 O D  U I  1 1  U I  L 1  0 0 1  0 0 o  0 O 0  U I \
 1 0  0 O  U I  0 O D  0 O I  U I  D D  D 0  U I  1 D  U I  D D  D 0  \
D L  U I  o U  o U  0 O D  o U  0 O D  o U  o U  1 C  1 C  0 O D  U I \
 1 I  U I  0 O D  1 C  U I  1 P  U I  o U  1 C  1 C  0 O D  0 O  0 O 0\
  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P\
 0  P 0  U I  D O  1 C  U I  D L  0 O  U I  o U  o U  o U  1 C  0 O D \
 0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  0 O O  0 0 0  0 0 C \
 0 0 O  0 O L  0 0 0  C o  0 O O  U I  C C  0 0 o  0 0 1  0 0 1  0 O 0\
  0 0 O  0 0 P  U I  0 O I  0 O D  0 O L  0 O 0  U I  0 0 o  0 0 D  0 \
O D  0 0 O  0 O U  U I  0 I 0  0 0 0  0 0 o  0 0 P  0 0 o  C L  0 O 0 \
 1 D  0 O O  0 O L  U I  0 0 D  0 O 0  0 0 1  0 0 L  0 O D  C C  0 O 0\
  U 1  U I  1 0  0 O  U I  o C  o C  1 L  1 L  o C  0 0 0  o C  o C  U\
 I  P 0  U I  U C  0 0 L  0 O D  0 O O  0 O 0  0 0 0  U C  0 O  U I  0\
 O D  0 O I  U I  U C  C 0  0 O C  0 0 I  D 0  C U  U C  U I  0 O D  0\
 0 O  U I  o C  0 0 0  0 0 0  o C  1 L  U I  D L  0 O  U I  U I  o C  \
o C  1 L  1 L  o C  0 0 0  o C  o C  U I  P 0  U I  U C  C o  0 0 o  0\
 O O  0 O D  0 0 0  U C  0 O  U I  U I  o C  0 0 0  0 0 0  o C  1 L  U\
 I  P 0  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 P  U I  0 0 1  0 O 0\
  0 0 I  0 O L  C o  C C  0 O 0  U I  1 O  U I  U C  C 0  0 O C  0 0 I\
  D 0  C U  U C  U I  1 1  U I  U C  U C  U I  1 0  0 O  U I  0 O D  o\
 U  0 O D  0 O D  0 O D  o U  o U  0 O D  0 O D  0 O D  U I  1 O  U I \
 U C  U C  U I  1 1  U I  o C  0 0 0  0 0 0  o C  1 L  U I  1 1  U I  \
o C  o C  1 L  1 L  o C  0 0 0  o C  o C  U I  1 0  0 O  0 O 0  0 O L \
 0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0 \
 U I  D O  D 0  U I  D L  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D  \
1 C  0 O D  o U  o U  U I  1 O  U I  U 1  0 O U  0 O 0  0 0 P  U I  0 \
O D  0 0 O  0 O I  0 0 0  U I  0 0 P  0 O 1  0 O 0  0 0 O  U I  0 O O \
 0 0 0  0 0 C  0 0 O  0 O L  0 0 0  C o  0 O O  U 1  U I  1 0  0 O  U \
I  o C  o C  1 L  1 L  o C  0 0 0  o C  o C  U I  P 0  U I  U C  0 0 L\
  0 O D  0 O O  0 O 0  0 0 0  U C  0 O  U I  0 O D  0 O I  U I  U C  C\
 0  0 O C  0 0 I  D 0  C U  U C  U I  0 O D  0 0 O  U I  o C  0 0 0  0\
 0 0  o C  1 L  U I  D L  0 O  U I  U I  o C  o C  1 L  1 L  o C  0 0 \
0  o C  o C  U I  P 0  U I  U C  C o  0 0 o  0 O O  0 O D  0 0 0  U C \
 0 O  U I  U I  o C  0 0 0  0 0 0  o C  1 L  U I  P 0  U I  o C  0 0 0\
  0 0 0  o C  1 L  U I  1 P  U I  0 0 1  0 O 0  0 0 I  0 O L  C o  C C\
  0 O 0  U I  1 O  U I  U C  C 0  0 O C  0 0 I  D 0  C U  U C  U I  1 \
1  U I  U C  U C  U I  1 0  0 O  U I  0 O D  o U  0 O D  0 O D  0 O D \
 o U  o U  0 O D  0 O D  0 O D  U I  1 O  U I  o U  0 O D  o U  0 O D \
 1 C  1 C  0 O D  o U  U I  1 1  U I  o C  0 0 0  0 0 0  o C  1 L  U I\
  1 1  U I  o C  o C  1 L  1 L  o C  0 0 0  o C  o C  U I  1 0  0 O  0\
 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U \
I  P 0  P 0  U I  D O  D I  U I  D L  0 O  U I  o U  o U  o U  1 C  0 \
O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  P D  0 0 o  0 O \
O  0 O D  0 0 0  U I  0 0 0  0 0 O  0 O L  0 I 0  U I  0 I 0  0 0 0  0\
 0 o  0 0 P  0 0 o  C L  0 O 0  U I  0 O O  0 0 0  0 0 C  0 0 O  0 O L\
  0 0 0  C o  0 O O  U 1  U I  1 0  0 O  U I  0 O D  o U  0 O D  0 O D\
  0 O D  o U  o U  0 O D  0 O D  0 O D  U I  1 O  U I  o U  0 O D  o U\
  0 O D  1 C  1 C  0 O D  o U  U I  1 1  U I  o C  0 0 0  0 0 0  o C  \
1 L  U I  1 1  U I  U C  C o  0 0 o  0 O O  0 O D  0 0 0  U C  U I  1 \
0  0 O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L\
  1 L  U I  P 0  P 0  U I  D O  D U  U I  D L  0 O  U I  o U  o U  o U\
  1 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L U  0 \
O 0  C o  0 0 1  C C  0 O 1  0 O D  0 0 O  U I  o C  0 0 P  0 O 1  0 O\
 0  0 0 1  U I  0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  0 0 D  U 1  \
U I  1 0  0 O  U I  o C  o C  o C  1 L  1 L  1 L  o C  0 0 0  U I  1 O\
  U I  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 1  U I  o \
C  0 0 0  0 0 0  o C  1 L  U I  1 0  0 O  U I  0 I O  C L  0 O C  C C \
 0 0 I  0 O L  0 0 o  0 O U  0 O D  0 0 O  U I  1 P  U I  0 O 0  0 0 O\
  0 O O  o C  0 O I  P L  0 O D  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 \
1  0 I 0  U I  1 O  U I  0 O D  0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 \
I 0  0 0 D  U I  1 P  U I  C o  0 0 1  0 O U  0 0 L  U I  C 0  U I  1 \
C  U I  C U  U I  1 0  U I  1 0  0 O  0 O 0  0 O L  0 O D  0 O I  U I \
 0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U I  P 0  P 0  U I  D U  D U  U I\
  D L  0 O  U I  o U  o U  o U  1 C  0 O D  0 O D  1 C  0 O D  o U  o \
U  U I  1 O  U I  U 1  0 O 0  0 0 O  C o  C L  0 O L  0 O 0  0 O O  U \
I  0 O L  0 0 0  C C  0 O o  U 1  U I  1 0  0 O  U I  0 O D  0 O D  0 \
O D  1 C  U I  P 0  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1\
 C  1 C  0 O D  1 C  o U  U I  1 P  U I  0 O U  0 O 0  0 0 P  L U  0 O\
 0  0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 0 I  C o \
 0 0 1  0 O 0  0 0 O  0 0 P  C o  0 O L  C L  0 O L  0 0 0  C C  0 O o\
  0 O 0  0 O O  0 0 I  0 O D  0 0 O  U C  U I  1 0  0 O  U I  o C  1 L\
  o C  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  0 0 0  U I  P 0  U I  0 I O\
  C L  0 O C  C C  U I  1 P  U I  o D  0 O 0  0 I 0  C L  0 0 0  C o  \
0 0 1  0 O O  U I  1 O  U I  U C  U C  U I  1 1  U I  U C  P C  0 0 O \
 0 0 P  0 O 0  0 0 1  U I  L O  0 O D  0 0 O  U C  U I  1 0  0 O  U I \
 o C  1 L  o C  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  0 0 0  U I  1 P  U\
 I  0 O O  0 0 0  o o  0 0 0  0 O O  C o  0 O L  U I  1 O  U I  1 0  0\
 O  U I  0 O D  0 O I  U I  0 0 O  0 0 0  0 0 P  U I  1 O  U I  o C  1\
 L  o C  1 L  o C  0 0 0  0 0 0  0 0 0  1 L  0 0 0  U I  1 P  U I  0 O\
 D  0 0 D  P o  0 0 0  0 0 O  0 O I  0 O D  0 0 1  0 O C  0 O 0  0 O O\
  U I  1 O  U I  1 0  U I  P 0  P 0  U I  o O  C o  0 O L  0 0 D  0 O \
0  U I  1 0  U I  D L  0 O  U I  U I  0 0 0  o C  o C  0 0 0  0 0 0  1\
 L  1 L  o C  1 L  1 L  0 0 0  U I  P 0  U I  o C  1 L  o C  1 L  o C \
 0 0 0  0 0 0  0 0 0  1 L  0 0 0  U I  1 P  U I  0 O U  0 O 0  0 0 P  \
L 1  0 O 0  0 I O  0 0 P  U I  1 O  U I  1 0  0 O  U I  U I  0 O D  0 \
O I  U I  0 0 0  o C  o C  0 0 0  0 0 0  1 L  1 L  o C  1 L  1 L  0 0 \
0  U I  P 0  P 0  U I  0 O D  0 O D  0 O D  1 C  U I  D L  0 O  U I  U\
 I  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  1 C  0 O D  \
1 C  o U  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L U  0 O 0  0 0 P  0 0 P\
  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 0 I  C o  0 0 1  0 O 0  0\
 0 O  0 0 P  C o  0 O L  C L  0 O L  0 0 0  C C  0 O o  0 O 0  0 O O  \
U C  U I  1 1  U I  U 1  0 O I  C o  0 O L  0 0 D  0 O 0  U 1  U I  1 \
0  0 O  U I  U I  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0\
 I O  0 O 0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P\
  0 O D  0 0 O  U I  1 O  U I  U 1  L L  P P  o o  P o  1 P  o L  0 0 \
0  0 0 P  0 O D  0 O I  0 O D  C C  C o  0 0 P  0 O D  0 0 0  0 0 O  1\
 O  L 1  0 O 0  C o  0 O C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  1 \
1  L O  C o  0 0 1  0 O 0  0 0 O  0 0 P  C o  0 O L  U I  P P  0 O L  \
0 0 0  C C  0 O o  U I  P L  0 O D  0 0 D  C o  C L  0 O L  0 O 0  0 O\
 O  1 1  D U  1 L  1 L  1 L  1 1  U 1  U I  1 U  U I  0 0 0  o C  0 0 \
0  o C  0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U I  1 U  U I  U 1  1 0  U\
 1  U I  1 0  0 O  U I  U I  0 O 0  0 O L  0 0 D  0 O 0  U I  D L  0 O\
  U I  U I  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I O  \
0 O 0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0 O \
D  0 0 O  U I  1 O  U I  U 1  L L  P P  o o  P o  1 P  o L  0 0 0  0 0\
 P  0 O D  0 O I  0 O D  C C  C o  0 0 P  0 O D  0 0 0  0 0 O  1 O  L \
1  0 O 0  C o  0 O C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  1 1  L o\
  0 0 1  0 0 0  0 0 O  0 O U  U I  L O  0 O D  0 0 O  P U  P U  1 1  D\
 U  1 L  1 L  1 L  1 1  U 1  U I  1 U  U I  0 0 0  o C  0 0 0  o C  0 \
0 0  1 L  1 L  0 0 0  o C  0 0 0  U I  1 U  U I  U 1  1 0  U 1  U I  1\
 0  0 O  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U  0 O \
D  0 0 O  U I  1 P  U I  0 O 0  0 0 O  0 O O  o C  0 O I  P L  0 O D  \
0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  U I  1 O  U I  0 O D  0\
 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o  0\
 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U I  C U  U I  1 0  U I  1 0  \
0 O  0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1\
 L  U I  P 0  P 0  U I  D U  D 1  U I  D L  0 O  U I  o U  o U  o U  1\
 C  0 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  0 O O  0 O\
 D  0 0 D  C o  C L  0 O L  0 O 0  U I  0 O L  0 0 0  C C  0 O o  U 1 \
 U I  1 0  0 O  U I  o C  1 L  o U  1 C  1 C  0 O D  1 C  0 O D  1 C  \
1 C  0 O D  1 C  o U  U I  1 P  U I  0 0 D  0 O 0  0 0 P  L U  0 O 0  \
0 0 P  0 0 P  0 O D  0 0 O  0 O U  U I  1 O  U I  U C  0 0 I  C o  0 0\
 1  0 O 0  0 0 O  0 0 P  C o  0 O L  C L  0 O L  0 0 0  C C  0 O o  0 \
O 0  0 O O  U C  U I  1 1  U I  U 1  0 0 P  0 0 1  0 0 o  0 O 0  U 1  \
U I  1 0  0 O  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 I \
O  0 O 0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P  0\
 O D  0 0 O  U I  1 O  U I  U 1  L L  P P  o o  P o  1 P  o L  0 0 0  \
0 0 P  0 O D  0 O I  0 O D  C C  C o  0 0 P  0 O D  0 0 0  0 0 O  1 O \
 L 1  0 O 0  C o  0 O C  L U  0 0 I  0 0 0  0 0 1  0 0 P  0 0 D  1 1  \
L O  C o  0 0 1  0 O 0  0 0 O  0 0 P  C o  0 O L  U I  C L  0 O L  0 0\
 0  C C  0 O o  U I  0 O 0  0 0 O  C o  C L  0 O L  0 O 0  0 O O  1 1 \
 D U  1 L  1 L  1 L  1 1  U 1  U I  1 U  U I  0 0 0  o C  0 0 0  o C  \
0 0 0  1 L  1 L  0 0 0  o C  0 0 0  U I  1 U  U I  U 1  1 0  U 1  U I \
 1 0  0 O  U I  0 I O  C L  0 O C  C C  0 0 I  0 O L  0 0 o  0 O U  0 \
O D  0 0 O  U I  1 P  U I  0 O 0  0 0 O  0 O O  o C  0 O I  P L  0 O D\
  0 0 1  0 O 0  C C  0 0 P  0 0 0  0 0 1  0 I 0  U I  1 O  U I  0 O D \
 0 0 O  0 0 P  U I  1 O  U I  0 0 D  0 I 0  0 0 D  U I  1 P  U I  C o \
 0 0 1  0 O U  0 0 L  U I  C 0  U I  1 C  U I  C U  U I  1 0  U I  1 0\
  0 O  U I  0 O D  0 O I  U I  D I  D U  U I  1 D  U I  D I  D U  D L \
 U I  o U  0 O D  1 C  o U  U I  1 I  U I  o U  1 C  1 C  0 O D  0 O  \
0 O 0  0 O L  0 O D  0 O I  U I  0 0 0  0 0 0  o C  0 0 0  1 L  1 L  U\
 I  P 0  P 0  U I  D U  D 0  U I  D L  0 O  U I  o U  o U  o U  1 C  0\
 O D  0 O D  1 C  0 O D  o U  o U  U I  1 O  U I  U 1  L I  0 O 0  0 0\
 U  0 0 o  0 O 0  0 0 D  0 0 P  0 O D  0 0 O  0 O U  U I  o 1  L U  o \
C  o L  1 D  L I  L O  P o  U I  o U  0 0 P  0 O 0  0 O C  0 0 D  U 1 \
 U I  1 0  0 O  U I  0 O D  0 O D  o U  o U  1 C  0 O D  U I  1 O  U I\
  o U  0 O D  o U  0 O D  1 C  1 C  0 O D  o U  U I  1 0  0 O  U I  0 \
O D  0 O I  U I  D O  D U  U I  1 D  U I  D O  D U  D L  U I  0 0 0  0\
 0 0  o C  0 0 0  o C  1 L  0 0 0  U I  1 U  U I  0 0 0  o C  1 L  0 0\
 0  U I  U o  U I  0 0 0  1 L  0 0 0  o C  1 L  U I  1 o  U I  o U  0 \
O D  o U  o U  U I  1 I  U I  o U  0 O D  o U  o U  0 O  0 O D  0 O I \
 U I  0 0 O  0 0 0  0 0 P  U I  0 0 0  0 0 0  1 L  1 L  1 L  U I  P 0 \
 P 0  U I  o L  0 0 0  0 0 O  0 O 0  U I  D L  0 O  U I  0 0 I  0 0 1 \
 0 O D  0 0 O  0 0 P  U I  U C  0 0 D  0 O 0  0 0 P  0 0 P  0 O D  0 0\
 O  0 O U  U I  0 0 L  0 O D  0 O 0  0 0 C  U I  0 O C  0 0 0  0 O O  \
0 O 0  U C  0 O  U I  0 I O  C L  0 O C  C C  U I  1 P  U I  0 O 0  0 \
I O  0 O 0  C C  0 0 o  0 0 P  0 O 0  C L  0 0 o  0 O D  0 O L  0 0 P \
 0 O D  0 0 O  U I  1 O  U I  U 1  P o  0 0 0  0 0 O  0 0 P  C o  0 O \
D  0 0 O  0 O 0  0 0 1  1 P  L U  0 O 0  0 0 P  L P  0 O D  0 O 0  0 0\
 C  o o  0 0 0  0 O O  0 O 0  1 O  U o  0 0 D  1 0  U 1  U I  U o  U I\
  0 0 0  0 0 0  1 L  1 L  1 L  U I  1 0  0 O  U D  U I  0 O O  0 O O  \
D 1  D D  D P  0 O I  C o  C o  0 O 0  D o  C o  C C  1 C  D 1  D D  C\
 L  C C  D P  D 0  C o  C L  0 O I  D D  D P  0 O 0  D U  C C  C L  D \
O  0 O I  D 0  0 O I  1 L  D 1  D P  D P  0 O O  D 0  C o  D 0  0 O"
.split("  ")])))
